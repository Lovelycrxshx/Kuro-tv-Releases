package app.lovelycrxshx.kuro;
import android.content.Context;
import com.google.android.gms.cast.CastMediaControlIntent;
import com.google.android.gms.cast.framework.CastOptions;
import com.google.android.gms.cast.framework.OptionsProvider;
import com.google.android.gms.cast.framework.SessionProvider;
import java.util.List;
/** The standard Cast receiver needs no user-created developer app or ID. */
public final class KuroCastOptions561 implements OptionsProvider {
    @Override public CastOptions getCastOptions(Context context){return new CastOptions.Builder().setReceiverApplicationId(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID).setResumeSavedSession(false).setEnableReconnectionService(false).build();}
    @Override public List<SessionProvider> getAdditionalSessionProviders(Context context){return null;}
}

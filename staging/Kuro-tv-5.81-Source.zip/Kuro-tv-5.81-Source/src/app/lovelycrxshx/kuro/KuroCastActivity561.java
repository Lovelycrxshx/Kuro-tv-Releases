package app.lovelycrxshx.kuro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;
import androidx.mediarouter.app.MediaRouteButton;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.framework.CastButtonFactory;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;

/**
 * Kuro 5.82 — Cast handoff.
 *
 * What changed against the 5.61 screen:
 *  - the panel is built with the app's own palette (see KuroDialogs581) instead of two
 *    hardcoded colours, so Cast stops looking like a different application;
 *  - a real MediaSession mirrors the TV's playback state, which is what gives hardware
 *    volume/media keys, the phone lock screen and Google TV's "Now playing" something to
 *    talk to;
 *  - the controller shows the TV's actual position and lets you scrub it, instead of
 *    offering three buttons and hoping;
 *  - leaving hands the position back to the caller, so the phone can resume where the TV
 *    stopped instead of silently restarting from the old spot.
 *
 * The receiver still only gets the direct stream URL — never cookies, headers or tokens
 * from the phone — and the caller keeps the consent prompt that says so.
 */
public final class KuroCastActivity561 extends FragmentActivity {

    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_POSITION = "position";
    /** Returned to the caller: where the TV actually was when the screen closed. */
    public static final String EXTRA_CAST_POSITION = "castPosition";
    /** Returned to the caller: true when the TV was stopped on the way out. */
    public static final String EXTRA_CAST_STOPPED = "castStopped";
    /** Returned to the caller: true when a device was connected during this screen. */
    public static final String EXTRA_CAST_ACTIVE = "castActive";

    private static final String CHANNEL = "kuro_cast_582";
    private static final int NOTIFICATION_ID = 5820;

    // Palette shared with the rest of the app.
    private static final int INK = KuroDialogs581.INK, MUTED = KuroDialogs581.MUTED,
            PURPLE = KuroDialogs581.PURPLE, CARD = KuroDialogs581.CARD,
            BORDER = KuroDialogs581.BORDER, PANEL = KuroDialogs581.PANEL,
            SELECTED = KuroDialogs581.SELECTED;

    private SessionManager sessions;
    private CastSession activeSession;
    private RemoteMediaClient client;
    private MediaSession mediaSession;
    private NotificationManager notifications;
    private final Handler ticker = new Handler(Looper.getMainLooper());

    private String address, title;
    private long startPosition, durationMs;
    private boolean sent, scrubbing, destroyed;

    private TextView stateLabel, positionLabel, deviceLabel, hintLabel;
    private SeekBar timeline;
    private LinearLayout controls;
    private TextView playPause;
    private boolean keepPlayingOnExit = true;

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Intent intent = getIntent();
        address = intent.getStringExtra(EXTRA_URL);
        title = intent.getStringExtra(EXTRA_TITLE);
        startPosition = Math.max(0, Math.min(KuroPlayback561.MAX_POSITION_MS, intent.getLongExtra(EXTRA_POSITION, 0)));
        // Same stream gate as the 5.61 screen: only the direct HLS handoff is castable.
        if (!KuroPlayback561.allowedHls(address, "zenkai", "hls")) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }
        if (title == null || title.trim().isEmpty()) title = "Kuro.tv";
        if (title.length() > 160) title = title.substring(0, 160);
        notifications = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        buildPanel();
        startCasting();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ticker.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ticker.removeCallbacks(tick);
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        ticker.removeCallbacks(tick);
        if (sessions != null) {
            try {
                sessions.removeSessionManagerListener(listener, CastSession.class);
            } catch (RuntimeException ignored) {
            }
        }
        detachClient();
        if (mediaSession != null) {
            try {
                mediaSession.setActive(false);
                mediaSession.release();
            } catch (RuntimeException ignored) {
            }
            mediaSession = null;
        }
        if (notifications != null) {
            try {
                notifications.cancel(NOTIFICATION_ID);
            } catch (RuntimeException ignored) {
            }
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ panel

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private GradientDrawable shape(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    private TextView button(String text, boolean primary) {
        TextView view = label(text, 14, primary ? 0xff140b1a : INK, true);
        view.setGravity(Gravity.CENTER);
        view.setMinHeight(dp(48));
        view.setPadding(dp(16), dp(10), dp(16), dp(10));
        view.setFocusable(true);
        view.setClickable(true);
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_focused},
                shape(primary ? 0xffc088f4 : SELECTED, 0xffc088f4, 12));
        states.addState(new int[]{android.R.attr.state_pressed},
                shape(primary ? 0xffc088f4 : SELECTED, 0xffc088f4, 12));
        states.addState(new int[]{}, shape(primary ? PURPLE : CARD, primary ? PURPLE : BORDER, 12));
        view.setBackground(states);
        return view;
    }

    private void buildPanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(PANEL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(shape(CARD, BORDER, 20));
        card.setPadding(dp(20), dp(18), dp(20), dp(18));

        View accent = new View(this);
        GradientDrawable accentShape = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{PURPLE, 0x00a65be4});
        accentShape.setCornerRadius(dp(2));
        accent.setBackground(accentShape);
        LinearLayout.LayoutParams accentParams = new LinearLayout.LayoutParams(dp(56), dp(3));
        accentParams.bottomMargin = dp(12);
        card.addView(accent, accentParams);

        TextView heading = label("Cast to your TV", 20, INK, true);
        card.addView(heading);

        deviceLabel = label("No device connected", 12, MUTED, false);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = dp(4);
        card.addView(deviceLabel, dlp);

        TextView nowPlaying = label(title, 14, INK, false);
        nowPlaying.setMaxLines(2);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        nlp.topMargin = dp(14);
        card.addView(nowPlaying, nlp);

        stateLabel = label("Choose the Cast icon and pick a device on the same network.", 12, MUTED, false);
        stateLabel.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.topMargin = dp(8);
        card.addView(stateLabel, slp);

        timeline = new SeekBar(this);
        timeline.setMax(1000);
        timeline.setProgress(0);
        timeline.setProgressTintList(android.content.res.ColorStateList.valueOf(PURPLE));
        timeline.setThumbTintList(android.content.res.ColorStateList.valueOf(PURPLE));
        timeline.setContentDescription("Playback position on the TV");
        timeline.setPadding(0, dp(12), 0, 0);
        timeline.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (fromUser && durationMs > 0) {
                    positionLabel.setText(format(durationMs * value / 1000) + " / " + format(durationMs));
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { scrubbing = true; }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                scrubbing = false;
                if (durationMs > 0 && client != null) {
                    long target = durationMs * bar.getProgress() / 1000;
                    try { client.seek(target); } catch (RuntimeException ignored) { }
                }
            }
        });
        card.addView(timeline, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        positionLabel = label("0:00", 12, MUTED, false);
        card.addView(positionLabel);

        MediaRouteButton routeButton = new MediaRouteButton(this);
        routeButton.setContentDescription("Choose a Cast device");
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(dp(72), dp(72));
        rlp.topMargin = dp(10);
        card.addView(routeButton, rlp);

        controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.topMargin = dp(10);
        card.addView(controls, clp);

        playPause = button("Play", true);
        playPause.setOnClickListener(v -> {
            RemoteMediaClient c = client();
            if (c == null) { Toast.makeText(this, "Connect a Cast device first.", Toast.LENGTH_SHORT).show(); return; }
            try {
                if (c.isPlaying()) c.pause(); else c.play();
            } catch (RuntimeException ignored) { }
            ticker.postDelayed(tick, 250);
        });
        TextView stop = button("Stop", false);
        stop.setOnClickListener(v -> {
            RemoteMediaClient c = client();
            if (c == null) { Toast.makeText(this, "Connect a Cast device first.", Toast.LENGTH_SHORT).show(); return; }
            try { c.stop(); } catch (RuntimeException ignored) { }
            stateLabel.setText("Stopped on the TV. Play to start it again.");
            ticker.postDelayed(tick, 250);
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        controls.addView(playPause, blp);
        LinearLayout.LayoutParams slp2 = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        slp2.setMarginStart(dp(8));
        controls.addView(stop, slp2);

        hintLabel = label("The TV fetches this stream itself, so it needs to reach the provider "
                + "directly. Streams that require phone cookies, headers or a verification check "
                + "cannot play on a TV.", 11, MUTED, false);
        hintLabel.setLineSpacing(dp(3), 1f);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = dp(12);
        card.addView(hintLabel, hlp);

        LinearLayout exitRow = new LinearLayout(this);
        exitRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.topMargin = dp(16);
        card.addView(exitRow, elp);

        TextView keep = button("Keep playing on TV", false);
        keep.setOnClickListener(v -> finishWith(false));
        TextView takeBack = button("Resume here", true);
        takeBack.setOnClickListener(v -> finishWith(true));
        LinearLayout.LayoutParams klp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tlp.setMarginStart(dp(8));
        exitRow.addView(keep, klp);
        exitRow.addView(takeBack, tlp);

        root.addView(card, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
        try {
            CastButtonFactory.setUpMediaRouteButton(getApplicationContext(), routeButton);
        } catch (RuntimeException | LinkageError ignored) {
            stateLabel.setText("The Cast button is unavailable. Google Play services are required.");
        }
        keep.requestFocus();
    }

    private String format(long ms) {
        if (ms < 0) ms = 0;
        long total = ms / 1000;
        long hours = total / 3600, minutes = (total % 3600) / 60, seconds = total % 60;
        return hours > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
                : String.format(java.util.Locale.US, "%d:%02d", minutes, seconds);
    }

    // ------------------------------------------------------------------ casting

    private void startCasting() {
        try {
            CastContext context = CastContext.getSharedInstance(this);
            sessions = context.getSessionManager();
            sessions.addSessionManagerListener(listener, CastSession.class);
            CastSession existing = sessions.getCurrentCastSession();
            if (existing != null && existing.isConnected()) {
                activeSession = existing;
                send(existing);
            }
        } catch (RuntimeException | LinkageError e) {
            stateLabel.setText("Cast is unavailable. Google Play services and a Cast device on the "
                    + "same network are required.");
        }
    }

    private final SessionManagerListener<CastSession> listener = new SessionManagerListener<CastSession>() {
        @Override public void onSessionStarted(CastSession session, String id) { attach(session); }
        @Override public void onSessionResumed(CastSession session, boolean suspended) { attach(session); }
        @Override public void onSessionEnded(CastSession session, int error) {
            sent = false;
            detachClient();
            activeSession = null;
            stateLabel.setText("The TV disconnected. Pick a device to connect again.");
            updateChrome();
        }
        @Override public void onSessionStartFailed(CastSession session, int error) {
            stateLabel.setText("Could not connect to that Cast device.");
        }
        @Override public void onSessionResumeFailed(CastSession session, int error) {
            stateLabel.setText("Could not resume the Cast session.");
        }
        @Override public void onSessionSuspended(CastSession session, int reason) {
            stateLabel.setText("The Cast connection paused. It will resume when the network returns.");
        }
        @Override public void onSessionStarting(CastSession session) {
            stateLabel.setText("Connecting…");
        }
        @Override public void onSessionEnding(CastSession session) {
            stateLabel.setText("Disconnecting…");
        }
        @Override public void onSessionResuming(CastSession session, String id) {
            stateLabel.setText("Reconnecting…");
        }
    };

    private void attach(CastSession session) {
        activeSession = session;
        if (session != null && session.isConnected()) send(session);
    }

    private RemoteMediaClient client() {
        if (client != null) return client;
        try {
            CastSession session = sessions == null ? null : sessions.getCurrentCastSession();
            client = session != null && session.isConnected() ? session.getRemoteMediaClient() : null;
        } catch (RuntimeException e) {
            client = null;
        }
        return client;
    }

    private void detachClient() {
        RemoteMediaClient c = client;
        client = null;
        if (c != null) {
            try { c.unregisterCallback(remoteCallback); } catch (RuntimeException ignored) { }
        }
    }

    private void send(CastSession session) {
        if (session == null || !session.isConnected()) return;
        RemoteMediaClient remote;
        try {
            remote = session.getRemoteMediaClient();
        } catch (RuntimeException e) {
            remote = null;
        }
        if (remote == null) {
            stateLabel.setText("The Cast device is not ready yet.");
            return;
        }
        if (sent) return;
        sent = true;
        client = remote;
        try {
            remote.registerCallback(remoteCallback);
        } catch (RuntimeException ignored) {
        }
        com.google.android.gms.cast.MediaMetadata metadata =
                new com.google.android.gms.cast.MediaMetadata(com.google.android.gms.cast.MediaMetadata.MEDIA_TYPE_MOVIE);
        metadata.putString(com.google.android.gms.cast.MediaMetadata.KEY_TITLE, title);
        MediaInfo media = new MediaInfo.Builder(address)
                .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType("application/x-mpegURL")
                .setMetadata(metadata)
                .build();
        stateLabel.setText("Sending to the TV…");
        try {
            remote.load(new MediaLoadRequestData.Builder()
                    .setMediaInfo(media)
                    .setAutoplay(true)
                    .setCurrentTime(startPosition)
                    .build())
                    .setResultCallback(result -> {
                        if (result.getStatus().isSuccess()) {
                            setResult(RESULT_OK);
                            stateLabel.setText("Playing on the TV.");
                        } else {
                            sent = false;
                            stateLabel.setText("The TV could not load this source. It may need headers, "
                                    + "cookies or a verification check, which Kuro never forwards.");
                        }
                        updateChrome();
                    });
        } catch (RuntimeException e) {
            sent = false;
            stateLabel.setText("The Cast device could not load this stream.");
        }
    }

    private final RemoteMediaClient.Callback remoteCallback = new RemoteMediaClient.Callback() {
        @Override public void onStatusUpdated() {
            refreshFromStatus();
            updateChrome();
        }
        @Override public void onMetadataUpdated() {
            updateChrome();
        }
        @Override public void onSendingRemoteMediaRequest() {
            stateLabel.setText("Sending to the TV…");
        }
    };

    private void refreshFromStatus() {
        RemoteMediaClient c = client();
        if (c == null) return;
        try {
            MediaStatus status = c.getMediaStatus();
            if (status == null) return;
            long duration = status.getMediaInfo() == null ? 0
                    : status.getMediaInfo().getStreamDuration();
            if (duration > 0) durationMs = duration;
        } catch (RuntimeException ignored) {
        }
    }

    private String describeState() {
        RemoteMediaClient c = client();
        if (c == null) return "No device connected";
        try {
            MediaStatus status = c.getMediaStatus();
            if (status == null) return sent ? "Waiting for the TV" : "Ready";
            switch (status.getPlayerState()) {
                case MediaStatus.PLAYER_STATE_PLAYING: return "Playing on TV";
                case MediaStatus.PLAYER_STATE_PAUSED: return "Paused on TV";
                case MediaStatus.PLAYER_STATE_BUFFERING: return "Buffering on TV";
                case MediaStatus.PLAYER_STATE_IDLE:
                    return status.getIdleReason() == MediaStatus.IDLE_REASON_FINISHED
                            ? "Finished on TV" : "Stopped on TV";
                default: return "Connected";
            }
        } catch (RuntimeException e) {
            return "Connected";
        }
    }

    private long currentPosition() {
        RemoteMediaClient c = client();
        if (c == null) return startPosition;
        try {
            long position = c.getApproximateStreamPosition();
            return position > 0 ? position : startPosition;
        } catch (RuntimeException e) {
            return startPosition;
        }
    }

    private void updateChrome() {
        if (destroyed) return;
        if (deviceLabel != null) {
            String device = null;
            try {
                if (activeSession != null && activeSession.isConnected()) {
                    device = activeSession.getCastDevice() == null ? null
                            : activeSession.getCastDevice().getFriendlyName();
                }
            } catch (RuntimeException ignored) {
            }
            deviceLabel.setText(device == null ? "No device connected" : "Casting to " + device);
        }
        if (playPause != null) {
            RemoteMediaClient c = client();
            boolean playing = false;
            try { playing = c != null && c.isPlaying(); } catch (RuntimeException ignored) { }
            playPause.setText(playing ? "Pause" : "Play");
        }
        if (stateLabel != null && (sent || client() != null)) stateLabel.setText(describeState());
        updateNotification();
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (destroyed) return;
            long position = currentPosition();
            if (positionLabel != null) {
                positionLabel.setText(durationMs > 0
                        ? format(position) + " / " + format(durationMs)
                        : format(position));
            }
            if (timeline != null && !scrubbing) {
                if (durationMs > 0) {
                    timeline.setProgress((int) Math.max(0, Math.min(1000, position * 1000 / durationMs)));
                } else {
                    timeline.setProgress(0);
                }
            }
            updateMediaSessionState(position);
            ticker.postDelayed(this, 1000);
        }
    };

    // ------------------------------------------------------------------ system media session

    private void ensureMediaSession() {
        if (mediaSession != null) return;
        try {
            mediaSession = new MediaSession(this, "KuroCast");
            mediaSession.setCallback(new MediaSession.Callback() {
                @Override public void onPlay() { RemoteMediaClient c = client(); if (c != null) try { c.play(); } catch (RuntimeException ignored) { } }
                @Override public void onPause() { RemoteMediaClient c = client(); if (c != null) try { c.pause(); } catch (RuntimeException ignored) { } }
                @Override public void onStop() { RemoteMediaClient c = client(); if (c != null) try { c.stop(); } catch (RuntimeException ignored) { } }
                @Override public void onSeekTo(long position) { RemoteMediaClient c = client(); if (c != null) try { c.seek(position); } catch (RuntimeException ignored) { } }
            });
            android.media.MediaMetadata metadata = new android.media.MediaMetadata.Builder()
                    .putString(android.media.MediaMetadata.METADATA_KEY_TITLE, title)
                    .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, "Kuro.tv · Casting")
                    .build();
            mediaSession.setMetadata(metadata);
            mediaSession.setSessionActivity(PendingIntent.getActivity(this, 0,
                    new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE));
            mediaSession.setActive(true);
        } catch (RuntimeException e) {
            mediaSession = null;
        }
    }

    private void updateMediaSessionState(long position) {
        ensureMediaSession();
        if (mediaSession == null) return;
        int state = PlaybackState.STATE_PAUSED;
        RemoteMediaClient c = client();
        try {
            if (c == null) state = PlaybackState.STATE_NONE;
            else if (c.isPlaying()) state = PlaybackState.STATE_PLAYING;
            else {
                MediaStatus status = c.getMediaStatus();
                if (status != null && status.getPlayerState() == MediaStatus.PLAYER_STATE_BUFFERING) {
                    state = PlaybackState.STATE_BUFFERING;
                }
            }
        } catch (RuntimeException ignored) {
        }
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_STOP
                | PlaybackState.ACTION_SEEK_TO;
        try {
            mediaSession.setPlaybackState(new PlaybackState.Builder()
                    .setActions(actions)
                    .setState(state, position, 1f)
                    .build());
        } catch (RuntimeException ignored) {
        }
    }

    private void updateNotification() {
        if (notifications == null || mediaSession == null) return;
        try {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Kuro casting",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Controls for a video playing on a Cast device.");
            notifications.createNotificationChannel(channel);
            PendingIntent open = PendingIntent.getActivity(this, 0,
                    new Intent(this, KuroCastActivity561.class), PendingIntent.FLAG_IMMUTABLE);
            int icon = getApplicationInfo().icon;
            if (icon == 0) return;
            Notification.Builder builder = new Notification.Builder(this, CHANNEL)
                    .setSmallIcon(icon)
                    .setContentTitle(title)
                    .setContentText(describeState() + " · " + format(currentPosition()))
                    .setContentIntent(open)
                    .setOngoing(client() != null)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setStyle(new Notification.MediaStyle()
                            .setMediaSession(mediaSession.getSessionToken())
                            .setShowActionsInCompactView());
            notifications.notify(NOTIFICATION_ID, builder.build());
        } catch (RuntimeException ignored) {
        }
    }

    // ------------------------------------------------------------------ exit

    private void finishWith(boolean resumeHere) {
        keepPlayingOnExit = !resumeHere;
        long position = currentPosition();
        boolean stopped = false;
        if (resumeHere) {
            RemoteMediaClient c = client();
            if (c != null) {
                try { c.stop(); stopped = true; } catch (RuntimeException ignored) { }
            }
        } else {
            // Leaving with the TV playing: park the phone where the TV is so the next
            // local resume does not jump backwards.
        }
        Intent result = new Intent();
        result.putExtra(EXTRA_CAST_POSITION, position);
        result.putExtra(EXTRA_CAST_STOPPED, stopped);
        result.putExtra(EXTRA_CAST_ACTIVE, client() != null && !stopped);
        setResult(RESULT_OK, result);
        finish();
    }

    /** Back keeps the TV playing (the safe default); "Resume here" is the explicit choice. */
    @Override
    public void onBackPressed() {
        finishWith(false);
    }
}

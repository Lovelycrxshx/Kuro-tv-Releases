package app.lovelycrxshx.kuro;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.IBinder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * Downloads the announced Kuro APK in the app over Wi-Fi or mobile data.
 *
 * There is no prompt, no browser hand-off and no "remind me later" button. The file is
 * checksummed when the release publishes one, then package, version and signing
 * identity are re-checked before the single "ready to install" notice. Android's
 * installer still decides whether the update is installed.
 */
public final class KuroUpdaterDownloadService extends Service {
    private volatile boolean running;
    private long lastProgressPost;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (running) return START_NOT_STICKY;
        running = true;
        KuroUpdater572.ensureChannel(this);
        try {
            startForeground(KuroUpdater572.PROGRESS_ID, progress(-1, "Preparing the update"));
        } catch (RuntimeException e) {
            running = false;
            stopSelf();
            return START_NOT_STICKY;
        }
        Thread worker = new Thread(this::work, "kuro-update-download");
        worker.setDaemon(true);
        worker.start();
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    private static final class WaitForWifi extends IOException {}

    private void work() {
        SharedPreferences p = KuroUpdater572.prefs(this);
        File part = null;
        try {
            String version = p.getString("version", "");
            String address = p.getString("assetUrl", "");
            long expectedSize = p.getLong("assetSize", -1);
            String digest = p.getString("assetDigest", "");
            File target = KuroUpdater572.apkFile(this, version);
            if (target == null || address.isEmpty()) throw new IOException("No update is queued.");
            android.net.Network wifi=KuroUpdater572.wifiOnly(this)?KuroUpdater572.activeWifi(this):null;
            if(KuroUpdater572.wifiOnly(this)&&wifi==null)throw new WaitForWifi();
            p.edit().putString("stage", "downloading").putLong("lastDownloadAt", System.currentTimeMillis()).apply();
            part = new File(target.getPath() + ".part");
            String actual = download(address, part, expectedSize, wifi);
            if (!digest.isEmpty() && !digest.equalsIgnoreCase(actual))
                throw new IOException("The downloaded file did not match the published checksum.");
            if (target.exists() && !target.delete()) throw new IOException("Could not replace the previous update file.");
            if (!part.renameTo(target)) throw new IOException("Could not finish saving the update file.");
            part = null;
            KuroApkPreflight572.Result check = KuroApkPreflight572.inspect(this, target);
            if (!check.ok()) {
                target.delete();
                throw new IOException(check.message());
            }
            KuroUpdater572.markReady(this, version);
            KuroUpdater572.notifyReady(this, false);
        } catch (Exception e) {
            if (part != null && part.isFile()) part.delete();
            if(e instanceof WaitForWifi||(KuroUpdater572.wifiOnly(this)&&KuroUpdater572.activeWifi(this)==null))KuroUpdater572.waitForWifi(this);
            else KuroUpdater572.markDownloadFailed(this, e.getMessage());
        } finally {
            running = false;
            try {
                stopForeground(STOP_FOREGROUND_REMOVE);
            } catch (RuntimeException ignored) {}
            stopSelf();
        }
    }

    private String download(String address, File part, long expectedSize, android.net.Network wifi) throws Exception {
        String current = address;
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        for (int hop = 0; hop <= 3; hop++) {
            if (!KuroUpdater572.safeHttps(current)) throw new IOException("Unsupported update address");
            checkWifi(wifi);
            HttpURLConnection c = (HttpURLConnection) (wifi==null?new URL(current).openConnection():wifi.openConnection(new URL(current)));
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("Accept", "application/octet-stream");
            c.setRequestProperty("User-Agent", "Kuro.tv-Android-5.73");
            try {
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String location = c.getHeaderField("Location");
                    if (location == null) throw new IOException("Update redirect unavailable");
                    current = new URL(new URL(current), location).toString();
                    continue;
                }
                if (code != 200) throw new IOException("Update download returned HTTP " + code);
                long total = expectedSize > 0 ? expectedSize : c.getContentLengthLong();
                if (total > KuroUpdater572.MAX_APK_BYTES) throw new IOException("The update file is larger than expected.");
                long written = 0;
                lastProgressPost = 0;
                try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(part)) {
                    byte[] buffer = new byte[65536];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        if (!running) throw new IOException("The download was stopped.");
                        checkWifi(wifi);
                        written += read;
                        if (written > KuroUpdater572.MAX_APK_BYTES) throw new IOException("The update file is larger than expected.");
                        out.write(buffer, 0, read);
                        md.update(buffer, 0, read);
                        long now = System.currentTimeMillis();
                        if (now - lastProgressPost > 1000) {
                            lastProgressPost = now;
                            int percent = total > 0 ? (int) (written * 100L / total) : -1;
                            notifyProgress(percent, written, total);
                        }
                    }
                    out.flush();
                }
                if (written <= 0) throw new IOException("The update download was empty.");
                return hex(md.digest());
            } finally {
                c.disconnect();
            }
        }
        throw new IOException("Too many update redirects");
    }

    private void checkWifi(android.net.Network pinned) throws WaitForWifi {
        if(!KuroUpdater572.wifiOnly(this))return;
        android.net.Network current=KuroUpdater572.activeWifi(this);
        if(pinned==null||current==null||!pinned.equals(current))throw new WaitForWifi();
    }

    private static String hex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b & 255));
        return out.toString();
    }

    private void notifyProgress(int percent, long written, long total) {
        try {
            String text;
            if (total > 0) text = (written / 1048576L) + " of " + Math.max(1, total / 1048576L) + " MiB";
            else text = (written / 1048576L) + " MiB";
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (manager != null) manager.notify(KuroUpdater572.PROGRESS_ID, progress(percent, text));
        } catch (RuntimeException ignored) {}
    }

    private Notification progress(int percent, String text) {
        Notification.Builder builder = new Notification.Builder(this, KuroUpdater572.CHANNEL)
                .setSmallIcon(getApplicationInfo().icon)
                .setColor(Color.rgb(174, 103, 230))
                .setContentTitle("Kuro update")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false);
        if (percent < 0) builder.setProgress(0, 0, true);
        else builder.setProgress(100, Math.max(0, Math.min(100, percent)), false);
        return builder.build();
    }
}

package app.lovelycrxshx.kuro;

import static org.junit.Assert.*;
import android.content.Intent;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import org.robolectric.android.controller.ActivityController;

/** Guard only; this does not connect to a Cast device. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk=28)
public class KuroCast561Test {
    @Test public void unknownCastUrlFinishesBeforeAnyReceiverIsUsed(){
        Intent i=new Intent(RuntimeEnvironment.getApplication(),KuroCastActivity561.class);
        i.putExtra("url","https://example.org/stream.m3u8");
        ActivityController<KuroCastActivity561> c=Robolectric.buildActivity(KuroCastActivity561.class,i).create();
        assertTrue(c.get().isFinishing());c.destroy();
    }
}

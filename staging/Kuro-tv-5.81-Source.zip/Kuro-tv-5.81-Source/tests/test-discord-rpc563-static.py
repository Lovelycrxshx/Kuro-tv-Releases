#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as E
root=Path(__file__).resolve().parent.parent
read=lambda f:(root/f).read_text()
main=read('src/app/lovelycrxshx/kuro/MainActivity.java')
rpc=read('src/app/lovelycrxshx/kuro/KuroDiscordRpc563.java')
oauth=read('src/app/lovelycrxshx/kuro/KuroDiscordOAuth564.java')
vault=read('src/app/lovelycrxshx/kuro/KuroDiscordVault564.java')
prefs=read('src/app/lovelycrxshx/kuro/KuroDiscordPreferences564.java')
model=read('src/app/lovelycrxshx/kuro/KuroPresence563.java')+read('src/app/lovelycrxshx/kuro/KuroPresence564.java')
native=read('native/kuro_discord_rpc563.cpp');ui=read('assets/settings560.js')
assert 'getBoolean("enabled",false)' in main and 'kuro-discord-rpc563' in main
assert 'discordEnabledChanged563(enabled)' in main and 'discordRpc563.stop()' in main
assert 'postDelayed(discordStop563,12000)' in main and 'isInPictureInPictureMode()' in main and 'main.postDelayed(this,3000)' in main
assert 'nativePlayer561.presenceState563()' in main and 'Cross-origin embeds cannot reliably report state' in main
assert 'attempt!=playerAttempt' in main and '!session.equals(watchSession)' in main
assert '1569077670074122250L' in rpc and 'DiscordSocialSdkInit.setEngineActivity(activity)' in rpc
assert all(x in native for x in ('UpdateRichPresence','ClearRichPresence','RunCallbacks','std::mutex','owner','linkGeneration','directGeneration','ActivityTypes::Watching','SetName("Kuro.tv")'))
assert 'SetOnlineStatus' not in native and 'SetStatus(' not in native
assert all(x in native for x in ('pendingRefresh','nativeAckRefresh','nativeRefreshing','nativeQuiesce','GetToken','RefreshToken'))
assert 'whenLinkSettled' in rpc and 'finishStop' in rpc and 'persistPending()' in rpc and 'if(closed)thread.quitSafely()' in rpc
assert 'MIN_SEND_MS=3000' in model and 'REFRESH_MS=3000' in model and 'retry567.ready' in rpc
assert all(x in model for x in ('u.getRawQuery()!=null','u.getRawUserInfo()!=null','u.getRawFragment()!=null','unsafePublicText'))
assert 'NO_PRESENCE_LINK,NO_PRESENCE_LINK' in rpc and '.AddButton(' not in native and 'ActivityButton' not in native
assert 'lang,image,"","",server' in main and 'isNeutralPoster566(poster)' in native
assert all(x in oauth for x in ('code_challenge_method','S256','MessageDigest.isEqual','getQueryParameters','MAX_AGE','getEncodedAuthority','getFragment','getData()','intent.setData(null)'))
assert all(x in vault for x in ('AndroidKeyStore','AES/GCM/NoPadding','setRandomizedEncryptionRequired(true)','updateAAD','commit()'))
for key in ('layout','separator','title','episode','poster','server','total','current','linked','pause','buffering','notification'):
 assert 'CHOICES.put("'+key+'"' in prefs and "['"+key+"'" in ui,key
assert 'CHOICES.put("download"' in prefs and "['download'" not in ui
assert 'CHOICES.put("watch"' in prefs and "['watch'" not in ui
assert 'SetLabel("Download")' not in native
for action in ('rpcHistory564','rpcTest564','rpcClear564','rpcReconnectCurrent564','rpcReconnectLinked564','rpcLink564','rpcUnlink564'):
 assert action in ui,action
assert 'DISCORD-SOCIAL-SDK-NOTICES.txt' in main and "action('licenses'" in ui
ns='{http://schemas.android.com/apk/res/android}'; tools='{http://schemas.android.com/tools}'
manifest=E.parse(root/'AndroidManifest.xml').getroot(); remove={x.get(ns+'name') for x in manifest.findall('uses-permission') if x.get(tools+'node')=='remove'}
assert {'android.permission.RECORD_AUDIO','android.permission.BLUETOOTH_CONNECT','android.permission.FOREGROUND_SERVICE_MICROPHONE'} <= remove
app=manifest.find('application');assert app.get(ns+'allowBackup')=='false'
assert app.find("receiver[@"+ns+"name='.KuroPresenceNotification564$Receiver']").get(ns+'exported')=='false'
assert any(d.get(ns+'scheme')=='discord-1569077670074122250' for d in app.findall('.//data'))
print('PASS static opt-in/lifecycle, dual targets, privacy, PKCE, token rotation, notification and voice-permission exclusions')

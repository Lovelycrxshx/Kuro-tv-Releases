/* Kuro player-only cosmetic ad guard. No network calls, clicks or native bridge. */
(function () {
  'use strict';
  try {
    if (window.__kuroAdGuard541) return;
    window.__kuroAdGuard541 = true;
    // The bundled local player has no third-party advertising.
    if (location.hostname === 'kuro.local') return;

    const selectors = [
      '[data-ad-slot]', '[data-ad-unit]', '[data-ad-zone]', '[data-ad-zone-id]',
      'ins.adsbygoogle', 'iframe[id^="google_ads_iframe"]',
      '.adsbox', '.ad-popup', '.ads-popup', '.ad-overlay', '.ads-overlay',
      '.advertisement-overlay', '[id^="exoclick-"]', '[class^="exo-native-widget"]'
    ].join(',');
    const verification = '#challenge-form,#challenge-stage,.cf-challenge,.cf-turnstile,.h-captcha,.g-recaptcha';
    const controls = 'video,audio,canvas,[role="slider"],.vjs-control-bar,.jw-controls,.plyr__controls,.video-controls,.player-controls';
    let observer = null, timer = 0;
    const pending = new Set(), retriedBadges = new WeakSet();

    function verificationActive() {
      return /^(just a moment|attention required|verify you are human|access denied)/i.test((document.title || '').trim()) || !!document.querySelector(verification);
    }
    function protectedNode(el) {
      if (!el || el.nodeType !== 1 || /^(HTML|BODY|VIDEO|AUDIO|SOURCE|TRACK|CANVAS)$/.test(el.tagName)) return true;
      if (el.matches(controls) || el.closest(verification) || el.querySelector(verification) || el.querySelector(controls)) return true;
      // Never hide a wrapper containing an unknown embedded player frame.
      if (el.tagName !== 'IFRAME' && el.querySelector('iframe')) return true;
      return false;
    }
    function hide(el) {
      if (protectedNode(el)) return false;
      el.style.setProperty('display', 'none', 'important');
      el.setAttribute('data-kuro-ad-hidden', '1');
      return true;
    }
    function closeCue(el) {
      if (el.querySelector('button[aria-label="Close"],button[title="Close"],[data-close],.close,.ad-close')) return true;
      const children = el.querySelectorAll('button,span,a');
      for (let i = 0; i < Math.min(children.length, 40); i++) {
        if (/^(?:×|✕|✖|x|close)$/i.test((children[i].textContent || '').trim())) return true;
      }
      return false;
    }
    function inspectBadge(badge) {
      const text = (badge.textContent || '').trim();
      if (!/^(?:ad|advertisement|sponsored)$/i.test(text) || protectedNode(badge)) return;
      let el = badge.parentElement;
      for (let depth = 0; el && depth < 5; depth++, el = el.parentElement) {
        if (protectedNode(el)) return;
        const css = getComputedStyle(el), r = el.getBoundingClientRect();
        if (!/^(?:absolute|fixed)$/.test(css.position) || r.width < 90 || r.height < 24 || r.height > Math.max(320, innerHeight * .95)) continue;
        const copy = (el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 1200);
        // The user's example is an Ad-labelled fake chat banner. Also accept an
        // explicit badge plus a close control, but never remove player controls.
        if (/\bmessage\s+from\b/i.test(copy) || closeCue(el)) { hide(el); return; }
      }
      // Some ad scripts attach positioning shortly after adding the label.
      if (!retriedBadges.has(badge)) {
        retriedBadges.add(badge);
        setTimeout(() => { if (badge.isConnected && !verificationActive()) inspectBadge(badge); }, 600);
      }
    }
    function scan(root) {
      if (!root || root.nodeType !== 1) return;
      if (verificationActive()) { if (observer) observer.disconnect(); pending.clear(); return; }
      if (root.matches(selectors)) hide(root);
      const marked = root.querySelectorAll(selectors);
      for (let i = 0; i < Math.min(marked.length, 300); i++) hide(marked[i]);
      // Text badges can be nested under otherwise randomly named ad elements.
      if (/^(SPAN|SMALL|B|STRONG|LABEL|DIV)$/.test(root.tagName)) inspectBadge(root);
      const badges = root.querySelectorAll('span,small,b,strong,label,div');
      for (let i = 0; i < Math.min(badges.length, 1600); i++) {
        const badge = badges[i];
        if (badge.textContent && badge.textContent.length <= 24) inspectBadge(badge);
      }
    }
    function flush() {
      timer = 0;
      const batch = Array.from(pending); pending.clear();
      for (const node of batch) scan(node);
    }
    function enqueue(node) {
      if (!node) return;
      if (node.nodeType === 3) node = node.parentElement;
      if (!node || node.nodeType !== 1) return;
      pending.add(node);
      if (!timer) timer = setTimeout(flush, 100);
    }
    observer = new MutationObserver(records => {
      for (const record of records) {
        if (record.type === 'characterData') enqueue(record.target);
        else for (const node of record.addedNodes) enqueue(node);
      }
    });
    observer.observe(document, {childList:true, subtree:true, characterData:true});
    if (document.documentElement) enqueue(document.documentElement);
    document.addEventListener('DOMContentLoaded', () => enqueue(document.documentElement), {once:true});
  } catch (_) { /* Cosmetic filtering must not interrupt playback. */ }
})();

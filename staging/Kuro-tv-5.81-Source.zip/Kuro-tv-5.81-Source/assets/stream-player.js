'use strict';
(function(){
 const video=document.getElementById('video');let reported=false;
 // Exact position is sent only to Kuro's origin-scoped Android listener.
 const params=new URLSearchParams(location.search),attempt=Number(params.get('attempt')),startMs=Number(params.get('startMs'));
 let lastProgress=0,resumeApplied=false;
 function progress(force,ended){if(!resumeApplied||!Number.isSafeInteger(attempt)||attempt<0||!window.KuroProgress561)return;const now=Date.now();if(!force&&now-lastProgress<5000)return;const position=Math.round(video.currentTime*1000),duration=Number.isFinite(video.duration)?Math.round(video.duration*1000):-1;if(!Number.isFinite(position)||position<0)return;lastProgress=now;try{window.KuroProgress561.postMessage(JSON.stringify({attempt,position,duration,ended:!!ended}));}catch(_){}}
 video.addEventListener('loadedmetadata',()=>{if(resumeApplied)return;resumeApplied=true;if(Number.isFinite(startMs)&&startMs>=5000&&startMs<=86400000&&(!Number.isFinite(video.duration)||startMs<video.duration*1000-1000)){try{video.currentTime=startMs/1000;}catch(_){}}});
 // Only explicit, validated episode ranges are used; never infer an intro from timing.
 let skipConfig={on:false,ranges:[]};
 window.__kuroSetMarkers574=config=>{skipConfig={on:config?.on===true,ranges:Array.isArray(config?.ranges)?config.ranges.filter(r=>Array.isArray(r)&&r.length===2&&r.every(Number.isFinite)&&r[0]>=0&&r[1]>r[0]&&r[1]<=86400&&r[1]-r[0]<=1800):[]}};
 video.addEventListener('timeupdate',()=>{if(!skipConfig.on||video.paused||video.seeking||!Number.isFinite(video.duration))return;for(const r of skipConfig.ranges){if(r[1]<=video.duration&&video.currentTime>=r[0]&&video.currentTime<r[1]){try{video.currentTime=r[1]}catch(_){}break}}});
 video.addEventListener('timeupdate',()=>progress(false,false));video.addEventListener('pause',()=>progress(true,video.ended));video.addEventListener('ended',()=>progress(true,true));window.addEventListener('pagehide',()=>progress(true,video.ended));
 function signal(type){if(reported)return;reported=true;location.href='kuro-player://event?type='+encodeURIComponent(type);}
 let source;try{
  source=new URL(new URLSearchParams(location.search).get('src')||'');const inner=new URL(source.searchParams.get('url')||'');
  if(source.protocol!=='https:'||source.hostname!=='www.zenkaitv.com'||source.pathname!=='/api/source'||source.port||source.username||source.password||source.hash||source.searchParams.getAll('url').length!==1||inner.protocol!=='https:'||inner.hostname!=='player.zilla-networks.com'||inner.port||inner.username||inner.password||inner.hash||!inner.pathname.startsWith('/m3u8/'))throw Error('Invalid stream');
 }catch(_){signal('fatal');return}
 let autoplay=params.get('autoplay')!=='0';window.__kuroSetAutoplay561=on=>{autoplay=!!on;video.autoplay=autoplay};video.muted=false;video.volume=1;video.autoplay=autoplay;video.addEventListener('error',()=>signal('fatal'),{once:true});
 if(window.Hls&&Hls.isSupported()){
  const hls=new Hls({enableWorker:false});hls.on(Hls.Events.ERROR,(_event,data)=>{if(!data.fatal)return;const status=Number(data.response?.code||data.networkDetails?.status||0);signal(status===401||status===403||status===429?'verification':'fatal')});
  hls.on(Hls.Events.MEDIA_ATTACHED,()=>hls.loadSource(source.href));hls.on(Hls.Events.MANIFEST_PARSED,()=>{if(autoplay)video.play().catch(()=>{})});hls.attachMedia(video);
 }else if(video.canPlayType('application/vnd.apple.mpegurl')){video.src=source.href;if(autoplay)video.play().catch(()=>{})}
 else signal('fatal');
})();

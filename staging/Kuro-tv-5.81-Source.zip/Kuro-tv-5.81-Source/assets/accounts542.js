'use strict';
/* Kuro 5.57: ordered four-column library, recovered imports and optional tracker sync. */
(() => {
 const IMPORT_KEY='kuro-imports-v1',PROFILE_KEY='kuro-profile-v1';
 const CARD_ART_KEY='kuro-profile-card-art-v1';
 const CHARACTER_ART=[{"name":"Satoru Gojo","title":"Jujutsu Kaisen","file":"profile-character549-00.jpg","banner":"profile-banner549-00.jpg","group":"anime"},{"name":"Sung Jinwoo","title":"Solo Leveling","file":"profile-character549-01.jpg","banner":"profile-banner549-01.jpg","group":"anime"},{"name":"Cid Kagenou","title":"The Eminence in Shadow","file":"profile-character549-02.jpg","banner":"profile-banner549-02.jpg","group":"anime"},{"name":"Kiyotaka Ayanokoji","title":"Classroom of the Elite","file":"profile-character549-03.jpg","banner":"profile-banner549-03.jpg","group":"anime"},{"name":"Light Yagami","title":"Death Note","file":"profile-character549-04.jpg","banner":"profile-banner549-04.jpg","group":"anime"},{"name":"Issei Hyoudou","title":"High School DxD","file":"profile-character549-05.jpg","banner":"profile-banner549-05.jpg","group":"anime"},{"name":"Alisa Kujou","title":"Alya Sometimes Hides Her Feelings in Russian","file":"profile-character549-06.jpg","banner":"profile-banner549-06.jpg","group":"anime"},{"name":"Denji","title":"Chainsaw Man","file":"profile-character549-07.jpg","banner":"profile-banner549-07.jpg","group":"anime"},{"name":"Loid Forger","title":"Spy x Family","file":"profile-character549-08.jpg","banner":"profile-banner549-08.jpg","group":"anime"},{"name":"Asta","title":"Black Clover","file":"profile-character549-09.jpg","banner":"profile-banner549-09.jpg","group":"anime"},{"name":"Zagan","title":"An Archdemon's Dilemma: How to Love Your Elf Bride","file":"profile-character549-10.jpg","banner":"profile-banner549-10.jpg","group":"anime"},{"name":"Fenrys","title":"Chillin' in Another World with Level 2 Super Cheat Powers","file":"profile-character549-11.jpg","banner":"profile-banner549-11.jpg","group":"anime"},{"name":"Alto Goldfield","title":"Vermeil in Gold","file":"profile-character549-12.jpg","banner":"profile-banner549-12.jpg","group":"anime"},{"name":"Ichigo Kurosaki","title":"Bleach","file":"profile-character549-13.jpg","banner":"profile-banner549-13.jpg","group":"anime"},{"name":"Frieren","title":"Frieren: Beyond Journey's End","file":"profile-character549-14.jpg","banner":"profile-banner549-14.jpg","group":"anime"},{"name":"Kotori Itsuka","title":"Date A Live","file":"profile-character549-15.jpg","banner":"profile-banner549-15.jpg","group":"anime"},{"name":"Marin Kitagawa","title":"My Dress-Up Darling","file":"profile-character549-16.jpg","banner":"profile-banner549-16.jpg","group":"anime"},{"name":"Mash Burnedead","title":"Mashle","file":"profile-character549-17.jpg","banner":"profile-banner549-17.jpg","group":"anime"},{"name":"Son Goku","title":"Dragon Ball","file":"profile-character549-18.jpg","banner":"profile-banner549-18.jpg","group":"anime"},{"name":"Gabimaru","title":"Hell's Paradise","file":"profile-character549-19.jpg","banner":"profile-banner549-19.jpg","group":"anime"},{"name":"Medaka Kuroiwa","title":"Medaka Kuroiwa Is Impervious to My Charms","file":"profile-character549-20.jpg","banner":"profile-banner549-20.jpg","group":"anime"},{"name":"Akame","title":"Akame ga Kill!","file":"profile-character549-21.jpg","banner":"profile-banner549-21.jpg","group":"anime"},{"name":"Sakuta Azusagawa","title":"Rascal Does Not Dream of Bunny Girl Senpai","file":"profile-character549-22.jpg","banner":"profile-banner549-22.jpg","group":"anime"},{"name":"Lilith Asami","title":"Trinity Seven","file":"profile-character549-23.jpg","banner":"profile-banner549-23.jpg","group":"anime"},{"name":"Ainz Ooal Gown","title":"Overlord","file":"profile-character549-24.jpg","banner":"profile-banner549-24.jpg","group":"anime"},{"name":"Anos Voldigoad","title":"The Misfit of Demon King Academy","file":"profile-character549-25.jpg","banner":"profile-banner549-25.jpg","group":"anime"},{"name":"Lloyd de Saloum","title":"I Was Reincarnated as the 7th Prince","file":"profile-character549-26.jpg","banner":"profile-banner549-26.jpg","group":"anime"},{"name":"Fuutarou Uesugi","title":"The Quintessential Quintuplets","file":"profile-character549-27.jpg","banner":"profile-banner549-27.jpg","group":"anime"},{"name":"Anna Yanami","title":"Makeine: Too Many Losing Heroines!","file":"profile-character549-28.jpg","banner":"profile-banner549-28.jpg","group":"anime"},{"name":"Eren Yeager","title":"Attack on Titan","file":"profile-character549-29.jpg","banner":"profile-banner549-29.jpg","group":"anime"},{"name":"Rimuru Tempest","title":"That Time I Got Reincarnated as a Slime","file":"profile-character549-30.jpg","banner":"profile-banner549-30.jpg","group":"anime"},{"name":"Kirito","title":"Sword Art Online","file":"profile-character549-31.jpg","banner":"profile-banner549-31.jpg","group":"anime"},{"name":"Izumi Miyamura","title":"Horimiya","file":"profile-character549-32.jpg","banner":"profile-banner549-32.jpg","group":"anime"},{"name":"Kazuya Kinoshita","title":"Rent-a-Girlfriend","file":"profile-character549-33.jpg","banner":"profile-banner549-33.jpg","group":"anime"},{"name":"Aqua Hoshino","title":"Oshi no Ko","file":"profile-character549-34.jpg","banner":"profile-banner549-34.jpg","group":"anime"},{"name":"Hachiman Hikigaya","title":"Oregairu","file":"profile-character549-35.jpg","banner":"profile-banner549-35.jpg","group":"anime"},{"name":"Vanitas","title":"The Case Study of Vanitas","file":"profile-character549-36.jpg","banner":"profile-banner549-36.jpg","group":"anime"},{"name":"Priestess","title":"Goblin Slayer","file":"profile-character549-37.jpg","banner":"profile-banner549-37.jpg","group":"anime"},{"name":"Yuuichi Katagiri","title":"Tomodachi Game","file":"profile-character549-38.jpg","banner":"profile-banner549-38.jpg","group":"anime"},{"name":"Natsu Dragneel","title":"Fairy Tail","file":"profile-character549-39.jpg","banner":"profile-banner549-39.jpg","group":"anime"},{"name":"Shouya Ishida","title":"A Silent Voice","file":"profile-character549-40.jpg","banner":"profile-banner549-40.jpg","group":"anime"},{"name":"Yuno Gasai","title":"Future Diary","file":"profile-character549-41.jpg","banner":"profile-banner549-41.jpg","group":"anime"},{"name":"Lelouch Lamperouge","title":"Code Geass","file":"profile-character549-42.jpg","banner":"profile-banner549-42.jpg","group":"anime"},{"name":"Raiden Shogun","title":"Genshin Impact","file":"profile-character549-43.jpg","banner":"profile-banner549-43.jpg","group":"game"},{"name":"Kafka","title":"Honkai: Star Rail","file":"profile-character549-44.jpg","banner":"profile-banner549-44.jpg","group":"game"},{"name":"Rover","title":"Wuthering Waves","file":"profile-character549-45.jpg","banner":"profile-banner549-45.jpg","group":"game"},{"name":"Belle","title":"Zenless Zone Zero","file":"profile-character549-46.jpg","banner":"profile-banner549-46.jpg","group":"game"},{"name":"Cadis Etrama Di Raizel","title":"Noblesse","file":"profile-character549-47.jpg","banner":"profile-banner549-47.jpg","group":"anime"},{"name":"Taro Sakamoto","title":"Sakamoto Days","file":"profile-character549-48.jpg","banner":"profile-banner549-48.jpg","group":"anime"},{"name":"Wang Ling","title":"The Daily Life of the Immortal King","file":"profile-character549-49.jpg","banner":"profile-banner549-49.jpg","group":"anime"},{"name":"Nikki","title":"Infinity Nikki","file":"profile-character549-50.jpg","banner":"profile-banner549-50.jpg","group":"game"},{"name":"Alf","title":"Silver Palace","file":"profile-character549-51.jpg","banner":"profile-banner549-51.jpg","group":"game"},{"name":"Nagi Umino & Erika Amano","title":"A Couple of Cuckoos","file":"profile-character549-52.jpg","banner":"profile-banner549-52.jpg","group":"anime"},{"name":"Kyouka Uzen","title":"Chained Soldier","file":"profile-character549-53.jpg","banner":"profile-banner549-53.jpg","group":"anime"},{"name":"Anzu Hanashiro","title":"The Tunnel to Summer, the Exit of Goodbyes","file":"profile-character549-54.jpg","banner":"profile-banner549-54.jpg","group":"anime"},{"name":"Dante","title":"Devil May Cry","file":"profile-character549-55.jpg","banner":"profile-banner549-55.jpg","group":"anime"},{"name":"Takashi Komuro","title":"Highschool of the Dead","file":"profile-character549-56.jpg","banner":"profile-banner549-56.jpg","group":"anime"},{"name":"Ayame Kajou","title":"Shimoneta","file":"profile-character549-57.jpg","banner":"profile-banner549-57.jpg","group":"anime"},{"name":"Rintaro Tsumugi","title":"The Fragrant Flower Blooms with Dignity","file":"profile-character549-58.jpg","banner":"profile-banner549-58.jpg","group":"anime"},{"name":"Rito Yuuki","title":"To Love Ru","file":"profile-character549-59.jpg","banner":"profile-banner549-59.jpg","group":"anime"},{"name":"Adam","title":"Record of Ragnarok","file":"profile-character549-60.jpg","banner":"profile-banner549-60.jpg","group":"anime"},{"name":"Hiraku Machio","title":"Farming Life in Another World","file":"profile-character549-61.jpg","banner":"profile-banner549-61.jpg","group":"anime"},{"name":"Ike","title":"The Strongest Magician in the Demon Lord’s Army Was a Human","file":"profile-character549-62.jpg","banner":"profile-banner549-62.jpg","group":"anime"},{"name":"Natsuo Fujii","title":"Domestic Girlfriend","file":"profile-character549-63.jpg","banner":"profile-banner549-63.jpg","group":"anime"},{"name":"Akuto Sai","title":"Demon King Daimao","file":"profile-character549-64.jpg","banner":"profile-banner549-64.jpg","group":"anime"},{"name":"Rudeus Greyrat","title":"Mushoku Tensei","file":"profile-character549-65.jpg","banner":"profile-banner549-65.jpg","group":"anime"},{"name":"Mori Jin","title":"The God of High School","file":"profile-character549-66.jpg","banner":"profile-banner549-66.jpg","group":"anime"},{"name":"Kenzo Tenma","title":"Monster","file":"profile-character549-67.jpg","banner":"profile-banner549-67.jpg","group":"anime"},{"name":"Satellizer el Bridget","title":"Freezing","file":"profile-character549-68.jpg","banner":"profile-banner549-68.jpg","group":"anime"},{"name":"Saber / Artoria Pendragon","title":"Fate series","file":"profile-character549-69.jpg","banner":"profile-banner549-69.jpg","group":"anime"},{"name":"Ichirou Satou","title":"Why the Hell Are You Here, Teacher!?","file":"profile-character549-70.jpg","banner":"profile-banner549-70.jpg","group":"anime"},{"name":"Basara Toujou","title":"The Testament of Sister New Devil","file":"profile-character549-71.jpg","banner":"profile-banner549-71.jpg","group":"anime"},{"name":"Kiyoshi Fujino","title":"Prison School","file":"profile-character549-72.jpg","banner":"profile-banner549-72.jpg","group":"anime"}];
 const CARD_ART={profile:['profile-banner547.jpg',...CHARACTER_ART.map(x=>x.banner)],anime:['profile-banner547.jpg','profile-card548-anime-a.jpg','profile-card548-anime-b.jpg',...CHARACTER_ART.map(x=>x.banner)],history:['profile-avatar547-b.jpg','profile-card548-history-a.jpg','profile-card548-history-b.jpg',...CHARACTER_ART.map(x=>x.banner)]};
 function readCardArt(){try{let v=JSON.parse(localStorage.getItem(CARD_ART_KEY)||'{}');const ok=(k,x)=>CARD_ART[k].includes(x)||!!window.kuroPresets571?.validBanner(x);return {anime:ok('anime',v.anime)?v.anime:CARD_ART.anime[0],history:ok('history',v.history)?v.history:CARD_ART.history[0]}}catch{return {anime:CARD_ART.anime[0],history:CARD_ART.history[0]}}}
 function showCardArt(){showCharacters('profile')}
 function showCharacters(initial='avatar'){
  if(!window.kuroPresets571){placeholder('The supplied artwork is unavailable.');return}
  const p=draftProfile||readProfile(),cards=readCardArt();
  const o=shell('Customize profile','Choose a category, preview a picture, then apply.',`<div id="profile-presets571"></div>`,true);o.classList.add('artwork-picker571');
  try{window.kuroPresets571.mount(o.querySelector('#profile-presets571'),{
   initial,current:{avatar:p.avatar,profile:p.banner,anime:cards.anime,history:cards.history,
    adjust:{anime:window.kuroPresets571.cardAdjust('anime'),history:window.kuroPresets571.cardAdjust('history')}},
   onCancel:()=>closeModal(),onApply:changed=>{
    const saved=readProfile();if(draftProfile){draftProfile.avatar=saved.avatar;draftProfile.banner=saved.banner}
    closeModal();refreshHeader560();if(view==='profile')profile();if(changed)placeholder('Profile artwork saved on this phone.');
   }
  });o.querySelector('.preset-tabs571 button')?.focus()}catch(_){message('The supplied artwork could not be opened.',true)}
 }

 let draftProfile=null,modalMode='',lastStatus=null,watchAccountMode=false,watchAccountToken=0,modalBusy=false,profileEditing=false;
 const nativeAvailable=()=>!!window.KuroNative&&typeof KuroNative.account==='function';
 const active=()=>!!(lastStatus&&['local','discord','mal','anilist'].some(k=>lastStatus.connections?.[k]?.connected));
 const profileImage=x=>typeof x==='string'&&x.length<1000000&&(/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(x)||(/^profile-avatar547-[a-l]\.jpg$/.test(x)||/^profile-character549-[0-9]{2}\.jpg$/.test(x)||/^profile-banner549-[0-9]{2}\.jpg$/.test(x)||x==='profile-banner547.jpg'||!!window.kuroPresets571?.validAvatar(x)||!!window.kuroPresets571?.validBanner(x)))?x:'';
 function readProfile(){try{let p=JSON.parse(localStorage.getItem(PROFILE_KEY)||'{}');return {name:String(p.name||'').slice(0,60),avatar:profileImage(p.avatar),banner:profileImage(p.banner)}}catch{return {name:'',avatar:'',banner:''}}}
 function readImports(){let raw=localStorage.getItem(IMPORT_KEY);if(!raw)return [];try{let a=JSON.parse(raw);if(!Array.isArray(a))throw Error();return a}catch{throw Error('Your imported list could not be read, so it was not changed.') }}
 // Imports remain separate, non-overwriting snapshots. Viewing never migrates them.
 const IMPORT_RESTRICTED_KEY='kuro-import-restricted-554',IMPORT_SAFE_KEY='kuro-import-classifications-554';
 const IMPORT_STATUS={WATCHING:'watching',CURRENT:'watching',REPEATING:'watching',PLANNED:'planned',PLANNING:'planned',PLAN_TO_WATCH:'planned',COMPLETED:'completed',PAUSED:'on_hold',ON_HOLD:'on_hold',DROPPED:'dropped'};
 const IMPORT_LABEL={watching:'Watching',planned:'Plan to watch',completed:'Completed',on_hold:'On hold',dropped:'Dropped'};
 let importSafeCache=null,importCheckNotice='';const importCheckedSession=new Set();
 function importedState(x){return IMPORT_STATUS[String(x?.status||'').trim().toUpperCase()]||''}
 function validImport(x){return !!x&&['mal','anilist'].includes(x.provider)&&/^[1-9][0-9]{0,18}$/.test(String(x.sourceId))&&typeof x.title==='string'&&!!x.title.trim()}
 function restrictedImportsEnabled(){try{return localStorage.getItem(IMPORT_RESTRICTED_KEY)==='yes'}catch(_){return false}}
 function importSafeKey(x){return x.provider+':'+String(x.sourceId)+':'+matchTitle(x.title)}
 function safeImportCache(){
  if(importSafeCache)return importSafeCache;importSafeCache=new Map();
  try{let rows=JSON.parse(localStorage.getItem(IMPORT_SAFE_KEY)||'[]');if(Array.isArray(rows))for(let r of rows.slice(0,5000)){
   if(r&&['mal','anilist'].includes(r.provider)&&/^[1-9][0-9]{0,8}$/.test(String(r.sourceId))&&typeof r.title==='string'&&r.title.length<=300&&Number.isFinite(r.checked)&&r.checked<=Date.now()&&Date.now()-r.checked<30*86400000){let key=importSafeKey(r);if(!key.endsWith(':'))importSafeCache.set(key,r)}
  }}catch(_){}return importSafeCache;
 }
 function importVisible(x){return KURO_ADULT_ENABLED||restrictedImportsEnabled()||x?.adult===false||(x?.adult!==true&&safeImportCache().has(importSafeKey(x)))}
 function safeImportImage(value){try{let u=new URL(String(value||''));return u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&u.href.length<=1600?u.href:''}catch(_){return ''}}
 function importImageFallback(img){if(!img)return;img.addEventListener('error',()=>{let mark=document.createElement('span');mark.setAttribute('aria-hidden','true');mark.textContent='✦';img.replaceWith(mark)},{once:true})}
 function importProvider(x){return x.provider==='mal'?'MyAnimeList':'AniList'}
 function importStatusLabel(x){return String(x.status||'').toUpperCase()==='REPEATING'?'Rewatching':(IMPORT_LABEL[importedState(x)]||'Unknown')}
 function importProgress(x){let n=Math.max(0,Math.min(100000,Number(x.progress)||0)),total=Math.max(0,Math.min(100000,Number(x.total)||0));return n+(total?' / '+total:'')+' episodes watched'}
 function importText(value){return String(value||'').replace(/<br\s*\/?\s*>/gi,' ').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,4000)}
 function importFact(value){return String(value||'').replace(/_/g,' ').trim().toLowerCase()}
 function openImportedDetails(item){
  if(!validImport(item)||!importVisible(item)){placeholder('This imported title is hidden by your content settings.');return}
  let picture=safeImportImage(item.image),o=shell(item.title,importProvider(item)+' · saved import',`<div class="import-detail554"><div class="import-detail-cover554">${picture?`<img src="${escapeHTML(picture)}" alt="">`:'<span>✦</span>'}</div><div><p><strong>${escapeHTML(importStatusLabel(item))}</strong></p><p>${escapeHTML(importProgress(item))}</p><p>Imported from ${escapeHTML(importProvider(item))}</p></div></div><div id="import-detail-extra554" class="import-detail-extra554" role="status">Loading anime details…</div><button type="button" id="import-detail-search554" class="account-primary">Find in Kuro</button><p class="account-note">Choose the exact title and season in search before playing. Imported data is not changed by opening details.</p>`,true);
  importImageFallback(o.querySelector('.import-detail-cover554 img'));
  o.querySelector('#import-detail-search554').onclick=()=>{closeModal();nav('search');doSearch(item.title);window.scrollTo(0,0)};
  const box=o.querySelector('#import-detail-extra554');
  request('importDetails',{provider:item.provider,sourceId:String(item.sourceId)}).then(r=>{
   if(!o.isConnected)return;
   if(!r||r.provider!==item.provider||String(r.sourceId)!==String(item.sourceId))throw Error('The provider did not confirm this exact anime.');
   if(r.adult===true&&!KURO_ADULT_ENABLED&&!restrictedImportsEnabled()){
    o.querySelector('.import-detail-cover554').innerHTML='<span>✦</span>';box.textContent='The provider marks this title 18+. Enable 18+ imports before viewing its details.';return;
   }
   if(!picture){let image=safeImportImage(r.image);if(image){let img=document.createElement('img');img.alt='';img.src=image;importImageFallback(img);o.querySelector('.import-detail-cover554').replaceChildren(img)}}
   const synopsis=importText(r.synopsis),facts=[];
   if(r.format)facts.push(['Format',importFact(r.format)]);if(r.airing)facts.push(['Airing',importFact(r.airing)]);if(r.date)facts.push(['First aired',String(r.date).slice(0,30)]);
   if(Number(r.episodes)>0)facts.push(['Episodes',String(Math.min(100000,Number(r.episodes)))]);
   if(Array.isArray(r.genres)&&r.genres.length)facts.push(['Genres',r.genres.filter(x=>typeof x==='string').slice(0,10).join(', ')]);
   if(Array.isArray(r.studios)&&r.studios.length)facts.push(['Studios',r.studios.filter(x=>typeof x==='string').slice(0,10).join(', ')]);
   box.innerHTML=(synopsis?`<h3>Synopsis</h3><p>${escapeHTML(synopsis)}</p>`:'<p>No synopsis is available from this provider.</p>')+(facts.length?`<dl>${facts.map(([k,v])=>`<div><dt>${escapeHTML(k)}</dt><dd>${escapeHTML(v)}</dd></div>`).join('')}</dl>`:'');
  }).catch(()=>{if(o.isConnected)box.textContent='More details are unavailable right now. Your saved title, status and progress are unchanged.'});
 }
 function importCardMarkup(x,i,allowRemove){
  const picture=safeImportImage(x.image);
  return `<article class="import-card import-card554"><button type="button" class="import-open554" data-import-detail="${i}" aria-label="Details for ${escapeHTML(x.title)}"><span class="import-cover554">${picture?`<img src="${escapeHTML(picture)}" loading="lazy" alt="">`:'<span aria-hidden="true">✦</span>'}</span><strong>${escapeHTML(x.title)}</strong></button><div class="import-copy"><small>${escapeHTML(importProvider(x))} · ${escapeHTML(importStatusLabel(x))}</small><small>${escapeHTML(importProgress(x))}</small><div class="import-actions"><button type="button" data-import-search="${i}">Find in Kuro</button>${allowRemove?`<button type="button" data-import-remove="${i}">Remove</button>`:''}</div></div></article>`;
 }
 function mountImportedBrowser(parent,all,filter,allowRemove){
  const candidates=all.filter(x=>validImport(x)&&(!filter||importedState(x)===filter)),visible=candidates.filter(importVisible),hidden=candidates.length-visible.length,unclassified=candidates.filter(x=>x.adult!==true&&x.adult!==false&&!importVisible(x)&&/^[1-9][0-9]{0,8}$/.test(String(x.sourceId))),unchecked=unclassified.filter(x=>!importCheckedSession.has(importSafeKey(x)));
  parent.className='import-browser554';
  parent.innerHTML=`<div class="heading"><h2>Imported anime</h2><span class="import-count554">${visible.length} visible</span></div><p class="account-import-note">Saved snapshots · profile totals include hidden entries and count local/imported entries separately.${hidden?' '+hidden+' adult or unclassified title(s) are hidden by Kuro’s content safety rules.':''}${restrictedImportsEnabled()?' 18+ and unclassified imports are visible on this phone.':''}${importCheckNotice?' '+escapeHTML(importCheckNotice):''}</p><div class="import-controls554"><label class="import-search554"><span>Search imported titles</span><input type="search" maxlength="160" autocomplete="off" placeholder="Search your imported anime" aria-label="Search imported anime"></label>${unclassified.length?`<button type="button" class="import-check554">${unchecked.length?'Check unclassified':'Recheck unclassified'}</button>`:''}${hidden||restrictedImportsEnabled()?`<button type="button" class="import-restricted554">${restrictedImportsEnabled()?'Hide 18+ / unclassified':'Show 18+ / unclassified'}</button>`:''}</div>${unclassified.length?'<p class="import-check-hint554" hidden>Optional safety check: sends up to 250 hidden anime IDs to AniList, without your login or watch progress. Titles confirmed non-adult appear here for 30 days.</p>':''}<div class="import-list import-grid554"></div><div class="import-more554"></div>`;
  const field=parent.querySelector('input'),grid=parent.querySelector('.import-list'),more=parent.querySelector('.import-more554'),count=parent.querySelector('.import-count554');let limit=240;
  function draw(){
   let query=field.value.trim().toLocaleLowerCase(),items=visible.filter(x=>!query||(x.title+' '+importProvider(x)+' '+importStatusLabel(x)).toLocaleLowerCase().includes(query)),shown=items.slice(0,limit);
   count.textContent=items.length+' visible'+(query?' match'+(items.length===1?'':'es'):'');
   grid.innerHTML=shown.length?shown.map((x,i)=>importCardMarkup(x,i,allowRemove)).join(''):'<div class="empty import-empty554">'+(query?'No matching imported anime.':hidden?'No titles are visible with the current content setting.':'No imported titles in this list yet.')+'</div>';
   grid.querySelectorAll('.import-cover554 img').forEach(importImageFallback);
   grid.querySelectorAll('[data-import-detail]').forEach(b=>b.onclick=()=>openImportedDetails(shown[Number(b.dataset.importDetail)]));
   grid.querySelectorAll('[data-import-search]').forEach(b=>b.onclick=()=>{let x=shown[Number(b.dataset.importSearch)];if(x){nav('search');doSearch(x.title);window.scrollTo(0,0)}});
   grid.querySelectorAll('[data-import-remove]').forEach(b=>b.onclick=()=>{
    const x=shown[Number(b.dataset.importRemove)];if(!x)return;
    if(!b.dataset.confirm){b.dataset.confirm='yes';b.textContent='Confirm remove';setTimeout(()=>{if(b.isConnected&&b.dataset.confirm){delete b.dataset.confirm;b.textContent='Remove'}},5000);return}
    try{let latest=readImports(),next=latest.filter(row=>!(row.provider===x.provider&&String(row.sourceId)===String(x.sourceId)));localStorage.setItem(IMPORT_KEY,JSON.stringify(next));library()}catch(_){placeholder('Could not update the imported list. Nothing else was changed.')}
   });
   more.innerHTML=items.length>shown.length?`<button type="button" class="import-load554">Show more (${items.length-shown.length} remaining)</button>`:'';
   const button=more.querySelector('button');if(button)button.onclick=()=>{limit+=240;draw()};
  }
  field.oninput=()=>{limit=240;draw()};draw();
  let checkButton=parent.querySelector('.import-check554');if(checkButton)checkButton.onclick=async()=>{
   if(!checkButton.dataset.confirm){checkButton.dataset.confirm='yes';checkButton.textContent='Confirm AniList ID check';let hint=parent.querySelector('.import-check-hint554');if(hint)hint.hidden=false;return}
   checkButton.disabled=true;let scanned=0,verified=0,failure=false;
   const work=(unchecked.length?unchecked:unclassified).slice(0,250).map(x=>({title:x.title,sourceId:String(x.sourceId),provider:x.provider,anilistId:x.provider==='anilist'?Number(x.sourceId):0,malId:x.provider==='mal'?Number(x.sourceId):0}));
   for(let i=0;i<work.length;i+=50){
    let batch=work.slice(i,i+50);checkButton.textContent='Checking '+Math.min(i+batch.length,work.length)+' / '+work.length+'…';
    try{let allowed=await classifyAdded(batch);for(const item of batch)importCheckedSession.add(importSafeKey(item));for(const item of allowed){let rec={provider:item.provider,sourceId:item.sourceId,title:item.title.slice(0,300),checked:Date.now()};safeImportCache().set(importSafeKey(rec),rec);verified++}scanned+=batch.length}catch(_){failure=true;break}
   }
   try{localStorage.setItem(IMPORT_SAFE_KEY,JSON.stringify([...safeImportCache().values()].slice(-5000)))}catch(_){failure=true}
   let remaining=unclassified.filter(x=>!importCheckedSession.has(importSafeKey(x))&&!safeImportCache().has(importSafeKey(x))).length;
   importCheckNotice=`Safety check: ${verified} confirmed non-adult from ${scanned} checked.${failure?' Some checks could not be completed or saved.':''}${remaining?' '+remaining+' remain to check.':''}`;
   if(parent.isConnected)library();
  };
  let adultButton=parent.querySelector('.import-restricted554');if(adultButton)adultButton.onclick=()=>{
   const enabled=restrictedImportsEnabled();
   if(!enabled&&!adultButton.dataset.confirm){adultButton.dataset.confirm='yes';adultButton.textContent='Confirm: I am 18+';return}
   try{localStorage.setItem(IMPORT_RESTRICTED_KEY,enabled?'no':'yes');library()}catch(_){placeholder('Could not save this content setting on your phone.')}
  };
 }
 function message(s,error=false){if(!s)return;const el=document.querySelector('#account-message');if(el){el.textContent=s;el.classList.toggle('error',!!error);el.hidden=false}else placeholder(s)}
 function request(action,data={}){
  return new Promise((resolve,reject)=>{
   if(!nativeAvailable())return reject(Error('Accounts are available in the Kuro Android app.'));
   let id='account-'+(++requestNo);pending[id]={resolve,reject};
   try{KuroNative.account(id,action,JSON.stringify(data))}catch(e){delete pending[id];reject(Error('The account request could not be started.'))}
  }).then(text=>{try{return JSON.parse(text)}catch{throw Error('The account response could not be read.')}});
 }
 window.kuroTrackerRequest553=(action,data)=>['trackerSync','trackerSearch','status'].includes(action)?request(action,data):Promise.reject(Error('Unsupported tracker action.'));
 async function status(){let s=await request('status');lastStatus=s;refreshHeader560();try{window.kuroSyncConnections553?.(s.connections||{})}catch(_){}return s}
 function closeModal(notify=true){if(modalBusy)return;if(notify&&(modalMode==='setup'||modalMode.startsWith('owner-')))cancelAdmin568();window.kuroSettings560?.closeAll?.();document.querySelector('#account-overlay')?.remove();modalMode='';document.documentElement.classList.remove('account-modal-open');if(watchAccountMode&&notify){watchAccountMode=false;document.documentElement.classList.remove('watch-account-active');try{window.KuroNative?.watchAccountClosed?.(watchAccountToken)}catch(_){}}}
 function shell(title,subtitle,body,wide=false,keepAdmin=false){
  if(!keepAdmin&&(modalMode==='setup'||modalMode.startsWith('owner-')))cancelAdmin568();closeModal(false);let o=document.createElement('div');o.id='account-overlay';o.className='account-overlay';o.innerHTML=`<section class="account-dialog ${wide?'account-dialog-wide':''}" role="dialog" aria-modal="true" aria-labelledby="account-dialog-title"><div class="account-dialog-head"><div><div class="account-eyebrow">KURO.TV · YOUR SPACE</div><h2 id="account-dialog-title">${escapeHTML(title)}</h2><p>${escapeHTML(subtitle)}</p></div><button type="button" class="account-x" aria-label="Close">×</button></div><div id="account-message" role="status" hidden></div>${body}</section>`;
  document.body.appendChild(o);document.documentElement.classList.add('account-modal-open');o.onclick=e=>{if(e.target===o)closeModal()};o.querySelector('.account-x').onclick=closeModal;o.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});return o;
 }
 function enableModal(el,enabled){el.querySelectorAll('button,input').forEach(n=>{if(!n.classList.contains('account-x'))n.disabled=!enabled})}
 // Owner setup is intentionally absent from ordinary account menus. The long
 // press only opens verification; the native bridge enforces the actual lock.
 let adminPollTimer568=0,adminExpiryTimer568=0;
 function stopAdminTimers568(){clearTimeout(adminPollTimer568);clearTimeout(adminExpiryTimer568);adminPollTimer568=adminExpiryTimer568=0}
 function cancelAdmin568(){stopAdminTimers568();if(nativeAvailable())request('adminCancel').catch(()=>{})}
 function adminReturn568(){cancelAdmin568();modalMode='';if(active())profileMenu560();else login()}
 function bindAdminGesture568(el){
  if(!el)return;let timer=0,start=null;
  const stop=()=>{clearTimeout(timer);timer=0;start=null};
  el.addEventListener('pointerdown',e=>{
   if(e.isPrimary===false||(e.pointerType==='mouse'&&e.button!==0))return;stop();start={x:e.clientX,y:e.clientY};
   timer=setTimeout(()=>{timer=0;start=null;if(el.isConnected)ownerEntry568()},1600);
  });
  el.addEventListener('pointermove',e=>{if(start&&(Math.abs(e.clientX-start.x)>12||Math.abs(e.clientY-start.y)>12))stop()});
  el.addEventListener('pointerup',stop);el.addEventListener('pointercancel',stop);el.addEventListener('contextmenu',e=>e.preventDefault());
  el.tabIndex=0;el.addEventListener('keydown',e=>{if(e.shiftKey&&e.key==='Enter'){e.preventDefault();ownerEntry568()}});
 }
 function ownerEntry568(){
  stopAdminTimers568();const o=shell('Owner verification','Only the owner can change provider setup.',`
   <p class="account-note">Verify the owner’s GitHub account to open setup for ten minutes. Kuro requests no repository permissions and never asks for your GitHub password or token.</p>
   <button type="button" class="account-primary" id="admin-start568">Verify with GitHub</button>
   <div class="account-foot"><button type="button" id="admin-back568">Back</button></div>`);
  modalMode='owner-entry';o.querySelector('#admin-back568').onclick=adminReturn568;
  o.querySelector('#admin-start568').onclick=async()=>{
   const button=o.querySelector('#admin-start568');button.disabled=true;
   try{
    const r=await request('adminBegin');if(!o.isConnected||modalMode!=='owner-entry')return
    if(!/^[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(r.userCode||'')||r.verificationUrl!=='https://github.com/login/device'){cancelAdmin568();throw Error('GitHub returned an unexpected verification response.')}
    ownerCode568(r);
   }catch(e){if(o.isConnected){button.disabled=false;message(e.message,true)}}
  };
 }
 function ownerCode568(data){
  const o=shell('Verify on GitHub','Copy this one-time code, then approve Kuro.tv Admin.',`
   <p class="account-note">Open the official GitHub page, enter this code and sign in as the owner. Only approve a request you started here. Then return to Kuro.</p>
   <div class="admin-code568" id="admin-code568" aria-label="GitHub verification code">${escapeHTML(data.userCode)}</div>
   <div class="admin-actions568"><button type="button" id="admin-copy568">Copy code</button><button type="button" id="admin-open568">Open GitHub</button></div>
   <p class="admin-hint568" id="admin-hint568" role="status">Waiting for you to open GitHub.</p>
   <button type="button" class="admin-retry568" id="admin-retry568" hidden>Start verification again</button>
   <div class="account-foot"><button type="button" id="admin-cancel568">Cancel</button></div>`,false,true);
  modalMode='owner-wait';const hint=o.querySelector('#admin-hint568'),open=o.querySelector('#admin-open568');let polling=false;
  o.querySelector('#admin-copy568').onclick=async()=>{try{await request('adminCopy');if(o.isConnected)hint.textContent='Code copied. Open GitHub and enter it.'}catch(e){message(e.message,true)}};
  o.querySelector('#admin-cancel568').onclick=adminReturn568;
  o.querySelector('#admin-retry568').onclick=async()=>{stopAdminTimers568();try{await request('adminCancel')}catch(_){}if(o.isConnected)ownerEntry568()};
  const schedule=ms=>{
   clearTimeout(adminPollTimer568);adminPollTimer568=setTimeout(async()=>{
    if(!o.isConnected||modalMode!=='owner-wait')return;
    try{
     let r=await request('adminPoll');if(!o.isConnected||modalMode!=='owner-wait')return
     if(r.state==='verified'){stopAdminTimers568();await setup();return}
     if(r.state!=='waiting')throw Error('GitHub verification returned an unexpected result.');
     if(r.notice)hint.textContent=r.notice;schedule(Math.max(250,Math.min(300000,Number(r.retryMs)||5000)));
    }catch(e){if(!o.isConnected)return;polling=false;open.disabled=true;hint.textContent=e.message;hint.classList.add('error');o.querySelector('#admin-retry568').hidden=false}
   },Math.max(250,Math.min(300000,Number(ms)||5000)));
  };
  open.onclick=async()=>{
   open.disabled=true;
   try{await request('adminOpen');if(!o.isConnected)return;hint.textContent='Enter the code on GitHub, approve, then return to Kuro.';open.textContent='Open GitHub again';open.disabled=false;if(!polling){polling=true;schedule(data.retryMs)}}
   catch(e){if(o.isConnected){open.disabled=false;message(e.message,true)}}
  };
 }
 function login(mode='login'){
  if(mode==='pin'){
   let o=shell('Connect AniList','One extra step keeps AniList’s token off an app redirect.',`<p class="account-note">AniList gives this app broad access to your account, not just your list. Kuro reads your identity and anime list and can update list status and watched episodes if you enable tracker sync. Copy the token shown on the official AniList page and paste it <strong>here on your phone</strong>—never in a chat. It will be encrypted on this device.</p><label class="account-label">ANILIST TOKEN<input id="account-pin" type="password" autocomplete="off" placeholder="Paste the token shown by AniList" maxlength="10000"></label><button type="button" id="account-pin-submit" class="account-primary">Connect AniList</button><div class="account-foot"><button type="button" id="account-back-login">Back to sign in</button></div>`);
   modalMode=mode;o.querySelector('#account-back-login').onclick=()=>login();o.querySelector('#account-pin-submit').onclick=async()=>{let input=o.querySelector('#account-pin'),token=input.value;input.value='';enableModal(o,false);try{let r=await request('anilistPin',{token});closeModal();placeholder(r.message);await status();if(view==='profile')profile()}catch(e){enableModal(o,true);message(e.message,true)}};return;
  }
  const signup=mode==='signup';
  let o=shell(signup?'Create a local account':'Welcome back',signup?'One account on this phone only.':'Sign in to your local account on this phone.',`
   <div class="account-shortcuts569" aria-label="Discord activity shortcuts"><button type="button" data-discord-shortcut569="presence">Discord Rich Presence</button><button type="button" data-discord-shortcut569="customization">Presence customization</button></div>
   <form id="account-form" novalidate>
    <label class="account-label">EMAIL ADDRESS<input id="account-email" type="email" autocomplete="email" inputmode="email" placeholder="name@email.com" maxlength="254"></label>
    <label class="account-label">PASSWORD<input id="account-password" type="password" autocomplete="${signup?'new-password':'current-password'}" placeholder="At least 8 characters" maxlength="1024"></label>
    <div class="account-form-meta"><span>This is a local sign-in, not an online account.</span><button type="button" id="account-show-password" aria-pressed="false">Show password</button></div>
    <p class="account-note">No email or OTP is sent. Your email is not verified. Remember your password: email recovery is unavailable. This sign-in does not lock your profile or lists.</p>
    <button type="submit" class="account-primary">${signup?'Create local account':'Log in'}</button>
   </form>
   <div class="account-divider"><span>or continue with</span></div><div class="account-provider-grid">
    <button type="button" data-signin="discord" aria-label="Continue with Discord"><span class="provider-mark discord-mark"><svg aria-hidden="true" viewBox="0 0 24 24"><path fill="currentColor" d="M6.1 5.1C8.1 4.2 9 4 10 4l.4.9a14 14 0 0 1 3.2 0L14 4c1 0 2 .3 3.9 1.1 2.3 3.1 3 6.5 2.5 10.6-1.8 1.5-3.2 2.2-4.7 2.6l-1-1.4c.7-.2 1.3-.5 1.9-.9-3.1 1.4-6.1 1.4-9.2 0 .6.4 1.2.7 1.9.9l-1 1.4c-1.5-.4-2.9-1.1-4.7-2.6-.5-4.1.2-7.5 2.5-10.6Z"/><circle fill="#1b1425" cx="9" cy="11.7" r="1.2"/><circle fill="#1b1425" cx="15" cy="11.7" r="1.2"/></svg></span><small>Discord</small></button>
    <button type="button" data-signin="mal" aria-label="Continue with MyAnimeList"><span class="provider-mark mal-mark">MAL</span><small>MyAnimeList</small></button>
    <button type="button" data-signin="anilist" aria-label="Continue with AniList"><span class="provider-mark ani-mark">A<span>L</span></span><small>AniList</small></button>
   </div>
   <div class="account-foot">${signup?'Already have a local account? <button type="button" id="account-switch">Log in</button>':'New on this phone? <button type="button" id="account-switch">Create account</button>'}</div>
   `);
  modalMode=mode;o.querySelectorAll('[data-discord-shortcut569]').forEach(b=>b.onclick=()=>window.kuroSettings560?.openDiscord569(b.dataset.discordShortcut569,settingsHooks560()));o.querySelector('#account-switch').onclick=()=>login(signup?'login':'signup');bindAdminGesture568(o.querySelector('#account-dialog-title'));
  o.querySelector('#account-show-password').onclick=()=>{let input=o.querySelector('#account-password'),button=o.querySelector('#account-show-password'),show=input.type==='password';input.type=show?'text':'password';button.textContent=show?'Hide password':'Show password';button.setAttribute('aria-pressed',String(show))};
  o.querySelector('#account-form').onsubmit=async e=>{
   e.preventDefault();let email=o.querySelector('#account-email').value.trim(),p=o.querySelector('#account-password'),password=p.value;p.value='';enableModal(o,false);
   try{let result=await request(signup?'signup':'email',{email,password});enableModal(o,true);message(result.message);let current=await status();if(current.connections?.local?.connected){closeModal();placeholder(result.message);if(view==='profile')profile()}}
   catch(err){enableModal(o,true);message(err.message,true)}
  };
  o.querySelectorAll('[data-signin]').forEach(button=>button.onclick=async()=>{
   let provider=button.dataset.signin;enableModal(o,false);
   try{let result=await request('begin',{provider});if(provider==='anilist'){login('pin');message(result.message)}else{enableModal(o,true);message(result.message)}}catch(e){enableModal(o,true);message(e.message,true)}
  });
 }
 async function setup(){
  const origin=document.querySelector('#account-overlay'),originMode=modalMode,gateStarted=performance.now();let data,gate;
  try{gate=await request('adminStatus');if(!origin?.isConnected||modalMode!==originMode)return;if(!gate.verified){ownerEntry568();message('Owner verification expired. Verify with GitHub again.',true);return}data=await status();if(!origin.isConnected||modalMode!==originMode)return}
  catch(e){if(origin?.isConnected){ownerEntry568();message(e.message,true)}return}
  const c=data.config||{},redirect=(kind,value)=>`<div class="account-redirect"><code>${escapeHTML(value)}</code><button type="button" data-copy="${kind}">Copy</button></div>`;
  let o=shell('Account setup','GitHub owner verified · changes apply on this phone.',`
   <form id="account-config-form" class="account-config">
    <label class="account-label">DISCORD APPLICATION ID<input id="config-discord" type="text" inputmode="numeric" autocomplete="off" value="${escapeHTML(c.discord||'')}" placeholder="Public application ID"></label>
    <label class="account-label">MYANIMELIST CLIENT ID<input id="config-mal" type="text" autocomplete="off" value="${escapeHTML(c.mal||'')}" placeholder="Public client ID"></label>
    <label class="account-label">ANILIST CLIENT ID<input id="config-anilist" type="text" inputmode="numeric" autocomplete="off" value="${escapeHTML(c.anilist||'')}" placeholder="Public client ID"></label>
    <button class="account-primary" type="submit">Save setup</button>
   </form>
   <p class="account-note">Changing a provider ID disconnects that provider on this phone. Existing bookmarks and imported anime are untouched.</p>
   <div class="account-help-title">Phone setup guide</div>
   <details class="account-help"><summary>1 · Discord</summary><p>In the Discord developer portal, use a public OAuth client with PKCE, enable its public-client option, and register this exact redirect. Kuro requests only the identify permission. Put its application ID above.</p>${redirect('discord',data.redirectDiscord)}<div class="account-help-actions"><button type="button" data-help="discord">Open Discord developer portal</button></div></details>
   <details class="account-help"><summary>2 · MyAnimeList</summary><p>Choose app type <strong>Android</strong> (or Other if Android is unavailable) when registering a public client with this exact redirect, then enter its public client ID above. A Web-type client requires a server-side secret and is not supported here. MAL grants broad account access; Kuro reads your identity and anime list and can update list status and watched episodes when tracker sync is on. MAL currently supports only plain PKCE; the custom Android redirect can be claimed by another app, so only use trusted apps on your phone.</p>${redirect('mal',data.redirectMal)}<div class="account-help-actions"><button type="button" data-help="mal">Open MAL app settings</button></div></details>
   <details class="account-help"><summary>3 · AniList</summary><p>Create an AniList app using its official PIN redirect below, then enter its client ID above. The official page shows a broad-access token which you paste into Kuro on your phone. Kuro never asks you to share it in chat.</p>${redirect('anilist',data.redirectAniList)}<div class="account-help-actions"><button type="button" data-help="anilist">Open AniList app settings</button></div></details>
   <div class="account-foot"><button type="button" id="account-return">Back</button></div>`,true,true);
  modalMode='setup';o.querySelector('#account-return').onclick=adminReturn568;
  clearTimeout(adminExpiryTimer568);adminExpiryTimer568=setTimeout(()=>{if(o.isConnected&&modalMode==='setup'){cancelAdmin568();ownerEntry568();message('Owner verification expired. Verify with GitHub again.',true)}},Math.max(250,Math.min(600000,(Number(gate.remainingMs)||0)-(performance.now()-gateStarted))));
  o.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>{if(window.KuroNative&&typeof KuroNative.copyAccountRedirect==='function')KuroNative.copyAccountRedirect(b.dataset.copy)});
  o.querySelectorAll('[data-help]').forEach(b=>b.onclick=()=>{if(window.KuroNative&&typeof KuroNative.openAccountHelp==='function')KuroNative.openAccountHelp(b.dataset.help)});
  o.querySelector('#account-config-form').onsubmit=async e=>{
   e.preventDefault();let patch={discord:o.querySelector('#config-discord').value.trim(),mal:o.querySelector('#config-mal').value.trim(),anilist:o.querySelector('#config-anilist').value.trim()};enableModal(o,false);
   try{let result=await request('configure',patch);enableModal(o,true);message(result.message);await status();if(view==='profile')profile()}catch(err){enableModal(o,true);message(err.message,true)}
  };
 }
 function putImports(response){
  if(!response||!Array.isArray(response.items)||!['mal','anilist'].includes(response.provider))throw Error('The imported list was not valid. Nothing was changed.');
  let old=readImports(),keys=new Set(old.map(x=>String(x.provider)+':'+String(x.sourceId))),added=0,skipped=0,rows=old.slice();
  for(const x of response.items){
   if(!x||x.provider!==response.provider||!/^[1-9][0-9]{0,18}$/.test(String(x.sourceId))||typeof x.title!=='string'||!x.title.trim())continue;
   let key=x.provider+':'+String(x.sourceId);if(keys.has(key)){skipped++;continue}keys.add(key);
   let image='';try{let u=new URL(String(x.image||''));if(u.protocol==='https:'&&!u.username&&!u.password&&!u.port)image=u.href}catch{}
   rows.push({provider:x.provider,sourceId:String(x.sourceId),malId:Number(x.malId)||0,anilistId:Number(x.anilistId)||0,title:x.title.trim().slice(0,300),image,status:String(x.status||'').slice(0,40),progress:Math.max(0,Math.min(100000,Number(x.progress)||0)),total:Math.max(0,Math.min(100000,Number(x.total)||0)),adult:typeof x.adult==='boolean'?x.adult:null});added++;
  }
  try{localStorage.setItem(IMPORT_KEY,JSON.stringify(rows))}catch{throw Error('Not enough local storage for the import. Existing lists were not changed.')}
  return `${added} added, ${skipped} already present and kept. Open My Lists to see your imports.${response.partial?' Partial import: '+String(response.reason||'some entries could not be read.'):''}`;
 }
 async function doImport(provider,button){
  button.disabled=true;let text=button.textContent;button.textContent='Importing…';
  try{let r=await request('import',{provider}),info=putImports(r);placeholder(info);if(view==='profile')profile();if(view==='library'&&listFilter==='imported')library()}
  catch(e){placeholder(e.message)}finally{if(button.isConnected){button.disabled=false;button.textContent=text}}
 }
 async function disconnect(provider,button){
  if(!button.dataset.confirm){button.dataset.confirm='yes';button.textContent='Confirm disconnect';setTimeout(()=>{if(button.isConnected&&button.dataset.confirm){delete button.dataset.confirm;button.textContent='Disconnect'}},5000);return}
  button.disabled=true;try{let r=await request('disconnect',{provider});placeholder(r.message);await status();if(view==='profile')profile()}catch(e){button.disabled=false;placeholder(e.message)}
 }
 function saveProfile(){
  const name=String(draftProfile?.name||'').trim();if(!name){placeholder('Choose a Kuro username first.');return}
  try{if(!window.kuroPresets571?.prepare())throw Error('Recovery is pending.');const raw=localStorage.getItem(PROFILE_KEY),old=raw===null?{}:JSON.parse(raw);if(!old||typeof old!=='object'||Array.isArray(old))throw Error('Profile is unreadable.');let p={...old,name:name.slice(0,60),avatar:profileImage(draftProfile.avatar),banner:profileImage(draftProfile.banner),presetSchema571:1};localStorage.setItem(PROFILE_KEY,JSON.stringify(p));draftProfile=null;profileEditing=false;refreshHeader560();placeholder('Kuro profile saved on this device.');profile()}catch{placeholder('Profile could not be saved safely. Existing data was kept.')}
 }
 // Profile image uploads were removed in 5.71; ignore results from an older pending picker.
 window.kuroImagePicked=()=>{};
 function row(provider,label,connected){
  const isConnected=!!connected?.connected,name=isConnected?String(connected.name||'Account'):'';
  const mark={local:'✉',discord:'◉',mal:'M',anilist:'A'}[provider]||'✦';
  return `<div class="account-connection"><span class="profile-icon547 ${escapeHTML(provider)}" aria-hidden="true">${escapeHTML(mark)}</span><div class="connection-copy"><strong>${escapeHTML(label)}</strong><span>${isConnected?'Connected as '+escapeHTML(name):'Not connected'}</span></div><div class="connection-actions">${isConnected&&(provider==='mal'||provider==='anilist')?`<button type="button" data-import="${provider}">Import list</button>`:''}${isConnected?`<button type="button" data-disconnect="${provider}">Disconnect</button>`:`<button type="button" data-connect="${provider}">Connect</button>`}</div></div>`;
 }
 profile=async function(){
  let marker=++window.renderSeq;main.innerHTML='<div class="overline">YOUR SPACE</div><h1>Profile</h1><div class="spinner" aria-label="Loading account"></div>';
  let s;try{s=await status()}catch(e){if(view!=='profile'||marker!==window.renderSeq)return;main.innerHTML=`<div class="overline">YOUR SPACE</div><h1>Profile</h1><div class="space"></div><div class="notice">${escapeHTML(e.message)}</div>`;return}
  if(view!=='profile'||marker!==window.renderSeq)return;
  const connected=active(),con=s.connections||{},p=draftProfile||readProfile(),defaultName=Object.values(con).find(x=>x&&x.connected)?.name||'Your profile';
  let imported=[];try{imported=readImports().filter(validImport)}catch(_){}
  const cats=categoryEntries().filter(x=>safeStoredItem(x.item)),count=k=>cats.filter(x=>x.status===k).length+imported.filter(x=>importedState(x)===k).length,hiddenImports=imported.filter(x=>!importVisible(x)).length;
  const bookmarkCount=stored('kuro-library').filter(safeStoredItem).length,historyCount=historyEntries().filter(x=>safeStoredItem(x.item)).length;
  const total=count('watching')+count('completed')+count('planned'),pct=k=>total?Math.round(100*count(k)/total):0;
  const avatar=p.avatar||'profile-default571.png',banner=p.banner||'',cardArt=readCardArt();
  const artBanners=[...new Set(CARD_ART.profile.filter(f=>f&&f!==banner))].slice(0,4);

  main.innerHTML=`<div class="profile-page547">
   <div class="profile-hero profile-hero547"><div class="profile-banner">${banner?`<img src="${escapeHTML(banner)}" alt="">`:``}<div class="profile-banner-shade"></div><button type="button" id="profile-banner-pick">Change banner</button></div>
    <div class="profile-summary"><div class="profile-avatar"><img src="${escapeHTML(avatar)}" alt=""></div><div class="profile-title"><strong>${escapeHTML(p.name||defaultName)}</strong><span>${connected?'Your Kuro profile · on this phone':'Your personal space'}</span><small>✧ &nbsp;Local profile</small></div><button type="button" id="profile-edit-toggle" class="profile-pencil547" aria-label="Edit profile">✎</button><button type="button" id="profile-avatar-pick" class="profile-camera547" aria-label="Choose profile photo">▣</button></div></div>
   <div class="profile-stats571" role="group" aria-label="Your activity on this phone"><span><b>${historyCount}</b><small>Episodes</small></span><span><b>${total}</b><small>Series</small></span><span><b>${bookmarkCount}</b><small>Saved</small></span></div>
   <div class="account-section profile-edit547" ${profileEditing?'':'hidden'}><div class="account-section-head"><div><h2>Edit profile</h2><p>Changes stay on this phone, not on your provider profile.</p></div></div><label class="account-label">KURO USERNAME<input id="profile-name" maxlength="60" value="${escapeHTML(p.name)}" placeholder="Choose your username"></label><button type="button" id="profile-save" class="account-primary">Save profile</button></div>
   ${connected?'':`<div class="account-empty"><h2>Your local space</h2><p>Your profile and saved lists stay on this phone. Sign in is optional.</p><button type="button" id="account-signin" class="account-primary">Log in or register</button></div>`}
   <div class="profile-private547"><span class="profile-icon547">♙</span><div><strong>Private profile</strong><small>Your Kuro profile stays on this phone</small></div><span class="profile-local547">LOCAL</span></div>
   <div class="profile-caption547">Profile artwork <small>Supplied pictures · offline</small></div><button type="button" id="profile-characters549" class="character-open549">✦ &nbsp; Customize PFP, Banner, Anime &amp; History <span>›</span></button>
   <div class="profile-art571"><div class="profile-caption547">Your art <small>Tap a picture to change it</small></div><div class="profile-art-row571"><button type="button" class="profile-art-tile571 is-avatar571" data-art-tab="avatar" aria-label="Change profile picture"><img src="${escapeHTML(avatar)}" alt=""></button>${artBanners.map((f,i)=>`<button type="button" class="profile-art-tile571" data-art-tab="profile" aria-label="Change profile banner"${i===0?' data-current="1"':''}><img src="${escapeHTML(f)}" alt=""></button>`).join('')}</div></div>
   <div class="profile-cards547"><button type="button" class="profile-card547 anime547" id="profile-anime" style="--profile-card-bg:url(&quot;${cardArt.anime}&quot;)"><span class="profile-card-icon547">▷</span><span class="profile-card-title547">Anime</span><span class="profile-card-sub547">Kuro + imported entries${hiddenImports?' · includes hidden':''}</span><span class="profile-stats547"><span><b>${count('watching')}</b><small>● Watching</small></span><span><b>${count('completed')}</b><small>● Done</small></span><span><b>${count('planned')}</b><small>● Planned</small></span></span><span class="profile-progress547"><i style="flex:0 0 ${pct('watching')}%"></i><i style="flex:0 0 ${pct('completed')}%"></i><i style="flex:0 0 ${pct('planned')}%"></i></span></button>
   <button type="button" class="profile-card547 history547" id="profile-history" style="--profile-card-bg:url(&quot;${cardArt.history}&quot;)"><span class="profile-card-icon547">◷</span><span class="profile-card-title547">History</span><span class="profile-card-sub547">Recently opened episodes</span><span class="profile-stats547"><span><b>${historyCount}</b><small>Episodes</small></span><span><b>${bookmarkCount}</b><small>Bookmarks</small></span></span><span class="profile-progress547"><i style="flex:0 0 ${historyCount?100:0}%"></i></span></button></div>
   <button type="button" id="profile-card-art548" class="profile-card-art548">✦ &nbsp; Change banner, Anime &amp; History backgrounds <span>›</span></button>
   <div class="profile-label547">Your lists</div><div class="profile-list547"><button type="button" id="profile-bookmarks" class="profile-link547"><span class="profile-icon547 gold">☆</span><span><strong>My library</strong><small>${bookmarkCount} saved bookmarks</small></span><b>›</b></button><button type="button" id="profile-imported" class="profile-link547"><span class="profile-icon547 green">⇩</span><span><strong>Imported library</strong><small>${imported.length} imported${hiddenImports?' · '+hiddenImports+' hidden':''}</small></span><b>›</b></button></div>
   <div class="profile-label547">Account</div><div class="profile-list547 profile-account-list547"><button type="button" id="profile-schedule" class="profile-link547"><span class="profile-icon547">▣</span><span><strong>Schedule</strong><small>Browse anime simulcasts</small></span><b>›</b></button><button type="button" id="profile-notifications" class="profile-link547"><span class="profile-icon547">♧</span><span><strong>Notifications</strong><small>Anime news and alerts</small></span><b>›</b></button>
    ${row('local','Email · on this phone',con.local)}${row('discord','Discord',con.discord)}${row('anilist','AniList account',con.anilist)}${row('mal','MyAnimeList account',con.mal)}
   </div><div id="tracker-sync553"></div><p class="account-privacy">Your local email is not verified. It does not lock or back up your profile, bookmarks, lists or history. Signing out does not delete saved data. Connected trackers may receive list status and watched episode progress.</p>${window.kuroLocalRestoreWarning?`<p class="account-privacy">${escapeHTML(window.kuroLocalRestoreWarning)}</p>`:''}</div>`;
  // CSP blocks style attributes in generated markup; apply persisted card art via CSSOM.
  document.querySelector('#profile-anime').style.setProperty('--profile-card-bg',`url("${cardArt.anime}")`);document.querySelector('#profile-history').style.setProperty('--profile-card-bg',`url("${cardArt.history}")`);
  // 5.72: each card keeps its own saved dim and soften values.
  window.kuroPresets571.applyCardStyle(document.querySelector('#profile-anime'),'anime');window.kuroPresets571.applyCardStyle(document.querySelector('#profile-history'),'history');
  document.querySelectorAll('#profile-anime .profile-progress547 i').forEach((el,i)=>el.style.flex=`0 0 ${[pct('watching'),pct('completed'),pct('planned')][i]}%`);document.querySelector('#profile-history .profile-progress547 i').style.flex=`0 0 ${historyCount?100:0}%`;
  let sign=document.querySelector('#account-signin');if(sign)sign.onclick=()=>login();
  document.querySelectorAll('[data-connect]').forEach(b=>b.onclick=()=>login());
  document.querySelectorAll('[data-disconnect]').forEach(b=>b.onclick=()=>disconnect(b.dataset.disconnect,b));
  document.querySelectorAll('[data-import]').forEach(b=>b.onclick=()=>doImport(b.dataset.import,b));
  window.kuroSyncPaint553?.();
  const openList=filter=>{listFilter=filter;nav('library');window.scrollTo(0,0)};
  document.querySelector('#profile-anime').onclick=()=>openList('all');document.querySelector('#profile-bookmarks').onclick=()=>openList('all');document.querySelector('#profile-history').onclick=()=>openList('history');document.querySelector('#profile-imported').onclick=()=>openList('imported');
  document.querySelector('#profile-card-art548').onclick=showCardArt;document.querySelectorAll('.profile-art-tile571').forEach(t=>{t.onclick=()=>showCharacters(t.dataset.artTab==='avatar'?'avatar':'profile')});let characterButton=document.querySelector('#profile-characters549');if(characterButton)characterButton.onclick=()=>showCharacters('avatar');document.querySelector('#profile-schedule').onclick=()=>{nav('simulcasts');window.scrollTo(0,0)};document.querySelector('#profile-notifications').onclick=()=>showNews();
  {if(!draftProfile)draftProfile=readProfile();let input=document.querySelector('#profile-name');input.oninput=()=>{draftProfile.name=input.value};document.querySelector('#profile-save').onclick=saveProfile;
   document.querySelector('#profile-edit-toggle').onclick=()=>{profileEditing=!profileEditing;profile()};
   document.querySelector('#profile-avatar-pick').onclick=()=>showCharacters('avatar');
   document.querySelector('#profile-banner-pick').onclick=()=>showCharacters('profile');
  }
 };
 // Local-only statistics do not estimate viewing time or completion from opens.
 function mountLibraryInsights573(){
  const tabs=document.querySelector('.category-tabs');if(!tabs)return;
  const allHistory=historyEntries().filter(x=>safeStoredItem(x.item));let marks=0;
  try{const data=watchedData();if(data&&typeof data==='object'&&!Array.isArray(data))for(const row of Object.values(data))if(row&&typeof row==='object'&&!Array.isArray(row))marks+=Object.values(row).filter(x=>x===true).length}catch(_){}
  const unique=new Set(allHistory.map(x=>JSON.stringify([x.item.source,x.item.url]))).size;
  const card=document.createElement('section');card.className='library-insights573';card.setAttribute('aria-label','Local viewing statistics');
  let goal=0;try{let n=Number(localStorage.getItem('kuro-weekly-goal573'));if(Number.isInteger(n)&&n>=1&&n<=200)goal=n}catch(_){}
  const now=new Date(),start=new Date(now.getFullYear(),now.getMonth(),now.getDate());start.setDate(start.getDate()-(start.getDay()+6)%7);const weekStart=start.getTime(),weekCount=allHistory.filter(x=>Number.isFinite(x.opened)&&x.opened>=weekStart&&x.opened<=now.getTime()).length;
  card.innerHTML=`<details><summary>Viewing activity on this device</summary><p><strong>${allHistory.length}</strong> recent episode records · <strong>${unique}</strong> titles in recent history · <strong>${marks}</strong> episodes marked watched</p><small>History holds up to 200 distinct episode records. Opened episodes are not necessarily completed; viewing time is not measured. Watched marks may include entries hidden by content preferences.</small><div class="weekly-goal573"><label>Weekly goal: episodes opened <input type="number" data-goal-input min="0" max="200" step="1" value="${goal}" inputmode="numeric"></label><button type="button" data-goal-save>Save goal</button><p role="status" aria-live="polite" data-goal-status></p><small>Monday to Sunday in your local time. A repeated episode counts once at its latest opening. Zero turns the goal off. This device-only setting is not included in backups.</small></div></details>`;tabs.before(card);
  const field=card.querySelector('[data-goal-input]'),status=card.querySelector('[data-goal-status]');const render=()=>{status.textContent=goal?`${weekCount} of ${goal} episodes opened this week (from recent history).`:'Weekly goal is off.'};render();card.querySelector('[data-goal-save]').onclick=()=>{const raw=field.value.trim(),n=Number(raw);if(!/^(?:0|[1-9][0-9]{0,2})$/.test(raw)||n>200){status.textContent='Enter a whole number from 0 to 200.';return}try{if(n===0)localStorage.removeItem('kuro-weekly-goal573');else localStorage.setItem('kuro-weekly-goal573',String(n));goal=n;render()}catch(_){status.textContent='Could not save the goal on this device.'}};
 }
 function mountLocalLibraryTools573(items){
  const saved=document.querySelector('#saved'),grid=saved?.querySelector('.grid');if(!grid)return;
  const cards=[...grid.querySelectorAll(':scope > [data-card]')];if(!cards.length)return;
  const tools=document.createElement('div');tools.className='library-tools573';tools.innerHTML='<label>Filter local titles <input type="search" maxlength="120" placeholder="Search titles" data-local-query></label><label>Audio availability <select data-local-audio><option value="all">Any</option><option value="sub">Sub reported</option><option value="dub">Dub reported</option><option value="unknown">Not reported</option></select></label><label>Library source <select data-local-source><option value="all">Any source</option></select></label><label>Sort <select data-local-sort><option value="original">Saved order</option><option value="az">Title A–Z</option><option value="za">Title Z–A</option></select></label><p role="status" aria-live="polite" data-local-count></p>';
  saved.before(tools);const input=tools.querySelector('[data-local-query]'),sort=tools.querySelector('[data-local-sort]'),audio=tools.querySelector('[data-local-audio]'),sourceFilter=tools.querySelector('[data-local-source]'),count=tools.querySelector('[data-local-count]');
  const sources=[...new Set(items.map(x=>String(x?.source||'')).filter(Boolean))].sort();for(const source of sources){const option=document.createElement('option');option.value=source;option.textContent=source;sourceFilter.append(option)}
  const update=()=>{const q=input.value.normalize('NFKC').trim().toLocaleLowerCase(),ordered=[...cards];if(sort.value!=='original')ordered.sort((a,b)=>{const x=a.querySelector('strong')?.textContent||'',y=b.querySelector('strong')?.textContent||'';return (sort.value==='az'?1:-1)*x.localeCompare(y,undefined,{sensitivity:'base',numeric:true})});let visible=0;for(const card of ordered){const item=items[Number(card.dataset.card)],c=item?.counts||{},sub=Number(c.sub)>0,dub=Number(c.dub)>0,matchAudio=audio.value==='all'||(audio.value==='sub'&&sub)||(audio.value==='dub'&&dub)||(audio.value==='unknown'&&!sub&&!dub);const match=(card.querySelector('strong')?.textContent||'').normalize('NFKC').toLocaleLowerCase().includes(q)&&matchAudio&&(sourceFilter.value==='all'||item?.source===sourceFilter.value);card.hidden=!match;if(match)visible++;grid.appendChild(card)}count.textContent=`${visible} of ${cards.length} local titles shown. Imported tracker entries are separate.`};input.oninput=update;sort.onchange=update;audio.onchange=update;sourceFilter.onchange=update;update();
 }
 const originalLibrary=library;
 function selectImportList(id){listFilter=id;library();if(typeof window.kuroSavePage==='function')window.kuroSavePage()}
 function bindLibraryFilters557(){document.querySelectorAll('.category-tabs [data-list-filter]').forEach(b=>b.onclick=()=>selectImportList(b.dataset.listFilter))}
 library=function(){
  if(listFilter==='imported'){
   ++window.renderSeq;let rows;try{rows=readImports()}catch(e){main.innerHTML=`<div class="overline">YOUR COLLECTION</div><h1>My library</h1><div class="space"></div><div class="notice error">${escapeHTML(e.message)}</div>`;return}
   main.innerHTML=`<div class="overline">YOUR COLLECTION</div><h1>My library</h1><p class="sub">Saved on this device only.</p><div class="tabs category-tabs" role="group" aria-label="Library filters">${libraryTabs557('imported')}</div><section id="import-browser554"></section>`;
   bindLibraryFilters557();mountImportedBrowser(document.querySelector('#import-browser554'),rows,'',true);return;
  }
  originalLibrary();bindLibraryFilters557();mountLibraryInsights573();const bookmarks=stored('kuro-library').filter(x=>x&&typeof x==='object'&&x.url&&safeStoredItem(x)),categorized=categoryEntries().filter(x=>safeStoredItem(x.item));const localItems=listFilter==='all'?allLocalTitles557(bookmarks,categorized):listFilter==='bookmarks'?bookmarks:categorized.filter(x=>x.status===listFilter).map(x=>x.item);mountLocalLibraryTools573(localItems);
  if(listFilter==='history'||listFilter==='bookmarks')return;
  let rows;try{rows=readImports()}catch(e){let warning=document.createElement('p');warning.className='notice error';warning.textContent=e.message;main.appendChild(warning);return}
  const category=listFilter==='all'?'':listFilter,candidates=rows.filter(x=>validImport(x)&&(!category||importedState(x)===category));if(!candidates.length)return;
  const saved=document.querySelector('#saved');if(!saved)return;let section=document.createElement('section');section.id='import-browser554';
  if(listFilter==='all'){
   const heading=saved.previousElementSibling;if(heading&&heading.classList.contains('heading'))heading.before(section);else saved.before(section);
   const empty=saved.querySelector('.empty');if(empty)empty.textContent='No local Kuro titles or bookmarks yet.';
  }else{
   saved.prepend(section);const empty=saved.querySelector('.empty');if(empty)empty.textContent='No local Kuro titles in this status.';
   const visible=candidates.filter(importVisible).length,heading=saved.previousElementSibling,span=heading?.querySelector('span');if(span){let local=categoryEntries().filter(x=>safeStoredItem(x.item)&&x.status===listFilter).length;span.textContent=(local+visible)+' entries'}
  }
  mountImportedBrowser(section,rows,category,false);
 };
 function refreshHeader560(){
  const button=document.querySelector('#header-login'),yes=active(),avatar=readProfile().avatar||'profile-default571.png';
  if(button){button.classList.toggle('is-profile560',yes);button.setAttribute('aria-label',yes?'Open profile menu':'Log in');button.textContent='';if(yes){let img=document.createElement('img');img.src=avatar;img.alt='';button.appendChild(img)}else button.textContent='Log in'}
  try{if(typeof window.KuroNative?.profileHeader560==='function')KuroNative.profileHeader560(yes,yes?avatar:'')}catch(_){}
 }
 window.kuroRefreshHeader560=refreshHeader560;
 function route560(id){
  if(id==='profile'||id==='connections'){nav('profile');window.scrollTo(0,0);return}
  if(id==='watchlist'||id==='history'||id==='bookmarks'){listFilter=id==='watchlist'?'all':id;nav('library');window.scrollTo(0,0);return}
  if(id==='continue'){let recent=historyEntries().find(x=>safeStoredItem(x.item));if(recent)openHistory(recent);else{listFilter='history';nav('library');window.scrollTo(0,0);placeholder('No previously opened episodes yet.')}}
 }
 window.kuroMenuNavigate560=route560;
 function navigate560(id){
  if(watchAccountMode&&typeof window.KuroNative?.watchMenuNavigate560==='function'){
   const token=watchAccountToken;closeModal(false);watchAccountMode=false;document.documentElement.classList.remove('watch-account-active');KuroNative.watchMenuNavigate560(id,token);return;
  }closeModal();route560(id);
 }
 function settingsHooks560(){return {navigate:navigate560,closeMenu:()=>closeModal(),reload:()=>{const watching=watchAccountMode;closeModal();if(watching&&typeof window.KuroNative?.settingsAction560==='function')KuroNative.settingsAction560('reload');else window.kuroPullRefresh560?.()},restored:()=>{refreshHeader560();if(view==='profile')profile();if(view==='library')library()},importTracker:async(provider,button)=>{
  let notice=document.querySelector('#transfer-notice560');if(!lastStatus?.connections?.[provider]?.connected){if(notice){notice.textContent='Connect '+(provider==='mal'?'MyAnimeList':'AniList')+' in Profile first.';notice.hidden=false}return}
  button.disabled=true;try{let result=putImports(await request('import',{provider}));if(notice){notice.textContent=result;notice.hidden=false}if(view==='profile')profile();if(view==='library')library()}catch(e){if(notice){notice.textContent=e.message;notice.hidden=false}}finally{if(button.isConnected)button.disabled=false}
 }} }
 const svg560={profile:'<circle cx="12" cy="8" r="3.3"/><path d="M5 20v-1.5c0-3.3 2.8-5.3 7-5.3s7 2 7 5.3V20z"/>',continue:'<path d="M4 5v5h5M4.7 10A8 8 0 1 1 5 15"/><path d="M12 7v5l3 2"/>',watchlist:'<path d="M20.8 8.5c0 4-4.5 7.3-8.8 11-4.3-3.7-8.8-7-8.8-11a4.5 4.5 0 0 1 8.8-1.3 4.5 4.5 0 0 1 8.8 1.3Z"/>',transfer:'<path d="M4 8h15M16 5l3 3-3 3M20 16H5M8 13l-3 3 3 3"/>',discordPresence:'<path d="M6 6c3-1.5 9-1.5 12 0 1.5 2.4 2.2 5.4 2 9-1.4 1.2-3 1.8-4.5 2.1l-1-1.4M8.5 17.1 7 15.7"/><circle cx="9" cy="11.5" r="1"/><circle cx="15" cy="11.5" r="1"/>',discordCustomize:'<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="10" cy="18" r="2"/>',settings:'<circle cx="12" cy="12" r="3"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.7 5.7l1.4 1.4M16.9 16.9l1.4 1.4M18.3 5.7l-1.4 1.4M7.1 16.9l-1.4 1.4"/><circle cx="12" cy="12" r="7.5"/>'};
 function profileMenu560(){
  if(modalMode==='setup'||modalMode.startsWith('owner-'))cancelAdmin568();closeModal(false);const p=readProfile(),con=lastStatus?.connections||{},local=con.local?.connected?String(con.local.name||''):'';
  const provider=['discord','mal','anilist'].find(k=>con[k]?.connected),providerName=provider?String(con[provider].name||''):'';
  const name=p.name||(!local&&providerName)||'Your profile',detail=local||(provider?({discord:'Discord',mal:'MyAnimeList',anilist:'AniList'}[provider]+' · '+providerName):'Saved on this phone');
  const items=[['profile','Profile'],['continue','Continue Watching'],['watchlist','Watch List'],['discordPresence','Discord Rich Presence'],['discordCustomize','Presence customization'],['transfer','Import/Export'],['settings','Settings']];
  let o=document.createElement('div');o.id='account-overlay';o.className='account-overlay profile-overlay560';
  o.innerHTML=`<section class="profile-drawer560" role="dialog" aria-modal="true" aria-label="Profile menu"><button class="profile-handle560" type="button" aria-label="Close profile menu">‹</button><div class="profile-drawer-inner560"><div class="profile-brand561"><span>KURO<span class="profile-brand-accent561">.TV</span></span><small>YOUR SPACE</small></div><div class="profile-identity560"><img src="${escapeHTML(p.avatar||'profile-default571.png')}" alt=""><div><strong>${escapeHTML(name)}</strong><small>${escapeHTML(detail)}</small></div></div><div class="profile-section561" aria-hidden="true">YOUR MENU</div><div class="profile-links560">${items.map(([id,title])=>`<button type="button" class="profile-link560" data-menu="${id}"><svg aria-hidden="true" viewBox="0 0 24 24">${svg560[id]}</svg><span>${title}</span></button>`).join('')}</div><div id="logout-confirm560" class="profile-confirm560" hidden></div><button type="button" class="profile-logout560">Logout <span aria-hidden="true">→</span></button></div></section>`;
  document.body.appendChild(o);document.documentElement.classList.add('account-modal-open');o.onclick=e=>{if(e.target===o)closeModal()};o.querySelector('.profile-handle560').onclick=()=>closeModal();bindAdminGesture568(o.querySelector('.profile-brand561'));
  o.addEventListener('keydown',e=>{if(e.key==='Escape'){e.stopPropagation();closeModal()}});
  // A deliberate horizontal swipe closes the drawer without hijacking vertical scrolling.
  let swipe560=null;o.addEventListener('touchstart',e=>{const t=e.touches?.[0];swipe560=t?{x:t.clientX,y:t.clientY}:null},{passive:true});o.addEventListener('touchend',e=>{const t=e.changedTouches?.[0],start=swipe560;swipe560=null;if(!t||!start)return;let dx=t.clientX-start.x,dy=t.clientY-start.y;if(dx<-80&&Math.abs(dx)>Math.abs(dy)*1.5)closeModal()},{passive:true});
  o.querySelectorAll('[data-menu]').forEach(b=>b.onclick=()=>{let id=b.dataset.menu;if(id==='settings')window.kuroSettings560?.open(settingsHooks560());else if(id==='discordPresence'||id==='discordCustomize')window.kuroSettings560?.openDiscord569(id==='discordPresence'?'presence':'customization',settingsHooks560());else if(id==='transfer')window.kuroSettings560?.openTransfer(settingsHooks560());else navigate560(id)});
  o.querySelector('.profile-logout560').onclick=()=>{
   let box=o.querySelector('#logout-confirm560');box.hidden=false;box.innerHTML='<strong>Log out on this phone?</strong><p>All connected Kuro sign-ins will be disconnected. Your profile, lists, imports and history stay on this phone. Provider access is not revoked online.</p><div><button type="button" data-cancel>Cancel</button><button type="button" data-confirm>Log out</button></div>';
   box.querySelector('[data-cancel]').onclick=()=>{box.hidden=true;box.textContent=''};box.querySelector('[data-confirm]').onclick=async()=>{let confirm=box.querySelector('[data-confirm]');confirm.disabled=true;let failed=false;for(const k of ['local','discord','mal','anilist'])if(lastStatus?.connections?.[k]?.connected){try{await request('disconnect',{provider:k})}catch(_){failed=true}}
    try{await status()}catch(_){failed=true}if(failed){confirm.disabled=false;box.querySelector('p').textContent='Some sign-ins could not be disconnected. Your saved data was not changed.';return}closeModal();placeholder('Logged out. Your profile and lists were kept on this phone.');if(view==='profile')profile()};
  };o.querySelector('[data-menu="profile"]').focus();return o;
 }
 window.kuroPullRefresh560=()=>{if(!['home','search','library','simulcasts','profile','detail','episode'].includes(view)){placeholder('This page cannot be refreshed here.');return}let current=view;let o=shell('Refresh this page?','This does not clear your saved data.','<p class="account-note">Kuro will refresh this page. The page may take time to load.</p><div class="account-provider-grid"><button type="button" id="refresh-no560">Cancel</button><button type="button" id="refresh-yes560">Refresh</button></div>');o.querySelector('#refresh-no560').onclick=()=>closeModal();o.querySelector('#refresh-yes560').onclick=()=>{closeModal();if(current==='detail'&&selected)openShow(selected);else if(current==='episode'&&episode)openEpisode(episode);else nav(current)}};
 document.querySelector('#header-login').onclick=()=>{if(active())profileMenu560();else login()};
 // Edge swipe is optional; the avatar remains the primary way to open the menu.
 let edge560=null;document.addEventListener('touchstart',e=>{const t=e.touches?.[0],blocked=document.querySelector('#account-overlay,#settings-overlay560,#transfer-overlay560,#discord-overlay569,#search-popup,#news-overlay');edge560=t&&t.clientX<=20&&!blocked&&active()?{x:t.clientX,y:t.clientY}:null},{passive:true});document.addEventListener('touchend',e=>{const t=e.changedTouches?.[0],start=edge560;edge560=null;if(!t||!start)return;let dx=t.clientX-start.x,dy=t.clientY-start.y;if(dx>80&&Math.abs(dx)>Math.abs(dy)*1.5)profileMenu560()},{passive:true});
 function accountBack560(){if(document.querySelector('#discord-overlay569'))return window.kuroSettings560.close('discord-overlay569');if(document.querySelector('#transfer-overlay560'))return window.kuroSettings560.close('transfer-overlay560');if(document.querySelector('#settings-overlay560'))return window.kuroSettings560.close('settings-overlay560');if(document.querySelector('#account-overlay')){closeModal();return true}return false}
 const oldBack=window.kuroBack;window.kuroBack=()=>{if(!accountBack560())oldBack()};window.kuroWatchAccountBack=accountBack560;
 window.kuroWatchAccountOpen=token=>{closeModal();watchAccountToken=Number(token)||0;watchAccountMode=true;document.documentElement.classList.add('watch-account-active');if(active())profileMenu560();else login()};
 window.kuroWatchAccountClose=()=>closeModal();
 window.kuroAccountEvent=async event=>{
  if(event?.error){message(event.error,true);return}
  if(watchAccountMode){if(event?.message)message(event.message)}else if(document.querySelector('#account-overlay'))closeModal();
  if(event?.message&&!watchAccountMode)placeholder(event.message);try{await status()}catch{}if(view==='profile')profile();
 };
 if(nativeAvailable())status().catch(()=>{});
})();

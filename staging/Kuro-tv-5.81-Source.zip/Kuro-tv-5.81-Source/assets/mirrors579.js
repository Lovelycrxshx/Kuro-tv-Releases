'use strict';
// HiAnime mirror rotation (5.79).
//
// Library 2 ('dk') is a HiAnime site. The same catalogue is served from several
// public domains, so instead of teaching every parser about three more source
// codes, the domain itself rotates: hianime.dk, then hianime.fm, hianime.al and
// hianimes.es. Everything downstream keeps using the 'dk' code path and only the
// origin changes, which means the existing search, detail, episode, server and
// failover logic applies to the new domains unchanged.
//
// A mirror is only ever skipped after a real request to it failed. Nothing is
// probed at startup and no domain is marked dead on a guess.
const HI_MIRRORS = [
 'https://hianime.dk',
 'https://hianime.fm',
 'https://hianime.al',
 'https://hianimes.es'
];

/** Hostnames of every mirror, used by the URL allowlists. */
const HI_MIRROR_HOSTS = HI_MIRRORS.map(o => o.replace(/^https:\/\//, ''));

/** True for any mirror host, including a subdomain such as cdn.hianime.dk. */
function hiIsMirrorHost(hostname) {
 const h = String(hostname || '');
 return HI_MIRROR_HOSTS.some(x => h === x || h.endsWith('.' + x));
}

/** The origin currently preferred for 'dk'. */
let hiMirrorIndex = 0;
function hiCurrentOrigin() { return HI_MIRRORS[hiMirrorIndex] || HI_MIRRORS[0]; }

/**
 * Moves to the next mirror after a failure and returns it, or '' when every
 * mirror has already been tried for this request.
 */
function hiRotateMirror(failedOrigin) {
 const current = String(failedOrigin || '').replace(/\/$/, '');
 const at = HI_MIRRORS.indexOf(current);
 if (at === -1) return '';
 const next = (at + 1) % HI_MIRRORS.length;
 if (next === hiMirrorIndex) return '';
 hiMirrorIndex = next;
 return HI_MIRRORS[next];
}

/** Keeps a known-good mirror selected across page loads in the same session. */
function hiRememberMirror(origin) {
 const at = HI_MIRRORS.indexOf(String(origin || '').replace(/\/$/, ''));
 if (at !== -1) hiMirrorIndex = at;
}

/** Maps any mirror origin onto 'dk' so callers can reuse the existing code path. */
function hiSourceCodeFor(url) {
 try { return hiIsMirrorHost(new URL(url).hostname) ? 'dk' : ''; } catch (_) { return ''; }
}

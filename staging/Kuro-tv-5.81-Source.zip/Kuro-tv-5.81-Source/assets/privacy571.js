'use strict';
/* Read-only disclosure and explicit, single-key local cleanup. No remote deletion. */
(()=>{
 const groups=[
  ['Bookmarks','kuro-library','Bookmarked titles on this device'],
  ['Watch statuses','kuro-categories-v1','Local watching/completed/planned labels'],
  ['Imported tracker list','kuro-imports-v1','Local imported entries, not the tracker account'],
  ['Recently opened titles','kuro-recent','Local continue-watching titles'],
  ['Episode history','kuro-episode-history-v1','Locally recorded episodes opened'],
  ['Watched marks','kuro-watched-v1','Local watched episode marks'],
  ['Last episode markers','kuro-last-episode-v1','Local last-opened episode per show'],
  ['Watch queue','kuro-watch-queue571-v1','Locally queued episodes'],
  ['Search history','kuro-search-history-v1','Recent submitted searches on this device'],
  ['Discovery preferences','kuro-discovery-hidden573','Words hidden from local discovery suggestions'],
  ['Weekly activity goal','kuro-weekly-goal573','Optional local goal for episodes opened'],
  ['Old per-series playback preferences','kuro-anime-preferences571-v1','Retained for backup only; no longer applied']
 ];
 const escape=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const bytes=s=>new Blob([s||'']).size;
 function amount(k){try{const s=localStorage.getItem(k);return s===null?0:bytes(s)}catch(_){return null}}
 function size(n){if(n===null)return 'Unavailable';if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(1)+' KB';return (n/1048576).toFixed(2)+' MB'}
 let root=null,returnFocus=null;
 function close(){if(!root)return;root.remove();root=null;if(returnFocus?.isConnected)returnFocus.focus();returnFocus=null}
 function presencePreview(){let o={},enabled=null;try{if(typeof KuroNative?.discordOptions564==='function')o=JSON.parse(KuroNative.discordOptions564()||'{}');if(typeof KuroNative?.discordRpcEnabled563==='function')enabled=!!KuroNative.discordRpcEnabled563()}catch(_){}
  const title=o.title==='hide'?'Watching an anime':'Sample Anime',ep=o.episode==='hide'?'Watching':'Episode 3',sep=o.separator==='bar'?' | ':o.separator==='dash'?' — ':' · ',progress=ep+sep+'SUB'+sep+'Selected',details=o.layout==='episode'&&o.episode!=='hide'?progress:title,state=o.layout==='episode'&&o.episode!=='hide'?title:progress;
  const image=o.title==='hide'||o.poster==='icon'?'App icon':'Anime cover if a safe cover is available; otherwise the app icon';
  return `<div class="privacy-section571"><h3>Local presence preview</h3><p>Illustration only · ${enabled===true?'sharing is enabled':enabled===false?'sharing is off':'sharing status is unavailable'}</p><p><strong>${escape(details)}</strong><br>${escape(state)}<br>${escape(image)}</p><p>No Watch or Download buttons are sent. Actual playback details, availability and Discord’s display may differ. This preview does not send a status or make a network request.</p></div>`;
 }
 function storageRows(){return groups.map(([label,key,desc],i)=>{let n=amount(key);return `<div class="storage-row571"><div><strong>${escape(label)}</strong><small>${escape(desc)} · ${escape(size(n))}</small></div><button type="button" data-clear="${i}" ${n===0?'disabled':''}>Clear</button></div>`}).join('')}
 function render(mode){if(!root)return;const body=root.querySelector('.privacy-body571');body.innerHTML=(mode==='preview'?presencePreview():'')+`<div class="privacy-section571"><h3>Privacy center</h3><p>Kuro stores its profile, lists, watch history, queue and settings on this device. It does not upload them to a Kuro cloud. Your local backup file is not encrypted and may include viewing history and profile artwork.</p><p>When you use a library or player, that third party receives your network connection and may use cookies. Blocking is limited and cannot guarantee privacy or availability. Connected trackers and Discord receive information only when their related features are used; their own policies apply.</p><p>Discord sharing can be switched off. When enabled, eligible anime details and a safe anime cover may be sent; source URLs and Watch/Download buttons are not sent. Local preview is illustrative and never publishes.</p><p>Gallery files, your accounts, cookies, downloads and backup files are not removed by the selective controls below.</p></div>${mode==='preview'?'':presencePreview()}<div class="privacy-section571"><h3>Selective local storage</h3><p>Approximate UTF-8 sizes of individual WebView values, not total app storage. WebView cache, account credentials, native downloads, media and phone storage are not counted. Clearing removes only the named local value; it does not delete remote tracker data. Export a backup first if you may need the data later.</p><p class="privacy-note571" role="status" aria-live="polite">Tap Clear, then Confirm to remove that one value.</p><div class="storage-rows571">${storageRows()}</div><p class="privacy-note571">Profile artwork: ${escape(size(amount('kuro-profile-v1')))} · Profile card backgrounds: ${escape(size(amount('kuro-profile-card-art-v1')))}. These are shown for reference and are not cleared here.</p></div>`;
  const note=body.querySelector('.privacy-note571');body.querySelectorAll('[data-clear]').forEach(b=>b.onclick=()=>{const n=Number(b.dataset.clear);if(!Number.isInteger(n)||!groups[n])return;if(b.dataset.confirm!=='true'){body.querySelectorAll('[data-confirm]').forEach(x=>{x.removeAttribute('data-confirm');x.textContent='Clear'});b.dataset.confirm='true';b.textContent='Confirm';note.textContent='Confirm clearing '+groups[n][0]+' on this device only. Other values are kept.';setTimeout(()=>{if(b.isConnected&&b.dataset.confirm==='true'){b.removeAttribute('data-confirm');b.textContent='Clear';note.textContent='Tap Clear, then Confirm to remove that one value.'}},8000);return}try{localStorage.removeItem(groups[n][1]);window.kuroStorageChanged571?.();render(mode);const next=root?.querySelector('.privacy-note571');if(next)next.textContent=groups[n][0]+' cleared on this device. Other values were kept.'}catch(_){note.textContent='Could not clear this value. Nothing else was changed.'}});
 }
 function open(mode='privacy'){if(root)return;returnFocus=document.activeElement;root=document.createElement('div');root.id='privacy-overlay571';root.className='dialog-overlay571';root.innerHTML=`<section class="dialog-panel571" role="dialog" aria-modal="true" aria-labelledby="privacy-title571"><header><div><small>KURO.TV · YOUR DATA</small><h2 id="privacy-title571">${mode==='preview'?'Presence preview':'Privacy & storage'}</h2></div><button type="button" data-close aria-label="Close privacy and storage">×</button></header><div class="privacy-body571"></div></section>`;document.body.append(root);root.querySelector('[data-close]').onclick=close;root.onclick=e=>{if(e.target===root)close()};root.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();close()}};render(mode);root.querySelector('[data-close]').focus()}
 window.kuroPrivacy571=Object.freeze({open,close});
 const previous=window.kuroBack;window.kuroBack=()=>{if(root){close();return}previous?.()};
})();

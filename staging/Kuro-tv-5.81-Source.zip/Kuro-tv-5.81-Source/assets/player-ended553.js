'use strict';
// Event-driven only: the currently loaded top-level player must report the end
// of its single HTML video. Cross-origin child frames cannot report here.
(()=>{
 if(window!==window.top||window.__kuroEnded553)return;
 window.__kuroEnded553=true;
 document.addEventListener('ended',event=>{
  const v=event.target,all=document.querySelectorAll('video');
  if(!(v instanceof HTMLVideoElement)||all.length!==1||all[0]!==v||!v.ended||!Number.isFinite(v.duration)||v.duration<180||v.currentTime<v.duration*.98)return;
  try{window.KuroFinished553?.postMessage('ended')}catch(_){}
 },true);
})();

'use strict';
/* Outbound tracker queue. No OAuth tokens or account passwords enter this file. */
(()=>{
 const KEY='kuro-tracker-sync-v1',providers=['anilist','mal'];
 const labels={anilist:'AniList',mal:'MyAnimeList'};
 const names={watching:'Watching',planned:'Plan to watch',completed:'Completed',on_hold:'On hold',dropped:'Dropped'};
 let state,unreadable=false,storageError=false,connections={},busy=false,timer=null,timerAt=0,background=false,nextAt=0;
 try{
  const raw=localStorage.getItem(KEY);state=raw?JSON.parse(raw):null;
  if(state&&(!Array.isArray(state.queue)||!state.links||!state.initialized||!state.auto||!state.cooldown))throw Error();
 }catch(_){unreadable=true}
 if(!state)state={v:1,queue:[],links:{},initialized:{},auto:{anilist:true,mal:true},cooldown:{},seq:0};
 function persist(){if(unreadable)return false;try{localStorage.setItem(KEY,JSON.stringify(state));storageError=false;return true}catch(_){storageError=true;return false}}
 function key(item){return String(item?.source||'')+'|'+String(item?.url||'')}
 function itemSnapshot(item){
  if(!item||typeof item.source!=='string'||typeof item.url!=='string'||typeof item.title!=='string'||!item.source||!item.url||!item.title.trim())return null;
  if(!KURO_ADULT_ENABLED&&adultFlag(item))return null;
  let titles=Array.isArray(item.titles)?item.titles.filter(x=>typeof x==='string').slice(0,12).map(x=>x.slice(0,300)):[];
  return {source:item.source.slice(0,40),url:item.url.slice(0,1600),title:item.title.trim().slice(0,300),titles,anilistId:Number(item.anilistId)||0,malId:Number(item.malId)||0,verifyTitle:!!item.verifyTitle};
 }
 function owner(p){const c=connections[p];return c?.connected&&typeof c.syncOwner==='string'&&/^[A-Za-z0-9_-]{24}$/.test(c.syncOwner)?c.syncOwner:''}
 function enabled(p){return state.auto[p]!==false}
 function identity(item){
  const link=state.links[key(item)]||{};
  if(link.confirmed)return {anilistId:Number(link.anilistId)||0,malId:Number(link.malId)||0,userMatched:true};
  if(item.verifyTitle)return {anilistId:0,malId:0,userMatched:false};
  return {anilistId:Number(item.anilistId)||Number(link.anilistId)||0,malId:Number(item.malId)||Number(link.malId)||0,userMatched:false};
 }
 function episodesFor(item){
  const all=watchedData(),entry=all[key(item)]||{};
  return Object.keys(entry).filter(n=>entry[n]===true&&/^[1-9][0-9]{0,3}$/.test(n)&&Number(n)<=5000).map(Number).sort((a,b)=>a-b);
 }
 function categoryFor(item){return categoryEntries().find(x=>key(x.item)===key(item))?.status||'watching'}
 function queueId(p,o,item){return p+'|'+o+'|'+key(item)}
 function upsert(p,o,raw,status,intent){
  const item=itemSnapshot(raw);if(!item||!names[status]||!o||unreadable)return;
  const id=queueId(p,o,item);let job=state.queue.find(x=>x.id===id);
  if(!job){job={id,provider:p,owner:o,item,status,intent,state:'pending',tries:0,retryAt:0,error:'',rev:0};state.queue.push(job)}
  else{
   job.item=item;job.status=status;
   if(intent==='status'||(intent==='watch'&&job.intent!=='status'))job.intent=intent;
   if(intent!=='backfill'){job.state='pending';job.tries=0;job.retryAt=0;job.error=''}
  }
  const ident=identity(item);if(!ident.anilistId&&!ident.malId)job.state='match';
  job.rev=++state.seq;
 }
 function backfill(p,o){
  const initialized=p+'|'+o;if(state.initialized[initialized])return;
  const found=new Map();
  for(const x of categoryEntries())if(x?.item&&names[x.status])found.set(key(x.item),{item:x.item,status:x.status});
  const known=[...stored('kuro-library'),...stored('kuro-recent'),...historyEntries().map(x=>x.item)];
  const watched=watchedData();
  for(const item of known){const k=key(item),record=watched[k];if(item&&record&&Object.values(record).some(x=>x===true)&&!found.has(k))found.set(k,{item,status:'watching'})}
  for(const x of found.values())upsert(p,o,x.item,x.status,'backfill');
  state.initialized[initialized]=true;
 }
 function schedule(delay=0){
  if(unreadable||storageError||background||document.hidden||!navigator.onLine||busy)return;
  const at=Math.max(Date.now()+delay,nextAt);if(timer&&timerAt<=at)return;
  if(timer)clearTimeout(timer);timerAt=at;timer=setTimeout(()=>{timer=null;timerAt=0;drain()},Math.max(0,at-Date.now()));
 }
 async function drain(){
  if(busy||unreadable||storageError||background||document.hidden||!navigator.onLine||!window.kuroTrackerRequest553)return;
  const now=Date.now();if(now<nextAt){schedule(nextAt-now);return}
  const eligible=state.queue.filter(j=>j.state==='pending'&&enabled(j.provider)&&owner(j.provider)===j.owner);
  const job=eligible.find(j=>Math.max(Number(j.retryAt)||0,Number(state.cooldown[j.provider])||0)<=now);
  if(!job){let due=Math.min(...eligible.map(j=>Math.max(Number(j.retryAt)||0,Number(state.cooldown[j.provider])||0)).filter(n=>n>now));if(Number.isFinite(due))schedule(due-now);return}
  const ident=identity(job.item);
  if(!ident.anilistId&&!ident.malId){job.state='match';job.error='Choose the exact anime.';persist();paint();schedule();return}
  busy=true;const captured={id:job.id,rev:job.rev,provider:job.provider,owner:job.owner,item:{...job.item},status:job.status,intent:job.intent};
  const data={provider:captured.provider,owner:captured.owner,status:captured.status,intent:captured.intent,title:captured.item.title,titles:captured.item.titles,watched:episodesFor(captured.item),...ident};
  try{
   const result=await window.kuroTrackerRequest553('trackerSync',data);
   const current=state.queue.find(j=>j.id===captured.id);
   if(current&&current.rev===captured.rev){
    const old=state.links[key(captured.item)]||{};
    state.links[key(captured.item)]={anilistId:Number(result.anilistId)||0,malId:Number(result.malId)||0,confirmed:!!old.confirmed};
    if(result.conflict){current.state='conflict';current.error='An existing provider status differs from Kuro.';current.tries=0}
    else state.queue=state.queue.filter(j=>j!==current);
   }
  }catch(e){
   const current=state.queue.find(j=>j.id===captured.id);if(current&&current.rev===captured.rev){
    const text=String(e?.message||'Sync could not be completed.').slice(0,300);current.error=text.replace(/^MATCH_REQUIRED:\s*/, '');
    if(/^MATCH_REQUIRED:/.test(text)||/HTTP 404/.test(text))current.state='match';
    else if(/HTTP (?:400|401|403)|session expired|account changed|sign in again/i.test(text))current.state='blocked';
    else{
     current.state='pending';current.tries=Math.min(8,(Number(current.tries)||0)+1);
     const found=text.match(/retry after (\d+) seconds/i),seconds=found?Math.max(1,Math.min(86400,Number(found[1]))):0;
     const wait=seconds?seconds*1000:Math.min(900000,15000*Math.pow(2,current.tries-1));
     current.retryAt=Date.now()+wait;if(/HTTP 429/.test(text))state.cooldown[captured.provider]=current.retryAt;
    }
   }
  }finally{
   busy=false;persist();paint();nextAt=Date.now()+6500;schedule(6500);
  }
 }
 window.kuroSyncConnections553=con=>{
  if(unreadable)return;connections=con||{};
  for(const p of providers){const o=owner(p);if(o&&enabled(p))backfill(p,o)}
  persist();paint();schedule();
 };
 window.kuroSyncCategoryChanged553=(item,status)=>{
  if(unreadable)return;
  if(!names[status]){state.queue=state.queue.filter(j=>key(j.item)!==key(item));persist();paint();return}
  for(const p of providers){const o=owner(p);if(o&&enabled(p))upsert(p,o,item,status,'status')}
  persist();paint();schedule();
 };
 const watchedChanges=new Map();let watchedTimer=null;
 window.kuroSyncWatchedChanged553=item=>{
  watchedChanges.set(key(item),item);if(watchedTimer)return;
  watchedTimer=setTimeout(()=>{watchedTimer=null;if(unreadable)return;
   for(const item of watchedChanges.values())for(const p of providers){const o=owner(p);if(o&&enabled(p))upsert(p,o,item,categoryFor(item),'watch')}
   watchedChanges.clear();persist();paint();schedule();
  },0);
 };
 window.kuroEpisodeEnded553=(id,number)=>{
  const chain=currentWatchChain,n=Number(number);
  if(!chain||chain.id!==id||!chain.alive()||!chain.launched||chain.blocked||!selected||selected.verifyTitle||!Number.isInteger(n)||n<1||n>5000||Number(chain.number)!==n||Number(episode?.number)!==n)return;
  if(!watchedHas(selected,n))watchedSet(selected,n,true);
 };
 function resume(){background=false;if(window.kuroTrackerRequest553)window.kuroTrackerRequest553('status',{}).then(s=>window.kuroSyncConnections553(s.connections||{})).catch(()=>{});schedule()}
 window.kuroSyncResume553=resume;
 window.kuroSyncSuspend553=()=>{background=true;if(timer)clearTimeout(timer);timer=null;timerAt=0};
 window.addEventListener('online',()=>schedule());
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule()});
 function closeMatch(){document.querySelector('#tracker-match553')?.remove()}
 function showMatch(job){
  if(!job||unreadable)return;closeMatch();const overlay=document.createElement('div');overlay.id='tracker-match553';overlay.className='status-overlay';
  overlay.innerHTML=`<section class="status-dialog tracker-match553" role="dialog" aria-modal="true" aria-labelledby="tracker-match-title553"><div class="status-heading"><h2 id="tracker-match-title553">Match this anime</h2><button type="button" class="status-close" aria-label="Close">×</button></div><div class="tracker-match-body553"><p>Choose the exact series and season for <strong>${escapeHTML(job.item.title)}</strong>. No title is selected automatically.</p><label for="tracker-query553">Anime title</label><input id="tracker-query553" type="search" maxlength="160" autocomplete="off"><button type="button" id="tracker-search553">Search AniList</button><p class="tracker-result-note553" role="status" aria-live="polite"></p><div class="tracker-results553"></div></div></section>`;
  document.body.appendChild(overlay);const input=overlay.querySelector('#tracker-query553'),results=overlay.querySelector('.tracker-results553'),note=overlay.querySelector('.tracker-result-note553');input.value=job.item.title.slice(0,160);
  overlay.querySelector('.status-close').onclick=closeMatch;overlay.onclick=e=>{if(e.target===overlay)closeMatch()};overlay.addEventListener('keydown',e=>{if(e.key==='Escape')closeMatch()});
  let matches=[];
  function draw(){
   results.innerHTML=matches.map((m,i)=>`<button type="button" class="tracker-candidate553" data-candidate553="${i}"><strong>${escapeHTML(m.title)}</strong><small>${escapeHTML(m.romaji||'')} · ${escapeHTML(String(m.year||'Year unknown'))} · ${escapeHTML(m.format||'Anime')} · ${m.episodes?escapeHTML(String(m.episodes))+' episodes':'Episodes unknown'}</small></button>`).join('');
   results.querySelectorAll('[data-candidate553]').forEach(b=>b.onclick=()=>{
    const m=matches[Number(b.dataset.candidate553)];if(!m)return;
    note.textContent='Confirm that this is the exact season. A wrong choice can update a different anime.';
    results.innerHTML=`<div class="tracker-confirm553"><strong>${escapeHTML(m.title)}</strong><small>${escapeHTML(m.romaji||'')} · ${escapeHTML(String(m.year||'Year unknown'))} · ${escapeHTML(m.format||'Anime')}</small><button type="button" id="tracker-confirm553">Use this exact anime</button><button type="button" id="tracker-back553">Back to results</button></div>`;
    results.querySelector('#tracker-back553').onclick=draw;
    results.querySelector('#tracker-confirm553').onclick=()=>{
     const a=Number(m.anilistId),mal=Number(m.malId)||0;if(!Number.isInteger(a)||a<1)return;
     state.links[key(job.item)]={anilistId:a,malId:mal,confirmed:true};
     for(const j of state.queue)if(key(j.item)===key(job.item)){j.state='pending';j.retryAt=0;j.error='';j.rev=++state.seq}
     if(!persist()){note.textContent='Could not save this match on the phone. Nothing was sent.';return}
     closeMatch();paint();schedule();
    };
   });
  }
  overlay.querySelector('#tracker-search553').onclick=async()=>{
   const button=overlay.querySelector('#tracker-search553');button.disabled=true;note.textContent='Searching AniList…';results.innerHTML='';
   try{const r=await window.kuroTrackerRequest553('trackerSearch',{query:input.value.trim()});if(!overlay.isConnected)return;matches=Array.isArray(r.items)?r.items:[];note.textContent=matches.length?'Select the matching season or film.':'No eligible matches found. Try another title.';draw()}
   catch(e){if(overlay.isConnected)note.textContent=String(e?.message||'Search unavailable. Try again later.')}
   finally{if(overlay.isConnected)button.disabled=false}
  };
 }
 function paint(){
  const box=document.querySelector('#tracker-sync553');if(!box)return;
  if(unreadable){box.innerHTML='<section class="account-section"><h2>Tracker sync</h2><p>Your sync queue could not be read. It was not changed; keep your app data.</p></section>';return}
  const active=state.queue.filter(j=>owner(j.provider)===j.owner),other=state.queue.length-active.length;
  const pending=active.filter(j=>j.state==='pending').length,match=active.filter(j=>j.state==='match'),conflicts=active.filter(j=>j.state==='conflict'),blocked=active.filter(j=>j.state==='blocked');
  const rows=[...match,...conflicts,...blocked].slice(0,12);
  box.innerHTML=`<section class="account-section tracker553"><div class="account-section-head"><h2>Tracker sync</h2><p>Connected trackers can receive your Kuro status and watched episodes while the app is open. Opening an episode alone does not mark it watched.</p></div><div class="tracker-toggles553">${providers.map(p=>`<button type="button" data-sync-toggle553="${p}" aria-pressed="${enabled(p)}">${labels[p]} sync: ${enabled(p)?'On':'Off'}</button>`).join('')}</div><p class="tracker-note553" role="status">${pending} pending · ${match.length} need a match · ${conflicts.length} status conflicts · ${blocked.length} need attention${other?' · '+other+' saved for a different account':''}${storageError?' · Could not save queue; no updates will be sent':''}</p><p class="tracker-note553">Existing conflicting provider statuses are kept until you choose. Progress is never intentionally lowered; scores, notes and provider entries are not deleted. Some players need manual “Mark watched”.</p>${rows.map((j,i)=>`<div class="tracker-review553"><strong>${escapeHTML(j.item.title)}</strong><small>${escapeHTML(labels[j.provider])} · ${escapeHTML(j.error||'Needs attention')}</small><div>${j.state==='match'?`<button type="button" data-sync-match553="${i}">Find exact anime</button>`:j.state==='conflict'?`<button type="button" data-sync-apply553="${i}">Use Kuro: ${escapeHTML(names[j.status])}</button><button type="button" data-sync-keep553="${i}">Keep provider status</button>`:`<button type="button" data-sync-retry-one553="${i}">Retry</button>`}</div></div>`).join('')}${match.length+conflicts.length+blocked.length>rows.length?'<p class="tracker-note553">More items will appear as these are resolved.</p>':''}<button type="button" class="tracker-retry553" id="tracker-retry553">Retry pending sync</button></section>`;
  box.querySelectorAll('[data-sync-toggle553]').forEach(b=>b.onclick=()=>{const p=b.dataset.syncToggle553;state.auto[p]=!enabled(p);if(enabled(p)){const o=owner(p);if(o){delete state.initialized[p+'|'+o];backfill(p,o)}}persist();paint();schedule()});
  box.querySelectorAll('[data-sync-match553]').forEach(b=>b.onclick=()=>showMatch(rows[Number(b.dataset.syncMatch553)]));
  box.querySelectorAll('[data-sync-apply553]').forEach(b=>b.onclick=()=>{const j=rows[Number(b.dataset.syncApply553)];if(!j)return;j.intent='status';j.state='pending';j.retryAt=0;j.error='';j.rev=++state.seq;persist();paint();schedule()});
  box.querySelectorAll('[data-sync-keep553]').forEach(b=>b.onclick=()=>{const j=rows[Number(b.dataset.syncKeep553)];state.queue=state.queue.filter(x=>x!==j);persist();paint()});
  box.querySelectorAll('[data-sync-retry-one553]').forEach(b=>b.onclick=()=>{const j=rows[Number(b.dataset.syncRetryOne553)];if(!j)return;j.state='pending';j.retryAt=0;j.error='';j.rev=++state.seq;persist();paint();schedule()});
  box.querySelector('#tracker-retry553').onclick=()=>{for(const j of active)if(j.state==='blocked'||j.state==='pending'){j.state='pending';j.retryAt=0;j.error='';j.rev=++state.seq}persist();paint();schedule()};
 }
 window.kuroSyncPaint553=paint;
 if(window.kuroTrackerRequest553)resume();
})();

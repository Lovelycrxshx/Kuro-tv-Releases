'use strict';
/* User-supplied offline artwork, a reversible preview, and a one-time migration. */
(()=>{
 const PROFILE='kuro-profile-v1',CARDS='kuro-profile-card-art-v1',JOURNAL='kuro-profile-preset-journal571-v1',MIGRATION='kuro-profile-migrated571-v1';
 const entries=Array.isArray(window.KURO_PRESETS571)?window.KURO_PRESETS571:[];
 const avatars=new Set(entries.map(x=>x.avatar)),banners=new Set(entries.map(x=>x.banner));
 const plain=x=>!!x&&typeof x==='object'&&!Array.isArray(x);
 // 5.72: each card keeps its own dim and soften values next to its background.
 const clampDim=v=>Math.max(0,Math.min(80,Math.round((Number(v)||0)/5)*5));
 const clampSoft=v=>Math.max(0,Math.min(20,Math.round((Number(v)||0)/2)*2));
 const normalizeAdjust=a=>({dim:clampDim(a&&a.dim),soft:clampSoft(a&&a.soft)});
 const rawObject=(key)=>{const text=localStorage.getItem(key);if(text===null)return {};let value;try{value=JSON.parse(text)}catch(_){throw Error('Saved profile artwork could not be read. Nothing was changed.')}if(!plain(value))throw Error('Saved profile artwork is invalid. Nothing was changed.');return value};
 const showWarning=()=>{window.kuroLocalRestoreWarning='Profile artwork migration or recovery could not finish. Keep your app data; do not clear or uninstall.'};
 function recover(){
  const raw=localStorage.getItem(JOURNAL);if(!raw)return;
  const j=JSON.parse(raw);if(!plain(j)||j.version!==1||!plain(j.before))throw Error('Invalid artwork recovery journal');
  for(const [key,value] of Object.entries(j.before))if(![PROFILE,CARDS].includes(key)||!(value===null||typeof value==='string'))throw Error('Invalid artwork recovery journal');
  for(const [key,value] of Object.entries(j.before))value===null?localStorage.removeItem(key):localStorage.setItem(key,value);
  localStorage.removeItem(JOURNAL);
 }
 function migrate(){
  // Do not create an empty profile: an existing backup must still be restorable
  // on a phone with no profile. The per-device marker is separate from backups.
  if(localStorage.getItem(MIGRATION)==='1')return false;
  const existing=localStorage.getItem(PROFILE);
  if(existing===null){localStorage.setItem(MIGRATION,'1');return false}
  const p=rawObject(PROFILE);if(p.presetSchema571===1){localStorage.setItem(MIGRATION,'1');return false}
  p.avatar='';p.banner='';p.presetSchema571=1;
  localStorage.setItem(PROFILE,JSON.stringify(p));localStorage.setItem(MIGRATION,'1');return true;
 }

 function prepare(){try{recover();const changed=migrate();if(changed)window.kuroRefreshHeader560?.();return true}catch(_){showWarning();return false}}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',prepare,{once:true});else prepare();
 function commit(draft,touched,adjust,adjustTouched){
  // Older callers pass only two arguments; then no adjustment is rewritten.
  const adjustKinds=adjustTouched instanceof Set?adjustTouched:new Set();
  recover(); // Never overwrite a prior interrupted Apply.
  const changes={};
  if(touched.has('avatar')||touched.has('profile')){
   const existed=localStorage.getItem(PROFILE)!==null,p=rawObject(PROFILE);
   if(!existed)p.name=''; // A newly selected image must remain exportable before a username is set.
   if(touched.has('avatar')){if(!avatars.has(draft.avatar))throw Error('Please choose a supplied profile picture.');p.avatar=draft.avatar}
   if(touched.has('profile')){if(!banners.has(draft.profile))throw Error('Please choose a supplied profile banner.');p.banner=draft.profile}
   p.presetSchema571=1;changes[PROFILE]=JSON.stringify(p);
  }
  if(touched.has('anime')||touched.has('history')||adjustKinds.has('anime')||adjustKinds.has('history')){
   const p=rawObject(CARDS);
   for(const kind of ['anime','history']){
    const imageChanged=touched.has(kind),adjustChanged=adjustKinds.has(kind);
    if(!imageChanged&&!adjustChanged)continue;
    // Only a new picture has to be one of the supplied choices. Adjusting the
    // dim or soften of an older background must never force a new picture.
    if(imageChanged){if(!banners.has(draft[kind]))throw Error('Please choose a supplied background.');p[kind]=draft[kind];}
    const a=adjust&&plain(adjust[kind])?adjust[kind]:null;
    // Another card's values and any older keys are left exactly as they were.
    if(a&&adjustChanged){p[kind+'Dim']=clampDim(a.dim);p[kind+'Soften']=clampSoft(a.soft)}
   }
   changes[CARDS]=JSON.stringify(p);
  }
  const keys=Object.keys(changes);if(!keys.length)return false;
  const before=Object.fromEntries(keys.map(k=>[k,localStorage.getItem(k)]));
  try{
   localStorage.setItem(JOURNAL,JSON.stringify({version:1,before}));
   for(const key of keys)localStorage.setItem(key,changes[key]);
   localStorage.removeItem(JOURNAL);
  }catch(_){
   try{for(const [key,value] of Object.entries(before))value===null?localStorage.removeItem(key):localStorage.setItem(key,value);localStorage.removeItem(JOURNAL)}catch(__){showWarning()}
   throw Error('Could not save artwork safely. Your previous selections were kept or will be recovered.');
  }
  return true;
 }
 function mount(host,{initial='avatar',current={},onApply=()=>{},onCancel=()=>{}}={}){
  if(!host||!entries.length)throw Error('The supplied artwork is unavailable.');
  const tabs=[['avatar','PFP'],['profile','Banner'],['anime','Anime'],['history','History']];
  let selected=tabs.some(([k])=>k===initial)?initial:'avatar';
  const draft={avatar:current.avatar||'',profile:current.profile||'',anime:current.anime||'',history:current.history||''},touched=new Set(),adjustTouched=new Set();
  const adjust={anime:normalizeAdjust(current.adjust&&current.adjust.anime),history:normalizeAdjust(current.adjust&&current.adjust.history)};
  host.innerHTML=`<p class="preset-intro571">Your supplied pictures stay on this phone. Tap a picture to preview it, then Apply or Cancel.</p>
   <div class="preset-preview571" aria-label="Profile artwork preview">
    <div class="preset-preview-banner571"><img class="preset-preview-cover571" alt=""><div class="preset-preview-overlay571"></div></div>
    <div class="preset-preview-person571"><img class="preset-preview-avatar571" alt=""><div><strong>Profile preview</strong><small>Only a preview until you apply</small></div></div>
    <div class="preset-preview-cards571"><div><img data-preview="anime" alt=""><span>Anime</span></div><div><img data-preview="history" alt=""><span>History</span></div></div>
   </div>
   <div class="preset-tabs571" role="tablist" aria-label="Artwork categories"></div>
   <p class="preset-status571" role="status" aria-live="polite"></p>
   <div class="preset-grid571" aria-label="Artwork choices"></div>
   <div class="preset-adjust571" hidden>
    <div class="preset-adjust-head571"><strong data-adjust-title>Background</strong><small>Anime and History are adjusted separately. Nothing is saved until you apply.</small></div>
    <label class="preset-slider571"><span>Dim <b data-adjust-value="dim">0%</b></span><input type="range" data-adjust="dim" min="0" max="80" step="5" value="0" aria-label="Dim this background"></label>
    <label class="preset-slider571"><span>Soften <b data-adjust-value="soft">Off</b></span><input type="range" data-adjust="soft" min="0" max="20" step="2" value="0" aria-label="Soften this background"></label>
   </div>
   <div class="preset-actions571"><button type="button" data-cancel>Cancel</button><button type="button" data-apply>Apply</button></div>`;
  const tabbar=host.querySelector('.preset-tabs571'),grid=host.querySelector('.preset-grid571'),status=host.querySelector('.preset-status571');
  const setImage=(el,src,fallback='')=>{if(src){el.src=src;el.hidden=false}else if(fallback){el.src=fallback;el.hidden=false}else{el.removeAttribute('src');el.hidden=true}};
  const adjustBox=host.querySelector('.preset-adjust571'),adjustTitle=host.querySelector('[data-adjust-title]');
  const sliders={dim:host.querySelector('[data-adjust="dim"]'),soft:host.querySelector('[data-adjust="soft"]')};
  const valueLabels={dim:host.querySelector('[data-adjust-value="dim"]'),soft:host.querySelector('[data-adjust-value="soft"]')};
  const adjusting=()=>selected==='anime'||selected==='history'?selected:'';
  function paintPreview(){
   setImage(host.querySelector('.preset-preview-cover571'),draft.profile);
   setImage(host.querySelector('.preset-preview-avatar571'),draft.avatar,'profile-default571.png');
   for(const k of ['anime','history']){
    const img=host.querySelector(`[data-preview="${k}"]`);setImage(img,draft[k]);
    if(img&&img.style){const a=adjust[k];img.style.filter=`brightness(${(0.65*(1-a.dim/100)).toFixed(3)}) blur(${a.soft}px)`;img.style.transform=`scale(${(1+a.soft*0.004).toFixed(3)})`}
   }
  }
  function syncAdjust(){
   const kind=adjusting();
   if(adjustBox)adjustBox.hidden=!kind;
   if(!kind)return;
   const label=tabs.find(x=>x[0]===kind)[1];
   if(adjustTitle)adjustTitle.textContent=label+' background';
   if(sliders.dim)sliders.dim.value=String(adjust[kind].dim);
   if(sliders.soft)sliders.soft.value=String(adjust[kind].soft);
   if(valueLabels.dim)valueLabels.dim.textContent=adjust[kind].dim+'%';
   if(valueLabels.soft)valueLabels.soft.textContent=adjust[kind].soft?adjust[kind].soft+'px':'Off';
  }
  function bindAdjust(){
   for(const key of ['dim','soft']){
    const el=sliders[key];if(!el)continue;
    el.oninput=()=>{
     const kind=adjusting();if(!kind)return;
     if(!draft[kind]){el.value=String(adjust[kind][key]);status.textContent='Choose a background picture first, then adjust it.';return}
     adjust[kind][key]=key==='dim'?clampDim(el.value):clampSoft(el.value);
     if(valueLabels[key])valueLabels[key].textContent=key==='dim'?adjust[kind][key]+'%':(adjust[kind][key]?adjust[kind][key]+'px':'Off');
     adjustTouched.add(kind);paintPreview();
     status.textContent=`${tabs.find(x=>x[0]===kind)[1]} preview adjusted. Apply to save it.`;
    };
   }
  }
  function draw(){
   tabbar.innerHTML='';for(const [key,label] of tabs){const b=document.createElement('button');b.type='button';b.textContent=label;b.dataset.tab=key;b.setAttribute('role','tab');b.setAttribute('aria-selected',String(key===selected));b.onclick=()=>{selected=key;draw()};tabbar.append(b)}
   grid.classList.toggle('is-avatar571',selected==='avatar');grid.replaceChildren();
   const prop=selected==='avatar'?'avatar':'banner';
   for(const item of entries){
    const file=item[prop],button=document.createElement('button');button.type='button';button.dataset.preset=file;button.className='preset-choice571';
    button.setAttribute('aria-label',`${tabs.find(x=>x[0]===selected)[1]}: ${item.label}`);button.setAttribute('aria-pressed',String(draft[selected]===file));
    const img=document.createElement('img');img.src=file;img.alt='';img.loading='lazy';img.decoding='async';button.append(img);
    const mark=document.createElement('span');mark.className='preset-check571';mark.setAttribute('aria-hidden','true');mark.textContent='✓';button.append(mark);
    button.onclick=()=>{draft[selected]=file;touched.add(selected);for(const other of grid.querySelectorAll('button'))other.setAttribute('aria-pressed',String(other===button));status.textContent=`${tabs.find(x=>x[0]===selected)[1]} preview selected. Apply to save it.`;paintPreview()};
    grid.append(button);
   }
   status.textContent=`${entries.length} supplied choices · ${tabs.find(x=>x[0]===selected)[1]}`;paintPreview();syncAdjust();
  }
  bindAdjust();
  host.querySelector('[data-cancel]').onclick=onCancel;
  host.querySelector('[data-apply]').onclick=()=>{try{const changed=commit(draft,touched,adjust,adjustTouched);onApply(changed)}catch(e){status.textContent=e.message||'Could not save your artwork.'}};
  draw();
 }
 /** Stored dim/soften for one card, already clamped to the allowed range. */
 function cardAdjust(kind){try{const v=rawObject(CARDS);return {dim:clampDim(v[kind+'Dim']),soft:clampSoft(v[kind+'Soften'])}}catch(_){return {dim:0,soft:0}}}
 /** Applies one card's values to any element that uses the card background variables. */
 function applyCardStyle(el,kind){
  if(!el||!el.style)return;
  const a=cardAdjust(kind);
  el.style.setProperty('--profile-card-dim571',(1-a.dim/100).toFixed(3));
  el.style.setProperty('--profile-card-soften571',a.soft+'px');
  el.style.setProperty('--profile-card-zoom571',(1+a.soft*0.004).toFixed(3));
 }
 window.kuroPresets571=Object.freeze({mount,prepare,commit,cardAdjust,applyCardStyle,clampDim,clampSoft,validAvatar:f=>avatars.has(f),validBanner:f=>banners.has(f)});
})();

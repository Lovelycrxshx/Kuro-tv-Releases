'use strict';
/* Kuro 5.60: HiAnime-style preferences, adapted to Kuro's player. */
(()=>{
 const KEY='kuro-settings560-v1';
 const choices={audio:['dub','default'],server1:['','Ryu','Volt','Warp','Ayame','HD-1'],server2:['','Ryu','Volt','Warp','Ayame','HD-1'],server3:['','Ryu','Volt','Warp','Ayame','HD-1'],keepOn:[true,false],errorAlerts:[true,false],siteView:['mobile','desktop'],orientation:['auto','portrait','landscape'],startup:['home','last'],theme:['dark','light'],accent:['purple','pink','blue','green','amber','teal','rose','ice'],pull:[true,false],handleSize:[40,48,56],handleOpacity:[60,80,100],textZoom:[85,100,115,130],brightness:[-1,40,70,100],adBlock:[true,false],thirdCookies:[true,false],external:['allow','ask','blocked']};
 const defaults=Object.freeze({audio:'dub',server1:'',server2:'',server3:'',keepOn:true,errorAlerts:false,siteView:'mobile',orientation:'auto',startup:'home',theme:'dark',accent:'purple',pull:false,handleSize:48,handleOpacity:100,textZoom:100,brightness:-1,adBlock:true,thirdCookies:false,external:'allow'});
 const colors={purple:'#c090f2',pink:'#f2a6d3',blue:'#83baff',green:'#8fdcb0',amber:'#efc47a',teal:'#7fd8d1',rose:'#f29c9c',ice:'#b8d9fa'};
 const valid=o=>!!o&&typeof o==='object'&&!Array.isArray(o)&&Object.keys(o).every(k=>Object.prototype.hasOwnProperty.call(choices,k)&&choices[k].includes(o[k]));
 function read(){try{let s=JSON.parse(localStorage.getItem(KEY)||'{}');return valid(s)?Object.assign({},defaults,s):{...defaults}}catch(_){return {...defaults}}}
 let state=read(),hooks={},loadedBackup=null;
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const native=()=>!!window.KuroNative&&typeof KuroNative.applySettings560==='function';
 function apply(){document.documentElement.dataset.kuroTheme=state.theme;document.documentElement.style.setProperty('--kuro-accent560',colors[state.accent]);document.documentElement.style.setProperty('--kuro-handle-size560',state.handleSize+'px');document.documentElement.style.setProperty('--kuro-handle-alpha560',String(state.handleOpacity/100));for(const el of document.querySelectorAll('.kuro-layer560,.profile-overlay560'))el.dataset.theme=state.theme;try{if(native())KuroNative.applySettings560(JSON.stringify(state))}catch(_){}}
 function save(key,value){if(!choices[key]?.includes(value))return false;const next={...state,[key]:value};try{localStorage.setItem(KEY,JSON.stringify(next));state=next;apply();return true}catch(_){notice('Could not save this setting on your phone.');return false}}
 function notice(text){let e=document.querySelector('#discord-notice569')||document.querySelector('#transfer-notice560')||document.querySelector('#settings-notice560');if(e){e.textContent=text;e.hidden=false}else if(typeof placeholder==='function')placeholder(text)}
 function select(k,title,description,labels){let options=choices[k].map((v,i)=>`<option value="${esc(String(v))}" ${state[k]===v?'selected':''}>${esc(labels[i])}</option>`).join('');return `<label class="settings-row560" data-filter="${esc((title+' '+description).toLowerCase())}"><span><strong>${esc(title)}</strong><small>${esc(description)}</small></span><select data-setting="${esc(k)}" aria-label="${esc(title)}">${options}</select></label>`}
 function action(id,title,description,android=false){return `<button type="button" class="settings-row560 settings-action560" data-action="${esc(id)}" data-filter="${esc((title+' '+description).toLowerCase())}" ${android&&!native()?'disabled':''}><span><strong>${esc(title)}</strong><small>${esc(description)}${android&&!native()?' · Android app only':''}</small></span><b aria-hidden="true">›</b></button>`}
 function rpcControl563(){
  let ok=native()&&typeof KuroNative.discordRpcEnabled563==='function'&&typeof KuroNative.setDiscordRpcEnabled563==='function',enabled=false;
  try{enabled=ok&&!!KuroNative.discordRpcEnabled563()}catch(_){ok=false}
  return `<label class="settings-row560" data-filter="discord rich presence share activity"><span><strong>Share activity</strong><small>Send “Watching Kuro.tv” to the selected account targets. Off by default.</small></span><select data-rpc563 aria-label="Discord Rich Presence" ${ok?'':'disabled'}><option value="false" ${!enabled?'selected':''}>Off</option><option value="true" ${enabled?'selected':''}>On</option></select></label>`;
 }
 const rpcSpecs564=[
  ['layout','Presence layout','Choose which line comes first.',['anime','episode'],['Anime first','Episode first']],
  ['separator','Separator style','Separates available episode details.',['dot','bar','dash'],['Dot ·','Bar |','Dash —']],
  ['title','Show anime title','Hiding the title also hides the episode name and poster.',['show','hide'],['Show','Hide']],
  ['episode','Show episode number and name','Hiding the episode also hides the episode name.',['show','hide'],['Show','Hide']],
  ['poster','Artwork','Uses an anime cover, not an episode thumbnail. Kuro may search AniList or Kitsu by title; otherwise the app icon is used.',['show','icon'],['Anime poster','App icon']],
  ['server','Show server','Uses the visible selected server when available.',['on','off'],['Show','Hide']],
  ['total','Show episode total','Only when the source reports a valid total.',['on','off'],['Show','Hide']],
  ['current','Current account sharing','Send to the account in the signed-in Discord Android app.',['on','off'],['On','Off']],
  ['linked','Linked account sharing','Send separately to the account you explicitly authorize below.',['on','off'],['On','Off']],
  ['pause','When playback pauses','Progress is hidden or the activity is cleared only when Kuro can detect a pause.',['show','noProgress','clear1','clear5'],['Show progress','Hide progress','Clear after 1 minute','Clear after 5 minutes']],
  ['buffering','Show buffering status','For supported players when buffering is detected.',['on','off'],['Show','Hide']],
  ['notification','Playback notification','Optional while playback is open. Controls are available only for supported players.',['on','off'],['On','Off']]
 ];
 function rpcOptions564(){try{return typeof KuroNative?.discordOptions564==='function'?JSON.parse(KuroNative.discordOptions564()):{}}catch(_){return {}}}
 function rpcSettings564(){
  let o=rpcOptions564(),ok=native()&&typeof KuroNative.setDiscordOption564==='function';
  return rpcSpecs564.map(([key,title,description,values,labels])=>`<label class="settings-row560" data-filter="${esc((title+' '+description+' discord presence').toLowerCase())}"><span><strong>${esc(title)}</strong><small>${esc(description)}</small></span><select data-rpc564="${esc(key)}" aria-label="${esc(title)}" ${ok?'':'disabled'}>${values.map((v,i)=>`<option value="${esc(v)}" ${o[key]===v?'selected':''}>${esc(labels[i])}</option>`).join('')}</select></label>`).join('');
 }
 // Replace Android's white native select popups with an accessible themed sheet.
 function syncChoice567(select){
  const button=select.__choiceButton567;if(!button)return;
  const option=select.options[select.selectedIndex],label=option?.textContent||'Choose';
  button.querySelector('.choice-value567').textContent=label;
  button.setAttribute('aria-label',(select.getAttribute('aria-label')||'Option')+': '+label);
  button.disabled=select.disabled;
 }
 function openChoice567(root,select,trigger){
  if(select.disabled||!root.isConnected)return;
  const previous=root.querySelector('.choice-backdrop567');if(previous)previous.remove();
  const backdrop=document.createElement('div');backdrop.className='choice-backdrop567';
  const panel=document.createElement('section');panel.className='choice-panel567';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');
  const title=document.createElement('h2');title.id='choice-title567';title.textContent=select.getAttribute('aria-label')||'Choose an option';panel.setAttribute('aria-labelledby',title.id);
  const heading=document.createElement('div');heading.className='choice-head567';
  const copy=document.createElement('div');const eyebrow=document.createElement('small');eyebrow.textContent='KURO.TV · SETTINGS';copy.append(eyebrow,title);
  const closeButton=document.createElement('button');closeButton.type='button';closeButton.className='choice-close567';closeButton.setAttribute('aria-label','Close choices');closeButton.textContent='×';heading.append(copy,closeButton);panel.append(heading);
  const list=document.createElement('div');list.className='choice-list567';list.setAttribute('role','radiogroup');list.setAttribute('aria-label',title.textContent);
  const close=()=>{if(!backdrop.isConnected)return;backdrop.remove();trigger.setAttribute('aria-expanded','false');if(trigger.isConnected)trigger.focus()};
  for(const option of Array.from(select.options)){
   if(option.disabled)continue;
   const row=document.createElement('button');row.type='button';row.className='choice-option567';row.setAttribute('role','radio');row.setAttribute('aria-checked',String(option.selected));row.dataset.choiceValue567=option.value;
   const text=document.createElement('span');text.textContent=option.textContent;const dot=document.createElement('i');dot.setAttribute('aria-hidden','true');row.append(text,dot);
   row.onclick=()=>{if(select.value!==option.value){select.value=option.value;select.dispatchEvent(new Event('change',{bubbles:true}))}syncChoice567(select);close()};list.append(row);
  }
  panel.append(list);backdrop.append(panel);root.append(backdrop);trigger.setAttribute('aria-expanded','true');
  closeButton.onclick=close;backdrop.onclick=e=>{if(e.target===backdrop)close()};
  backdrop.addEventListener('keydown',e=>{
   if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close();return}
   const options=Array.from(list.querySelectorAll('button'));let i=options.indexOf(document.activeElement);
   if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)&&options.length){e.preventDefault();i=e.key==='Home'?0:e.key==='End'?options.length-1:e.key==='ArrowDown'?(i+1+options.length)%options.length:(i-1+options.length)%options.length;options[i].focus();return}
   if(e.key==='Tab'){
    const focusable=[closeButton,...options],at=focusable.indexOf(document.activeElement);
    if(e.shiftKey&&at<=0){e.preventDefault();focusable[focusable.length-1].focus()}
    else if(!e.shiftKey&&at===focusable.length-1){e.preventDefault();focusable[0].focus()}
   }
  });
  (list.querySelector('[aria-checked="true"]')||closeButton).focus();
 }
 function mountChoices567(root){
  root.querySelectorAll('.settings-row560 select').forEach(select=>{
   if(select.__choiceButton567)return;
   const trigger=document.createElement('button');trigger.type='button';trigger.className='settings-choice567';
   trigger.dataset.choiceFor=select.dataset.setting||select.dataset.rpc564||(select.hasAttribute('data-rpc563')?'rpc563':'choice');
   trigger.setAttribute('aria-haspopup','dialog');trigger.setAttribute('aria-expanded','false');
   const value=document.createElement('span');value.className='choice-value567';const arrow=document.createElement('span');arrow.className='choice-chevron567';arrow.setAttribute('aria-hidden','true');arrow.textContent='⌄';trigger.append(value,arrow);
   select.classList.add('settings-select-hidden567');select.setAttribute('aria-hidden','true');select.tabIndex=-1;select.insertAdjacentElement('afterend',trigger);select.__choiceButton567=trigger;syncChoice567(select);
   select.addEventListener('change',()=>syncChoice567(select));
   trigger.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openChoice567(root,select,trigger)});
   const row=select.closest('label');if(row)row.addEventListener('click',e=>{if(e.target===trigger||trigger.contains(e.target))return;e.preventDefault();if(!select.disabled)openChoice567(root,select,trigger)});
  });
 }
 function group(title,description,content){return `<section class="settings-group560" data-section="${esc(title.toLowerCase())}"><div class="settings-group-head560"><h3>${esc(title)}</h3><p>${esc(description)}</p></div><div class="settings-rows560">${content}</div></section>`}
 function presenceGroup569(){return group('Discord Rich Presence','While visible or in picture-in-picture, Kuro requests updates every 3 seconds. Discord may delay or throttle them. Background clearing is best-effort.',rpcControl563()+action('preview571','Preview locally','Illustrative sample; does not publish or connect')+action('rpcStatus563','Connection status','Check current and linked account status and last accepted updates',true)+action('rpcHistory564','Connection history','Recent local connection events; no tokens or anime names',true)+action('rpcTest564','Send 15-second test','Send a temporary generic activity to enabled targets',true)+action('rpcClear564','Clear presence','Turn sharing off and request removal on both targets',true)+action('rpcReconnectCurrent564','Reconnect current account','Reconnect the installed Discord Android app',true)+action('rpcReconnectLinked564','Reconnect linked account','Reconnect the separately authorized account',true)+action('rpcLink564','Link another Discord account','Authorize through Discord in your browser',true)+action('rpcUnlink564','Disconnect linked account','Remove the authorization from this phone',true)+action('connections','Account connections','Manage Discord, MyAnimeList and AniList'))}
 function customizationGroup569(){return group('Presence customization','Title, episode, artwork, privacy and playback choices. Some details are unavailable in embedded players.',rpcSettings564())}
 function layer(id,title,subtitle){let old=document.getElementById(id);if(old)old.remove();let root=document.createElement('div');root.__returnFocus573=document.activeElement;root.id=id;root.className='kuro-layer560';root.dataset.theme=state.theme;root.innerHTML=`<section class="settings-panel560" role="dialog" aria-modal="true" aria-labelledby="${id}-title"><div class="settings-header560"><button type="button" class="settings-back560" aria-label="Back">‹</button><div><h2 id="${id}-title">${esc(title)}</h2><p>${esc(subtitle)}</p></div><button type="button" class="settings-close560" aria-label="Close">×</button></div><div class="settings-body560"></div></section>`;document.body.appendChild(root);root.onclick=e=>{if(e.target===root)close(id)};root.querySelector('.settings-back560').onclick=()=>close(id);root.querySelector('.settings-close560').onclick=()=>close(id);root.addEventListener('keydown',e=>{if(e.defaultPrevented)return;if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close(id);return}if(e.key==='Tab'){const list=[...root.querySelectorAll('button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]):not([aria-hidden=true]),textarea:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])')].filter(x=>x.offsetWidth||x.offsetHeight||x.getClientRects().length);if(!list.length)return;const i=list.indexOf(document.activeElement);if(e.shiftKey&&i<=0){e.preventDefault();list[list.length-1].focus()}else if(!e.shiftKey&&(i===-1||i===list.length-1)){e.preventDefault();list[0].focus()}}});queueMicrotask(()=>{if(root.isConnected)root.querySelector('.settings-back560')?.focus()});let edge=null;root.addEventListener('touchstart',e=>{let t=e.touches?.[0];edge=t&&t.clientX<=24?{x:t.clientX,y:t.clientY}:null},{passive:true});root.addEventListener('touchend',e=>{let t=e.changedTouches?.[0],start=edge;edge=null;if(!t||!start)return;let dx=t.clientX-start.x,dy=t.clientY-start.y;if(dx>80&&Math.abs(dx)>Math.abs(dy)*1.5)close(id)},{passive:true});return root}
 function close(id='settings-overlay560'){const root=document.getElementById(id);if(!root)return false;const returnFocus=root.__returnFocus573;root.remove();if(returnFocus?.isConnected&&typeof returnFocus.focus==='function')returnFocus.focus();if(id==='transfer-overlay560')loadedBackup=null;try{hooks.onClosed?.(id)}catch(_){}return true}
 function closeAll(){close('discord-overlay569');close('transfer-overlay560');close('settings-overlay560')}
 function bindRpc569(root,body){
  let rpc=body.querySelector('[data-rpc563]');if(rpc)rpc.onchange=()=>{try{const on=rpc.value==='true';KuroNative.setDiscordRpcEnabled563(on);notice(on?'Discord Rich Presence is on. Open the signed-in Discord app, then check your profile.':'Discord Rich Presence is off; Kuro requested removal of its activity.')}catch(_){rpc.value='false';notice('Discord Rich Presence could not be changed.')}};
  body.querySelectorAll('select[data-rpc564]').forEach(el=>el.onchange=()=>{try{if(!KuroNative.setDiscordOption564(el.dataset.rpc564,el.value))throw Error();notice('Discord presence setting saved on this phone.')}catch(_){notice('Could not save this Discord setting.');let o=rpcOptions564();if(o[el.dataset.rpc564])el.value=o[el.dataset.rpc564]}});
 }
 function open(h={}){hooks=h;const root=layer('settings-overlay560','Settings','Make Kuro feel like yours'),body=root.querySelector('.settings-body560');
  body.innerHTML=`<label class="settings-search560"><span aria-hidden="true">⌕</span><input type="search" id="settings-search560" autocomplete="off" placeholder="Search settings" aria-label="Search settings"></label><p id="settings-notice560" class="settings-notice560" role="status" hidden></p>`+
  group('Quick actions','Your viewing shortcuts',action('continue','Continue watching','Reopen your latest saved episode')+action('history','Watch history','View recently opened episodes')+action('watchlist','Watch list','Open My Lists')+action('bookmarks','Favorites','Open bookmarks')+action('pip','Picture-in-picture','Native playback supports play/pause; embedded player controls vary',true)+action('reload','Reload','Ask before refreshing the current page or player'))+
  group('Appearance and startup','Preferences for this device',select('siteView','Site view','Changes the player website view on the next player.',['Mobile','Desktop'])+select('orientation','Screen orientation','System rotation, portrait or landscape.',['Automatic','Portrait','Landscape'])+select('startup','Open app to','Last page restores a safe checkpoint, not live playback.',['Home','Last page'])+select('theme','App theme','Changes the main catalogue and Settings panel; some player and external screens keep their own colours.',['Dark','Light'])+select('accent','Accent color','Changes the menu and Settings accent.',['Purple','Pink','Blue','Green','Amber','Teal','Rose','Ice'])+select('pull','Pull to refresh','Ask before refreshing a supported Kuro page.',['On with confirmation','Off'])+select('handleSize','Sidebar handle size','Changes the close handle on the profile menu.',['Small','Medium','Large'])+select('handleOpacity','Sidebar handle opacity','Changes the close handle opacity.',['60%','80%','100%'])+select('textZoom','Website text size','Text size for Kuro and player WebViews.',['Small','Normal','Large','Extra large'])+action('resetZoom','Reset page zoom','Reset text zoom to normal')+select('brightness','App brightness','Only this app; does not change system brightness.',['System default','40%','70%','100%']))+
  group('Privacy and links','Blocking can affect some players',select('adBlock','Ad and tracker blocklist','Limited host and cosmetic filtering; applies to new players.',['On','Off'])+select('thirdCookies','Third-party cookies','Applies to player WebViews. Verification may need cookies.',['Allowed','Blocked'])+select('external','External links','Built-in links only; player redirects stay blocked and OAuth opens only when requested.',['Open when tapped','Ask before opening','Blocked'])+action('privacy571','Privacy & storage','Review sharing and clear selected local data')+action('queue571','Watch queue','Open your private local episode queue')+action('cache','Clear cache','Cached files only; accounts, lists and cookies are kept.',true)+action('diagnostics','Diagnostics','App and Android WebView information',true)+action('downloads','Manage downloads','View Kuro offline downloads',true)+action('transfer','Back up settings and lists','Export or safely merge a local file'))+
  presenceGroup569()+customizationGroup569()+
  group('Kuro updates','Checks the public Kuro release page',action('updates572','Update status and checks','Three reminders, then Kuro downloads and checks the update on this phone. Android always asks before installing.',true)+action('updatesInterval573','Update reminder spacing','Choose approximately 1, 2 or 3 days between notices. Android may delay them.',true)+action('updatesNetwork573','Update download network','Choose Wi-Fi only or allow mobile data. Release checks may use any network.',true))+
  group('Developer','About this app',action('developer','Developer · lovelycrxshxツ','Open the developer’s Discord profile',true)+action('licenses','Third-party notices','Read Discord SDK and other open-source licenses',true));
  bindRpc569(root,body);
  body.querySelectorAll('select[data-setting]').forEach(el=>el.onchange=()=>{let k=el.dataset.setting,found=choices[k].find(x=>String(x)===el.value);if(!save(k,found)){el.value=String(state[k]);return}if(k==='theme')root.dataset.theme=state.theme});body.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>runAction(b.dataset.action));const search=body.querySelector('#settings-search560');search.oninput=()=>{let q=search.value.trim().toLocaleLowerCase();body.querySelectorAll('.settings-group560').forEach(g=>{let sectionMatch=(g.dataset.section||'').includes(q),n=0;g.querySelectorAll('.settings-row560').forEach(r=>{let show=!q||sectionMatch||(r.dataset.filter||'').includes(q);r.hidden=!show;if(show)n++});g.hidden=!n})};mountChoices567(root);root.querySelector('.settings-back560').focus();apply();return root}
 function openDiscord569(mode='presence',h={}){
  if(!['presence','customization'].includes(mode))return;
  close('settings-overlay560');close('transfer-overlay560');hooks=h;
  const custom=mode==='customization';
  const root=layer('discord-overlay569',custom?'Presence customization':'Discord Rich Presence',custom?'Choose what your Discord activity shares':'Activity controls and account connections');
  const body=root.querySelector('.settings-body560');
  body.innerHTML='<p id="discord-notice569" class="settings-notice560" role="status" hidden></p>'+
   (custom?customizationGroup569()+action('discordPresence569','Discord Rich Presence','Manage sharing and account connections'):presenceGroup569()+action('discordCustomize569','Presence customization','Choose titles, artwork and privacy'));
  bindRpc569(root,body);body.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>runAction(b.dataset.action));mountChoices567(root);
  root.querySelector('.settings-back560').focus();
 }
 function runAction(id){if(id==='privacy571'||id==='preview571'||id==='queue571'){closeAll();hooks.closeMenu?.();if(id==='queue571')window.kuroQueue571?.open();else window.kuroPrivacy571?.open(id==='preview571'?'preview':'privacy');return}if(id==='discordPresence569'||id==='discordCustomize569'){openDiscord569(id==='discordPresence569'?'presence':'customization',hooks);return}if(['continue','history','watchlist','bookmarks','connections'].includes(id)){closeAll();hooks.navigate?.(id);return}if(id==='transfer'){openTransfer(hooks);return}if(id==='reload'){closeAll();hooks.reload?.();return}if(id==='resetZoom'){save('textZoom',100);const el=document.querySelector('[data-setting="textZoom"]');if(el){el.value='100';syncChoice567(el)}notice('Text zoom reset to normal.');return}if(id==='help'){notice('If a player fails, try a different numbered server. Some sources need verification or may be unavailable; Kuro cannot bypass these checks.');return}if(!native()){notice('This action is available in the Android app.');return}try{if(id==='rpcHistory564'){notice(typeof KuroNative.discordHistory564==='function'?KuroNative.discordHistory564():'Connection history is unavailable.');(document.querySelector('#discord-notice569')||document.querySelector('#settings-notice560'))?.scrollIntoView({block:'center'});return}const rpcActions={rpcClear564:'clear',rpcReconnectCurrent564:'current',rpcReconnectLinked564:'linked',rpcTest564:'test',rpcLink564:'link',rpcUnlink564:'unlink'};if(rpcActions[id]){if(typeof KuroNative.discordAction564!=='function'){notice('This Discord action is unavailable.');return}KuroNative.discordAction564(rpcActions[id]);if(id==='rpcClear564'){const el=document.querySelector('[data-rpc563]');if(el){el.value='false';syncChoice567(el)}}return}if(id==='rpcStatus563'){notice(typeof KuroNative.discordRpcStatus563==='function'?KuroNative.discordRpcStatus563():'Discord RPC is not available.');(document.querySelector('#discord-notice569')||document.querySelector('#settings-notice560'))?.scrollIntoView({block:'center'});return}if(id==='diagnostics'){notice(KuroNative.diagnostics560());return}if(id==='pip'){closeAll();hooks.closeMenu?.()}KuroNative.settingsAction560(id)}catch(_){notice('Could not open this Android action.')}}
 function openTransfer(h={}){hooks=h;const root=layer('transfer-overlay560','Import / Export','Your lists, your choice'),body=root.querySelector('.settings-body560');body.innerHTML=`<p class="transfer-intro560">Import from connected trackers, or use a local backup file. Existing Kuro entries win; importing never replaces your saved entries.</p><p id="transfer-notice560" class="settings-notice560" role="status" hidden></p>`+group('Trackers','Connect these accounts in Profile first.',action('mal','Import from MyAnimeList','Add missing anime without overwriting')+action('anilist','Import from AniList','Add missing anime without overwriting'))+group('Local file','Files are not encrypted. They can contain profile pictures and viewing history. They include the new menu settings, not Advanced video controls. Passwords, provider tokens and cookies are excluded. Restored tracker titles are hidden until reclassified.',action('export','Export local backup','Choose where to save a JSON file',true)+action('import','Import local backup','Preview and merge a Kuro backup',true))+`<div id="backup-preview560" class="backup-preview560" hidden></div>`;body.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>{const id=b.dataset.action;if(id==='mal'||id==='anilist'){hooks.importTracker?.(id,b);return}try{if(id==='export'){const text=window.kuroBackup560.exportText();KuroNative.backupFile560('export',text)}else if(id==='import')KuroNative.backupFile560('import','')}catch(e){notice(e.message||'Could not open the file picker.')}});root.querySelector('.settings-back560').focus();return root}
 // A restore remains a local-wins merge. Filtering is performed only after the
 // entire file has passed the existing validation and credential scrub.
 const restoreGroups560=[
  {id:'library',name:'Library and lists',keys:['kuro-library','kuro-categories-v1','kuro-imports-v1','kuro-watch-queue571-v1','kuro-anime-preferences571-v1']},
  {id:'history',name:'Viewing history and progress',keys:['kuro-recent','kuro-episode-history-v1','kuro-watched-v1','kuro-last-episode-v1']},
  {id:'profile',name:'Profile and artwork',keys:['kuro-profile-v1','kuro-profile-card-art-v1']},
  {id:'settings',name:'Menu settings',keys:['kuro-settings560-v1']}
 ];
 window.kuroBackupLoaded560=(text,error)=>{
  const box=document.querySelector('#backup-preview560');if(!box)return false;if(error){notice(error);return true}
  try{
   loadedBackup=window.kuroBackup560.preview(text);const data=loadedBackup.backup.data;
   const groups=restoreGroups560.filter(g=>g.keys.some(k=>Object.prototype.hasOwnProperty.call(data,k)));
   box.hidden=false;box.innerHTML=`<strong>Review backup</strong><p>${loadedBackup.summary} list entries in this file. Choose what to merge. Existing items and profiles are kept; account credentials are not restored.</p>${groups.map(g=>{const count=g.keys.reduce((n,k)=>n+(Array.isArray(data[k])?data[k].length:(data[k]&&typeof data[k]==='object'?Object.keys(data[k]).length:0)),0);return `<label class="backup-settings-option560"><input type="checkbox" data-restore-group="${g.id}" ${g.id==='settings'?'data-apply-settings':'checked'}> ${g.name} (${count} entries${g.id==='settings'?'; replaces current menu settings':''})</label>`}).join('')}<div><button type="button" data-cancel>Cancel</button><button type="button" data-confirm>Confirm merge</button></div>`;
   box.querySelector('[data-cancel]').onclick=()=>{loadedBackup=null;box.hidden=true;box.textContent=''};
   box.querySelector('[data-confirm]').onclick=()=>{try{
    const selected=restoreGroups560.filter(g=>box.querySelector(`[data-restore-group="${g.id}"]`)?.checked);
    if(!selected.length){notice('Select at least one section to restore.');return}
    const allowed=new Set(selected.flatMap(g=>g.keys));const subset=Object.fromEntries(Object.entries(data).filter(([k])=>allowed.has(k)));
    const result=window.kuroBackup560.merge({...loadedBackup.backup,data:subset},{applySettings:allowed.has('kuro-settings560-v1')});
    loadedBackup=null;box.hidden=true;box.textContent='';notice(`Merge finished: ${result.added} added, ${result.kept} already present and kept.${result.updated?' Menu settings restored.':''}`);hooks.restored?.()
   }catch(e){notice(e.message)}}
  }catch(e){loadedBackup=null;box.hidden=true;box.textContent='';notice(e.message)}return true
 };
 window.kuroSettings560=Object.freeze({open,openDiscord569,openTransfer,close,closeAll,snapshot:()=>({...state}),validate:valid,reload:()=>{state=read();apply()},isOpen:()=>!!document.querySelector('#settings-overlay560,#transfer-overlay560,#discord-overlay569')});
 let y0=0,x0=0,pullEligible=false;document.addEventListener('touchstart',e=>{const t=e.touches?.[0];pullEligible=!!(state.pull&&t&&window.scrollY===0&&!document.querySelector('#account-overlay,#settings-overlay560,#transfer-overlay560,#discord-overlay569,#search-popup,#news-overlay')&&!e.target.closest('input,textarea,select,button'));if(pullEligible){y0=t.clientY;x0=t.clientX}},{passive:true});document.addEventListener('touchend',e=>{const t=e.changedTouches?.[0];if(!pullEligible||!t)return;pullEligible=false;if(t.clientY-y0<90||Math.abs(t.clientX-x0)>60)return;window.kuroPullRefresh560?.()},{passive:true});apply();
})();

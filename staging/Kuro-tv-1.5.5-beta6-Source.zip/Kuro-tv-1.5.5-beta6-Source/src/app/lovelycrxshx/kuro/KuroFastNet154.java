package app.lovelycrxshx.kuro;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLException;
import okhttp3.ConnectionPool;
import okhttp3.Dns;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Kuro 1.5.4 high-speed HTTP/2 connection pool + Encrypted DNS-over-HTTPS (DoH)
 * ISP unblock resolver (Cloudflare 1.1.1.1 & Google 8.8.8.8 over IP-literal TLS).
 */
final class KuroFastNet154 {
    static final class SourceResult {
        final byte[] bytes;
        final String contentType;
        SourceResult(byte[] bytes, String contentType) {
            this.bytes = bytes;
            this.contentType = contentType == null ? "" : contentType;
        }
    }

    private static final class DnsEntry {
        final List<InetAddress> addresses;
        final long expiresAtMs;
        DnsEntry(List<InetAddress> addresses, long expiresAtMs) {
            this.addresses = addresses;
            this.expiresAtMs = expiresAtMs;
        }
    }

    private static final class CatalogCacheEntry {
        final String body;
        final long expiresAtMs;
        CatalogCacheEntry(String body, long expiresAtMs) {
            this.body = body;
            this.expiresAtMs = expiresAtMs;
        }
    }

    private static final long DNS_TTL_MS = 10L * 60L * 1000L;
    private static final long CATALOG_TTL_MS = 90L * 1000L;
    private static final MediaType JSON_MEDIA = MediaType.parse("application/json; charset=utf-8");

    private static volatile String dohMode = "auto"; // "auto" | "always" | "off"
    private static final ConcurrentHashMap<String, DnsEntry> dnsCache = new ConcurrentHashMap<>();
    private static final Set<String> poisonedHosts = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());

    private static final Map<String, CatalogCacheEntry> catalogCache = Collections.synchronizedMap(
            new LinkedHashMap<String, CatalogCacheEntry>(64, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, CatalogCacheEntry> eldest) {
                    return size() > 64;
                }
            });

    static final ConnectionPool POOL = new ConnectionPool(12, 3, TimeUnit.MINUTES);

    // Bootstrap client hits numeric IP literals (1.1.1.1 / 8.8.8.8 / 1.0.0.1) directly over TLS,
    // requiring zero system DNS resolution even when carrier DNS is poisoned or offline.
    private static final OkHttpClient DOH_CLIENT = new OkHttpClient.Builder()
            .connectionPool(new ConnectionPool(4, 2, TimeUnit.MINUTES))
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .followRedirects(false)
            .followSslRedirects(false)
            .build();

    static final Dns DNS = new Dns() {
        @Override
        public List<InetAddress> lookup(String hostname) throws UnknownHostException {
            if (hostname == null || hostname.isEmpty()) throw new UnknownHostException("Empty host");
            String host = hostname.trim().toLowerCase(Locale.ROOT);
            if ("localhost".equals(host) || isNumericIpLiteral(host)) {
                return Dns.SYSTEM.lookup(hostname);
            }

            long now = System.currentTimeMillis();
            DnsEntry cached = dnsCache.get(host);
            if (cached != null && cached.expiresAtMs > now && !cached.addresses.isEmpty()) {
                return cached.addresses;
            }

            String mode = dohMode;
            if ("off".equals(mode)) {
                List<InetAddress> sys = Dns.SYSTEM.lookup(hostname);
                putDnsCache(host, sys, now + DNS_TTL_MS);
                return sys;
            }

            boolean forceDoh = "always".equals(mode) || poisonedHosts.contains(host);
            if (!forceDoh) {
                try {
                    List<InetAddress> sys = Dns.SYSTEM.lookup(hostname);
                    List<InetAddress> clean = filterValidPublicAddresses(sys);
                    if (!clean.isEmpty()) {
                        putDnsCache(host, clean, now + DNS_TTL_MS);
                        return clean;
                    }
                    markPoisoned(host);
                } catch (UnknownHostException ignored) {
                    // Fall through to encrypted DoH when carrier DNS blocks or fails the domain.
                }
            }

            List<InetAddress> doh = resolveViaDoh(host);
            if (!doh.isEmpty()) {
                putDnsCache(host, doh, now + DNS_TTL_MS);
                return doh;
            }

            // Final fallback to system DNS if DoH endpoints are blocked on a restricted firewall.
            List<InetAddress> fallback = Dns.SYSTEM.lookup(hostname);
            if (!fallback.isEmpty()) {
                putDnsCache(host, fallback, now + 60000L);
                return fallback;
            }
            throw new UnknownHostException("Could not resolve " + hostname);
        }
    };

    static final OkHttpClient CLIENT = new OkHttpClient.Builder()
            .dns(DNS)
            .connectionPool(POOL)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(14, TimeUnit.SECONDS)
            .followRedirects(false)
            .followSslRedirects(false)
            .build();

    private KuroFastNet154() {}

    static void setDohMode(String mode) {
        String normalized = "always".equals(mode) ? "always" : ("off".equals(mode) ? "off" : "auto");
        if (!normalized.equals(dohMode)) {
            dohMode = normalized;
            dnsCache.clear();
        }
    }

    static String getDohMode() {
        return dohMode;
    }

    static void clearCaches() {
        dnsCache.clear();
        poisonedHosts.clear();
        catalogCache.clear();
        try {
            POOL.evictAll();
        } catch (RuntimeException ignored) {}
    }

    static void trimMemory(int level) {
        long now = System.currentTimeMillis();
        for (Map.Entry<String, DnsEntry> e : dnsCache.entrySet()) {
            DnsEntry v = e.getValue();
            if (v == null || v.expiresAtMs <= now) dnsCache.remove(e.getKey());
        }
        if (level >= 10) {
            catalogCache.clear();
        }
        if (level >= 15 || level >= 40) {
            try {
                POOL.evictAll();
            } catch (RuntimeException ignored) {}
        }
    }

    private static void putDnsCache(String host, List<InetAddress> addrs, long expiresAtMs) {
        if (host == null || addrs == null || addrs.isEmpty()) return;
        if (dnsCache.size() > 256) dnsCache.clear();
        dnsCache.put(host, new DnsEntry(addrs, expiresAtMs));
    }

    private static void markPoisoned(String host) {
        if (host == null || host.isEmpty()) return;
        if (poisonedHosts.size() > 256) poisonedHosts.clear();
        poisonedHosts.add(host);
    }

    private static boolean isNumericIpLiteral(String host) {
        if (host.indexOf(':') >= 0) return true;
        return host.matches("^[0-9]{1,3}(\\.[0-9]{1,3}){3}$");
    }

    private static List<InetAddress> filterValidPublicAddresses(List<InetAddress> list) {
        if (list == null || list.isEmpty()) return Collections.emptyList();
        List<InetAddress> out = new ArrayList<>(list.size());
        for (InetAddress a : list) {
            if (a == null) continue;
            // Filter carrier DNS sinkholes (0.0.0.0, 127.0.0.1, 10.x.x.x, 192.168.x.x, 169.254.x.x)
            if (a.isAnyLocalAddress() || a.isLoopbackAddress() || a.isLinkLocalAddress() || a.isSiteLocalAddress()) {
                continue;
            }
            out.add(a);
        }
        return out;
    }

    private static List<InetAddress> resolveViaDoh(String host) {
        String encoded = Uri.encode(host);
        String[] endpoints = new String[] {
            "https://1.1.1.1/dns-query?name=" + encoded + "&type=A",
            "https://8.8.8.8/resolve?name=" + encoded + "&type=A",
            "https://1.0.0.1/dns-query?name=" + encoded + "&type=A",
            "https://9.9.9.9:5053/dns-query?name=" + encoded + "&type=A",
            "https://1.1.1.1/dns-query?name=" + encoded + "&type=AAAA",
            "https://8.8.8.8/resolve?name=" + encoded + "&type=AAAA"
        };
        for (String url : endpoints) {
            Request req = new Request.Builder()
                    .url(url)
                    .header("Accept", "application/dns-json")
                    .header("User-Agent", "Kuro.tv/1.5.4")
                    .get()
                    .build();
            try (Response resp = DOH_CLIENT.newCall(req).execute()) {
                if (resp.code() != 200 || resp.body() == null) continue;
                byte[] bytes = readCapped(resp.body(), 65536);
                JSONObject json = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
                JSONArray answers = json.optJSONArray("Answer");
                if (answers == null || answers.length() == 0) continue;
                List<InetAddress> resolved = new ArrayList<>();
                for (int i = 0; i < answers.length() && resolved.size() < 8; i++) {
                    JSONObject row = answers.optJSONObject(i);
                    if (row == null) continue;
                    int type = row.optInt("type", 0);
                    if (type != 1 && type != 28) continue;
                    String data = row.optString("data", "").trim();
                    if (data.isEmpty() || (!isNumericIpLiteral(data))) continue;
                    try {
                        InetAddress parsed = InetAddress.getByName(data);
                        InetAddress bound = InetAddress.getByAddress(host, parsed.getAddress());
                        if (!bound.isAnyLocalAddress() && !bound.isLoopbackAddress() && !bound.isSiteLocalAddress()) {
                            resolved.add(bound);
                        }
                    } catch (Exception ignored) {}
                }
                if (!resolved.isEmpty()) return resolved;
            } catch (Exception ignored) {}
        }
        return Collections.emptyList();
    }

    private static byte[] readCapped(ResponseBody body, int maxBytes) throws IOException {
        try (InputStream in = body.byteStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                if (n > maxBytes - out.size()) throw new IOException("Response too large");
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }

    private static boolean shouldRetryWithDoh(IOException e, String host) {
        if (!"auto".equals(dohMode) || host == null || poisonedHosts.contains(host)) return false;
        return (e instanceof UnknownHostException)
                || (e instanceof ConnectException)
                || (e instanceof SocketTimeoutException)
                || (e instanceof SSLException);
    }

    static SourceResult fetchSource(URI u, Map<String, String> headers, int maxBytes) throws Exception {
        String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
        for (int attempt = 0; attempt < 2; attempt++) {
            Request.Builder rb = new Request.Builder().url(u.toURL()).get();
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    if (e.getKey() != null && e.getValue() != null) rb.header(e.getKey(), e.getValue());
                }
            }
            try (Response resp = CLIENT.newCall(rb.build()).execute()) {
                int code = resp.code();
                if (code != 200) throw new Exception("Source returned HTTP " + code + " (no verification bypass)");
                ResponseBody body = resp.body();
                byte[] bytes = body == null ? new byte[0] : readCapped(body, maxBytes);
                return new SourceResult(bytes, resp.header("Content-Type", ""));
            } catch (IOException ioe) {
                if (attempt == 0 && shouldRetryWithDoh(ioe, host)) {
                    markPoisoned(host);
                    dnsCache.remove(host);
                    continue;
                }
                throw ioe;
            }
        }
        throw new IOException("Network error");
    }

    static byte[] fetchPoster(URI u, int maxBytes) throws IOException {
        String host = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
        for (int attempt = 0; attempt < 2; attempt++) {
            Request req = new Request.Builder()
                    .url(u.toURL())
                    .header("User-Agent", "Mozilla/5.0")
                    .header("Accept", "image/webp,image/avif,image/*,*/*;q=0.8")
                    .get()
                    .build();
            try (Response resp = CLIENT.newCall(req).execute()) {
                if (resp.code() != 200 || resp.body() == null) return null;
                return readCapped(resp.body(), maxBytes);
            } catch (IOException ioe) {
                if (attempt == 0 && shouldRetryWithDoh(ioe, host)) {
                    markPoisoned(host);
                    dnsCache.remove(host);
                    continue;
                }
                throw ioe;
            }
        }
        return null;
    }

    static String postAnilistCatalog(String payloadJson, int maxBytes) throws Exception {
        long now = System.currentTimeMillis();
        CatalogCacheEntry hit = catalogCache.get(payloadJson);
        if (hit != null && hit.expiresAtMs > now) {
            return hit.body;
        }
        byte[] raw = payloadJson.getBytes(StandardCharsets.UTF_8);
        String host = "graphql.anilist.co";
        for (int attempt = 0; attempt < 2; attempt++) {
            Request req = new Request.Builder()
                    .url("https://graphql.anilist.co")
                    .header("Accept", "application/json")
                    .header("User-Agent", "Kuro.tv/5.73 (public catalogue)")
                    .post(RequestBody.create(JSON_MEDIA, raw))
                    .build();
            try (Response resp = CLIENT.newCall(req).execute()) {
                if (resp.code() != 200 || resp.body() == null) throw new IOException("Catalogue unavailable");
                String result = new String(readCapped(resp.body(), maxBytes), StandardCharsets.UTF_8);
                JSONObject parsed = new JSONObject(result);
                if (parsed.has("errors") || parsed.optJSONObject("data") == null) {
                    throw new IOException("Catalogue unavailable");
                }
                catalogCache.put(payloadJson, new CatalogCacheEntry(result, System.currentTimeMillis() + CATALOG_TTL_MS));
                return result;
            } catch (IOException ioe) {
                if (attempt == 0 && shouldRetryWithDoh(ioe, host)) {
                    markPoisoned(host);
                    dnsCache.remove(host);
                    continue;
                }
                throw ioe;
            }
        }
        throw new IOException("Catalogue unavailable");
    }

    private static final MediaType FORM_MEDIA = MediaType.parse("application/x-www-form-urlencoded; charset=utf-8");

    private static final OkHttpClient ACCOUNT_CLIENT = CLIENT.newBuilder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .followRedirects(false)
            .followSslRedirects(false)
            .build();

    private static final OkHttpClient PREFLIGHT_CLIENT = CLIENT.newBuilder()
            .connectTimeout(3, TimeUnit.SECONDS)
            .readTimeout(4, TimeUnit.SECONDS)
            .followRedirects(false)
            .followSslRedirects(false)
            .build();

    private static volatile String cachedDiscordRedirect154 = null;

    static JSONObject accountRequest(String method, URI u, Map<String, String> headers, String body) throws Exception {
        String host = u.getHost();
        if (!"https".equals(u.getScheme()) || host == null || u.getUserInfo() != null || u.getPort() != -1
                || !(host.equals("myanimelist.net") || host.equals("api.myanimelist.net")
                || host.equals("discord.com") || host.equals("graphql.anilist.co"))) {
            throw new AccountError("Blocked an unsafe account request.");
        }
        if (!("GET".equals(method) || "POST".equals(method) || "PUT".equals(method))) {
            throw new AccountError("Blocked an unsupported account request.");
        }
        if ("PUT".equals(method) && !("api.myanimelist.net".equals(host)
                && u.getPath() != null && u.getPath().matches("/v2/anime/[0-9]{1,10}/my_list_status"))) {
            throw new AccountError("Blocked an unsafe tracker update.");
        }
        byte[] rawBody = null;
        MediaType bodyType = JSON_MEDIA;
        if (body != null) {
            rawBody = body.getBytes(StandardCharsets.UTF_8);
            if (rawBody.length > 30000) throw new AccountError("Request too large.");
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    if (e.getKey() != null && "content-type".equalsIgnoreCase(e.getKey()) && e.getValue() != null) {
                        MediaType parsed = MediaType.parse(e.getValue());
                        if (parsed != null) bodyType = parsed;
                        break;
                    }
                }
            }
        }
        String lowerHost = host.toLowerCase(Locale.ROOT);
        for (int attempt = 0; attempt < 2; attempt++) {
            RequestBody reqBody = null;
            if (rawBody != null) {
                reqBody = RequestBody.create(bodyType, rawBody);
            } else if ("POST".equals(method) || "PUT".equals(method)) {
                reqBody = RequestBody.create((MediaType) null, new byte[0]);
            }
            Request.Builder rb = new Request.Builder()
                    .url(u.toURL())
                    .method(method, reqBody)
                    .header("Accept", "application/json")
                    .header("User-Agent", "Kuro.tv/1.5.4 (Android)");
            if (headers != null) {
                for (Map.Entry<String, String> h : headers.entrySet()) {
                    if (h.getKey() != null && h.getValue() != null) rb.header(h.getKey(), h.getValue());
                }
            }
            try (Response resp = ACCOUNT_CLIENT.newCall(rb.build()).execute()) {
                int status = resp.code();
                if (status < 200 || status >= 300) {
                    if (status == 429) {
                        long seconds = 60;
                        try {
                            seconds = Math.max(1, Math.min(86400, Long.parseLong(resp.header("Retry-After", "60"))));
                        } catch (Exception ignored) {}
                        throw new AccountError("Provider rate-limited the request (HTTP 429); retry after " + seconds + " seconds.");
                    }
                    if (status == 403) throw new AccountError("Provider blocked the request (HTTP 403). Check access before retrying manually.");
                    if (status == 401) throw new AccountError("Sign-in was rejected or the session expired (HTTP 401). Check your setup or sign in again.");
                    if (status >= 300 && status < 400) throw new AccountError("The provider sent an unexpected redirect. No credentials were forwarded.");
                    throw new AccountError("The provider rejected the request (HTTP " + status + "). Check the account details and provider settings.");
                }
                ResponseBody respBody = resp.body();
                if (respBody == null) return new JSONObject();
                byte[] bytes;
                try {
                    bytes = readCapped(respBody, 3000000);
                } catch (IOException tooLarge) {
                    throw new AccountError("Provider response too large.");
                }
                String text = new String(bytes, StandardCharsets.UTF_8).trim();
                return text.isEmpty() ? new JSONObject() : new JSONObject(text);
            } catch (IOException ioe) {
                if (attempt == 0 && shouldRetryWithDoh(ioe, lowerHost)) {
                    markPoisoned(lowerHost);
                    dnsCache.remove(lowerHost);
                    continue;
                }
                throw new AccountError("Could not reach the provider. Check your connection and setup.");
            }
        }
        throw new AccountError("Could not reach the provider. Check your connection and setup.");
    }

    static String resolveDiscordRedirect154(String clientId) {
        if (!"1569077670074122250".equals(clientId)) {
            return AccountOAuth.DISCORD_REDIRECT;
        }
        String hit = cachedDiscordRedirect154;
        if (hit != null) return hit;
        String[] candidates = new String[] {
            KuroDiscordOAuth564.REDIRECT,
            AccountOAuth.DISCORD_REDIRECT
        };
        for (String cand : candidates) {
            for (int attempt = 0; attempt < 2; attempt++) {
                try {
                    String form = "client_id=" + Uri.encode(clientId)
                            + "&grant_type=authorization_code"
                            + "&code=kuro_preflight_probe_154"
                            + "&redirect_uri=" + Uri.encode(cand)
                            + "&code_verifier=dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk";
                    Request req = new Request.Builder()
                            .url("https://discord.com/api/oauth2/token")
                            .header("Accept", "application/json")
                            .header("User-Agent", "Kuro.tv/1.5.4 (Android)")
                            .post(RequestBody.create(FORM_MEDIA, form.getBytes(StandardCharsets.UTF_8)))
                            .build();
                    try (Response resp = PREFLIGHT_CLIENT.newCall(req).execute()) {
                        ResponseBody rb = resp.body();
                        String txt = rb == null ? "" : new String(readCapped(rb, 16384), StandardCharsets.UTF_8);
                        if (txt.contains("invalid_grant")) {
                            cachedDiscordRedirect154 = cand;
                            return cand;
                        }
                        break;
                    }
                } catch (IOException ioe) {
                    if (attempt == 0 && shouldRetryWithDoh(ioe, "discord.com")) {
                        markPoisoned("discord.com");
                        dnsCache.remove("discord.com");
                        continue;
                    }
                    break;
                } catch (Exception ignored) {
                    break;
                }
            }
        }
        return KuroDiscordOAuth564.REDIRECT;
    }

    private static boolean validBrowserPackage154(String pkg, String selfPkg) {
        if (pkg == null || pkg.isEmpty()) return false;
        if (pkg.equals(selfPkg) || "android".equals(pkg) || pkg.startsWith("com.android.internal")) return false;
        if ("com.discord".equals(pkg) || pkg.startsWith("com.discord.")) return false;
        return true;
    }

    static boolean openInBrowser154(Activity a, String target) {
        if (a == null || target == null || target.isEmpty()) return false;
        try {
            Uri uri = Uri.parse(target);
            Intent browser = new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE);
            PackageManager pm = a.getPackageManager();
            String selfPkg = a.getPackageName();
            String chosenPkg = null;
            if (pm != null) {
                Intent probe = new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.org/")).addCategory(Intent.CATEGORY_BROWSABLE);
                ResolveInfo def = pm.resolveActivity(probe, PackageManager.MATCH_DEFAULT_ONLY);
                if (def != null && def.activityInfo != null && validBrowserPackage154(def.activityInfo.packageName, selfPkg)) {
                    chosenPkg = def.activityInfo.packageName;
                }
                if (chosenPkg == null) {
                    List<ResolveInfo> list = pm.queryIntentActivities(probe, PackageManager.MATCH_ALL);
                    if (list == null || list.isEmpty()) list = pm.queryIntentActivities(probe, 0);
                    if (list != null) {
                        String[] preferred = new String[] {
                            "com.android.chrome", "com.brave.browser", "com.sec.android.app.sbrowser",
                            "org.mozilla.firefox", "com.microsoft.emmx", "com.opera.browser",
                            "com.vivaldi.browser", "com.kiwibrowser.browser"
                        };
                        for (String pref : preferred) {
                            for (ResolveInfo ri : list) {
                                if (ri != null && ri.activityInfo != null && pref.equals(ri.activityInfo.packageName)) {
                                    chosenPkg = pref;
                                    break;
                                }
                            }
                            if (chosenPkg != null) break;
                        }
                        if (chosenPkg == null) {
                            for (ResolveInfo ri : list) {
                                if (ri != null && ri.activityInfo != null && validBrowserPackage154(ri.activityInfo.packageName, selfPkg)) {
                                    chosenPkg = ri.activityInfo.packageName;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if (chosenPkg != null) {
                browser.setPackage(chosenPkg);
                try {
                    a.startActivity(browser);
                    return true;
                } catch (Exception ignored) {
                    browser.setPackage(null);
                }
            }
            a.startActivity(browser);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

package app.lovelycrxshx.kuro;

import android.net.Uri;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Kuro 1.3 - the overlay assets the WebView is allowed to serve.
 *
 * MainActivity answers `https://kuro.local/...` from the APK only for the paths
 * it knows about. The 1.1 theme files were in the APK and linked from
 * index.html but missing from that list, so the WebView dropped them: the app
 * stayed violet and the Account picker never appeared. This class is generated
 * from the overlay directories by tools/webview_assets_1.3.py, so whatever an
 * overlay ships is served.
 */
final class KuroWebAssets13 {
    private static final Set<String> SERVED = new HashSet<>(Arrays.asList(
        "/beta-continue-1.5.js",
        "/beta-downloads-1.5.js",
        "/beta-extras-1.5.css",
        "/beta-extras-1.5.js",
        "/beta-motion-1.5.css",
        "/beta-motion-1.5.js",
        "/beta-polish-1.5.2.css",
        "/beta-polish-1.5.2.js",
        "/beta-ui-1.5.4.css",
        "/beta-ui-1.5.4.js",
        "/beta-whatsnew-1.5.js",
        "/index.html",
        "/intro/animation.mp4",
        "/profile-art-arm.js",
        "/profile-art/banner/art-11.webp",
        "/profile-art/banner/art-12.webp",
        "/profile-art/banner/art-13.webp",
        "/profile-art/banner/art-14.webp",
        "/profile-art/banner/art-15.webp",
        "/profile-art/banner/art-16.webp",
        "/profile-art/banner/art-17.webp",
        "/profile-art/banner/art-18.webp",
        "/profile-art/banner/art-19.webp",
        "/profile-art/banner/art-20.webp",
        "/profile-art/banner/art-21.webp",
        "/profile-art/banner/art-22.webp",
        "/profile-art/banner/art-23.webp",
        "/profile-art/banner/art-24.webp",
        "/profile-art/banner/art-25.webp",
        "/profile-art/banner/art-26.webp",
        "/profile-art/banner/art-27.webp",
        "/profile-art/banner/art-28.webp",
        "/profile-art/banner/art-29.webp",
        "/profile-art/banner/art-30.webp",
        "/profile-art/banner/art-31.webp",
        "/profile-art/banner/art-32.webp",
        "/profile-art/banner/art-33.webp",
        "/profile-art/banner/art-34.webp",
        "/profile-art/banner/art-35.webp",
        "/profile-art/banner/art-36.webp",
        "/profile-art/banner/art-37.webp",
        "/profile-art/banner/art-38.webp",
        "/profile-art/banner/art-39.webp",
        "/profile-art/banner/art-40.webp",
        "/profile-art/banner/art-41.webp",
        "/profile-art/banner/art-42.webp",
        "/profile-art/banner/art-43.webp",
        "/profile-art/banner/art-44.webp",
        "/profile-art/banner/art-45.webp",
        "/profile-art/banner/art-46.webp",
        "/profile-art/banner/art-47.webp",
        "/profile-art/banner/art-48.webp",
        "/profile-art/banner/art-49.webp",
        "/profile-art/banner/art-50.webp",
        "/profile-art/pfp/art-11.webp",
        "/profile-art/pfp/art-12.webp",
        "/profile-art/pfp/art-13.webp",
        "/profile-art/pfp/art-14.webp",
        "/profile-art/pfp/art-15.webp",
        "/profile-art/pfp/art-16.webp",
        "/profile-art/pfp/art-17.webp",
        "/profile-art/pfp/art-18.webp",
        "/profile-art/pfp/art-19.webp",
        "/profile-art/pfp/art-20.webp",
        "/profile-art/pfp/art-21.webp",
        "/profile-art/pfp/art-22.webp",
        "/profile-art/pfp/art-23.webp",
        "/profile-art/pfp/art-24.webp",
        "/profile-art/pfp/art-25.webp",
        "/profile-art/pfp/art-26.webp",
        "/profile-art/pfp/art-27.webp",
        "/profile-art/pfp/art-28.webp",
        "/profile-art/pfp/art-29.webp",
        "/profile-art/pfp/art-30.webp",
        "/profile-art/pfp/art-31.webp",
        "/profile-art/pfp/art-32.webp",
        "/profile-art/pfp/art-33.webp",
        "/profile-art/pfp/art-34.webp",
        "/profile-art/pfp/art-35.webp",
        "/profile-art/pfp/art-36.webp",
        "/profile-art/pfp/art-37.webp",
        "/profile-art/pfp/art-38.webp",
        "/profile-art/pfp/art-39.webp",
        "/profile-art/pfp/art-40.webp",
        "/profile-art/pfp/art-41.webp",
        "/profile-art/pfp/art-42.webp",
        "/profile-art/pfp/art-43.webp",
        "/profile-art/pfp/art-44.webp",
        "/profile-art/pfp/art-45.webp",
        "/profile-art/pfp/art-46.webp",
        "/profile-art/pfp/art-47.webp",
        "/profile-art/pfp/art-48.webp",
        "/profile-art/pfp/art-49.webp",
        "/profile-art/pfp/art-50.webp",
        "/theme-accent-1.1.js",
        "/theme-amber-1.1.css",
        "/theme-citron-1.1.css",
        "/theme-coral-1.1.css",
        "/theme-crimson-1.1.css",
        "/theme-emerald-1.1.css",
        "/theme-gold-1.1.css",
        "/theme-graphite-1.1.css",
        "/theme-ice-1.1.css",
        "/theme-indigo-1.1.css",
        "/theme-lime-1.1.css",
        "/theme-magenta-1.1.css",
        "/theme-mint-1.1.css",
        "/theme-picker-1.1.css",
        "/theme-plum-1.1.css",
        "/theme-rich-1.5.css",
        "/theme-rose-1.1.css",
        "/theme-royal-1.1.css",
        "/theme-sapphire-1.1.css",
        "/theme-sky-1.1.css",
        "/theme-sunset-1.1.css",
        "/theme-teal-1.1.css",
        "/theme-violet-1.1.css"
    ));

    private KuroWebAssets13() {
    }

    static boolean served(Uri uri) {
        return "https".equals(uri.getScheme())
                && "kuro.local".equals(uri.getHost())
                && uri.getPath() != null
                && SERVED.contains(uri.getPath());
    }

    static String mime(String path) {
        int dot = path.lastIndexOf('.');
        String ext = dot < 0 ? "" : path.substring(dot).toLowerCase(java.util.Locale.ROOT);
        switch (ext) {
            case ".html": return "text/html";
            case ".css": return "text/css";
            case ".js": return "application/javascript";
            case ".json": return "application/json";
            case ".webp": return "image/webp";
            case ".png": return "image/png";
            case ".jpg":
            case ".jpeg": return "image/jpeg";
            case ".svg": return "image/svg+xml";
            default: return "application/octet-stream";
        }
    }
}

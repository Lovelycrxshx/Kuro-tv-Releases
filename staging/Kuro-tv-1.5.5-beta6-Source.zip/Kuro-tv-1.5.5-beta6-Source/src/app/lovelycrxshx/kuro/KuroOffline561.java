package app.lovelycrxshx.kuro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import androidx.annotation.OptIn;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.database.DatabaseProvider;
import androidx.media3.database.StandaloneDatabaseProvider;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.cache.Cache;
import androidx.media3.datasource.cache.NoOpCacheEvictor;
import androidx.media3.datasource.cache.SimpleCache;
import androidx.media3.exoplayer.offline.Download;
import androidx.media3.exoplayer.offline.DownloadCursor;
import androidx.media3.exoplayer.offline.DownloadManager;
import androidx.media3.exoplayer.offline.DownloadRequest;
import androidx.media3.exoplayer.offline.DownloadService;
import org.json.JSONObject;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;

/** User-confirmed, app-private offline storage; never extracts embed URLs or DRM keys. */
@OptIn(markerClass = UnstableApi.class)
final class KuroOffline561 {
    private static DownloadManager manager;
    private static final java.util.concurrent.Executor DOWNLOAD_EXECUTOR=Executors.newFixedThreadPool(2);
    private static Cache cache;
    private KuroOffline561(){}
    // Playback uses PlaceholderDataSource upstream: a missing cache span can never fetch the network.
    static androidx.media3.datasource.DataSource.Factory offlineFactory(Context c){return new androidx.media3.datasource.cache.CacheDataSource.Factory().setCache(cache(c)).setUpstreamDataSourceFactory(androidx.media3.datasource.PlaceholderDataSource.FACTORY).setCacheWriteDataSinkFactory(null);}
    static synchronized DownloadManager manager(Context c){
        if(manager!=null)return manager;
        Context app=c.getApplicationContext();
        DatabaseProvider db=new StandaloneDatabaseProvider(app);
        cache=new SimpleCache(new File(app.getFilesDir(),"kuro-offline561"),new NoOpCacheEvictor(),db);
        androidx.media3.datasource.okhttp.OkHttpDataSource.Factory http=KuroHttp561.factory();
        manager=new DownloadManager(app,db,cache,http,DOWNLOAD_EXECUTOR);
        manager.setMaxParallelDownloads(1);manager.setMinRetryCount(0);
        return manager;
    }
    static synchronized Cache cache(Context c){manager(c);return cache;}
    static void confirmDownload(Activity activity,String address,String key,String title,String episode){
        if(!KuroPlayback561.allowedHls(address,"zenkai","hls")){Toast.makeText(activity,"This source does not expose a supported direct download.",Toast.LENGTH_LONG).show();return;}
        new AlertDialog.Builder(activity).setTitle("Download for offline viewing?")
            .setMessage("Only continue if you own this video or the provider permits offline downloads. Kuro does not bypass DRM or access checks; protected media may not work offline. The private download index may contain the source URL; offline media is not included in Kuro's JSON backup. A download may include multiple qualities and use substantial storage or mobile data. The source may refuse downloading or expire.")
            .setNegativeButton("Cancel",null).setPositiveButton("I have permission",(d,w)->{
                try{
                    JSONObject info=new JSONObject();info.put("title",limit(title,160));info.put("episode",limit(episode,20));info.put("key",KuroPlayback561.validKey(key)?key:"");
                    String id=KuroPlayback561.sha((key==null?"":key)+"\n"+address);
                    DownloadRequest request=new DownloadRequest.Builder(id,android.net.Uri.parse(address)).setMimeType(MimeTypes.APPLICATION_M3U8).setData(info.toString().getBytes(StandardCharsets.UTF_8)).build();
                    manager(activity);DownloadService.sendAddDownload(activity,KuroDownloadService561.class,request,false);DownloadService.sendResumeDownloads(activity,KuroDownloadService561.class,false);
                    Toast.makeText(activity,"Download queued. Open Manage downloads to check its status.",Toast.LENGTH_LONG).show();
                }catch(Exception e){Toast.makeText(activity,"Could not start the download on this device.",Toast.LENGTH_LONG).show();}
            }).show();
    }

    static void confirmBatchDownload154(Activity activity, String rawJson) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed() || rawJson == null || rawJson.length() > 250000) return;
        final List<JSONObject> valid = new ArrayList<>();
        try {
            org.json.JSONArray arr = new org.json.JSONArray(rawJson);
            for (int i = 0; i < arr.length() && valid.size() < 30; i++) {
                JSONObject row = arr.optJSONObject(i);
                if (row == null) continue;
                String addr = row.optString("address", "");
                if (!KuroPlayback561.allowedHls(addr, "zenkai", "hls")) continue;
                valid.add(row);
            }
        } catch (Exception ignored) {}
        if (valid.isEmpty()) {
            Toast.makeText(activity, "No direct HLS streams available for batch offline download on this source.", Toast.LENGTH_LONG).show();
            return;
        }
        String showTitle = limit(valid.get(0).optString("title", "Anime"), 90);
        String firstEp = limit(valid.get(0).optString("episode", "1"), 16);
        String lastEp = limit(valid.get(valid.size() - 1).optString("episode", firstEp), 16);
        String rangeLabel = valid.size() == 1 ? ("Episode " + firstEp) : ("Episodes " + firstEp + " – " + lastEp + " (" + valid.size() + " episodes)");
        new AlertDialog.Builder(KuroDialogs581.themed(activity))
                .setTitle("Batch download " + valid.size() + (valid.size() == 1 ? " episode?" : " episodes?"))
                .setMessage(showTitle + "\n" + rangeLabel + "\n\nQueues verified direct HLS streams into Kuro offline storage. Only store content you have permission to keep.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Queue " + valid.size(), (d, w) -> {
                    int queued = 0;
                    for (JSONObject row : valid) {
                        try {
                            String addr = row.optString("address", "");
                            String key = row.optString("key", "");
                            String t = limit(row.optString("title", "Video"), 120);
                            String ep = limit(row.optString("episode", ""), 20);
                            String id = "kuro561:" + Integer.toHexString((addr + "|" + key).hashCode());
                            JSONObject meta = new JSONObject().put("title", t).put("episode", ep).put("key", KuroPlayback561.validKey(key) ? key : "");
                            DownloadRequest req = new DownloadRequest.Builder(id, android.net.Uri.parse(addr))
                                    .setMimeType(MimeTypes.APPLICATION_M3U8)
                                    .setData(meta.toString().getBytes(StandardCharsets.UTF_8))
                                    .build();
                            DownloadService.sendAddDownload(activity, KuroDownloadService561.class, req, false);
                            queued++;
                        } catch (Exception ignored) {}
                    }
                    if (queued > 0) {
                        try { DownloadService.sendResumeDownloads(activity, KuroDownloadService561.class, false); } catch (Exception ignored) {}
                        Toast.makeText(activity, "Queued " + queued + (queued == 1 ? " episode" : " episodes") + " for offline playback.", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(activity, "Could not start batch download on this device.", Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }
    private static String limit(String text,int max){if(text==null)return "";return text.length()>max?text.substring(0,max):text;}
    static JSONObject metadata(Download d){try{return new JSONObject(new String(d.request.data,StandardCharsets.UTF_8));}catch(Exception ignored){return new JSONObject();}}
    private static String state(Download d){
        switch(d.state){case Download.STATE_COMPLETED:return "Ready offline";case Download.STATE_DOWNLOADING:float p=d.getPercentDownloaded();return p>=0?"Downloading · "+Math.round(p)+"%":"Downloading";case Download.STATE_FAILED:return "Failed — the source may not permit downloading";case Download.STATE_STOPPED:return "Paused";case Download.STATE_REMOVING:return "Removing";default:return "Queued";}
    }
    static void showDownloads(Activity activity){
        final DownloadManager m;
        try{m=manager(activity);}catch(RuntimeException e){Toast.makeText(activity,"Offline storage is unavailable.",Toast.LENGTH_LONG).show();return;}
        final androidx.media3.exoplayer.offline.DownloadIndex index=m.getDownloadIndex();
        java.util.concurrent.ExecutorService io=Executors.newSingleThreadExecutor();
        io.execute(()->{List<Download> list=new ArrayList<>();boolean failed=false;try(DownloadCursor cursor=index.getDownloads()){while(cursor.moveToNext()&&list.size()<500)list.add(cursor.getDownload());}catch(Exception e){failed=true;}
            final boolean error=failed;activity.runOnUiThread(()->{if(activity.isFinishing()||activity.isDestroyed())return;if(error){Toast.makeText(activity,"Could not read offline downloads.",Toast.LENGTH_LONG).show();return;}showList(activity,list);});io.shutdown();
        });
    }
    private static void showList(Activity a,List<Download> downloads){
        AlertDialog.Builder b=new AlertDialog.Builder(a).setTitle("Kuro downloads").setNegativeButton("Close",null).setNeutralButton("Android downloads",(d,w)->{try{a.startActivity(new Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS));}catch(Exception e){Toast.makeText(a,"Android Downloads is unavailable.",Toast.LENGTH_SHORT).show();}});
        if(downloads.isEmpty())b.setMessage("No Kuro offline downloads yet. A Download button appears for a supported direct stream. Only download content you have permission to store.");
        else{String[] labels=new String[downloads.size()];for(int i=0;i<labels.length;i++){Download x=downloads.get(i);JSONObject info=metadata(x);String title=info.optString("title","Video"),ep=info.optString("episode","");labels[i]=title+(ep.isEmpty()?"":" · Episode "+ep)+"\n"+state(x);}b.setItems(labels,(d,which)->actions(a,downloads.get(which)));}b.show();
    }
    // ---- 1.5-beta: download housekeeping for the Settings screen ----------
    private static final String CLEAN_PREFS = "kuro-offline-clean15";
    private static volatile String active15 = "";

    static void markPlayed15(Context c, String key) {
        if (!KuroPlayback561.validKey(key)) return;
        c.getSharedPreferences(CLEAN_PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean("p:" + key, true).apply();
    }

    private static boolean played15(Context c, String key) {
        return KuroPlayback561.validKey(key) && c.getSharedPreferences(CLEAN_PREFS, Context.MODE_PRIVATE)
                .getBoolean("p:" + key, false);
    }

    /** The download that is playing right now; never removed, not even by "all". */
    static void setActive15(String key) { active15 = KuroPlayback561.validKey(key) ? key : ""; }

    private static boolean isActive15(Download d) {
        return !active15.isEmpty() && active15.equals(metadata(d).optString("key", ""));
    }

    /** Opened at least once and no checkpoint left: finished, or restarted. */
    private static boolean watched15(Context c, Download d) {
        String key = metadata(d).optString("key", "");
        return played15(c, key) && KuroPlayback561.read(c, key) == 0;
    }

    private static int episode15(String value) {
        if (value == null || value.isEmpty()) return -1;
        int n = 0, digits = 0;
        for (int i = 0; i < value.length() && i < 5; i++) {
            char ch = value.charAt(i);
            if (ch < '0' || ch > '9') break;
            n = n * 10 + (ch - '0');
            digits++;
        }
        return digits == 0 ? -1 : n;
    }

    private static long bytes15(Context c) {
        try {
            Cache store = cache(c);
            return store == null ? 0L : store.getCacheSpace();
        } catch (RuntimeException e) { return 0L; }
    }

    static String summary15(Context c) {
        int count = 0, ready = 0, watched = 0;
        try (DownloadCursor cursor = manager(c).getDownloadIndex().getDownloads()) {
            while (cursor.moveToNext() && count < 500) {
                Download d = cursor.getDownload();
                count++;
                if (d.state == Download.STATE_COMPLETED) ready++;
                if (watched15(c, d)) watched++;
            }
        } catch (Exception ignored) { }
        try {
            return new JSONObject().put("count", count).put("ready", ready)
                    .put("watched", watched).put("bytes", bytes15(c)).toString();
        } catch (org.json.JSONException e) {
            return "{\"count\":0,\"ready\":0,\"watched\":0,\"bytes\":0}";
        }
    }

    private static List<Download> all15(Context c) {
        List<Download> out = new ArrayList<>();
        try (DownloadCursor cursor = manager(c).getDownloadIndex().getDownloads()) {
            while (cursor.moveToNext() && out.size() < 500) out.add(cursor.getDownload());
        } catch (Exception ignored) { }
        return out;
    }

    private static int remove15(Context c, List<Download> doomed) {
        int removed = 0;
        for (Download d : doomed) {
            if (isActive15(d)) continue;
            try {
                DownloadService.sendRemoveDownload(c, KuroDownloadService561.class, d.request.id, false);
                removed++;
            } catch (RuntimeException ignored) { }
        }
        return removed;
    }

    /** mode: all | watched | older (needs days) | latest (one episode per title). */
    static int clean15(Context c, String mode, int days) {
        List<Download> all = all15(c);
        List<Download> doomed = new ArrayList<>();
        if ("all".equals(mode)) {
            doomed.addAll(all);
        } else if ("watched".equals(mode)) {
            for (Download d : all) if (watched15(c, d)) doomed.add(d);
        } else if ("older".equals(mode)) {
            long cutoff = System.currentTimeMillis()
                    - Math.max(1, Math.min(365, days)) * 24L * 60L * 60L * 1000L;
            for (Download d : all) {
                if (watched15(c, d) && d.updateTimeMs > 0 && d.updateTimeMs < cutoff) doomed.add(d);
            }
        } else if ("latest".equals(mode)) {
            java.util.HashMap<String, Integer> best = new java.util.HashMap<>();
            for (Download d : all) {
                JSONObject info = metadata(d);
                String title = info.optString("title", "").trim();
                int ep = episode15(info.optString("episode", ""));
                if (title.isEmpty() || ep < 0) continue;
                Integer seen = best.get(title);
                if (seen == null || ep > seen) best.put(title, ep);
            }
            for (Download d : all) {
                JSONObject info = metadata(d);
                String title = info.optString("title", "").trim();
                int ep = episode15(info.optString("episode", ""));
                Integer seen = best.get(title);
                if (seen == null || ep < 0 || ep >= seen) continue;
                doomed.add(d);
            }
        }
        return remove15(c, doomed);
    }
    private static void actions(Activity a,Download download){
        boolean ready=download.state==Download.STATE_COMPLETED,failed=download.state==Download.STATE_FAILED;String[] choices=ready?new String[]{"Play offline","Remove this download"}:failed?new String[]{"Retry this download","Remove this download"}:new String[]{"Remove this download"};
        new AlertDialog.Builder(a).setTitle(metadata(download).optString("title","Download")).setItems(choices,(dialog,which)->{
            if(ready&&which==0){Intent intent=new Intent(a,KuroOfflineActivity561.class);intent.putExtra("id",download.request.id);a.startActivity(intent);return;}
            if(failed&&which==0){new AlertDialog.Builder(a).setTitle("Retry this download?").setMessage("Retry only when the provider permits it. If access or verification is required, stop and check it manually.").setNegativeButton("Cancel",null).setPositiveButton("Retry",(d,w)->{try{DownloadService.sendAddDownload(a,KuroDownloadService561.class,download.request,false);DownloadService.sendResumeDownloads(a,KuroDownloadService561.class,false);Toast.makeText(a,"Download queued again.",Toast.LENGTH_SHORT).show();}catch(RuntimeException e){Toast.makeText(a,"Could not retry this download.",Toast.LENGTH_SHORT).show();}}).show();return;}
            new AlertDialog.Builder(a).setTitle("Remove this download?").setMessage("Only this offline copy is removed. Your lists and history stay.").setNegativeButton("Cancel",null).setPositiveButton("Remove",(d,w)->{try{DownloadService.sendRemoveDownload(a,KuroDownloadService561.class,download.request.id,false);Toast.makeText(a,"Removing download.",Toast.LENGTH_SHORT).show();}catch(RuntimeException e){Toast.makeText(a,"Could not remove download.",Toast.LENGTH_SHORT).show();}}).show();
        }).setNegativeButton("Back",(d,w)->showDownloads(a)).show();
    }
}

'use strict';
const $=s=>document.querySelector(s), main=$('#main');let source='ms',view='home',selected=null,episode=null,episodes=[],servers=[],stack=[],requestNo=0;
const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const label=s=>({'ms':'Library 1','dk':'Library 2','nine':'Library 3','zoro':'Library 4','ani':'Library 5','salt':'Library 6','flix':'Library 7','zenkai':'Library 8','wixi':'Library 9','aw':'Library 10','miruro':'Library 11','kitsune':'Library 12','paradise':'Library 13'}[s]||'Library');
const base=s=>({'ms':'https://hianime.ms','dk':(typeof hiCurrentOrigin==='function'?hiCurrentOrigin():'https://hianime.dk'),'nine':'https://9anime.or.at','zoro':'https://zorotv.ba','ani':'https://aniwaves.ru','salt':'https://animesalt.cx','flix':'https://hianimeq.top','zenkai':'https://www.zenkaitv.com','wixi':'https://aniwixi.xyz','aw':'https://aniwatch.co.at','miruro':'https://www.miruro.cx','kitsune':'https://kitsunee.moe','paradise':'https://api.animeparadise.moe'}[s]||'');
function validUrl(u,kind='source'){try{const p=new URL(u);if(p.protocol!=='https:')return '';let hosts=kind==='source'?['hianime.ms',...HI_MIRROR_HOSTS,'9anime.or.at','zorotv.ba','animesalt.cx','aniwaves.ru','hianimeq.top','www.zenkaitv.com','aniwixi.xyz','animeav1.com','aniwatch.co.at','www.miruro.cx','kitsunee.moe','api.animeparadise.moe','www.animeparadise.moe','aniwaves.tv','anikoto.cz','gogoanimes.cv','www.animevillage.org']:kind==='image'?null:['gogoanime.com.by','hianime.ms',...HI_MIRROR_HOSTS,'megaplay.buzz','vidtube.site','vidnest.fun','tryembed.us.cc','zokoanime.video','player.hianimes.es','my.1anime.site','zorotv.ba','player.abyssplayer.com','play.vhscdn.to','hianimeq.top','www.zenkaitv.com','aniwixi.xyz','animeav1.uns.bio','byselapuix.com','www.mp4upload.com','1anime.site','www.animeparadise.moe'];if(hosts&&!hosts.some(h=>p.hostname===h||p.hostname.endsWith('.'+h)))return '';return p.href}catch{return ''}}
const parse=s=>new DOMParser().parseFromString(s,'text/html');const abs=(url,s)=>{try{return new URL(url,base(s)).href}catch{return ''}};
let pending={};window.__nativeResult=(id,error)=>{let p=pending[id];if(!p)return;delete pending[id];if(error)p.reject(new Error(error));else fetch('/result/'+encodeURIComponent(id)).then(r=>{if(!r.ok)throw Error('Source response unavailable');return r.text()}).then(p.resolve,p.reject)};
function get(url){
 const host=(()=>{try{return new URL(url).hostname}catch{return ''}})(),miruro=host==='www.miruro.cx',kitsune=host==='kitsunee.moe',paradise=host==='api.animeparadise.moe',blockedCode=miruro?'miruro':kitsune?'kitsune':paradise?'paradise':'';
 if(paradise&&!paradiseEnabled())return Promise.reject(Error('Library 13 is turned off.'));
 if((paradise&&paradiseBlocked())||(blockedCode&&unifiedVerificationBlocked.has(blockedCode)))return Promise.reject(Error('The library requested human verification.'));
 return new Promise((resolve,reject)=>{if(!validUrl(url))return reject(Error('Invalid source URL'));let id=String(++requestNo);if(window.KuroNative){pending[id]={resolve,reject};try{KuroNative.get(id,url)}catch(e){delete pending[id];reject(e)}}else fetch('/proxy?url='+encodeURIComponent(url)).then(r=>{if(!r.ok)throw Error('HTTP '+r.status);return r.text()}).then(resolve,reject)}).then(raw=>{if(/^\s*(?:<!doctype|<html)/i.test(raw)&&/<title[^>]*>\s*(?:just a moment|attention required|verify you are human|access denied)/i.test(raw))throw Error('The library requested human verification.');return raw}).catch(e=>{if(blockedCode&&unifiedProblem(e)){unifiedVerificationBlocked.add(blockedCode);if(paradise)paradiseMarkBlocked()}throw e});
}
function pageTransition(){main.classList.remove('library-view573','home-surface576');closeSortPicker(false);closeAirPicker(false);detachPager();main.classList.remove('page-enter');void main.offsetWidth;main.classList.add('page-enter')}
function nav(n){pageTransition();view=n;main.classList.toggle('library-view573',n==='library');document.querySelectorAll('nav button').forEach(b=>{let active=b.dataset.nav===n;b.classList.toggle('active',active);if(active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')});if(n==='home')home();if(n==='search')searchPage();if(n==='library')library();if(n==='simulcasts')simulcasts();if(n==='profile')profile();if(n==='news')newsPage()}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{if(b.dataset.nav==='library')listFilter='all';nav(b.dataset.nav);window.scrollTo(0,0)});
$('#header-home').onclick=()=>{closeSearchPopup();nav('home');window.scrollTo(0,0)};$('#header-search').onclick=()=>toggleSearchPopup();function placeholder(message){let box=$('#header-message');if(!box){box=document.createElement('div');box.id='header-message';box.className='header-message';document.querySelector('header').after(box)}box.textContent=message;setTimeout(()=>box.remove(),4000)}$('#header-notice').onclick=showNews;$('#header-login').onclick=()=>placeholder('Login will be added later.');
// Compact search keeps the current page in place. Suggestions come from the selected library.
let popupSequence=0,popupTimer,watchSearchMode=false,watchSearchToken=0;
function closeSearchPopup(){
 popupSequence++;clearTimeout(popupTimer);document.querySelector('#search-popup')?.remove();$('#header-search').setAttribute('aria-expanded','false');
 if(watchSearchMode){watchSearchMode=false;document.documentElement.classList.remove('watch-search-active');try{window.KuroNative?.watchSearchClosed?.(watchSearchToken)}catch(_){}}
}
function selectSearchItem(item){
 if(watchSearchMode&&window.KuroNative?.watchSearchSelected){
  // The native layer closes the player first and returns the validated item
  // to this same local UI. Closing the search alone never changes the player.
  const payload=JSON.stringify(item);watchSearchMode=false;document.documentElement.classList.remove('watch-search-active');closeSearchPopup();KuroNative.watchSearchSelected(payload,watchSearchToken);return;
 }
 closeSearchPopup();openShow(item);
}
window.kuroWatchSearchOpen=token=>{closeSearchPopup();watchSearchToken=Number(token)||0;watchSearchMode=true;document.documentElement.classList.add('watch-search-active');toggleSearchPopup()};
window.kuroWatchSearchClose=()=>closeSearchPopup();
window.kuroWatchSearchResult=payload=>{try{let item=JSON.parse(payload);if(item&&unifiedCodes.includes(item.source)&&validUrl(item.url))openShow(item)}catch(_){}};
// Recent searches are local to this device. No search is saved until explicitly
// submitted or a result is selected. Storage failures never block searching.
const searchHistoryKey='kuro-search-history-v1';
function recentSearches(){try{let a=JSON.parse(localStorage.getItem(searchHistoryKey)||'[]');return Array.isArray(a)?a.filter(x=>typeof x==='string'&&x.length>0&&x.length<=120).slice(0,8):[]}catch(_){return []}}
function rememberSearch(q){q=String(q||'').trim().slice(0,120);if(!q)return;try{localStorage.setItem(searchHistoryKey,JSON.stringify([q,...recentSearches().filter(x=>x.toLocaleLowerCase()!==q.toLocaleLowerCase())].slice(0,8)))}catch(_){}}
function toggleSearchPopup(){
 if($('#search-popup')){closeSearchPopup();return}
 let box=document.createElement('section');box.id='search-popup';box.className='search-popup';box.setAttribute('aria-label','Search anime');
 box.innerHTML=`<div class="popup-top"><strong>Search anime</strong><button type="button" id="popup-close" aria-label="Close search">×</button></div><div class="popup-input"><input id="popup-query" type="search" autocomplete="off" maxlength="120" placeholder="Search anime titles" aria-label="Anime title"><button id="popup-go" type="button">Search</button></div><div class="popup-label">${label(source)} · Suggestions</div><div id="popup-results" class="popup-results" aria-live="polite"></div>`;
 document.querySelector('header').appendChild(box);$('#header-search').setAttribute('aria-expanded','true');let input=$('#popup-query');$('#popup-close').onclick=()=>{closeSearchPopup();$('#header-search').focus()};
 const showRecent=()=>{let result=$('#popup-results'),history=recentSearches();if(!history.length){result.textContent='Start typing a title.';return}result.innerHTML=`<div class="popup-label">Recent searches · saved on this device</div>${history.map((q,i)=>`<button type="button" class="popup-result" data-recent-search="${i}"><span>${escapeHTML(q)}</span><b>›</b></button>`).join('')}<button type="button" class="chip small" id="clear-search-history">Clear search history</button>`;result.querySelectorAll('[data-recent-search]').forEach(b=>b.onclick=()=>{input.value=history[Number(b.dataset.recentSearch)];rememberSearch(input.value);run()});result.querySelector('#clear-search-history').onclick=()=>{try{localStorage.removeItem(searchHistoryKey)}catch(_){}showRecent()}};
 const run=async()=>{let q=input.value.trim(),s=source,seq=++popupSequence,result=$('#popup-results');if(!q){showRecent();return}result.textContent='Searching…';try{let items=(await fetchCatalogPage({source:s,mode:'search',query:q},1)).items.slice(0,8);if(seq!==popupSequence||!box.isConnected)return;result.innerHTML=items.length?items.map((x,i)=>`<button type="button" class="popup-result" data-suggestion="${i}">${x.img?`<img src="${escapeHTML(x.img)}" alt="">`:''}<span>${escapeHTML(x.title)}<small>${escapeHTML(x.meta||label(s))}</small></span><b>›</b></button>`).join(''):'No titles found.';result.querySelectorAll('[data-suggestion]').forEach(b=>b.onclick=()=>{rememberSearch(q);let item=items[Number(b.dataset.suggestion)];selectSearchItem(item)})}catch(e){if(seq===popupSequence&&box.isConnected)result.textContent='Search unavailable. Check your connection or try another library.'}};
 input.oninput=()=>{popupSequence++;clearTimeout(popupTimer);if(!input.value.trim()){showRecent();return}popupTimer=setTimeout(run,450)};
 input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();clearTimeout(popupTimer);rememberSearch(input.value);run()}else if(e.key==='Escape'){closeSearchPopup();$('#header-search').focus()}};$('#popup-go').onclick=()=>{clearTimeout(popupTimer);rememberSearch(input.value);run()};showRecent();input.focus()
}

document.addEventListener('click',e=>{let box=$('#search-popup');if(box&&!e.composedPath().includes(box)&&!e.composedPath().includes($('#header-search')))closeSearchPopup()});
function bindSources(callback){document.querySelectorAll('[data-source]').forEach(b=>b.onclick=()=>{source=b.dataset.source;callback()})}
const sourceBar=()=>`<div class="sourcebar"><span class="sub">Library</span><div class="source-grid">${['ms','dk','nine','zoro','ani','salt','flix','zenkai','wixi','aw','miruro','kitsune','paradise'].map(s=>`<button class="chip small ${source===s?'active':''}" data-source="${s}">${label(s)}</button>`).join('')}</div></div>`;

function parseCounts(root,src){
 const n=el=>{const t=el?.textContent.trim()||'';const m=t.match(/^(?:(?:Sub|Dub)\s*)?(\d+)$/i);return m?m[1]:null};
 let sub=n(root.querySelector(src==='ms'?'.hk-tag--sub':'.tick-sub'));
 let dub=n(root.querySelector(src==='ms'?'.hk-tag--dub':'.tick-dub'));
 let total=null;if(src==='dk'||src==='aw')total=n(root.querySelector('.tick-eps'));else for(const e of root.querySelectorAll('.hk-tag')){let m=e.textContent.trim().match(/^(\d+)\s*(?:eps?|episodes?)$/i);if(m){total=m[1];break}}
 return {sub,dub,total};
}
function badgeMarkup(counts){if(!counts)return '';let safe=v=>typeof v==='string'&&/^\d+$/.test(v)?escapeHTML(v):'';let sub=safe(counts.sub),dub=safe(counts.dub),total=safe(counts.total);if(!sub&&!dub&&!total)return '';return `<span class="counts">${sub?`<span class="count subcount" aria-label="${sub} subtitled episodes" title="Subtitled episodes"><span class="ccicon">CC</span>${sub}</span>`:''}${dub?`<span class="count dubcount" aria-label="${dub} dubbed episodes" title="Dubbed episodes"><svg aria-hidden="true" viewBox="0 0 24 24"><path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3Zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.93V22h2v-3.07A7 7 0 0 0 19 12h-2Z"/></svg>${dub}</span>`:''}${total?`<span class="count totalcount" aria-label="${total} episodes reported" title="Episodes reported">${total}</span>`:''}</span>`}
async function hydrateStored(key,items,containerId,marker){await Promise.all(items.map(async(item,i)=>{if(item.counts||!validUrl(item.url))return;try{let doc=parse(await get(item.url));let scope=item.source==='ms'?doc.querySelector('.hk-title__chips'):doc.querySelector('.anisc-detail .film-stats');if(!scope)return;let counts=parseCounts(scope,item.source);if(!counts.sub&&!counts.dub&&!counts.total)return;item.counts=counts;let saved=stored(key);let entry=saved.find(x=>x.url===item.url);if(entry&&!entry.counts){entry.counts=counts;save(key,saved)}if(window.renderSeq!==marker)return;let container=document.getElementById(containerId);let poster=container?.querySelector(`[data-card="${i}"] .poster`);if(poster&&!poster.querySelector('.counts'))poster.insertAdjacentHTML('beforeend',badgeMarkup(counts));}catch(_){}}))}
function cardMarkup(items){return items.length?`<div class="grid">${items.map((x,i)=>`<button class="card" data-card="${i}"><div class="poster">${x.img?`<img src="${escapeHTML(x.img)}" loading="lazy" alt="">`:''}${badgeMarkup(x.counts)}</div><strong>${escapeHTML(x.title)}</strong><small>${escapeHTML(x.meta||'Anime')}</small></button>`).join('')}</div>`:'<div class="empty">No results found.</div>'}
function bindCards(items,root=document){root.querySelectorAll('[data-card]').forEach(b=>b.onclick=()=>openShow(items[Number(b.dataset.card)]))}
function parseExtraCards(html,s){let d=parse(html),nodes=d.querySelectorAll(s==='nine'?'.flw-item':s==='zoro'?'.bsx':s==='ani'?'.item':'article.post'),out=[],seen=new Set();nodes.forEach(n=>{let a=n.querySelector(s==='nine'?'.film-name a':s==='zoro'?'a[href*="/anime/"]':s==='ani'?'.info a.name':'a[href*="/series/"],a[href*="/movies/"]'),img=n.querySelector('img');if(!a)return;let name=(s==='zoro'?a.getAttribute('title'):s==='salt'?n.querySelector('.entry-title')?.textContent:a.textContent)?.trim()||img?.getAttribute('alt')||'';let url=validUrl(new URL(a.getAttribute('href'),base(s)).href),imageRaw=img?.getAttribute('data-src')||img?.getAttribute('src')||'',image=imageRaw?validUrl(new URL(imageRaw,base(s)).href,'image'):'';if(!url||new URL(url).hostname!==new URL(base(s)).hostname||!name||seen.has(url))return;seen.add(url);let c={};if(s==='ani'){const num=sel=>n.querySelector(sel)?.textContent.trim().match(/^\d+$/)?.[0]||null;c={sub:num('.ep-status.sub'),dub:num('.ep-status.dub'),total:num('.ep-status.total')}}out.push({title:name,url,img:image,source:s,counts:c,meta:'Anime'})});return out}
function parseCards(html,s){if(s!=='ms'&&s!=='dk'&&s!=='flix'&&s!=='aw')return parseExtraCards(html,s);let d=parse(html),nodes=d.querySelectorAll(s==='ms'?'.hk-tile':'.flw-item'),out=[],seen=new Set();nodes.forEach(n=>{let a=n.querySelector(s==='ms'?'.hk-tile__name a':'.film-name a')||n.querySelector('a[href]');let img=n.querySelector('img');let name=(s==='aw'?a?.getAttribute('title'):'')||(s==='ms'?n.querySelector('.hk-tile__name'):n.querySelector('.film-name'))?.textContent.trim()||img?.getAttribute('alt')||'';let url=validUrl(abs(a?.getAttribute('href')||'',s));let imageRaw=img?.getAttribute('data-src')||img?.getAttribute('src')||'',image=imageRaw?validUrl(abs(imageRaw,s),'image'):'';if(name&&url&&!seen.has(url)){seen.add(url);let metaNode=n.querySelector(s==='ms'?'.hk-tile__meta':'.fd-infor'),parts=[...(metaNode?.querySelectorAll('span')||[])].map(x=>x.textContent.trim()).filter(Boolean),meta=parts.length?parts.join(' · '):(metaNode?.textContent.trim().replace(/\s+/g,' ')||'');out.push({title:name,url,img:image,source:s,counts:parseCounts(n,s),meta})}});return out}
// 5.30: categories and their provider-specific filters.  Unsupported sources are
// left unavailable rather than passing unverified genre or popularity parameters.
const discoveryGenres=[
 {id:"action",name:"Action",icon:"✦",note:"Big moments"},
 {id:"adventure",name:"Adventure",icon:"⌁",note:"New horizons"},
 {id:"comedy",name:"Comedy",icon:"☼",note:"A lighter mood"},
 {id:"drama",name:"Drama",icon:"◇",note:"Stories that stay"},
 {id:"fantasy",name:"Fantasy",icon:"✧",note:"Worlds beyond"},
 {id:"romance",name:"Romance",icon:"♡",note:"Close connections"},
 {id:"sci-fi",name:"Sci-Fi",icon:"◉",note:"Possible futures"},
 {id:"mystery",name:"Mystery",icon:"⌕",note:"Follow the clues"},
 {id:"slice-of-life",name:"Slice of Life",icon:"❀",note:"Everyday moments"},
 {id:"supernatural",name:"Supernatural",icon:"☾",note:"Beyond ordinary"},
 {id:"isekai",name:"Isekai",icon:"✺",note:"Another world"},
 {id:"sports",name:"Sports",icon:"◈",note:"Chase the win"},
 {id:"horror",name:"Horror",icon:"☽",note:"Into the shadows"},
 {id:"music",name:"Music",icon:"♫",note:"Stories with rhythm"},
 {id:"school",name:"School",icon:"✎",note:"Classroom stories"},
 {id:"psychological",name:"Psychological",icon:"◌",note:"Inside the mind"},
 {id:"thriller",name:"Thriller",icon:"⚡",note:"On the edge"},
 {id:"suspense",name:"Suspense",icon:"◐",note:"What happens next"},
 {id:"historical",name:"Historical",icon:"⌛",note:"Stories of the past"},
 {id:"martial-arts",name:"Martial Arts",icon:"↟",note:"Skill and spirit"},
 {id:"mecha",name:"Mecha",icon:"⚙",note:"Machines in motion"},
 {id:"military",name:"Military",icon:"✢",note:"Courage and conflict"},
 {id:"magic",name:"Magic",icon:"✶",note:"A little wonder"},
 {id:"game",name:"Game",icon:"▦",note:"Play the story"},
 {id:"samurai",name:"Samurai",icon:"⚔",note:"The way of the blade"},
 {id:"space",name:"Space",icon:"☄",note:"Beyond the stars"},
 {id:"vampire",name:"Vampire",icon:"♢",note:"Creatures of night"},
 {id:"super-power",name:"Super Power",icon:"ϟ",note:"Extraordinary gifts"},
 {id:"parody",name:"Parody",icon:"♧",note:"A playful twist"},
 {id:"gourmet",name:"Gourmet",icon:"♨",note:"Food and friendship"},
 {id:"shounen",name:"Shonen",icon:"↟",note:"Bold journeys"},
 {id:"shoujo",name:"Shojo",icon:"✿",note:"Heartfelt stories"},
 {id:"seinen",name:"Seinen",icon:"✶",note:"Another perspective"},
 {id:"josei",name:"Josei",icon:"❃",note:"Life and connection"},
 {id:"kids",name:"Kids",icon:"☀",note:"For younger viewers"},
 {id:"reincarnation",name:"Reincarnation",icon:"↻",note:"A second chance"},
 {id:"time-travel",name:"Time Travel",icon:"◷",note:"Across the years"},
 {id:"villainess",name:"Villainess",icon:"♕",note:"A new point of view"},
 {id:"adult-cast",name:"Adult Cast",icon:"♙",note:"Grown-up leads"},
 {id:"boys-love",name:"Boys Love",icon:"♡",note:"Love stories"},
 {id:"girls-love",name:"Girls Love",icon:"ღ",note:"Love stories"},
 {id:"mahou-shoujo",name:"Mahou Shoujo",icon:"✰",note:"Magical heroines"},
 {id:"performing-arts",name:"Performing Arts",icon:"♬",note:"On the stage"},
 {id:"racing",name:"Racing",icon:"➤",note:"Speed and rivalry"},
 {id:"video-game",name:"Video Game",icon:"▣",note:"Digital worlds"},
 {id:"detective",name:"Detective",icon:"⌕",note:"Solve the case"},
 {id:"survival",name:"Survival",icon:"△",note:"Against the odds"},
 {id:"award-winning",name:"Award Winning",icon:"✸",note:"Recognized stories"},
 {id:"urban-fantasy",name:"Urban Fantasy",icon:"◧",note:"Magic in the city"},
 {id:"workplace",name:"Workplace",icon:"▤",note:"Life on the job"},
 {id:"demons",name:"Demons",icon:"♠",note:"Otherworldly forces"},
 {id:"family",name:"Family",icon:"⌂",note:"Stories together"},
];
// Each mapping comes from that library’s filter form or genre taxonomy.
const providerGenreMaps={
 ms:{"action":"Action","adventure":"Adventure","comedy":"Comedy","drama":"Drama","fantasy":"Fantasy","romance":"Romance","sci-fi":"Sci-Fi","mystery":"Mystery","slice-of-life":"Slice of Life","supernatural":"Supernatural","isekai":"Isekai","sports":"Sports","horror":"Horror","music":"Music","school":"School","psychological":"Psychological","thriller":"Thriller","suspense":"Suspense","historical":"Historical","martial-arts":"Martial Arts","mecha":"Mecha","military":"Military","magic":"Magic","game":"Game","samurai":"Samurai","space":"Space","vampire":"Vampire","super-power":"Super Power","parody":"Parody","gourmet":"Gourmet","shounen":"Shounen","shoujo":"Shoujo","seinen":"Seinen","josei":"Josei","kids":"Kids","boys-love":"Boys Love","girls-love":"Girls Love","mahou-shoujo":"Mahou Shoujo","performing-arts":"Performing Arts","racing":"Racing","award-winning":"Award Winning","demons":"Demons"},
 dk:{"action":"Action","adventure":"Adventure","comedy":"Comedy","drama":"Drama","fantasy":"Fantasy","romance":"Romance","sci-fi":"Sci-Fi","mystery":"Mystery","slice-of-life":"Slice of Life","supernatural":"Supernatural","isekai":"Isekai","sports":"Sports","horror":"Horror","music":"Music","school":"School","psychological":"Psychological","thriller":"Thriller","historical":"Historical","martial-arts":"Martial Arts","mecha":"Mecha","military":"Military","magic":"Magic","game":"Game","samurai":"Samurai","space":"Space","vampire":"Vampire","super-power":"Super Power","parody":"Parody","shounen":"Shounen","shoujo":"Shoujo","seinen":"Seinen","josei":"Josei","kids":"Kids","demons":"Demons"},
 nine:{"action":"3","adventure":"4","comedy":"56","drama":"82","fantasy":"5","romance":"24","sci-fi":"350","mystery":"23","slice-of-life":"343","supernatural":"26","isekai":"41","sports":"759","horror":"22","music":"240","school":"57","psychological":"134","suspense":"135","historical":"21","martial-arts":"366","mecha":"349","military":"507","super-power":"315","parody":"121","gourmet":"342","shounen":"6","shoujo":"25","seinen":"176","josei":"42","reincarnation":"122","time-travel":"164","villainess":"43","adult-cast":"69","boys-love":"219","girls-love":"341","mahou-shoujo":"535","performing-arts":"289","urban-fantasy":"427"},
 ani:{"action":"1","adventure":"10","comedy":"4","drama":"30","fantasy":"5","romance":"23","sci-fi":"44","mystery":"272","slice-of-life":"8","supernatural":"19","isekai":"12","sports":"96","horror":"188","music":"317","school":"106","psychological":"139","suspense":"138","historical":"180","martial-arts":"209","mecha":"45","military":"55","samurai":"181","space":"869","vampire":"934","super-power":"6","parody":"748","gourmet":"90","shounen":"7","shoujo":"25","seinen":"17","josei":"298","kids":"93","reincarnation":"13","time-travel":"470","villainess":"359345","adult-cast":"15","mahou-shoujo":"241","performing-arts":"1011","racing":"1162","video-game":"94","detective":"593","survival":"677","award-winning":"2035","urban-fantasy":"586648","workplace":"16"},
 aw:{"action":"action","adventure":"adventure","comedy":"comedy","drama":"drama","fantasy":"fantasy","romance":"romance","sci-fi":"sci-fi","mystery":"mystery","slice-of-life":"slice-of-life","supernatural":"supernatural","isekai":"isekai","sports":"sports","horror":"horror","music":"music","school":"school","psychological":"psychological","thriller":"thriller","suspense":"suspense","historical":"historical","martial-arts":"martial-arts","mecha":"mecha","military":"military","samurai":"samurai","super-power":"super-power","parody":"parody","gourmet":"gourmet","shounen":"shounen","shoujo":"shoujo","seinen":"seinen","kids":"kids","boys-love":"boys-love","girls-love":"girls-love","mahou-shoujo":"mahou-shoujo"},
 flix:{"action":"action","adventure":"adventure","comedy":"comedy","drama":"drama","fantasy":"fantasy","romance":"romance","mystery":"mystery","slice-of-life":"slice-of-life","supernatural":"supernatural","sports":"sports","horror":"horror","music":"music","school":"school","historical":"historical","mecha":"mecha","military":"military","parody":"parody","shounen":"shounen","kids":"kids"},
 salt:{"action":"action","adventure":"adventure","comedy":"comedy","drama":"drama","fantasy":"fantasy","romance":"romance","sci-fi":"sci-fi","mystery":"mystery","slice-of-life":"slice-of-life","supernatural":"supernatural","isekai":"isekai","sports":"sports","horror":"horror-genre","music":"musical","school":"school","psychological":"psychological","thriller":"thriller","suspense":"suspense","historical":"historical","martial-arts":"martial-arts","mecha":"mecha","military":"military","samurai":"samurai","vampire":"vampire","super-power":"super-power","parody":"parody","gourmet":"gourmet","shounen":"shounen","kids":"kids","reincarnation":"reincarnation","time-travel":"time-travel","adult-cast":"adult-cast","video-game":"video-game","award-winning":"award-winning","family":"family"},
};

// Library 12 uses its own AniList-backed filter vocabulary.
providerGenreMaps.kitsune={"action":"action","adventure":"adventure","comedy":"comedy","drama":"drama","fantasy":"fantasy","romance":"romance","sci-fi":"sci-fi","mystery":"mystery","slice-of-life":"slice-of-life","supernatural":"supernatural","isekai":"isekai","sports":"sports","horror":"horror","music":"music","school":"school","psychological":"psychological","thriller":"thriller","historical":"historical","martial-arts":"martial-arts","mecha":"mecha","military":"military","magic":"magic","game":"game","samurai":"samurai","space":"space","vampire":"vampire","super-power":"super-power","parody":"parody","shounen":"shounen","shoujo":"shoujo","seinen":"seinen","josei":"josei","kids":"kids","demons":"demons"};
function supportedGenres(s){if(s==='unified')return discoveryGenres.filter(g=>unifiedCodes.some(code=>Object.prototype.hasOwnProperty.call(providerGenreMaps[code]||{},g.id)));const map=providerGenreMaps[s]||{};return discoveryGenres.filter(g=>Object.prototype.hasOwnProperty.call(map,g.id))}
function sourceGenre(s,id){return (providerGenreMaps[s]||{})[id]||''}
function popularityAvailable(s,mode){return (['ms','dk','nine','ani','flix'].includes(s)&&['all','genre','music'].includes(mode))||(s==='aw'&&mode==='all')||(s==='kitsune'&&['all','genre','music'].includes(mode))}
let activePager=null,homePagerState=null,browsePagerState=null;
let browseTab='all',browseGenreId='',browseQuery='',browseSort='source',genreFilter='';
let showOrigin={view:'home',y:0};
function detachPager(){
 const p=activePager;if(!p)return;
 p.disposed=true;p.state.generation++;p.state.loading=false;
 if(p.observer)p.observer.disconnect();if(p.imageObserver)p.imageObserver.disconnect();
 if(p.scrollHandler)window.removeEventListener('scroll',p.scrollHandler);
 p.imageQueue=[];activePager=null;
}
function makePager(spec){if(spec.source==='unified')return makeUnifiedPager(spec);return {spec,items:[],seen:new Set(),page:1,done:false,loading:false,error:'',autoPaused:false,generation:0}}
function sameSpec(a,b){return !!a&&JSON.stringify(a.spec)===JSON.stringify(b)}
function catalogUrl(spec,page){
 const s=spec.source,mode=spec.mode,q=encodeURIComponent(spec.query||''),root=base(s);
 const genre=sourceGenre(s,spec.genre||'music'),g=encodeURIComponent(genre);
 if(!root||!Number.isInteger(page)||page<1)return '';
 if((mode==='genre'||mode==='music')&&!genre)return '';
 if(s==='miruro')return miruroCatalogUrl(spec,page);
 if(s==='kitsune')return kitsuneCatalogUrl(spec,page);
 if(s==='paradise')return paradiseCatalogUrl(spec,page);
 if(s==='zenkai'){
  if(mode==='search')return page===1?root+'/api/anilist/search?q='+q:'';
  if(mode==='new')return ''; // Recent episodes are not a verified newly-added series list.
  if(mode==='popularShelf')return page===1?root+'/api/scraped-catalog?limit=24&page=1':'';
  if(mode==='all')return root+'/api/scraped-catalog?limit=24&page='+page;
  return '';
 }
 if(s==='wixi'){
  if(mode==='popularShelf')return page===1?root+'/wp-json/aniwixi/v1/anime?page=1&per_page=24':'';
  if(mode==='new')return ''; // This API does not document a newest-series sort.
  if(mode==='all')return root+'/wp-json/aniwixi/v1/anime?page='+page+'&per_page=24';
  if(mode==='search')return root+'/wp-json/aniwixi/v1/search?q='+q+'&page='+page+'&per_page=24';
  return '';
 }
 if(s==='aw'){
  if(mode==='popularShelf')return page===1?root+'/most-popular-anime/':'';
  if(mode==='all')return root+'/most-popular-anime/?anime-page='+page;
  if(mode==='search')return root+'/?s='+q+(page>1?'&page='+page:'');
  if(mode==='airing')return root+'/top-airing/?anime-page='+page;
  if(mode==='genre'||mode==='music')return root+'/genre/'+g+'/?page='+page;
  return ''; // The source's recent episode updates are not a newly-added-series feed.
 }
 if(s==='flix'){
  if(mode==='popularShelf')return page===1?root+'/most-popular/':'';
  if(mode==='all')return root+'/most-popular/?anime-page='+page;
  if(mode==='new')return page===1?root+'/new-on-site/':'';
  if(mode==='airing')return root+'/top-airing/?anime-page='+page;
  if(mode==='search')return root+'/?s='+q+'&page='+page;
  if(mode==='genre'||mode==='music')return root+'/genre/'+g+'/?page='+page;
  return '';
 }
 if(mode==='popularShelf')return page===1?(s==='zoro'?root+'/anime/':s==='salt'?root+'/':''):'';
 if(s==='zoro'){
  if(!['all','search'].includes(mode))return '';
  return root+'/wp-json/wp/v2/categories?per_page=24&page='+page+'&hide_empty=true&_fields=id,name,slug,link'+(mode==='search'?'&search='+q:'');
 }
 if(s==='salt'){
  if(mode==='new')return page===1?root+'/':'';
  if(mode==='all')return root+(page===1?'/series/':'/series/page/'+page+'/');
  if(mode==='search')return root+(page===1?'/':'/page/'+page+'/')+'?s='+q;
  if(mode==='genre'||mode==='music')return root+'/category/'+g+(page===1?'/':'/page/'+page+'/')+'?type=series';
  return '';
 }
 if(s==='nine'){
  const query=mode==='search'?'keyword='+q:mode==='airing'?'status=2':mode==='new'?'sort=recentlyAdded':(mode==='genre'||mode==='music')?'genre='+g+'&sort=mostWatched':mode==='all'?'sort=mostWatched':'';
  return query?root+'/filter/'+(page===1?'':'page/'+page+'/')+'?'+query:'';
 }
 if(s==='ani'){
  if(mode==='airing')return root+'/ongoing'+(page===1?'':'/page/'+page);
  let query=mode==='search'?'keyword='+q:mode==='new'?'sort_by=created_at':(mode==='genre'||mode==='music')?'genre%5B%5D='+g+'&sort_by=popularity':mode==='all'?'sort_by=popularity':'';
  if(!query)return '';if(page>1)query+='&page='+page;
  return root+'/filter?'+query;
 }
 let path='',query='';
 if(mode==='all')path='/most-popular';
 else if(mode==='new'){if(s==='ms')path='/new-releases';else{path='/filter';query='sort=recently_added'}}
 else if(mode==='search'){path='/search';query='keyword='+q}
 else if(mode==='genre'||mode==='music'){path=s==='ms'?'/browse':'/filter';query=s==='ms'?'genres%5B%5D='+g+'&sort=popularity':'genre='+g+'&sort=popularity'}
 else if(mode==='airing'){if(s==='dk'){path='/filter';query='status=Airing'}else path='/top-airing'}
 else return '';
 if(page>1)query+=(query?'&':'')+'page='+page;
 return root+path+(query?'?'+query:'');
}
function sourceNeedsVerification(doc){
 const title=(doc.querySelector('title')?.textContent||'').trim();
 return /^(just a moment|attention required|verify you are human|access denied)/i.test(title)||!!doc.querySelector('#challenge-form,#challenge-stage,.cf-challenge');
}
function providerHasNext(doc,page,src){
 const candidates=[...doc.querySelectorAll('.pagination a[href],.anime-pagination a[href],a[rel="next"],.wp-pagenavi a[href]')];
 return candidates.some(a=>{
  if(a.classList.contains('disabled')||a.closest('.disabled')||a.getAttribute('aria-disabled')==='true')return false;
  const txt=(a.textContent||'').trim(),hint=(a.getAttribute('aria-label')||'')+' '+(a.getAttribute('title')||'');
  const looksNext=txt===String(page+1)||/\bnext\b/i.test(hint)||/^next\b/i.test(txt)||txt==='›'||a.classList.contains('next');
  if(!looksNext)return false;
  try{const u=new URL(a.getAttribute('href'),base(src));if(u.protocol!=='https:'||u.hostname!==new URL(base(src)).hostname)return false;
   const n=Number(u.searchParams.get('paged')||u.searchParams.get('anime-page')||u.searchParams.get('page')||(u.pathname.match(/\/page\/(\d+)/)||[])[1]||0);
   return n===page+1;
  }catch{return false}
 });
}
function zoroCategories(raw){
 let rows;try{rows=JSON.parse(raw)}catch(_){throw Error('The library returned an unreadable catalogue.')}
 if(!Array.isArray(rows))throw Error('The library returned an unreadable catalogue.');
 const items=rows.flatMap(row=>{
  let slug=String(row?.slug||''),name=String(row?.name||'').trim(),url=validUrl(String(row?.link||''));
  if(!name||name.length>300||!/^[a-z0-9][a-z0-9-]{0,180}$/.test(slug)||!url)return [];
  let parsed=new URL(url);if(parsed.hostname!=='zorotv.ba'||parsed.pathname!=='/category/'+slug+'/')return [];
  // This is a candidate series URL, never an automatic episode/season match.
  // Its heading is checked against the category name before opening it.
  return [{title:name,url:base('zoro')+'/anime/'+slug+'/',img:'',source:'zoro',meta:'Anime',verifyTitle:true}];
 });
 return {items,hasNext:rows.length===24};
}
// Libraries 4 and 6 publish finite popular charts on their own pages.  Library 6
// also publishes a distinct "New Anime Arrivals" shelf.  These are not fabricated
// rankings or episode-update lists; the general catalogue stays separately paged.
function zoroPopular(doc){
 const seen=new Set(),out=[];
 for(const n of doc.querySelectorAll('.serieslist.wpop-alltime li')){
  const a=n.querySelector('.leftseries h4 a[href]'),im=n.querySelector('img');
  const title=(a?.textContent||'').trim(),url=validUrl(abs(a?.getAttribute('href')||'','zoro'));
  const img=im?validUrl(abs(im.getAttribute('data-src')||im.getAttribute('src')||'','zoro'),'image'):'';
  if(!title||!url||new URL(url).hostname!=='zorotv.ba'||!new URL(url).pathname.startsWith('/anime/')||seen.has(url))continue;
  seen.add(url);out.push({title,url,img,source:'zoro',meta:'Series',verifyTitle:true});
 }
 return out;
}
function saltHomeShelf(doc,mode){
 let nodes=[];
 if(mode==='popularShelf'){
  const anchor=doc.querySelector('a[data-post="series"][data-category]'),id=anchor?.closest('[data-tbs]')?.getAttribute('data-tbs');
  const chart=id?doc.getElementById(id):null;nodes=chart?[...chart.querySelectorAll('.chart-item')]:[];
 }else{
  const section=[...doc.querySelectorAll('section.widget_list_movies_series')].find(x=>/new anime arrivals/i.test(x.querySelector('h3')?.textContent||''));
  nodes=section?[...section.querySelectorAll('article.post')]:[];
 }
 const out=[],seen=new Set();
 for(const n of nodes){
  const a=n.querySelector('a[href*="/series/"]'),im=n.querySelector('img');
  const url=validUrl(abs(a?.getAttribute('href')||'','salt'));
  const title=(mode==='popularShelf'?n.querySelector('.chart-title')?.textContent:(n.querySelector('.entry-title')?.textContent||im?.getAttribute('alt')?.replace(/^Image\s+/i,'')))?.trim()||'';
  const img=im?validUrl(abs(im.getAttribute('data-src')||im.getAttribute('src')||'','salt'),'image'):'';
  if(!title||!url||new URL(url).hostname!=='animesalt.cx'||!new URL(url).pathname.startsWith('/series/')||seen.has(url))continue;
  seen.add(url);out.push({title,url,img,source:'salt',meta:'Series'});
 }
 return out;
}
const homeDocuments=new Map();
function sharedHomeDocument(source,url){
 const cached=homeDocuments.get(source);if(cached&&cached.expires>Date.now())return cached.promise;
 const entry={expires:Date.now()+5*60*1000,promise:null};
 entry.promise=get(url).catch(e=>{if(homeDocuments.get(source)===entry)homeDocuments.delete(source);throw e});
 homeDocuments.set(source,entry);return entry.promise;
}
async function fetchCatalogPage(spec,page){
 const url=catalogUrl(spec,page);
 if(!url)throw Error('This section is not available from '+label(spec.source)+'. Choose another library.');
 const special=spec.mode==='popularShelf'||(spec.source==='salt'&&spec.mode==='new');
 const share=special||(spec.mode==='all'&&page===1);
 const raw=share?await sharedHomeDocument(spec.source+'|'+url,url):await get(url);
 if(spec.source==='miruro')return miruroCatalog(spec,page,raw);
 if(spec.source==='kitsune')return kitsuneCatalog(spec,page,raw);
 if(spec.source==='paradise')return paradiseCatalog(spec,page,raw);
 if(['zenkai','wixi'].includes(spec.source))return addedCatalog(spec,page,raw);
 if(spec.source==='zoro'&&!special)return zoroCategories(raw);
 const doc=parse(raw);if(sourceNeedsVerification(doc))throw Error('The library requested human verification. Try another library or check it manually.');
 if(special){const items=spec.source==='zoro'?zoroPopular(doc):spec.source==='flix'||spec.source==='aw'?parseCards(raw,spec.source):saltHomeShelf(doc,spec.mode);if(!items.length)throw Error('The library’s '+(spec.mode==='new'?'new arrivals':'popularity chart')+' could not be read.');return {items,hasNext:false}}
 return {items:parseCards(raw,spec.source),hasNext:providerHasNext(doc,page,spec.source)};
}
function cardItemMarkup(x,index){
 return `<button class="card" type="button" data-card="${index}"><div class="poster">${x.img?`<img src="${escapeHTML(x.img)}" loading="lazy" decoding="async" alt="">`:'<span class="poster-fallback" aria-hidden="true">✦</span>'}${badgeMarkup(x.counts)}</div><strong>${escapeHTML(x.title)}</strong><small>${escapeHTML(x.meta||'Anime')}</small></button>`;
}
function updatePagerStatus(p){
 if(p.state.unified)return unifiedPagerStatus(p);
 if(activePager!==p||p.disposed)return;
 const st=p.state,box=p.status;if(p.onStatus)p.onStatus(st,p);
 if(st.loading){box.innerHTML='<span class="pager-loading"><span class="pager-dot" aria-hidden="true"></span> Loading more anime…</span>';return}
 if(st.error){box.innerHTML=`<p class="pager-message">${escapeHTML(st.error)}</p>${st.noRetry?'':'<button type="button" class="pager-button" data-pager-retry>Retry</button>'}`;let retry=box.querySelector('button');if(retry)retry.onclick=()=>{st.error='';st.autoPaused=false;loadMore(p,true)};return}
 if(st.done){box.innerHTML=`<p class="pager-message">${st.items.length?'You’ve reached the end of this library’s available results.':'No titles found in this library.'}</p>`;return}
 box.innerHTML=`${st.autoPaused?'<p class="pager-message">No new titles on the last page. You can try the next page.</p>':''}<button type="button" class="pager-button" data-pager-more>Load more <span aria-hidden="true">↓</span></button>`;
 box.querySelector('button').onclick=()=>{st.autoPaused=false;loadMore(p,true)};
}
function renderPagerCards(p,force=false){
 if(activePager!==p||p.disposed)return;
 const st=p.state,sort=p.sort?p.sort():'source',skip=p.skip||0;
 const allowed=i=>i>=skip&&!(p.excludeUrls&&p.excludeUrls.has(st.items[i].url))&&(!p.itemFilter||p.itemFilter(st.items[i]));
 if(force||sort!=='source'||p.shown>st.items.length){
  if(p.imageObserver){p.imageObserver.disconnect();p.imageObserver=null}
  let indices=st.items.map((_,i)=>i).filter(allowed);
  if(sort==='az'||sort==='za')indices.sort((a,b)=>st.items[a].title.localeCompare(st.items[b].title,undefined,{sensitivity:'base'})*(sort==='az'?1:-1));
  p.grid.innerHTML=indices.map(i=>p.renderCard(st.items[i],i)).join('');p.shown=st.items.length;
 }else if(p.shown<st.items.length){
  let indices=[];for(let i=p.shown;i<st.items.length;i++)if(allowed(i))indices.push(i);
  p.grid.insertAdjacentHTML('beforeend',indices.map(i=>p.renderCard(st.items[i],i)).join(''));p.shown=st.items.length;
 }
 if(p.count)p.count.textContent=st.items.length?st.items.length+' loaded':st.unified?'One library':label(st.spec.source);
 if(p.afterRender){try{p.afterRender(p)}catch(_){}}
 observeCandidatePosters(p);
}
// Library 4's public category index has no posters; verify visible candidates
// one at a time before showing their actual source-provided image.
function observeCandidatePosters(p){
 if((p.state.spec.source!=='zoro'&&!p.state.unified)||!('IntersectionObserver' in window))return;
 if(!p.imageObserver)p.imageObserver=new IntersectionObserver(entries=>{
  for(const entry of entries){if(!entry.isIntersecting)continue;p.imageObserver.unobserve(entry.target);
   let idx=Number(entry.target.dataset.card),item=p.state.items[idx];if(item&&item.verifyTitle&&!item.img&&!item.imageTried){item.imageTried=true;p.imageQueue.push(item)}
  }pumpCandidateImages(p);
 },{rootMargin:'120px 0px'});
 p.grid.querySelectorAll('[data-card]').forEach(el=>{let x=p.state.items[Number(el.dataset.card)];if(x?.verifyTitle&&!x.img&&!x.imageTried)p.imageObserver.observe(el)});
}
async function pumpCandidateImages(p){
 if(p.imageBusy||p.disposed||activePager!==p)return;p.imageBusy=true;
 while(p.imageQueue.length&&!p.disposed&&activePager===p){
  const item=p.imageQueue.shift();try{let doc=parse(await get(item.url));
   if(p.disposed||activePager!==p){item.imageTried=false;break}
   if(sourceNeedsVerification(doc)||matchTitle(doc.querySelector('h1')?.textContent)!==matchTitle(item.title))continue;
   const image=validUrl(doc.querySelector('meta[property="og:image"]')?.getAttribute('content')||'','image');
   if(image){item.img=image;if(p.onData&&p.state.items[0]===item)p.onData(item);const index=p.state.items.indexOf(item),poster=p.grid.querySelector(`[data-card="${index}"] .poster`);if(poster){poster.querySelector('.poster-fallback')?.remove();let img=document.createElement('img');img.loading='lazy';img.decoding='async';img.alt='';img.src=image;poster.prepend(img)}}
  }catch(_){item.imageTried=false;/* The source may not have a matching series or be temporarily unavailable. */}
 }
 p.imageBusy=false;
}
async function loadMore(p,manual=false){
 if(p.state.unified)return unifiedLoadMore(p,manual,false);
 const st=p.state;if(activePager!==p||p.disposed||st.loading||st.done||(st.error&&!manual)||(st.autoPaused&&!manual))return;
 const request=++st.generation,page=st.page;st.loading=true;st.error='';updatePagerStatus(p);
 try{
  const result=await fetchCatalogPage(st.spec,page);
  if(activePager!==p||p.disposed||st.generation!==request)return;
  if(page===1&&st.spec.mode==='all'&&!result.items.length&&!result.hasNext)throw Error('The library returned no readable catalogue. Its layout may have changed.');
  let added=0;for(const item of result.items){let key=item.source+'|'+item.url;if(!st.seen.has(key)){st.seen.add(key);st.items.push(item);added++}}
  st.page=page+1;st.done=!result.hasNext;st.autoPaused=added===0&&!st.done;
  renderPagerCards(p);if(p.onData&&st.items.length)p.onData(st.items[0]);
 }catch(e){
  if(activePager!==p||p.disposed||st.generation!==request)return;
  if(st.spec.source==='zoro'&&page>1&&/HTTP 400\b/i.test(String(e.message))){st.done=true}
  else if(/^This section is not available/.test(String(e.message))){st.error=String(e.message);st.noRetry=true}
  else st.error=/\b(?:403|429)\b/.test(String(e.message))?'The library blocked this request or asked for verification. Check it manually or choose another library.':('Couldn’t load '+label(st.spec.source)+'. '+String(e.message||'Please try again.'));
 }finally{
  if(activePager===p&&!p.disposed&&st.generation===request){st.loading=false;updatePagerStatus(p);if(p.observer&&!st.done&&!st.error&&!st.autoPaused){p.observer.unobserve(p.sentinel);p.observer.observe(p.sentinel)}}
 }
}
function mountPager(state,options={}){
 detachPager();const root=$('#results');if(!root)return;
 root.innerHTML='<div class="'+(options.layout==='air'?'air-list':'grid')+' pager-grid"></div><div class="pager-status" role="status" aria-live="polite"></div><div class="list-sentinel" aria-hidden="true"></div>';
 const p={state,root,grid:root.querySelector('.pager-grid'),status:root.querySelector('.pager-status'),sentinel:root.querySelector('.list-sentinel'),shown:0,renderCard:options.renderCard||cardItemMarkup,sort:options.sort,onData:options.onData,onStatus:options.onStatus,skip:options.skip||0,excludeUrls:options.excludeUrls||null,count:options.count||null,disposed:false,imageQueue:[],imageBusy:false};
 activePager=p;p.grid.onclick=e=>{const b=e.target.closest('[data-card]');if(!b||!p.grid.contains(b))return;const x=state.items[Number(b.dataset.card)];if(x)openShow(x)};
 renderPagerCards(p);if(p.onData&&state.items.length)p.onData(state.items[0]);updatePagerStatus(p);
 if('IntersectionObserver' in window){p.observer=new IntersectionObserver(entries=>{if(entries.some(x=>x.isIntersecting))loadMore(p)},{rootMargin:'0px 0px 240px 0px'});p.observer.observe(p.sentinel)}
 else{p.scrollHandler=()=>{if(p.sentinel.getBoundingClientRect().top<innerHeight+240)loadMore(p)};window.addEventListener('scroll',p.scrollHandler,{passive:true})}
 if(!state.items.length&&!state.done&&!state.error)loadMore(p);
}
// 5.81: the home hero is a swipeable deck of the strongest titles, with page dots.
// Each slide is a real catalogue item, so the pill always opens its episode list.
let heroDeck581=[],heroIndex581=0,heroTimer581=0,heroTouched581=0;
function heroTag581(x){
 return ['zenkai','wixi','kitsune','paradise'].includes(x.source)?'LIBRARY PICK':x.source==='zoro'?'ALL-TIME FAVORITE':x.source==='salt'||x.source==='nine'?'MOST WATCHED':'POPULAR IN '+label(x.source).toUpperCase();
}
function heroSlide581(x,i){
 return `<div class="hero-slide" role="group" aria-roledescription="slide" aria-label="${i+1} of ${heroDeck581.length}: ${escapeHTML(x.title)}" data-hero="${i}">${x.img?`<img src="${escapeHTML(x.img)}" alt="" loading="${i===0?'eager':'lazy'}">`:'<span class="hero-slide-blank" aria-hidden="true">✦</span>'}<div class="hero-slide-shade"></div><div class="hero-slide-copy"><div class="overline">✦ ${escapeHTML(heroTag581(x))}</div><h1>${escapeHTML(x.title)}</h1><p>${escapeHTML(x.meta||'Anime')} · ${escapeHTML(label(x.source))}</p><button type="button" class="btn primary" data-hero-open="${i}">▶ &nbsp;Watch</button></div></div>`;
}
function paintHero581(){
 const spot=$('#spotlight');if(!spot||view!=='home')return;
 if(!heroDeck581.length)return;
 if(heroIndex581>=heroDeck581.length)heroIndex581=0;
 spot.innerHTML=`<div class="hero-deck581"><div class="hero-track581" role="region" aria-label="Featured titles">${heroDeck581.map(heroSlide581).join('')}</div>${heroDeck581.length>1?`<div class="hero-dots581" role="group" aria-label="Choose a featured title">${heroDeck581.map((x,i)=>`<button type="button" class="hero-dot581" data-hero-dot="${i}" aria-label="${escapeHTML(x.title)}" aria-current="${i===heroIndex581?'true':'false'}"></button>`).join('')}</div>`:''}</div>`;
 const track=spot.querySelector('.hero-track581');
 const go=(i,smooth=true)=>{heroIndex581=(i+heroDeck581.length)%heroDeck581.length;const left=track.clientWidth*heroIndex581;if(typeof track.scrollTo==='function'){try{track.scrollTo({left,behavior:smooth?'smooth':'auto'})}catch{track.scrollLeft=left}}else track.scrollLeft=left;spot.querySelectorAll('[data-hero-dot]').forEach((d,n)=>d.setAttribute('aria-current',String(n===heroIndex581)))};
 spot.querySelectorAll('[data-hero-open]').forEach(b=>b.onclick=()=>{const x=heroDeck581[Number(b.dataset.heroOpen)];if(x)openShow(x)});
 spot.querySelectorAll('[data-hero-dot]').forEach(d=>d.onclick=()=>{heroTouched581=Date.now();go(Number(d.dataset.heroDot))});
 track.addEventListener('scroll',()=>{const i=Math.round(track.scrollLeft/Math.max(1,track.clientWidth));if(i!==heroIndex581&&i>=0&&i<heroDeck581.length){heroIndex581=i;spot.querySelectorAll('[data-hero-dot]').forEach((d,n)=>d.setAttribute('aria-current',String(n===i)))}},{passive:true});
 track.addEventListener('pointerdown',()=>{heroTouched581=Date.now()});
 clearInterval(heroTimer581);heroTimer581=0;
 const reduce=window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
 if(heroDeck581.length>1&&!reduce)heroTimer581=setInterval(()=>{
  if(view!=='home'||document.visibilityState!=='visible'||Date.now()-heroTouched581<9000)return;
  const active=document.activeElement;if(active&&track.contains(active))return;
  go(heroIndex581+1);
 },7000);
}
function renderSpotlight(x){
 if(!x)return;
 const add=items=>{for(const item of items){if(!item||!item.url||typeof item.title!=='string')continue;if(!heroDeck581.some(h=>h.url===item.url))heroDeck581.push(item)}heroDeck581=heroDeck581.slice(0,5);paintHero581()};
 add(Array.isArray(x)?x:[x]);
}
// A small, on-device discovery hint. This compares title words, not genres or
// an external recommendation service; source catalogues are already loaded.
function discoveryWords573(title){return [...new Set(String(title||'').normalize('NFKC').toLocaleLowerCase().match(/[\p{L}\p{N}]{4,}/gu)||[])].filter(x=>!new Set(['the','season','episode','anime','with','from','into','your','this','that','part']).has(x))}
let discoveryCandidates573=[];
function homeDiscovery573(candidates){
 discoveryCandidates573=Array.isArray(candidates)?candidates:[];const root=document.getElementById('home-discovery573');if(!root||view!=='home')return;
 const history=historyEntries().map(x=>x.item).filter(safeStoredItem).filter(x=>typeof x.title==='string').slice(0,100);
 const seen=new Set(history.map(x=>String(x.title).normalize('NFKC').toLocaleLowerCase().trim())),urls=new Set(history.map(x=>x.url));
 const words=new Set(history.flatMap(x=>discoveryWords573(x.title)));let blocked=[];try{const saved=JSON.parse(localStorage.getItem('kuro-discovery-hidden573')||'[]');if(Array.isArray(saved))blocked=saved.filter(x=>typeof x==='string').slice(0,20).map(x=>x.normalize('NFKC').toLocaleLowerCase().trim()).filter(Boolean)}catch(_){}const unique=new Set(),matches=[];
 for(const x of candidates||[]){if(!x||!x.url||typeof x.title!=='string'||!safeStoredItem(x)||urls.has(x.url))continue;const title=x.title.normalize('NFKC').toLocaleLowerCase().trim();if(!title||seen.has(title)||unique.has(title)||blocked.some(w=>title.includes(w)))continue;let shared=discoveryWords573(x.title).filter(w=>words.has(w));if(!shared.length)continue;unique.add(title);matches.push({item:x,score:shared.length})}
 matches.sort((a,b)=>b.score-a.score);const items=matches.slice(0,8).map(x=>x.item);root.innerHTML=items.length?cardMarkup(items):'<div class="rail-message">'+(history.length?'No similar title words found in the loaded catalogue yet.':'Open episodes to see local discovery suggestions here.')+'</div>';if(items.length)bindCards(items,root);
}
const homeDiscoverySection573=`<section class="home-rail" aria-labelledby="discovery-heading573"><div class="home-rail-heading"><div><div class="overline">ON THIS DEVICE</div><h2 id="discovery-heading573">Discover from your history</h2></div></div><p class="home-rail-caption">Matches words in titles you opened against the loaded catalogue. Suggestions may be unrelated; history stays on this device.</p><button type="button" class="btn" id="recommend-open573">More recommendations</button><details class="discovery-preferences573"><summary>Discovery content preferences</summary><label>Hide suggestions containing these title words (comma-separated)<input id="discovery-hidden573" maxlength="400" type="text" autocomplete="off"></label><button type="button" id="discovery-save573">Save preferences</button><p id="discovery-status573" role="status"></p><small>Filters suggestions, seasonal titles and the release calendar; not search, your library, related titles or adult content. Saved on this device; not included in backups.</small></details><div id="home-discovery573" class="shelf" aria-live="polite"></div></section>`;
function bindDiscovery573(){document.getElementById('recommend-open573')?.addEventListener('click',()=>window.kuroRecommendations573?.());const field=document.getElementById('discovery-hidden573'),button=document.getElementById('discovery-save573'),status=document.getElementById('discovery-status573');if(!field||!button)return;try{let a=JSON.parse(localStorage.getItem('kuro-discovery-hidden573')||'[]');if(Array.isArray(a))field.value=a.filter(x=>typeof x==='string').slice(0,20).join(', ')}catch(_){}button.onclick=()=>{let a=[...new Set(field.value.split(',').map(x=>x.normalize('NFKC').trim()).filter(Boolean))];if(a.length>20||a.some(x=>x.length>60)){status.textContent='Use at most 20 terms, each no longer than 60 characters.';return}try{if(a.length)localStorage.setItem('kuro-discovery-hidden573',JSON.stringify(a));else localStorage.removeItem('kuro-discovery-hidden573');status.textContent='Discovery preferences saved on this device.';homeDiscovery573(discoveryCandidates573)}catch(_){status.textContent='Could not save preferences on this device.'}}}
const homeShelves=new Map();
function homeShelfCards(root,items,isNew=false){
 const key=items.map(x=>x.url).join('|')+(isNew?'|new':'');if(root.dataset.shelfKey===key)return;
 root.dataset.shelfKey=key;
 if(!isNew){root.innerHTML=cardMarkup(items);bindCards(items,root);return}
 // 5.81: the freshly-added shelf marks each poster with a NEW chip.
 root.innerHTML=`<div class="grid">${items.map((x,i)=>`<button class="card" type="button" data-card="${i}"><div class="poster">${x.img?`<img src="${escapeHTML(x.img)}" loading="lazy" decoding="async" alt="">`:'<span class="poster-fallback" aria-hidden="true">✦</span>'}<span class="poster-new581">NEW</span>${badgeMarkup(x.counts)}</div><strong>${escapeHTML(x.title)}</strong><small>${escapeHTML(x.meta||'Anime')}</small></button>`).join('')}</div>`;
 bindCards(items,root);
}
function homeRankedStatus(st,p){
 const root=$('#home-popular');if(!root||st.items.length)return;
 if(st.error){root.innerHTML=`<div class="rail-message">${escapeHTML(st.error)} ${st.noRetry?'':'<button type="button" data-home-retry>Retry</button>'}</div>`;const button=root.querySelector('button');if(button)button.onclick=()=>{st.error='';loadMore(p,true)};}
 else if(st.done)root.innerHTML='<div class="rail-message">No popular titles were returned by this library.</div>';
 else root.innerHTML='<div class="rail-message"><span class="pager-dot"></span> Loading popular titles…</div>';
}
function renderHomeRanked(x){
 const p=activePager,root=$('#home-popular');if(!p||!root||!p.state.items.length)return;
 renderSpotlight(p.state.items.slice(0,5));homeShelfCards(root,p.state.items.slice(0,8));
}
function loadHomeShelf(s,mode,rootId,marker){
 const root=document.getElementById(rootId);if(!root)return;
 const spec={source:s,mode},key=s+'|'+mode;
 const alive=()=>marker===window.renderSeq&&view==='home'&&source===s&&root.isConnected;
 const show=items=>{
  if(!alive())return;homeShelfCards(root,items,mode==='new');
  if(mode==='popularShelf'&&items.length){
   renderSpotlight(items.slice(0,5));
   if(activePager&&activePager.state===homePagerState){activePager.excludeUrls=new Set(items.map(x=>x.url));renderPagerCards(activePager,true)}
  }
 };
 if(!catalogUrl(spec,1)){root.innerHTML=`<div class="rail-message">New additions aren’t available from ${escapeHTML(label(s))} right now.</div>`;return}
 const cached=homeShelves.get(key);if(cached){show(cached.items);if(cached.expires>Date.now())return}
 else root.innerHTML=`<div class="rail-message"><span class="pager-dot"></span> Loading ${mode==='new'?'new arrivals':'popular titles'}…</div>`;
 fetchCatalogPage(spec,1).then(result=>{
  if(!result.items.length)throw Error('The library returned no readable titles.');
  homeShelves.set(key,{items:result.items.slice(0,mode==='new'?20:25),expires:Date.now()+5*60*1000});
  if(alive())root.querySelector('.home-refresh-error')?.remove();show(homeShelves.get(key).items);
 }).catch(e=>{
  if(!alive())return;
  const msg=/\b(?:403|429)\b/.test(String(e.message))?'The library blocked this request or asked for verification. Check it manually or choose another library.':String(e.message||'Could not load this shelf.');
  const notice=`<div class="rail-message home-refresh-error">${cached?'Showing previously loaded titles. ':''}${escapeHTML(msg)} <button type="button" data-shelf-retry>Retry</button></div>`;
  root.querySelector('.home-refresh-error')?.remove();if(cached)root.insertAdjacentHTML('beforeend',notice);else root.innerHTML=notice;
  root.querySelector('[data-shelf-retry]').onclick=()=>loadHomeShelf(s,mode,rootId,marker);
 });
}
function home(){
 main.classList.add('home-surface576');detachPager();clearInterval(heroTimer581);heroTimer581=0;heroDeck581=[];heroIndex581=0;heroTouched581=0;let marker=++window.renderSeq,recentAll=stored('kuro-recent').slice(0,20),recent=recentAll.filter(safeStoredItem),s=source,ranked=popularityAvailable(s,'all');
 refreshStoredClassifications(recentAll,marker,()=>{if(view==='home')home()});
 const popularLabel=['zenkai','wixi'].includes(s)?'LIBRARY PICKS':s==='zoro'?'ALL-TIME FAVORITES':s==='nine'||s==='salt'?'MOST WATCHED':'POPULARITY';
 const popularTitle=['zenkai','wixi'].includes(s)?'Explore anime':s==='salt'?'Popular series':'Popular anime';
 main.innerHTML=`<div id="spotlight"><div class="hero"><div class="overline">YOUR NEXT STORY AWAITS</div><h1>Find your next obsession.</h1><p class="sub">Anime, all in one place.</p></div></div>${sourceBar()}<section class="home-rail" aria-labelledby="popular-heading"><div class="home-rail-heading"><div><div class="overline">FIRST UP · ${escapeHTML(label(s).toUpperCase())}</div><h2 id="popular-heading">${popularTitle}</h2></div><span class="home-rail-tag">${popularLabel}</span></div><p class="home-rail-caption">${['zenkai','wixi'].includes(s)?'Titles in the library’s own order, not a popularity ranking.':s==='salt'?'The library’s most-watched series; its catalogue also includes cartoons.':'Ranked by the selected library.'}</p><div id="home-popular" class="shelf" aria-live="polite"></div></section><section class="home-rail" aria-labelledby="new-heading"><div class="home-rail-heading"><div><div class="overline">JUST ADDED</div><h2 id="new-heading">New to the library</h2></div><span class="home-rail-tag">NEW</span></div><p class="home-rail-caption">Recently added by ${escapeHTML(label(s))}; not necessarily new releases.</p><div id="home-new" class="shelf" aria-live="polite"></div></section><section class="home-rail" aria-labelledby="recent-heading"><div class="home-rail-heading"><div><div class="overline">PICK UP WHERE YOU LEFT OFF</div><h2 id="recent-heading">Recently watched</h2></div>${recent.length?'<button class="clear-recent" id="clear-recent">Clear all</button>':'<span class="home-rail-tag">ON THIS DEVICE</span>'}</div><div id="recent" class="shelf">${recent.length?cardMarkup(recent):'<div class="rail-message">Episodes you open will appear here.</div>'}</div></section><div class="heading home-more-heading"><div><div class="overline">KEEP EXPLORING</div><h2>${ranked?'More popular anime':'Explore the library'}</h2><p class="home-rail-caption">${ranked?'More titles in popularity order.':'More titles in library order; the chart above is limited.'}</p></div><span id="home-count">${label(s)}</span></div><div id="results"></div>`;
 bindSources(()=>{homePagerState=null;window.scrollTo(0,0);home()});
 if(recent.length){bindCards(recent,$('#recent'));hydrateStored('kuro-recent',recent,'recent',marker);let button=$('#clear-recent');const arm=()=>{button.textContent='Confirm clear';button.onclick=()=>{save('kuro-recent',[]);home()};setTimeout(()=>{if(button.isConnected){button.textContent='Clear all';button.onclick=arm}},5000)};button.onclick=arm}
 const spec={source:s,mode:'all'};if(!sameSpec(homePagerState,spec))homePagerState=makePager(spec);
 mountPager(homePagerState,{skip:ranked?8:0,onData:ranked?renderHomeRanked:null,onStatus:ranked?homeRankedStatus:null,count:$('#home-count')});
 if(!ranked)loadHomeShelf(s,'popularShelf','home-popular',marker);
 loadHomeShelf(s,'new','home-new',marker);
}
window.renderSeq=0;
function tabButton(id,title,icon){return `<button type="button" role="tab" id="discover-tab-${id}" aria-controls="browse-panel" aria-selected="${browseTab===id}" tabindex="${browseTab===id?0:-1}" class="discover-tab ${browseTab===id?'active':''}" data-browse-tab="${id}"><span aria-hidden="true">${icon}</span>${title}</button>`}
function genreTiles(filter=''){
 const term=String(filter).trim().toLocaleLowerCase(),genres=supportedGenres(source).filter(g=>(g.name+' '+g.note).toLocaleLowerCase().includes(term));
 if(!supportedGenres(source).length)return `<div class="genre-empty"><strong>Genres aren’t available here yet.</strong><span>Choose another library to explore its categories.</span></div>`;
 if(!genres.length)return '<div class="genre-empty"><strong>No matching genres.</strong><span>Try another word.</span></div>';
 return `<div class="genre-grid">${genres.map(g=>`<button type="button" class="genre-tile" data-genre="${g.id}"><span class="genre-icon" aria-hidden="true">${g.icon}</span><span class="genre-copy"><strong>${g.name}</strong><small>${g.note}</small></span><span class="genre-arrow" aria-hidden="true">↗</span></button>`).join('')}</div>`;
}
function sourceSortLabel(mode){return 'Source mix'}
function currentSortLabel(mode){return browseSort==='az'?'Title A–Z':browseSort==='za'?'Title Z–A':sourceSortLabel(mode)}
let sortReturnFocus=null,sortOldOverflow='';
function closeSortPicker(restore=true){
 const modal=$('#sort-modal');if(!modal)return;
 modal.remove();document.body.style.overflow=sortOldOverflow;
 const trigger=$('#result-sort');if(trigger)trigger.setAttribute('aria-expanded','false');
 const previous=sortReturnFocus;sortReturnFocus=null;if(restore&&previous?.isConnected)previous.focus();
}
function setBrowseSort(value,mode,overlay){
 if(!['source','az','za'].includes(value))return;
 browseSort=value;const text=$('#result-sort-label');if(text)text.textContent=currentSortLabel(mode);
 if(activePager)renderPagerCards(activePager,true);
 if(overlay)overlay.querySelectorAll('[data-sort-choice]').forEach(b=>{const selected=b.dataset.sortChoice===value;b.setAttribute('aria-checked',String(selected));b.tabIndex=selected?0:-1;b.classList.toggle('chosen',selected)});
}
function openSortPicker(mode){
 if($('#sort-modal'))return;sortReturnFocus=document.activeElement;sortOldOverflow=document.body.style.overflow;
 const overlay=document.createElement('div');overlay.id='sort-modal';overlay.className='sort-overlay';
 const first=sourceSortLabel(mode),detail='A mix of available source lists; not a global ranking.';
 const choices=[['source',first,detail],['az','Title A–Z','Sort only the titles already loaded.'],['za','Title Z–A','Sort only the titles already loaded.']];
 overlay.innerHTML=`<section class="sort-sheet" role="dialog" aria-modal="true" aria-labelledby="sort-title" aria-describedby="sort-description"><div class="sort-handle" aria-hidden="true"></div><div class="sort-heading"><div><div class="overline">MAKE IT YOURS</div><h2 id="sort-title">Sort titles</h2><p id="sort-description">Choose how to arrange this list.</p></div><button type="button" class="sort-close" aria-label="Close sort options">×</button></div><div class="sort-choices" role="radiogroup" aria-label="Sort order">${choices.map(([id,title,sub])=>`<button type="button" role="radio" aria-checked="${browseSort===id}" tabindex="${browseSort===id?0:-1}" class="sort-option ${browseSort===id?'chosen':''}" data-sort-choice="${id}"><span class="sort-option-icon" aria-hidden="true">${id==='source'?'✦':id==='az'?'A':'Z'}</span><span class="sort-option-copy"><strong>${escapeHTML(title)}</strong><small>${escapeHTML(sub)}</small></span><span class="sort-radio" aria-hidden="true"></span></button>`).join('')}</div><p class="sort-footnote">A–Z and Z–A reorder loaded titles, not the entire library.</p></section>`;
 document.body.appendChild(overlay);document.body.style.overflow='hidden';$('#result-sort')?.setAttribute('aria-expanded','true');
 overlay.onclick=e=>{if(e.target===overlay)closeSortPicker()};overlay.querySelector('.sort-close').onclick=()=>closeSortPicker();
 overlay.querySelectorAll('[data-sort-choice]').forEach(b=>b.onclick=()=>{setBrowseSort(b.dataset.sortChoice,mode,overlay);closeSortPicker()});
 overlay.onkeydown=e=>{
  if(e.key==='Escape'){e.preventDefault();closeSortPicker();return}
  const radios=[...overlay.querySelectorAll('[data-sort-choice]')],current=radios.indexOf(document.activeElement);
  if(current>=0&&['ArrowDown','ArrowRight','ArrowUp','ArrowLeft'].includes(e.key)){
   e.preventDefault();const next=radios[(current+(['ArrowDown','ArrowRight'].includes(e.key)?1:-1)+radios.length)%radios.length];setBrowseSort(next.dataset.sortChoice,mode,overlay);next.focus();return;
  }
  if(e.key==='Tab'){
   const focusable=[overlay.querySelector('.sort-close'),overlay.querySelector('[aria-checked="true"]')].filter(Boolean),at=focusable.indexOf(document.activeElement);
   if((!e.shiftKey&&at===focusable.length-1)||(e.shiftKey&&at<=0)||at<0){e.preventDefault();focusable[e.shiftKey?focusable.length-1:0]?.focus()}
  }
 };
 overlay.querySelector('[aria-checked="true"]')?.focus();
}
function searchPage(initial){
 detachPager();++window.renderSeq;
 if(typeof initial==='string'&&initial.trim()){browseQuery=initial.trim();browseTab='all';browseGenreId='';browsePagerState=null;browseSort='source'}
 let genre=discoveryGenres.find(g=>g.id===browseGenreId),gridOnly=browseTab==='genres'&&!genre;
 let mode=browseQuery?'search':browseTab==='airing'?'airing':browseTab==='music'?'music':genre?'genre':'all';
 let heading=browseQuery?'Results for “'+browseQuery+'”':genre?genre.name+' anime':browseTab==='airing'?'Airing now':browseTab==='music'?'Music anime':'All anime';
 let intro=mode==='airing'?'The selected library’s airing list. Release timing and availability can vary.':mode==='search'?'Results follow the library’s search order.':mode==='music'?(source==='salt'?'The library calls this category Musical; not a standalone music player.':'Anime in the library’s music genre; not a standalone music player.'):popularityAvailable(source,mode)?'Popular first, ranked by the selected library.':mode==='genre'?'Library order; a category popularity sort isn’t available here.':'Library order; popularity rankings may be limited.';
 let genres=supportedGenres(source),genreArea=`<div class="discover-section genre-section"><div><div class="overline">FIND YOUR MOOD</div><h2>Explore by genre</h2><p class="sub">Choose a path through ${escapeHTML(label(source))}.</p></div><span class="genre-count" id="genre-count">${genres.length} genres</span></div>${genres.length?`<label class="genre-search"><span aria-hidden="true">⌕</span><input id="genre-filter" type="search" autocomplete="off" aria-label="Find a genre" placeholder="Find a genre" value="${escapeHTML(genreFilter)}"></label>`:''}<div id="genre-results">${genreTiles(genreFilter)}</div>`;
 const sortButton=`<button type="button" class="sort-trigger" id="result-sort" aria-haspopup="dialog" aria-expanded="false"><svg aria-hidden="true" viewBox="0 0 24 24"><path d="M4 7h16M7 12h10M10 17h4"/></svg><span><small>Sort by</small><strong id="result-sort-label">${escapeHTML(currentSortLabel(mode))}</strong></span><b aria-hidden="true">⌄</b></button>`;
 main.innerHTML=`<div class="discover-head"><div><div class="overline">THE KURO CATALOG</div><h1>${view==='simulcasts'?'Simulcasts':'Browse anime'}</h1><p class="sub">Discover your next favorite.</p></div><span class="discover-mark" aria-hidden="true">✦</span></div>${sourceBar()}<form class="search discover-search" id="discover-search"><input id="q" type="search" autocomplete="off" aria-label="Anime title" placeholder="Search anime titles" value="${escapeHTML(browseQuery)}"><button id="go" class="btn primary" type="submit">Search</button></form><div class="discover-tabs" role="tablist" aria-label="Browse sections">${tabButton('all','All anime','✦')}${tabButton('airing','Simulcasts','◉')}${tabButton('genres','Genres','◇')}${tabButton('music','Music','♫')}</div><section id="browse-panel" role="tabpanel" aria-labelledby="discover-tab-${browseTab}">${gridOnly?genreArea:`<div class="discover-section"><div><div class="overline">${escapeHTML(label(source))} · EXPLORE</div><h2>${escapeHTML(heading)}</h2><p class="sub">${escapeHTML(intro)}</p></div>${sortButton}</div>${genre?'<button class="genre-back" id="genres-back" type="button">‹ All genres</button>':''}<div class="discover-list"><div id="results"></div></div>`}</section>`;
 bindSources(()=>{browsePagerState=null;browseSort='source';genreFilter='';window.scrollTo(0,0);searchPage()});
 $('#discover-search').onsubmit=e=>{e.preventDefault();doSearch($('#q').value)};
 document.querySelectorAll('[data-browse-tab]').forEach(b=>{b.onclick=()=>{browseTab=b.dataset.browseTab;browseGenreId='';browseQuery='';browsePagerState=null;browseSort='source';genreFilter='';window.scrollTo(0,0);if(browseTab==='airing'){browseTab='all';nav('simulcasts')}else searchPage()};b.onkeydown=e=>{if(!['ArrowRight','ArrowLeft','Home','End'].includes(e.key))return;e.preventDefault();let tabs=[...document.querySelectorAll('[data-browse-tab]')],i=tabs.indexOf(b);i=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;let id=tabs[i].dataset.browseTab;tabs[i].click();document.querySelector('[data-browse-tab="'+id+'"]')?.focus()}});
 const bindGenreButtons=()=>document.querySelectorAll('[data-genre]').forEach(b=>b.onclick=()=>browseGenre(b.dataset.genre));
 bindGenreButtons();
 if(gridOnly){
  const input=$('#genre-filter');if(input)input.oninput=()=>{genreFilter=input.value;$('#genre-results').innerHTML=genreTiles(genreFilter);const n=supportedGenres(source).filter(g=>(g.name+' '+g.note).toLocaleLowerCase().includes(genreFilter.trim().toLocaleLowerCase())).length;$('#genre-count').textContent=n+' '+(n===1?'genre':'genres');bindGenreButtons()};
  return;
 }
 const back=$('#genres-back');if(back)back.onclick=()=>{browseGenreId='';browsePagerState=null;browseSort='source';window.scrollTo(0,0);searchPage()};
 $('#result-sort').onclick=()=>openSortPicker(mode);
 const spec={source,mode};if(mode==='search')spec.query=browseQuery;if(mode==='genre')spec.genre=genre.id;if(mode==='music')spec.genre='music';
 if(!sameSpec(browsePagerState,spec))browsePagerState=makePager(spec);
 mountPager(browsePagerState,{sort:()=>browseSort});
}
function doSearch(q){browseQuery=String(q||'').trim();browseTab='all';browseGenreId='';browsePagerState=null;browseSort='source';window.scrollTo(0,0);if(view==='simulcasts')nav('search');else searchPage()}
function browseGenre(g){if(!sourceGenre(source,g)||!discoveryGenres.some(x=>x.id===g))return;browseGenreId=g;browseQuery='';browseTab='genres';browsePagerState=null;browseSort='source';window.scrollTo(0,0);if(view==='simulcasts')nav('search');else searchPage()}
function returnToShowOrigin(){let origin=showOrigin||{view:'home',y:0};let target=['home','search','library','simulcasts','profile'].includes(origin.view)?origin.view:'home';nav(target);requestAnimationFrame(()=>window.scrollTo(0,origin.y||0))}

function stored(key){try{return JSON.parse(localStorage.getItem(key)||'[]')}catch{return []}}function save(key,v){try{localStorage.setItem(key,JSON.stringify(v));return true}catch{return false}}
let listFilter='all';
const statuses=[['watching','Watching'],['planned','Plan to watch'],['completed','Completed'],['on_hold','On hold'],['dropped','Dropped']];
// A single ordered source for every My Lists view, including imported snapshots.
const libraryFilters557=[['all','All'],['watching','Watching'],['completed','Completed'],['on_hold','On hold'],['dropped','Dropped'],['planned','Planned to watch'],['imported','Imported'],['bookmarks','Bookmark'],['history','History']];
function libraryTabs557(active){return libraryFilters557.map(([id,name])=>`<button type="button" class="chip small ${id===active?'active':''}" data-list-filter="${id}" aria-pressed="${id===active}">${name}</button>`).join('')}
function allLocalTitles557(bookmarks,categorized){
 const seen=new Set();return [...bookmarks,...categorized.map(x=>x.item)].filter(item=>{
  if(!item||typeof item!=='object'||!item.url)return false;
  const key=JSON.stringify([String(item.source||''),String(item.url)]);if(seen.has(key))return false;seen.add(key);return true;
 });
}
function categoryEntries(){return stored('kuro-categories-v1').filter(x=>x&&x.item&&x.item.url&&statuses.some(s=>s[0]===x.status))}
function setCategory(item,status){let a=categoryEntries().filter(x=>!(x.item.url===item.url&&x.item.source===item.source));if(statuses.some(x=>x[0]===status))a.unshift({item:compactItem(item),status});if(save('kuro-categories-v1',a))try{window.kuroSyncCategoryChanged553?.(compactItem(item),status)}catch(_){}}
function getCategory(item){return categoryEntries().find(x=>x.item.url===item.url&&x.item.source===item.source)?.status||''}
function historyEntries(){return stored('kuro-episode-history-v1').filter(x=>x&&x.item&&x.item.url&&x.ep&&x.ep.number)}
function recordHistory(item,ep){let rows=historyEntries().filter(x=>!(x.item.url===item.url&&x.item.source===item.source&&String(x.ep.number)===String(ep.number)));rows.unshift({item:compactItem(item),ep:{number:String(ep.number),name:ep.name||'',url:ep.url},opened:Date.now()});save('kuro-episode-history-v1',rows.slice(0,200))}
async function openHistory(row){await openShow(row.item);if(view!=='detail'||selected.url!==row.item.url)return;let ep=episodes.find(x=>String(x.number)===String(row.ep.number));if(ep)openEpisode(ep);else if(/^\d+$/.test(String(row.ep.number))){let missing={number:String(row.ep.number),name:row.ep.name||'',url:row.ep.url||row.item.url,missing:true};episodes=[missing];openEpisode(missing)}}
function updateStatusButton(item){let b=$('#watch-status');if(b)b.textContent=(statuses.find(x=>x[0]===getCategory(item))?.[1]||'Not in a list')+'  ▾'}
function closeStatusPicker(){let modal=$('#status-modal');if(modal)modal.remove();let button=$('#watch-status');if(button)button.focus()}
function openStatusPicker(item){if($('#status-modal'))return;let active=getCategory(item),overlay=document.createElement('div');overlay.id='status-modal';overlay.className='status-overlay';overlay.innerHTML=`<section class="status-dialog" role="dialog" aria-modal="true" aria-labelledby="status-title"><div class="status-heading"><strong id="status-title">Add to My Lists</strong><button class="status-close" aria-label="Close">×</button></div><div role="radiogroup" aria-label="Watch status">${[['','Not in a list'],...statuses].map(([id,name])=>`<button class="status-option ${active===id?'chosen':''}" role="radio" aria-checked="${active===id}" data-status="${id}"><span>${name}</span><span class="status-radio" aria-hidden="true"></span></button>`).join('')}</div></section>`;document.body.appendChild(overlay);overlay.onclick=e=>{if(e.target===overlay)closeStatusPicker()};overlay.querySelector('.status-close').onclick=closeStatusPicker;overlay.querySelectorAll('[data-status]').forEach(b=>b.onclick=()=>{setCategory(item,b.dataset.status);updateStatusButton(item);closeStatusPicker()});overlay.onkeydown=e=>{if(e.key==='Escape')closeStatusPicker()};overlay.querySelector('[aria-checked=true]')?.focus()}
function library(){let marker=++window.renderSeq,allBookmarks=stored('kuro-library'),allCategories=categoryEntries(),allHistory=historyEntries();refreshStoredClassifications([...allBookmarks,...allCategories.map(x=>x.item),...allHistory.map(x=>x.item)],marker,()=>{if(view==='library')library()});let bookmarks=allBookmarks.filter(x=>x&&typeof x==='object'&&x.url&&safeStoredItem(x)),categorized=allCategories.filter(x=>safeStoredItem(x.item)),history=allHistory.filter(x=>safeStoredItem(x.item)),arr=listFilter==='all'?allLocalTitles557(bookmarks,categorized):listFilter==='bookmarks'?bookmarks:categorized.filter(x=>x.status===listFilter).map(x=>x.item),isHistory=listFilter==='history';main.innerHTML=`<div class="overline">YOUR COLLECTION</div><div class="library-title571"><h1>My library</h1><button type="button" id="queue-open571">Watch queue</button></div><p class="sub">Your library is stored on this device; linked trackers can receive status and watched episodes.</p><div class="tabs category-tabs" role="group" aria-label="Library filters">${libraryTabs557(listFilter)}</div><div class="heading"><h2>${isHistory?'History':listFilter==='all'?'All local titles':listFilter==='bookmarks'?'Bookmarks':statuses.find(x=>x[0]===listFilter)?.[1]||'My library'}</h2>${isHistory&&history.length?'<button class="clear-recent" id="clear-history">Clear all</button>':`<span>${isHistory?history.length:arr.length} ${isHistory?'episodes':'titles'}</span>`}</div>${isHistory?`<p class="sub history-note573">Episodes opened in Kuro 5.21 or later. Exact resume is available only where the player can reliably report and seek to a position.</p><div class="history-grid">${history.map((x,i)=>`<article class="history-card"><button class="history-open" data-history="${i}"><div class="history-image">${x.item.img?`<img src="${escapeHTML(x.item.img)}" alt="">`:''}<span>▶</span></div><strong>${escapeHTML(x.item.title)}</strong><small>Episode ${escapeHTML(x.ep.number)}${x.ep.name?' · '+escapeHTML(x.ep.name):''}</small><small>Opened</small></button><button class="history-remove" data-remove-history="${i}" aria-label="Remove from history">×</button></article>`).join('')||'<div class="empty">Episodes you open will appear here.</div>'}</div>`:`<div id="saved">${arr.length?cardMarkup(arr):'<div class="empty">No titles in this list yet.</div>'}</div>`}`;$('#queue-open571').onclick=()=>window.kuroQueue571?.open();document.querySelectorAll('[data-list-filter]').forEach(b=>b.onclick=()=>{listFilter=b.dataset.listFilter;library()});if(!isHistory)bindCards(arr,$('#saved'));else{document.querySelectorAll('[data-history]').forEach(b=>b.onclick=()=>openHistory(history[Number(b.dataset.history)]));document.querySelectorAll('[data-remove-history]').forEach(b=>b.onclick=()=>{let index=Number(b.dataset.removeHistory);history.splice(index,1);save('kuro-episode-history-v1',history);library()});let clear=$('#clear-history');if(clear)clear.onclick=()=>{clear.textContent='Confirm clear';clear.onclick=()=>{save('kuro-episode-history-v1',[]);library()};setTimeout(()=>{if(clear.isConnected)library()},5000)}}}


function simulcasts(){renderSimulcasts()}
function profile(){++window.renderSeq;main.innerHTML=`<div class="overline">YOUR SPACE</div><h1>Profile</h1><div class="space"></div><div class="panel"><h2>Local profile</h2><p class="sub">Your saved anime stays on this device. No account or cloud sync is connected.</p></div><div class="space"></div><div class="notice">Community posts, shared profiles, achievements, and synced watch progress need a separate online service. They are not included in this preview.</div>`}
// Watched state is stored locally per library and title; no completion is inferred from opening a player.
function watchedKey(item){return item.source+'|'+item.url}
function watchedData(){try{return JSON.parse(localStorage.getItem('kuro-watched-v1')||'{}')}catch(_){return {}}}
function watchedSet(item,num,value){let data=watchedData(),key=watchedKey(item);data[key]=data[key]||{};if(value)data[key][String(num)]=true;else delete data[key][String(num)];localStorage.setItem('kuro-watched-v1',JSON.stringify(data));try{window.kuroSyncWatchedChanged553?.(compactItem(item))}catch(_){}}
function watchedHas(item,num){return !!(watchedData()[watchedKey(item)]||{})[String(num)]}
function lastEpisodes(){try{return JSON.parse(localStorage.getItem('kuro-last-episode-v1')||'{}')}catch(_){return {}}}
function rememberEpisode(item,ep){let data=lastEpisodes();data[watchedKey(item)]=String(ep.number);localStorage.setItem('kuro-last-episode-v1',JSON.stringify(data))}
function updateWatchedUI(item){let all=episodes.length>0&&episodes.every(e=>watchedHas(item,e.number));let b=$('#mark-all');if(b){b.textContent=all?'✓✓ Watched':'✓✓ Mark all watched';b.disabled=!episodes.length}let next=$('#next-unwatched');if(next)next.disabled=!episodes.some(e=>!watchedHas(item,e.number));document.querySelectorAll('[data-mark]').forEach(b=>{let ep=episodes[Number(b.dataset.mark)],yes=ep&&watchedHas(item,ep.number);b.textContent=yes?'✓✓ Watched':'✓ Mark watched';b.setAttribute('aria-pressed',yes?'true':'false')})}
const bookmarkIcon='<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M6 3.5h12v17l-6-4-6 4z"/></svg>';
function detailFacts(d,src){let facts=[];if(src==='ms'){for(const row of d.querySelectorAll('.hk-title__facts dl > div')){let key=row.querySelector('dt')?.textContent.trim(),value=row.querySelector('dd')?.textContent.trim().replace(/\s+/g,' ');if(['Aired','Season','Status','Episode length','Studio','Japanese name'].includes(key)&&value)facts.push([key,value])}let genres=[...d.querySelectorAll('.hk-facts__genres a')].map(x=>x.textContent.trim()).filter(Boolean);if(genres.length)facts.push(['Genres',genres.join(', ')])}else{for(const row of d.querySelectorAll('.anisc-info .item')){let key=row.querySelector('.item-head')?.textContent.trim().replace(/:$/,''),value=(row.querySelector('.name')?.textContent.trim()||[...row.querySelectorAll('a')].map(x=>x.textContent.trim()).filter(Boolean).join(', '));if(['Japanese','Aired','Premiered','Status','Genres','Studios'].includes(key)&&value)facts.push([key,value])}}return facts.slice(0,8)}
function detailExtra(item,facts){let c=item.counts||{},badges=[c.sub?`<span>CC ${escapeHTML(c.sub)}</span>`:'',c.dub?`<span>🎙 ${escapeHTML(c.dub)}</span>`:'',c.total?`<span>${escapeHTML(c.total)} episodes</span>`:''].join('');return `<section class="anime-extra">${badges?`<div class="detail-badges">${badges}</div>`:''}${item.description?`<h2>Synopsis</h2><p class="synopsis">${escapeHTML(item.description)}</p>`:''}${facts.length?`<dl class="anime-facts">${facts.map(([k,v])=>`<div><dt>${escapeHTML(k)}</dt><dd>${escapeHTML(v)}</dd></div>`).join('')}</dl>`:''}${!item.description&&!facts.length&&!badges?'<p class="sub">More details aren’t available from this library.</p>':''}</section>`}
let episodeLimit571=150;
function renderDetailEpisodes(item,marker){
 if(marker!==window.renderSeq||!$('#eps'))return;
 const search=$('#episode-search571'),q=String(search?.value||'').normalize('NFKC').toLocaleLowerCase().trim();
 const matches=episodes.map((e,i)=>({e,i})).filter(({e})=>!q||(`${e.number} ${e.name||''}`).normalize('NFKC').toLocaleLowerCase().includes(q));
 const shown=matches.slice(0,episodeLimit571);
 $('#eps').innerHTML=episodes.length?`<p class="episode-count571" role="status" aria-live="polite">${matches.length} matching episode${matches.length===1?'':'s'}${matches.length>shown.length?' · showing '+shown.length:''}</p>${shown.length?`<div class="episodeList episodes">${shown.map(({e,i})=>`<div class="episode-row"><button data-ep="${i}"><span>${escapeHTML(e.number)}</span><strong>${escapeHTML(e.name||`Episode ${e.number}`)}</strong><b>›</b></button><button class="watched-toggle" data-mark="${i}" aria-pressed="false">✓ Mark watched</button><button type="button" class="episode-queue571" data-queue-episode="${i}" aria-label="Add episode ${escapeHTML(e.number)} to watch queue">+</button></div>`).join('')}</div>`:'<div class="notice">No episodes match this search.</div>'}${matches.length>shown.length?'<button type="button" class="episode-more571" id="episode-more571">Show more episodes</button>':''}`:'<div class="notice">No episodes found at this source.</div>';
 document.querySelectorAll('#eps [data-ep]').forEach(b=>b.onclick=()=>openEpisode(episodes[Number(b.dataset.ep)]));
 document.querySelectorAll('#eps [data-queue-episode]').forEach(b=>b.onclick=()=>{try{const added=window.kuroQueue571.add(item,episodes[Number(b.dataset.queueEpisode)]);placeholder(added?'Added to your local watch queue.':'That episode is already in your watch queue.')}catch(e){placeholder(e.message||'This episode could not be queued.')}});
 const more=$('#episode-more571');if(more)more.onclick=()=>{episodeLimit571+=150;renderDetailEpisodes(item,marker)};
 $('#watch-now').disabled=!episodes.length;document.querySelectorAll('#eps [data-mark]').forEach(b=>b.onclick=()=>{let ep=episodes[Number(b.dataset.mark)];watchedSet(item,ep.number,!watchedHas(item,ep.number));updateWatchedUI(item)});updateWatchedUI(item);
}
// Re-open only an exact saved source, series URL and episode, never a guessed match.
window.kuroQueueOpen571=async row=>{
 if(!window.kuroQueue571?.identity(row)){placeholder('The saved episode is invalid.');return false}
 await openShow(row.item);
 if(view!=='detail'||!selected||selected.source!==row.item.source||selected.url!==row.item.url){placeholder('The saved series could not be opened. Your queue was kept.');return false}
 const matches=episodes.filter(e=>!e.missing&&String(Number(e.number))===row.ep.number&&(!row.ep.url||e.url===row.ep.url)&&(!e.unifiedOwner||(e.unifiedOwner.source===row.item.source&&e.unifiedOwner.url===row.item.url)));
 if(matches.length!==1){placeholder('The exact saved episode is unavailable or ambiguous. Your queue was kept.');return false}
 await openEpisode(matches[0]);return true;
};
window.kuroStorageChanged571=()=>{if(view==='library')library();else if(view==='profile')profile()};

function safeStoredItem(item){return !item||!['zenkai','wixi','kitsune','paradise'].includes(item.source)||allowClassifiedItem(item)}
function refreshStoredClassifications(items,marker,redraw){
 let needs=items.filter(x=>x&&['zenkai','wixi','kitsune','paradise'].includes(x.source)&&!adultFlag(x)&&!adultCache.has('a'+Number(x.anilistId))&&!adultCache.has('m'+Number(x.malId)));
 if(!needs.length)return;let batches=[];for(let i=0;i<needs.length;i+=24)batches.push(needs.slice(i,i+24));
 Promise.allSettled(batches.map(x=>classifyAdded(x))).then(()=>{if(marker===window.renderSeq&&needs.some(x=>safeStoredItem(x)))redraw()});
}
function offerLinkedResume(item,marker){
 if(marker!==window.renderSeq||!$('#eps')||!$('#watch-now'))return;
 let n=lastEpisodes()[watchedKey(item)]||'1';if(!/^\d+$/.test(String(n))||Number(n)<1||Number(n)>5000)n='1';
 let missing={number:String(Number(n)),name:'',url:item.url,missing:true};episodes=[missing];$('#watch-now').disabled=false;
 $('#eps').innerHTML=`<div class="notice" role="status">This library’s episode list is unavailable. Check your connection and retry, or try episode ${escapeHTML(n)} in linked libraries.</div><div class="space"></div><button class="btn" id="retry-episodes573">Retry episode list</button> <button class="btn" id="linked-resume">▶ Try linked libraries</button>`;
 $('#retry-episodes573').onclick=()=>openShow(item);$('#linked-resume').onclick=()=>openEpisode(missing);
}
async function openShow(item){const fromCombined=!!item?.unified;if(home===unifiedHome&&!fromCombined&&item&&unifiedCodes.includes(item.source))item={...unifiedCopy(item),unified:true,unifiedVariants:[unifiedCopy(item)]};if(fromCombined)item=unifiedPreferred(item);if(['zenkai','wixi','kitsune','paradise'].includes(item?.source)){let gate=++window.renderSeq;try{let allowed=await classifyAdded([item]);if(gate!==window.renderSeq)return;if(!allowed.length){placeholder('This title is hidden while 18+ is off or its classification is unknown.');return}}catch(_){if(gate===window.renderSeq)placeholder('18+ classification is temporarily unavailable.');return}}if(!['detail','episode','news'].includes(view))showOrigin={view,y:window.scrollY};pageTransition();selected=item;source=item.source;view='detail';episodes=[];episodeLimit571=150;let marker=++window.renderSeq;main.innerHTML=`<div class="topline"><button class="back" id="back">‹ Back</button><span class="sub">One library</span></div><div class="info"><div class="poster">${item.img?`<img src="${escapeHTML(item.img)}" alt="">`:''}</div><div><div class="overline">ANIME DETAILS</div><h1>${escapeHTML(item.title)}</h1><p>${escapeHTML(item.meta||'Browse episodes below.')}</p></div></div><div class="watch-actions"><button id="save" class="chip bookmark">${bookmarkIcon}<span>Bookmark</span></button><button class="btn primary" id="watch-now" disabled>▶ Watch now</button><button class="btn" id="mark-all" disabled>✓✓ Mark all watched</button></div><div class="category-control"><span>My list</span><button id="watch-status" class="status-button" type="button" aria-haspopup="dialog"></button></div><button type="button" id="related-open573" class="anime-prefs-open571">Related titles and watch order</button><div id="detail-extra"><div class="spinner"></div></div><div class="heading"><h2>Episodes</h2><button class="next-episode" id="next-unwatched" disabled>Next unwatched ›</button></div><label class="episode-search571"><span>Search episodes</span><input id="episode-search571" type="search" autocomplete="off" placeholder="Episode number or title" aria-label="Search episodes by number or title"></label><p id="unified-episodes-status" class="unified-episodes-status" role="status" aria-live="polite"></p><div id="eps"><div class="spinner"></div></div><div class="space"></div><button class="btn" id="other">Search this title ↗</button>`;$('#back').onclick=()=>returnToShowOrigin();$('#episode-search571').oninput=()=>{episodeLimit571=150;renderDetailEpisodes(item,marker)};if(item.verifyTitle||item.source==='aw')$('#save').disabled=true;updateStatusButton(item);$('#watch-status').onclick=()=>openStatusPicker(item);$('#related-open573').onclick=()=>window.kuroRelated573?.(item);$('#watch-now').onclick=()=>{let last=lastEpisodes()[watchedKey(item)];let ep=episodes.find(e=>String(e.number)===last)||episodes[0];if(ep)openEpisode(ep)};$('#next-unwatched').onclick=()=>{let ep=episodes.find(e=>!watchedHas(item,e.number));if(ep)openEpisode(ep)};$('#mark-all').onclick=()=>{let all=episodes.length&&episodes.every(e=>watchedHas(item,e.number));episodes.forEach(e=>watchedSet(item,e.number,!all));updateWatchedUI(item)};$('#save').onclick=()=>{let a=stored('kuro-library'),i=a.findIndex(x=>x.url===item.url);if(i>=0){a.splice(i,1);$('#save').innerHTML=bookmarkIcon+'<span>Bookmark</span>'}else{a.unshift(compactItem(item));$('#save').innerHTML=bookmarkIcon+'<span>Bookmarked</span>'}save('kuro-library',a)};if(stored('kuro-library').some(x=>x.url===item.url))$('#save').innerHTML=bookmarkIcon+'<span>Bookmarked</span>';$('#other').onclick=()=>{view='search';searchPage(item.title)};
try{let raw=await get(item.url);if(marker!==window.renderSeq)return;
if(['zenkai','wixi','miruro','kitsune','paradise'].includes(item.source)){
 let data=item.source==='miruro'?await miruroDetails(item,raw):item.source==='kitsune'?await kitsuneDetails(item,raw):item.source==='paradise'?await paradiseDetails(item,raw):await addedDetails(item,raw);if(marker!==window.renderSeq)return;episodes=data.episodes;$('#detail-extra').innerHTML=detailExtra(item,data.facts);renderDetailEpisodes(item,marker);if(!episodes.length)offerLinkedResume(item,marker);unifiedBeginEpisodeScan(item,marker);return;
}
let awResolved=item.source==='aw'?await awDetail(item,raw):null;let d=awResolved?awResolved.doc:item.source==='flix'?await flixDetail(item,raw):parse(raw);if(marker!==window.renderSeq)return;if(awResolved){$('#save').disabled=false;if(stored('kuro-library').some(x=>x.url===item.url))$('#save').innerHTML=bookmarkIcon+'<span>Bookmarked</span>';updateStatusButton(item)}if(item.verifyTitle&&(sourceNeedsVerification(d)||matchTitle(d.querySelector('h1')?.textContent)!==matchTitle(item.title)))throw Error('This exact title and season could not be verified in the selected library.');if(item.verifyTitle)$('#save').disabled=false;
unifiedIdsFromDocument(item,d);
let scope=item.source==='ms'?d.querySelector('.hk-title__chips'):d.querySelector('.anisc-detail .film-stats');if(scope){let c=parseCounts(scope,item.source);if(c.sub||c.dub||c.total)item.counts=c}item.description=(d.querySelector(item.source==='ms'?'[itemprop=description]':'.anisc-detail .film-description .text')?.textContent||d.querySelector('.anisc-info .item-title .text')?.textContent||'').trim().replace(/\s+/g,' ').slice(0,3000);$('#detail-extra').innerHTML=detailExtra(item,detailFacts(d,item.source));if(item.source==='ms'){episodes=Array.from(d.querySelectorAll('.hk-ep,.hk-wep')).map(x=>({number:x.getAttribute('data-ep')||x.getAttribute('data-episode')||x.textContent.trim(),name:(x.getAttribute('data-name')||'').trim(),url:validUrl(abs(x.getAttribute('href'),source))})).filter(x=>x.url);if(!episodes.length){let first=d.querySelector('a[href*="/watch-"]');if(first)episodes=[{number:'1',url:validUrl(abs(first.getAttribute('href'),source))}]}}else if(item.source==='dk'){let first=item.url.includes('/watch/')?item.url:abs(d.querySelector('.btn-play[href]')?.getAttribute('href')||'',source);if(!validUrl(first)||!first.includes('/watch/'))throw Error('No episode link found');let w=parse(item.url===first?d.documentElement.outerHTML:await get(first)),anime=w.querySelector('#ani_detail')?.getAttribute('data-anime-id');if(!/^\d+$/.test(anime||''))throw Error('Episode list unavailable');hiRememberMirror(new URL(first).origin);let data=JSON.parse(await get(base('dk')+'/ajax/v2/episode/list/'+anime));let ed=parse(data.html||'');episodes=Array.from(ed.querySelectorAll('.ep-item')).map(x=>({number:x.getAttribute('data-number')||x.textContent.trim(),name:(x.querySelector('.ep-name')?.getAttribute('title')||x.querySelector('.ep-name')?.textContent||x.getAttribute('title')||'').trim(),filler:x.classList.contains('ssl-item-filler')||x.getAttribute('data-filler')==='true',url:validUrl(abs(x.getAttribute('href'),'dk'))})).filter(x=>x.url)}else if(item.source==='flix'){episodes=await flixEpisodes(d)}else if(item.source==='aw'){episodes=await awEpisodes(d,awResolved.episodeDoc)}else if(item.source==='nine'){let id=d.querySelector('.block_area-episodes[data-series]')?.getAttribute('data-series');if(!/^\d+$/.test(id||''))throw Error('Episode list unavailable');let ed=parse(JSON.parse(await get(base('nine')+'/wp-json/9animetv/v1/episodes/'+id+'?active=0')).pages||'');episodes=[...ed.querySelectorAll('.ep-item[data-number][href]')].map(a=>({number:a.getAttribute('data-number'),name:a.getAttribute('title')||'',url:validUrl(new URL(a.getAttribute('href'),base('nine')).href)})).filter(x=>x.url)}else if(item.source==='zoro'){episodes=[...d.querySelectorAll('[class*=eplister] a[href]')].map(a=>({number:a.querySelector('.epl-num')?.textContent.trim()||'',name:a.querySelector('.epl-title')?.textContent.trim()||'',url:validUrl(new URL(a.getAttribute('href'),base('zoro')).href)})).filter(x=>/^\d+$/.test(x.number)&&x.url).sort((a,b)=>Number(a.number)-Number(b.number))}else if(item.source==='ani'){let id=d.querySelector('#watch-main[data-id]')?.getAttribute('data-id');if(!/^\d+$/.test(id||''))throw Error('Episode list unavailable');let ed=parse(JSON.parse(await get(base('ani')+'/ajax/episode/list/'+id)).result||'');episodes=[...ed.querySelectorAll('a[data-num][href]')].map(a=>({number:a.getAttribute('data-num'),name:a.querySelector('.d-title')?.textContent.trim()||'',url:validUrl(new URL(a.getAttribute('href'),base('ani')).href)})).filter(x=>x.url&&/^\d+$/.test(x.number))}else if(item.source==='salt'){let seen=new Set();episodes=[...d.querySelectorAll('a[href*="/episode/"]')].map(a=>{let u=validUrl(new URL(a.getAttribute('href'),base('salt')).href),m=u&&new URL(u).pathname.match(/-1x(\d+)\/?$/);return m?{number:m[1],name:'',url:u}:null}).filter(x=>x&&!seen.has(x.number)&&seen.add(x.number)).sort((a,b)=>Number(a.number)-Number(b.number))}renderDetailEpisodes(item,marker);if(!episodes.length)offerLinkedResume(item,marker);unifiedBeginEpisodeScan(item,marker);}catch(e){if(marker===window.renderSeq){if($('#detail-extra .spinner'))$('#detail-extra').innerHTML='<p class="sub">Details unavailable.</p>';$('#eps').innerHTML=`<div class="notice error" role="alert">Couldn’t load episodes. Check your connection and try again. ${isVerification(e)?'This library may require verification.':''}</div><div class="space"></div><button class="btn" id="retry-episodes573">Retry episode list</button>`;$('#retry-episodes573').onclick=()=>openShow(item);
 if(item.source==='miruro'&&isVerification(e)&&window.KuroNative?.verifyLibrary11){$('#eps').insertAdjacentHTML('beforeend','<div class="space"></div><button class="btn" data-miruro-verify>Verify Library 11</button> <button class="btn" data-miruro-retry>Retry Library 11</button>');$('#eps [data-miruro-verify]').onclick=()=>KuroNative.verifyLibrary11();$('#eps [data-miruro-retry]').onclick=()=>{unifiedVerificationBlocked.delete('miruro');openShow(item)}}
 if(!isVerification(e)&&!item.verifyTitle&&!/(?:could not be verified|conflicting catalogue identifiers)/i.test(String(e.message||''))){let safe=true;if(['zenkai','wixi','kitsune','paradise'].includes(item.source))try{safe=(await classifyAdded([item])).length===1}catch(_){safe=false}if(safe&&marker===window.renderSeq){offerLinkedResume(item,marker);unifiedBeginEpisodeScan(item,marker)}}
}}}
// Exact-title fallback: never guess a season or episode.
async function fallbackNine(title,number){if(!/^\d+$/.test(String(number)))return [];const origin='https://9anime.or.at';const norm=x=>String(x||'').normalize('NFKC').toLowerCase().replace(/\s*\(dub\)\s*$/i,'').replace(/[^\p{L}\p{N}]+/gu,' ').trim();let search=parse(await get(origin+'/?s='+encodeURIComponent(title)));let urls=[...search.querySelectorAll('a[href]')].filter(a=>norm(a.textContent)===norm(title)).map(a=>validUrl(new URL(a.getAttribute('href'),origin).href)).filter(u=>u&&new URL(u).hostname==='9anime.or.at'&&new URL(u).pathname.startsWith('/anime/'));urls=[...new Set(urls)];if(urls.length!==1)return [];let show=parse(await get(urls[0]));let headline=show.querySelector('h1,h2')?.textContent||'';if(norm(headline)!==norm(title))return [];let sid=show.querySelector('.block_area-episodes[data-series]')?.getAttribute('data-series');if(!/^\d+$/.test(sid||''))return [];let episodesData=JSON.parse(await get(origin+'/wp-json/9animetv/v1/episodes/'+sid+'?active=0'));let eps=parse(episodesData.pages||'');let episodes=[...eps.querySelectorAll('.ep-item[data-number][data-id]')].filter(a=>a.getAttribute('data-number')===String(Number(number))&&/^\d+$/.test(a.getAttribute('data-id'))).slice(0,2),out=[];for(let entry of episodes){let link=entry.getAttribute('href')||'',epUrl=validUrl(new URL(link,origin).href);if(!epUrl||new URL(epUrl).hostname!=='9anime.or.at')continue;let response=JSON.parse(await get(origin+'/ajax/episode/servers?id='+entry.getAttribute('data-id')));let doc=parse(response.html||'');for(let item of doc.querySelectorAll('.server-item[data-embed]')){let url='';try{url=validUrl(atob(item.getAttribute('data-embed')),'player')}catch(_){}let lang=(item.getAttribute('data-type')||'').toLowerCase();if(url&&(lang==='sub'||lang==='dub'))out.push({name:'Server',lang,url,referer:'nine'})}}return out}
const matchTitle=x=>String(x||'').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
async function fallbackZoro(title,number){if(!/^\d+$/.test(String(number)))return [];let origin='https://zorotv.ba',search=parse(await get(origin+'/?s='+encodeURIComponent(title))),urls=[...search.querySelectorAll('.bsx a[href]')].filter(a=>matchTitle(a.getAttribute('title'))===matchTitle(title)).map(a=>validUrl(new URL(a.getAttribute('href'),origin).href)).filter(u=>u&&new URL(u).hostname==='zorotv.ba'&&new URL(u).pathname.startsWith('/anime/'));urls=[...new Set(urls)];if(urls.length!==1)return [];let show=parse(await get(urls[0]));if(matchTitle(show.querySelector('h1')?.textContent)!==matchTitle(title))return [];let items=[...show.querySelectorAll('[class*=eplister] a[href]')].filter(a=>a.querySelector('.epl-num')?.textContent.trim()===String(Number(number))),out=[];for(let item of items.slice(0,2)){let url=validUrl(new URL(item.getAttribute('href'),origin).href);if(!url||new URL(url).hostname!=='zorotv.ba')continue;let lang=/english-dubbed/i.test(url)?'dub':/english-subbed/i.test(url)?'sub':'';if(!lang)continue;let page=parse(await get(url));for(let iframe of page.querySelectorAll('iframe[src]')){let p=validUrl(new URL(iframe.getAttribute('src'),origin).href,'player');if(p&&new URL(p).hostname==='zorotv.ba'&&new URL(p).pathname.startsWith('/wp-content/themes/animestream-child/player/'))out.push({name:'Server',url:p,lang,referer:'zoro'})}}return out}
async function fallbackSalt(title,number){if(!/^\d+$/.test(String(number))||/\b(?:season|part|cour|ii|iii|iv|2nd|3rd)\b/i.test(title))return [];let origin='https://animesalt.cx',search=parse(await get(origin+'/?s='+encodeURIComponent(title))),urls=[...search.querySelectorAll('article')].filter(a=>matchTitle(a.querySelector('.entry-title')?.textContent)===matchTitle(title)).map(a=>a.querySelector('a[href*="/series/"]')?.getAttribute('href')).filter(Boolean).map(u=>validUrl(new URL(u,origin).href)).filter(u=>u&&new URL(u).hostname==='animesalt.cx');urls=[...new Set(urls)];if(urls.length!==1)return [];let show=parse(await get(urls[0]));if(matchTitle(show.querySelector('h1')?.textContent)!==matchTitle(title))return [];let links=[...show.querySelectorAll('a[href*="/episode/"]')].map(a=>validUrl(new URL(a.getAttribute('href'),origin).href)).filter(u=>u&&new URL(u).hostname==='animesalt.cx'&&new RegExp('-1x'+Number(number)+'/?$','i').test(new URL(u).pathname));links=[...new Set(links)];if(links.length!==1)return [];let page=parse(await get(links[0])),out=[];for(let iframe of page.querySelectorAll('iframe[data-src]')){let u;try{u=new URL(iframe.getAttribute('data-src'),origin)}catch(_){continue}if(u.hostname!=='animesalt.cx'||!u.pathname.endsWith('/plyr/player.php'))continue;try{let tracks=JSON.parse(atob(u.searchParams.get('data')||''));if(!Array.isArray(tracks))continue;for(let track of tracks){let lang=String(track.language||'').trim().toLowerCase()==='english'?'dub':String(track.language||'').trim().toLowerCase()==='japanese'?'sub':'';let url=validUrl(track.link,'player');if(lang&&url&&new URL(url).hostname==='player.abyssplayer.com')out.push({name:'Server',lang,url,referer:'salt'})}}catch(_){}}return out}
async function fallbackAni(title,number){if(!/^\d+$/.test(String(number)))return [];let origin='https://aniwaves.ru',d=parse(await get(origin+'/filter?keyword='+encodeURIComponent(title)));let urls=[...d.querySelectorAll('.item .info a.name[href]')].filter(a=>matchTitle(a.textContent)===matchTitle(title)).map(a=>validUrl(new URL(a.getAttribute('href'),origin).href)).filter(u=>u&&new URL(u).hostname==='aniwaves.ru'&&new URL(u).pathname.startsWith('/watch/'));urls=[...new Set(urls)];if(urls.length!==1)return [];let page=parse(await get(urls[0])),id=page.querySelector('#watch-main[data-id]')?.getAttribute('data-id');if(!/^\d+$/.test(id||'')||matchTitle(page.querySelector('h1')?.textContent)!==matchTitle(title))return [];let epsRes=JSON.parse(await get(origin+'/ajax/episode/list/'+id)),eps=parse(epsRes.result||'');let ep=[...eps.querySelectorAll('a[data-num][data-ids]')].filter(a=>a.getAttribute('data-num')===String(Number(number)));if(ep.length!==1)return [];let ids=ep[0].getAttribute('data-ids');if(!new RegExp('^'+id+'&eps='+Number(number)+'$').test(ids))return [];let result=JSON.parse(await get(origin+'/ajax/server/list?servers='+ids)),sd=parse(result.result||''),out=[];for(let group of sd.querySelectorAll('.servers .type[data-type]')){let lang=group.getAttribute('data-type');if(lang!=='sub'&&lang!=='dub')continue;for(let li of [...group.querySelectorAll('li[data-link-id]')].slice(0,2)){let token=li.getAttribute('data-link-id');if(!/^[a-f0-9]{16,600}$/i.test(token||''))continue;let api=JSON.parse(await get(origin+'/ajax/sources?id='+encodeURIComponent(token)+'&asi=0&autoPlay=0'));let url=validUrl(api.result?.url||'','player');if(url&&new URL(url).hostname==='play.vhscdn.to')out.push({name:'Server',lang,url,referer:'ani'})}}return out}
// News is fetched by the Android app from a small set of labelled feeds.
// The optional AniList details are shown only for an exact, unambiguous catalogue-title match.
const newsState={items:[],failed:[],checkedAt:0,filter:'all',limit:25,loading:false,error:'',serial:0,meta:{},looked:new Set()};
let newsReturn='home',newsObserver=null,newsMetaTimer=null,newsMetaBusy=false,newsOverlayMode=false,watchNewsMode=false,watchNewsToken=0,newsReturnFocus=null;const newsEligible=new Set();
function newsActive(){return newsOverlayMode||view==='news'}
function openNewsOverlay(token=0,fromWatch=false){
 closeSearchPopup();if(newsOverlayMode)closeNewsOverlay();newsOverlayMode=true;watchNewsMode=!!fromWatch;watchNewsToken=Number(token)||0;newsReturnFocus=document.activeElement;
 document.documentElement.classList.add(fromWatch?'watch-news-active':'news-overlay-active');let overlay=document.createElement('section');overlay.id='news-overlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Anime updates');document.body.appendChild(overlay);newsPage();document.getElementById('news-back')?.focus();
}
function closeNewsOverlay(){
 if(!newsOverlayMode)return;const wasWatch=watchNewsMode,token=watchNewsToken;newsOverlayMode=false;watchNewsMode=false;document.querySelector('#news-overlay')?.remove();document.documentElement.classList.remove('watch-news-active','news-overlay-active');if(newsObserver)newsObserver.disconnect();clearTimeout(newsMetaTimer);
 if(newsReturnFocus?.isConnected)newsReturnFocus.focus();newsReturnFocus=null;if(wasWatch)try{window.KuroNative?.watchNewsClosed?.(token)}catch(_){}
}
window.kuroWatchNewsOpen=token=>openNewsOverlay(token,true);
window.kuroWatchNewsClose=()=>closeNewsOverlay();
function newsBridge(method,...args){
 return new Promise((resolve,reject)=>{
  if(!window.KuroNative||typeof KuroNative[method]!=='function'){reject(Error('News is available in the Android app.'));return}
  const id='news-'+(++requestNo);pending[id]={resolve,reject};
  try{KuroNative[method](id,...args)}catch(e){delete pending[id];reject(e)}
 });
}
function showNews(){openNewsOverlay(0,false)}
window.kuroNewsOpen=showNews;
function returnFromNews(){
 if(newsReturn==='detail'&&selected)openShow(selected);else if(newsReturn==='episode'&&selected&&episode)openEpisode(episode);else nav(['home','search','library','simulcasts','profile'].includes(newsReturn)?newsReturn:'home');
}
function newsDate(ms){if(!Number(ms))return 'Date not supplied';try{return new Date(Number(ms)).toLocaleString(undefined,{year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}catch{return 'Date not supplied'}}
function newsPage(){
 if(!newsOverlayMode)++window.renderSeq;
 const container=newsOverlayMode?document.getElementById('news-overlay'):main;if(!container)return;
 container.innerHTML=`<div class="news-topline"><button class="back" id="news-back">‹ Back</button><span>LIVE UPDATES</span></div><div class="news-title-row"><div><div class="overline">STORIES WORTH SHARING</div><h1>Anime updates</h1><p class="sub">News reports and posts from official channels, all in one place.</p></div><div class="news-heading-icon" aria-hidden="true">✦</div></div><div id="news-alerts" class="news-alerts"></div><div class="news-controls"><div class="news-filters" aria-label="Filter updates"><button data-news-filter="all">All</button><button data-news-filter="news">News</button><button data-news-filter="official">Official</button></div><button id="news-refresh" class="news-refresh">↻ Refresh</button></div><p id="news-status" class="news-status" aria-live="polite"></p><div id="news-posts" class="news-posts"></div><button id="news-more" class="news-more" hidden>Show more updates</button><div class="news-footnote">Reports are labelled by outlet; official channels can post clips or other videos, not only announcements. Coverage is limited to the selected feeds. Some posts are in Japanese.</div>`;
 $('#news-back').onclick=newsOverlayMode?closeNewsOverlay:returnFromNews;$('#news-refresh').onclick=()=>loadNews('force');$('#news-more').onclick=()=>{newsState.limit+=25;renderNewsPosts();lookupNewsMetadata()};
 document.querySelectorAll('[data-news-filter]').forEach(b=>b.onclick=()=>{newsState.filter=b.dataset.newsFilter;newsState.limit=25;renderNewsPosts();lookupNewsMetadata()});
 renderNewsAlerts();renderNews();if(!newsState.loading)loadNews('cache').then(()=>loadNews('refresh'));
}
function renderNewsAlerts(){
 let box=$('#news-alerts');if(!box)return;let settings={enabled:false,allowed:false};
 try{if(window.KuroNative&&typeof KuroNative.newsSettings==='function')settings=JSON.parse(KuroNative.newsSettings())}catch{}
 const available=!!window.KuroNative,active=!!settings.enabled&&!!settings.allowed;
 let message=!available?'Available in the Android app':!settings.enabled?'Off · the in-app feed still works':!settings.allowed?'Blocked by Android · allow notifications':'On · Android checks periodically';
 box.innerHTML=`<div class="news-bell" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M18 8a6 6 0 0 0-12 0c0 7-2 7-2 9h16c0-2-2-2-2-9ZM10 20h4"/></svg></div><div class="news-alert-copy"><strong>Phone alerts</strong><small>${escapeHTML(message)}</small></div>${available?`<button id="news-alert-toggle" class="news-alert-toggle ${active?'is-on':''}" aria-label="${active?'Turn off':'Enable'} phone alerts">${active?'On':'Enable'}</button>${settings.enabled&&!settings.allowed?'<button id="news-alert-disable" class="news-alert-disable" aria-label="Turn off phone alerts">Off</button>':''}`:''}`;
 let button=$('#news-alert-toggle');if(button)button.onclick=()=>{if(window.KuroNative&&KuroNative.setNewsAlerts)KuroNative.setNewsAlerts(!active)};let disable=$('#news-alert-disable');if(disable)disable.onclick=()=>KuroNative.setNewsAlerts(false);
}
window.kuroNewsPermissionsChanged=()=>{if(newsActive())renderNewsAlerts()};
// A startup/resume check can finish while the feed is visible. Refresh only
// the cached cards; never navigate away from the current Watch page.
window.kuroNewsAutoUpdated=()=>{if(newsActive()&&!newsState.loading)loadNews('cache')};
async function loadNews(mode){
 if(mode!=='cache'&&newsState.loading)return;
 if(mode!=='cache'){newsState.loading=true;renderNewsStatus()}
 const token=++newsState.serial;
 try{
  const text=await newsBridge('news',mode);const data=JSON.parse(text);
  if(token!==newsState.serial)return;
  newsState.items=Array.isArray(data.items)?data.items.filter(x=>x&&typeof x.title==='string'&&typeof x.url==='string'):[];
  newsState.failed=Array.isArray(data.failed)?data.failed:[];newsState.checkedAt=Number(data.checkedAt)||0;newsState.error='';
  if(newsActive()){renderNews();lookupNewsMetadata()}
 }catch(e){if(token===newsState.serial){newsState.error=newsState.items.length?'Could not refresh. Showing saved updates.':'Could not load updates. Check your connection and try Refresh.';if(newsActive())renderNewsStatus()}}
 finally{if(mode!=='cache'){newsState.loading=false;if(newsActive())renderNewsStatus()}}
}
function renderNews(){if(!newsActive()||!$('#news-posts'))return;renderNewsStatus();renderNewsPosts()}
function renderNewsStatus(){
 let out=$('#news-status'),refresh=$('#news-refresh');if(!out)return;if(refresh){refresh.disabled=newsState.loading;refresh.textContent=newsState.loading?'Checking…':'↻ Refresh'}
 if(newsState.loading){out.textContent=newsState.items.length?'Checking for new updates…':'Getting the latest updates…';return}
 if(newsState.error){out.textContent=newsState.error;return}
 if(newsState.failed.length){out.textContent='Couldn’t update: '+newsState.failed.join(', ')+'. '+(newsState.items.length?'Showing available or saved updates. ':'No updates are available yet. ')+'Tap Refresh to try again.'+(newsState.checkedAt?' Last checked '+newsDate(newsState.checkedAt):'');return}
 out.textContent=newsState.checkedAt?'Last checked '+newsDate(newsState.checkedAt):'Updates are saved on this device for offline viewing.';
}
function newsCleanImage(url){try{let u=new URL(url);let h=u.hostname.toLowerCase();if(u.protocol!=='https:'||u.username||u.password||u.port)return '';if(h==='a.storyblok.com'||h==='animecorner.me'||h==='www.animecorner.me'||h==='anitrendz.net'||h==='www.anitrendz.net'||h==='cdn.myanimelist.net'||h==='ytimg.com'||h.endsWith('.ytimg.com')||h==='s4.anilist.co'||h==='s3.anilist.co'||(h==='i0.wp.com'&&u.pathname.startsWith('/anitrendz.net/news/wp-content/uploads/')))return u.href}catch{}return ''}
function newsCleanLink(url){try{let u=new URL(url);let h=u.hostname.toLowerCase();if(u.protocol!=='https:'||u.username||u.password||u.port)return '';if(h==='crunchyroll.com'||h.endsWith('.crunchyroll.com')||['animecorner.me','anitrendz.net','myanimelist.net','tohoanimationstore.us','aniplex.co.jp','prtimes.jp','youtube.com'].some(d=>h===d||h==='www.'+d)||h==='anilist.co')return u.href}catch{}return ''}
function newsIsVideo(item){try{let h=new URL(item.url).hostname.toLowerCase();return item.kind==='official'&&(h==='youtube.com'||h==='www.youtube.com')}catch{return false}}
function newsOpen(url){let safe=newsCleanLink(url);if(safe&&window.KuroNative&&KuroNative.openNewsUrl)KuroNative.openNewsUrl(safe)}
function newsCard(item,index){
 const image=newsCleanImage(item.image||''),official=item.kind==='official',video=newsIsVideo(item),meta=newsState.meta[item.id]||null;
 return `<article class="news-post" data-news-id="${index}"><div class="news-post-head"><div class="news-avatar" aria-hidden="true">✦</div><div class="news-byline"><strong>${escapeHTML(item.source||'Anime updates')}</strong><span>${video?'OFFICIAL VIDEO':official?'OFFICIAL UPDATE':'NEWS REPORT'} · ${escapeHTML(newsDate(item.published))}</span></div><span class="news-kind ${official?'official':''}">${official?'Official':'News'}</span></div><div class="news-post-body"><div class="news-divider"></div><h2 class="news-headline"><span>${escapeHTML(item.title)}</span></h2><div class="news-meta" data-news-meta="${index}">${meta?newsMetaMarkup(meta,item):''}</div>${item.summary?`<p class="news-summary">${escapeHTML(item.summary)}</p>`:''}<div class="news-catalog" data-news-catalog="${index}">${meta?newsDetailsMarkup(meta,item):''}</div><div class="news-source-label"><b>Source:</b> ${escapeHTML(item.source||'Publisher')} ${official?(video?'· official channel':'· official publisher'):'· news outlet'}</div><div class="news-media ${!image&&!(meta&&newsCleanImage(meta.cover))?'is-empty':''}" data-news-media="${index}">${newsMediaMarkup(item,index,meta)}</div><div class="news-actions" data-news-actions="${index}"><button data-news-open="${index}">${video?'▶  Watch official video':official?'Read official update':'Read full report'} <span>↗</span></button>${meta&&meta.link?`<button data-news-catalog-link="${index}" class="news-catalog-link">AniList details ↗</button>`:''}</div></div></article>`;
}
function newsMediaMarkup(item,index,meta){
 const image=newsCleanImage(item.image||''),poster=meta?newsCleanImage(meta.cover):'',video=newsIsVideo(item);
 return `${image?`<button class="news-media-source ${video?'is-video':''}" data-news-open="${index}" aria-label="${video?'Watch official video':'Open news report'}"><img src="${escapeHTML(image)}" loading="lazy" alt=""><span>${video?'▶':'View source ↗'}</span></button>`:''}${poster&&poster!==image?`<div class="news-poster"><img src="${escapeHTML(poster)}" loading="lazy" alt="Catalog poster"><small>AniList catalog</small></div>`:''}`;
}
function newsMetaMarkup(meta,item){return meta.alternate.length?`<p class="news-alt">Alternate titles: ${escapeHTML(meta.alternate.join(' · '))}</p>`:''}
function newsDetailsMarkup(meta,item){
 let sequel=/\b(?:season\s*(?:[2-9]|\d\d)|(?:2nd|3rd|4th|5th|second|third|fourth)\s+season|sequel)\b/i.test(item.title)&&!/\b(?:season\s*(?:[2-9]|\d\d)|(?:2nd|3rd|4th|5th|second|third|fourth)\s+season|sequel)\b/i.test(meta.candidate);
 const synopsis=meta.synopsis?`<p class="news-synopsis">${escapeHTML(meta.synopsis)}</p>`:'',genres=meta.genres.length?`<div class="news-fact"><b>Genres:</b> ${escapeHTML(meta.genres.join(', '))}</div>`:'',studio=!sequel&&meta.studios.length?`<div class="news-fact"><b>Production:</b> ${escapeHTML(meta.studios.join(', '))}</div>`:'';
 return synopsis||genres||studio?`<div class="news-catalog-label">SERIES INFO · ANILIST${sequel?' · MAY DIFFER BY SEASON':''}</div>${synopsis}${genres||studio?'<div class="news-divider short"></div>':''}${genres}${studio}`:'';
}
function renderNewsPosts(){
 let box=$('#news-posts');if(!box)return;document.querySelectorAll('[data-news-filter]').forEach(b=>b.classList.toggle('active',b.dataset.newsFilter===newsState.filter));
 let arr=newsState.items.map((item,index)=>({item,index})).filter(x=>newsState.filter==='all'||x.item.kind===newsState.filter),shown=arr.slice(0,newsState.limit);
 box.innerHTML=shown.length?shown.map(x=>newsCard(x.item,x.index)).join(''):`<div class="news-empty">${newsState.loading?'Finding the latest updates…':newsState.failed.length?'No saved updates yet. Check your connection and refresh.':'No updates in this view yet.'}</div>`;
 $('#news-more').hidden=arr.length<=shown.length;bindNewsActions(box);observeNewsCards(box);
}
function observeNewsCards(box){
 if(newsObserver)newsObserver.disconnect();
 const cards=Array.from(box.querySelectorAll('.news-post'));
 if(!('IntersectionObserver' in window)){cards.slice(0,8).forEach(c=>{let x=newsState.items[Number(c.dataset.newsId)];if(x)newsEligible.add(x.id)});return}
 newsObserver=new IntersectionObserver(entries=>{
  for(const e of entries)if(e.isIntersecting){let x=newsState.items[Number(e.target.dataset.newsId)];if(x&&!newsState.looked.has(x.id))newsEligible.add(x.id)}
  if(newsEligible.size){clearTimeout(newsMetaTimer);newsMetaTimer=setTimeout(lookupNewsMetadata,250)}
 },{root:newsOverlayMode?document.getElementById('news-overlay'):null,rootMargin:'500px 0px'});cards.forEach(c=>newsObserver.observe(c));
}
function updateNewsCards(){
 let box=$('#news-posts');if(!box)return;
 box.querySelectorAll('.news-post').forEach(card=>{let index=Number(card.dataset.newsId),item=newsState.items[index],meta=item&&newsState.meta[item.id];if(!meta||card.dataset.enriched==='yes')return;
  card.dataset.enriched='yes';card.querySelector('[data-news-meta]').innerHTML=newsMetaMarkup(meta,item);card.querySelector('[data-news-catalog]').innerHTML=newsDetailsMarkup(meta,item);
  let media=card.querySelector('[data-news-media]');media.innerHTML=newsMediaMarkup(item,index,meta);media.classList.toggle('is-empty',!newsCleanImage(item.image||'')&&!newsCleanImage(meta.cover||''));
  let actions=card.querySelector('[data-news-actions]');if(meta.link&&!actions.querySelector('[data-news-catalog-link]'))actions.insertAdjacentHTML('beforeend',`<button data-news-catalog-link="${index}" class="news-catalog-link">AniList details ↗</button>`);bindNewsActions(card);
 });
}
function bindNewsActions(box){
 box.querySelectorAll('[data-news-open]').forEach(b=>b.onclick=()=>{let x=newsState.items[Number(b.dataset.newsOpen)];if(x)newsOpen(x.url)});
 box.querySelectorAll('[data-news-catalog-link]').forEach(b=>b.onclick=()=>{let x=newsState.items[Number(b.dataset.newsCatalogLink)],m=x&&newsState.meta[x.id];if(m)newsOpen(m.link)});
}
function candidateTitle(headline){
 const t=String(headline||'').replace(/\s+/g,' ').trim(),m=t.match(/^(.{3,140}?)\s+(?:(?:TV|Television)\s+)?Anime\b/i);if(!m)return '';
 return m[1].replace(/^[\s'"‘’“”「」『』]+|[\s'"‘’“”「」『』:–—-]+$/g,'').trim();
}
function normalizeNewsTitle(s){return String(s||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9\u3040-\u30ff\u4e00-\u9faf]+/g,'')}
function exactNewsMeta(candidate,list){
 const key=normalizeNewsTitle(candidate);if(!key||!Array.isArray(list))return null;
 let match=list.filter(m=>{let t=m&&m.title||{},names=[t.english,t.romaji,t.native,...(Array.isArray(m&&m.synonyms)?m.synonyms:[])];return names.some(x=>x&&normalizeNewsTitle(x)===key)});
 let ids=new Set(match.map(x=>String(x.id)));if(ids.size!==1)return null;
 const m=match[0],titles=m.title||{},alts=[titles.english,titles.romaji,titles.native].filter(x=>typeof x==='string'&&x.trim()&&normalizeNewsTitle(x)!==key),unique=[];
 for(const x of alts)if(!unique.some(y=>normalizeNewsTitle(y)===normalizeNewsTitle(x)))unique.push(x.trim());
 let synopsis=String(m.description||'').replace(/<br\s*\/?\s*>/gi,' ').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();if(synopsis.length>650)synopsis=synopsis.slice(0,647).replace(/\s+\S*$/,'')+'…';
 let studios=Array.isArray(m.studios&&m.studios.nodes)?m.studios.nodes.filter(x=>x&&x.isAnimationStudio&&x.name).map(x=>String(x.name)):[];
 return {candidate,alternate:unique.slice(0,2),synopsis,genres:Array.isArray(m.genres)?m.genres.filter(x=>typeof x==='string').slice(0,8):[],studios:studios.slice(0,4),cover:newsCleanImage(m.coverImage&&m.coverImage.large||''),link:newsCleanLink(m.siteUrl||'')};
}
async function lookupNewsMetadata(){
 if(!newsActive()||newsMetaBusy||!window.KuroNative||typeof KuroNative.newsMetadata!=='function')return;
 const arr=newsState.items.filter(x=>newsState.filter==='all'||x.kind===newsState.filter).slice(0,newsState.limit);let candidates=[],items=[];
 for(const item of arr){if(!newsEligible.has(item.id))continue;newsEligible.delete(item.id);const c=candidateTitle(item.title);if(!c||newsState.looked.has(item.id))continue;newsState.looked.add(item.id);candidates.push(c);items.push(item);if(candidates.length>=8)break}
 if(!candidates.length)return;newsMetaBusy=true;
 try{
  const data=JSON.parse(await newsBridge('newsMetadata',JSON.stringify(candidates)));
  items.forEach((item,i)=>{let m=exactNewsMeta(candidates[i],data&&data.data&&data.data['m'+i]&&data.data['m'+i].media);if(m)newsState.meta[item.id]=m});
  if(newsActive()&&$('#news-posts'))updateNewsCards();
 }catch{/* The feed remains usable when optional catalog data is unavailable. */}
 finally{newsMetaBusy=false;if(newsActive()&&newsEligible.size){clearTimeout(newsMetaTimer);newsMetaTimer=setTimeout(lookupNewsMetadata,600)}}
}

// Replace the provider picker with one progressive, merged discovery surface.
home=unifiedHome;searchPage=unifiedSearchPage;simulcasts=unifiedSimulcasts;toggleSearchPopup=unifiedSearchPopup;browseGenre=unifiedBrowseGenre;
window.kuroBack=()=>{if(newsOverlayMode){closeNewsOverlay();return}if($('#sort-modal')){closeSortPicker();return}if($('#status-modal')){closeStatusPicker();return}if($('#search-popup')){closeSearchPopup();return}if(view==='episode')openShow(selected);else if(view==='detail')returnToShowOrigin();else if(view==='news')returnFromNews();else nav('home')};nav('home');

window.kuroOpenDetails=()=>{if(selected)openShow(selected)};
// Native watch-header actions first close the player, then navigate here.
window.kuroWatchHeader=action=>{if(!['home','search','news'].includes(action))return;if(action==='search'){window.kuroWatchSearchOpen();return}closeSearchPopup();if(action==='news'){showNews();return}nav('home');window.scrollTo(0,0)};

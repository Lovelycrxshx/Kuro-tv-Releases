'use strict';
// At most one bounded, cancellable search is active per watch session. Matches are exact.
let watchSerial=0,currentWatchChain=null;
const isVerification=e=>/HTTP\s*(?:403|429)\b|requested human verification|verification required/i.test(String(e?.message||e||''));
function validEpisodeNumber(x){return /^\d+$/.test(String(x))&&Number(x)>0&&Number(x)<=5000;}
async function legacyPrimary(s,ep,item=selected){
 if(ep.missing)return [];
 if(s==='flix')return flixServers(ep);
 if(s==='zenkai')return zenkaiServers(item,ep);
 if(s==='wixi')return wixiServers(item,ep);
 if(s==='aw')return awServers(ep);
 if(s==='miruro')return miruroServers(item,ep);
 if(s==='kitsune')return kitsuneServers(item,ep);
 if(s==='paradise')return paradiseServers(item,ep);
 if(['nine','zoro','ani','salt'].includes(s))return ({nine:fallbackNine,zoro:fallbackZoro,ani:fallbackAni,salt:fallbackSalt})[s](selected.title,ep.number);
 let d=parse(await get(ep.url));if(sourceNeedsVerification(d))throw Error('The library requested human verification.');let out=[];
 if(s==='ms'){
  let cfg=JSON.parse(d.querySelector('[data-hk-watch]')?.getAttribute('data-hk-watch')||'{}');
  for(const b of d.querySelectorAll('.hk-srv')){
   let lang=b.getAttribute('data-version'),key=b.getAttribute('data-server'),url=b.getAttribute('data-src')||'';
   if(!url&&key==='backup'&&cfg.token)url=base('ms')+'/stream/'+encodeURIComponent(cfg.token)+'/'+encodeURIComponent(lang);
   if(!url&&cfg.mirror?.[key]&&cfg.al)url=cfg.mirror[key].replace('{al}',cfg.al).replace('{ep}',cfg.movie?1:cfg.ep).replace('{lang}',lang);
   url=validUrl(abs(url,'ms'),'player');if(url&&(lang==='sub'||lang==='dub'))out.push({name:b.textContent.trim(),lang,url,referer:'ms'});
  }
 }else if(s==='dk'){
  let id=d.querySelector('#ani_detail')?.getAttribute('data-id')||new URL(ep.url).searchParams.get('ep');if(!/^\d+$/.test(id||''))return [];
  let res=JSON.parse(await get(base('dk')+'/ajax/v2/episode/servers?episodeId='+id));let sd=parse(res.html||'');
  for(let b of sd.querySelectorAll('.server-item')){let url='';try{url=validUrl(atob(b.getAttribute('data-hash')),'player')}catch(_){}let lang=(b.getAttribute('data-type')||'').toLowerCase();if(url&&(lang==='sub'||lang==='dub'))out.push({name:b.getAttribute('data-server-name')||'Server',lang,url,referer:'dk'})}
 }return out;
}
async function fallbackMain(s,title,number,expected={}){
 if(!validEpisodeNumber(number))return [];
 // HiAnime is served from several mirrors. Walk the list when one fails, so a
 // dead domain costs one request instead of the whole library.
 if(s==='dk'){
  try{let r=await fallbackMainOne('dk',title,number,expected);if(r.length)return r}catch(e){if(isVerification(e))throw e}
  let origin=base('dk');
  for(let hop=0;hop<HI_MIRRORS.length-1;hop++){
   let next=hiRotateMirror(origin);if(!next)break;
   try{let r=await fallbackMainOne('dk',title,number,expected);if(r.length){hiRememberMirror(next);return r}}catch(e){if(isVerification(e))throw e}
   origin=next;
  }
  return [];
 }
 return fallbackMainOne(s,title,number,expected);
}
async function fallbackMainOne(s,title,number,expected={}){
 let list=(await fetchCatalogPage({source:s,mode:'search',query:title},1)).items.filter(x=>matchTitle(x.title)===matchTitle(title));
 const urls=[...new Set(list.map(x=>x.url))];if(urls.length!==1)return [];
 let show=parse(await get(urls[0]));if(sourceNeedsVerification(show))throw Error('The library requested human verification.');
 let heading=s==='ms'?show.querySelector('h1')?.textContent:show.querySelector('.anisc-detail .film-name')?.textContent;
 if(matchTitle(heading)!==matchTitle(title))return [];
 if(expected.anilistId){let a=show.querySelector('a[href^="https://anilist.co/anime/"]')?.getAttribute('href')?.match(/\/anime\/(\d+)/);if(a&&Number(a[1])!==Number(expected.anilistId))return []}
 if(expected.malId){let m=show.querySelector('a[href^="https://myanimelist.net/anime/"]')?.getAttribute('href')?.match(/\/anime\/(\d+)/);if(m&&Number(m[1])!==Number(expected.malId))return []}
 let eps=[];
 if(s==='ms'){
  eps=[...show.querySelectorAll('.hk-ep,.hk-wep')].flatMap(x=>{let n=x.getAttribute('data-ep')||x.getAttribute('data-episode'),u=validUrl(abs(x.getAttribute('href'),s));return validEpisodeNumber(n)&&u?[{number:String(Number(n)),url:u}]:[]});
 }else{
  let first=validUrl(abs(show.querySelector('.btn-play[href]')?.getAttribute('href')||'',s));
  if(!first||!hiIsMirrorHost(new URL(first).hostname)||!new URL(first).pathname.startsWith('/watch/'))return [];
  hiRememberMirror(new URL(first).origin);
  let page=parse(await get(first));if(sourceNeedsVerification(page))throw Error('The library requested human verification.');
  let id=page.querySelector('#ani_detail')?.getAttribute('data-anime-id');if(!/^\d+$/.test(id||''))return [];
  let json=JSON.parse(await get(base('dk')+'/ajax/v2/episode/list/'+id)),d=parse(json.html||'');
  eps=[...d.querySelectorAll('.ep-item[data-number][href]')].flatMap(x=>{let n=x.getAttribute('data-number'),u=validUrl(abs(x.getAttribute('href'),'dk'));return validEpisodeNumber(n)&&u?[{number:String(Number(n)),url:u}]:[]});
 }
 let matches=eps.filter(x=>x.number===String(Number(number)));if(matches.length!==1)return [];
 // The parser reads only the supplied source, title and episode; no global selected state is changed.
 return legacyPrimary(s,matches[0]);
}
async function fallbackFlix(title,number){
 if(!validEpisodeNumber(number))return [];
 let candidates=[];
 // The source mixes series and latest-episode cards in search; inspect at most
 // three source-reported pages and collapse episode cards to verified series URLs.
 for(let page=1;page<=3;page++){let result=await fetchCatalogPage({source:'flix',mode:'search',query:title},page);candidates.push(...result.items.filter(x=>matchTitle(x.title)===matchTitle(title)));if(!result.hasNext)break}
 let series=new Map();
 for(const item of candidates){
  let raw=await get(item.url),doc=parse(raw),url=item.url;
  if(sourceNeedsVerification(doc))throw Error('The library requested human verification.');
  if(!new URL(url).pathname.startsWith('/anime/')){
   let a=doc.querySelector('.anisc-detail .film-name a[href]');url=validUrl(abs(a?.getAttribute('href')||'','flix'));
   if(!url||new URL(url).hostname!=='hianimeq.top'||!new URL(url).pathname.startsWith('/anime/')||matchTitle(a?.textContent)!==matchTitle(title))continue;
  }
  if(!series.has(url))series.set(url,{...item,url});
 }
 if(series.size!==1)return [];let item=[...series.values()][0],d=await flixDetail(item,await get(item.url)),eps=await flixEpisodes(d),matches=eps.filter(x=>x.number===String(Number(number)));
 return matches.length===1?flixServers(matches[0]):[];
}
async function fallbackAdded(s,title,number,expected={}){
 if(!validEpisodeNumber(number))return [];
 let list=(await fetchCatalogPage({source:s,mode:'search',query:title},1)).items.filter(x=>[x.title,...(x.titles||[])].some(t=>matchTitle(t)===matchTitle(title)));
 const ids=[...new Set(list.map(x=>x.anilistId))];if(ids.length!==1)return [];
 let item=list.find(x=>x.anilistId===ids[0]);if(expected.anilistId&&Number(expected.anilistId)!==Number(item.anilistId))return [];if(expected.malId&&item.malId&&Number(expected.malId)!==Number(item.malId))return [];let details=await addedDetails(item,await get(item.url));
 let eps=details.episodes.filter(x=>x.number===String(Number(number)));if(eps.length!==1)return [];
 return s==='zenkai'?zenkaiServers(item,eps[0]):wixiServers(item,eps[0]);
}
const failoverAdapters={ms:(t,n,id)=>fallbackMain('ms',t,n,id),dk:(t,n,id)=>fallbackMain('dk',t,n,id),nine:fallbackNine,zoro:fallbackZoro,ani:fallbackAni,salt:fallbackSalt,flix:fallbackFlix,wixi:(t,n,id)=>fallbackAdded('wixi',t,n,id),zenkai:(t,n,id)=>fallbackAdded('zenkai',t,n,id),aw:fallbackAw,miruro:fallbackMiruro,kitsune:fallbackKitsune,paradise:fallbackParadise};
function renderWatchServers(chain){
 if(!chain.alive())return;let box=$('#servers');if(!box)return;
 box.innerHTML=servers.length?`<div class="control">${servers.map((s,i)=>`<button class="btn" data-server="${i}">▶ &nbsp; Server ${servers.slice(0,i+1).filter(x=>x.lang===s.lang).length} <span class="muted">· ${escapeHTML((s.lang||'').toUpperCase())}${s.note?' · '+escapeHTML(s.note):''}</span></button>`).join('')}</div>`:chain.done?'<div class="notice">No supported exact-match servers were found.</div>':'<div class="spinner"></div>';
 if(!servers.length&&chain.done)miruroWatchActions(box,chain);
 box.querySelectorAll('[data-server]').forEach(b=>b.onclick=()=>{if(window.KuroNative)launchWatch(Number(b.dataset.server));else placeholder('Playback opens in the Android app.')});
}
function miruroWatchActions(box,chain){
 if(unifiedVerificationBlocked.has('miruro')&&window.KuroNative?.verifyLibrary11){box.insertAdjacentHTML('beforeend','<div class="space"></div><button class="btn" data-miruro-verify>Verify Library 11</button>');box.querySelector('[data-miruro-verify]').onclick=()=>KuroNative.verifyLibrary11();}
 if(chain.source==='kitsune'&&chain.kitsuneId&&window.KuroNative?.openLibrary12Episode){box.insertAdjacentHTML('beforeend','<div class="space"></div><button class="btn" data-kitsune-open>Open Library 12 in browser</button>');box.querySelector('[data-kitsune-open]').onclick=()=>KuroNative.openLibrary12Episode(String(chain.kitsuneId),chain.number);}
 if(chain.source==='miruro'&&chain.miruroId&&window.KuroNative?.openLibrary11Episode){box.insertAdjacentHTML('beforeend','<div class="space"></div><button class="btn" data-miruro-open>Open Library 11 in browser</button>');box.querySelector('[data-miruro-open]').onclick=()=>KuroNative.openLibrary11Episode(chain.miruroId,chain.number);}
}
function addChainServers(chain,items,primary=false){
 if(!chain.alive()||chain.done||(chain.blocked&&!primary))return;
 if(chain.initializing&&!primary){if(!chain.fallbackStop)chain.buffer.push(...(items||[]).slice(0,50));return;}
 let added=[];
 for(const s of items||[]){
  if(!s||!validUrl(s.url,'player')||!['sub','dub'].includes(String(s.lang||'').toLowerCase()))continue;
  let path=new URL(s.url).pathname,mal=path.match(/\/stream\/mal\/(\d+)\/(\d+)\//),anilist=path.match(/\/embed\/anime\/(\d+)\/(\d+)\//);
  if(mal&&(Number(mal[2])!==Number(chain.number)||(chain.identity.malId&&Number(mal[1])!==chain.identity.malId)))continue;
  if(anilist&&(Number(anilist[2])!==Number(chain.number)||(chain.identity.anilistId&&Number(anilist[1])!==chain.identity.anilistId)))continue;
  let key=s.url+'|'+s.lang;if(chain.seen.has(key)||servers.length>=50)continue;chain.seen.add(key);servers.push(s);added.push(s);
 }
 if(!added.length)return;renderWatchServers(chain);
 if(chain.launched&&window.KuroNative?.addServers)KuroNative.addServers(chain.id,JSON.stringify({servers:added}));
 else if(!chain.launched&&window.KuroNative){chain.launched=true;launchWatch(preferredServer(servers));}
}
function finishChain(chain,blocked=false){
 if(!chain.alive()||chain.done)return;
 if(chain.initializing){chain.pendingFinish=!!blocked;chain.fallbackStop=!!blocked;return;}
 chain.done=true;chain.blocked=blocked;clearTimeout(chain.timer);
 if(chain.launched&&window.KuroNative?.addServers)KuroNative.addServers(chain.id,JSON.stringify({servers:[],done:true,blocked}));
 if(blocked&&!servers.length){let el=$('#servers');if(el){el.innerHTML='<div class="notice">A library requested human verification. Please check it manually before retrying.</div>';miruroWatchActions(el,chain)}}
 else renderWatchServers(chain);
}
async function seekFallbacks(chain){
 let order=['village578','wave575','koto575','gogo575','ms','dk','nine','zoro','ani','salt','flix','wixi','zenkai','aw','miruro','kitsune','paradise'].filter(x=>x!==chain.source),cursor=0;
 async function worker(){
  while(chain.alive()&&!chain.done&&!chain.fallbackStop){
   let s=order[cursor++];if(!s)return;if(unifiedVerificationBlocked.has(s))continue;
   try{let found=await failoverAdapters[s](chain.title,chain.number,chain.identity);if(!chain.alive()||chain.done||chain.fallbackStop)return;addChainServers(chain,found)}
   catch(e){if(isVerification(e)){unifiedVerificationBlocked.add(s);chain.fallbackRestricted=true;continue}}
  }
 }
 await Promise.all([worker(),worker(),worker()]);if(chain.alive()&&!chain.done&&!chain.fallbackStop)finishChain(chain,!!chain.fallbackRestricted && !servers.length && !chain.buffer.length);
}
async function openEpisode(ep){
 if(!selected||!validEpisodeNumber(ep.number))return;
 const owner=ep.unifiedOwner||selected;if(ep.unifiedOwner&&!unifiedKnownIdentity(selected,owner))return;
 pageTransition();rememberEpisode(selected,ep);episode=ep;view='episode';let marker=++window.renderSeq;servers=[];
 const chain={id:'watch-'+(++watchSerial),marker,source:owner.source,miruroId:owner.source==='miruro'?owner.miruroId:'',kitsuneId:owner.source==='kitsune'?owner.anilistId:0,title:selected.title,number:String(Number(ep.number)),identity:{anilistId:Number(selected.anilistId)||0,malId:Number(selected.malId)||0},seen:new Set(),done:false,blocked:false,launched:false,initializing:true,buffer:[],fallbackStop:false,pendingFinish:null,alive(){return currentWatchChain===this&&window.renderSeq===this.marker&&view==='episode'}};
 currentWatchChain=chain;
 main.innerHTML=`<div class="topline"><button class="back" id="back">‹ Episodes</button><span class="sub">One library</span></div><div class="overline">READY TO WATCH</div><h1>${escapeHTML(selected.title)}</h1><p class="sub">Episode ${escapeHTML(ep.number)} · Select an available server</p><div class="heading"><h2>Video servers</h2></div><div id="servers"><div class="spinner"></div></div><div class="space"></div><div class="notice">Servers are third-party players. Availability and video controls can vary.</div><div class="space"></div><button class="btn" id="other">Search this title ↗</button>`;
 $('#back').onclick=()=>openShow(selected);$('#other').onclick=()=>{view='search';searchPage(selected.title)};
 chain.timer=setTimeout(()=>{chain.initializing=false;finishChain(chain)},60000);
 // Search in parallel but never start a different library before the selected one resolves.
 seekFallbacks(chain);let primary=[];
 try{primary=await legacyPrimary(chain.source,ep,owner)}catch(e){if(isVerification(e)){chain.initializing=false;finishChain(chain,true);return}}
 if(!chain.alive()||chain.done)return;chain.initializing=false;
 // Choose a dub from already-resolved matches without delaying the primary.
 // A later-arriving dub never interrupts a source that is already playing.
 addChainServers(chain,chain.fallbackStop?primary:[...primary,...chain.buffer],true);chain.buffer.length=0;
 if(chain.pendingFinish!==null)finishChain(chain,chain.pendingFinish);
}
function preferredServer(list){
 let global=window.kuroSettings560?.snapshot?.()||{},audio=global.audio||'dub';
 const names=[global.server1,global.server2,global.server3],nameMatches=(s,n)=>String(s.name||'').trim().toLowerCase()===String(n).trim().toLowerCase();
 if(audio==='default')return 0
 const language=audio==='sub'?'sub':'dub';
 for(const n of names){if(!n)continue;let i=list.findIndex(s=>String(s.lang||'').trim().toLowerCase()===language&&nameMatches(s,n));if(i>=0)return i}
 let i=list.findIndex(s=>String(s.lang||'').trim().toLowerCase()===language);if(i>=0)return i;
 i=list.findIndex(s=>String(s.lang||'').trim().toLowerCase()===(language==='dub'?'sub':'dub'));return i>=0?i:0;
}
function launchWatch(index){
 let chain=currentWatchChain;if(!chain||!chain.alive())return;
 let e=episodes.map(x=>{let o={number:String(x.number).slice(0,20),name:String(x.name||'').slice(0,160),filler154:Boolean(window.kuroIsEpisodeSkipped154&&window.kuroIsEpisodeSkipped154(selected,x))};if(x.filler||/\bfiller\b/i.test(String(x.name||'')))o.f=1;else if(/\brecap\b/i.test(String(x.name||'')))o.r=1;try{if(typeof watchedHas==='function'&&watchedHas(selected,x.number))o.w=1}catch(_){}return o});let current=Math.max(0,episodes.findIndex(x=>x===episode||x.url===episode.url&&String(x.number)===String(episode.number)));
 let payload={session:chain.id,skipFiller154:Boolean(window.kuroShouldSkipFiller154&&window.kuroShouldSkipFiller154(selected)),lookupDone:chain.done,blocked:chain.blocked,title:selected.title,episode:String(episode.number),episodeName:String(episode.name||'').slice(0,160),episodeImage:String(episode.thumbnail||episode.image||episode.img||'').slice(0,512),episodeIdentity:String(episode.url||'').slice(0,4096),source:chain.source,showIdentity:String(selected.url||'').slice(0,4096),servers,episodes:e,current,index,animeInfo:{image:selected.img||'',meta:selected.meta||'',description:selected.description||'',counts:selected.counts||{},countsSource:String(selected.source||''),anilistId:selected.verifyTitle?0:Number(selected.anilistId)||0}};
 recordHistory(selected,episode);chain.launched=true;KuroNative.play(JSON.stringify(payload));let recent=stored('kuro-recent').filter(x=>x.url!==selected.url);recent.unshift(compactItem(selected));save('kuro-recent',recent.slice(0,20));
}
window.kuroPlayerClosed=id=>{if(currentWatchChain?.id===id){clearTimeout(currentWatchChain.timer);currentWatchChain.launched=false;currentWatchChain.done=true}};
window.kuroChooseEpisode=i=>{if(Number.isInteger(i)&&i>=0&&i<episodes.length)openEpisode(episodes[i])};

// Experimental exact-title failover adapters. Never guess an episode or execute
// source HTML; only known player hosts and explicit sub/dub servers are used.
async function requestedWave575(host,title,number,expected={}){
 if(!validEpisodeNumber(number)||!['aniwaves.tv','anikoto.cz'].includes(host))return [];
 const origin='https://'+host, fetchDoc=async url=>{let d=parse(await get(url));if(sourceNeedsVerification(d))throw Error('The library requested human verification.');return d};
 let search=await fetchDoc(origin+'/filter?keyword='+encodeURIComponent(title));
 let urls=[...new Set([...search.querySelectorAll('.item .info a.name[href]')].filter(a=>matchTitle(a.textContent)===matchTitle(title)).flatMap(a=>{
  try{let u=new URL(a.getAttribute('href'),origin);if(u.hostname!==host||u.protocol!=='https:'||!/^\/watch\/[a-z0-9-]+(?:\/ep-\d+)?\/?$/i.test(u.pathname))return [];u.pathname=u.pathname.replace(/\/ep-\d+\/?$/,'');u.search='';u.hash='';return [u.href]}catch(_){return []}
 }))];
 if(urls.length!==1)return [];
 let show=await fetchDoc(urls[0]);if(matchTitle(show.querySelector('h1')?.textContent)!==matchTitle(title))return [];
 for(const [key,domain] of [['anilistId','anilist.co'],['malId','myanimelist.net']]){
  const links=[...show.querySelectorAll('a[href]')].flatMap(a=>{try{let u=new URL(a.href,origin),m=u.pathname.match(/^\/anime\/(\d+)/);return u.hostname===domain&&m?[Number(m[1])]:[]}catch(_){return []}});
  if(expected[key]&&links.length&&!links.includes(Number(expected[key])))return [];
 }
 let id=show.querySelector('#watch-main[data-id]')?.getAttribute('data-id');if(!/^\d{1,8}$/.test(id||''))return [];
 const episodeResult=JSON.parse(await get(origin+'/ajax/episode/list/'+id));if(episodeResult.status!==200||typeof episodeResult.result!=='string')return [];
 let doc=parse(episodeResult.result),eps=[...doc.querySelectorAll('a[data-num][data-ids]')].filter(a=>a.getAttribute('data-num')===String(Number(number))&&a.getAttribute('enabled')!=='0');if(eps.length!==1)return [];
 let token=eps[0].getAttribute('data-ids')||'', serverQuery;
 if(host==='aniwaves.tv'){if(token!==id+'&eps='+Number(number))return [];serverQuery=token}
 else {if(!/^[A-Za-z0-9+/=_-]{1,1500}$/.test(token))return [];serverQuery=encodeURIComponent(token)}
 let data=JSON.parse(await get(origin+'/ajax/server/list?servers='+serverQuery));if(data.status!==200||typeof data.result!=='string')return [];
 let groups=parse(data.result).querySelectorAll('.servers .type[data-type]'),out=[];
 for(const group of groups){let lang=(group.getAttribute('data-type')||'').toLowerCase();if(!['sub','dub'].includes(lang))continue;
  for(const li of [...group.querySelectorAll('li[data-link-id]')].slice(0,4)){
   let key=li.getAttribute('data-link-id')||'';if(!/^[A-Za-z0-9+/=_-]{16,1500}$/.test(key))continue;
   let apiUrl=host==='aniwaves.tv'?origin+'/ajax/sources?id='+encodeURIComponent(key)+'&asi=0&autoPlay=0':origin+'/ajax/server?get='+encodeURIComponent(key);
   let response=JSON.parse(await get(apiUrl));if(response.status!==200)continue;let url=validUrl(response.result?.url||'','player');if(!url)continue;
   let playerHost=new URL(url).hostname,allowed=host==='aniwaves.tv'?['play.vhscdn.to']:['megaplay.buzz','vidtube.site','vidnest.fun'];if(!allowed.includes(playerHost))continue;
   out.push({name:host==='aniwaves.tv'?'Aniwaves TV':'Anikoto',url,lang,referer:host==='aniwaves.tv'?'aniwaves-tv':'anikoto-cz'});
  }
 }
 return out;
}
failoverAdapters.wave575=(t,n,id)=>requestedWave575('aniwaves.tv',t,n,id);
failoverAdapters.koto575=(t,n,id)=>requestedWave575('anikoto.cz',t,n,id);

async function requestedGogo575(title,number){
 if(!validEpisodeNumber(number))return [];
 const origin='https://gogoanimes.cv';
 const doc=async u=>{let d=parse(await get(u));if(sourceNeedsVerification(d))throw Error('The library requested human verification.');return d};
 let search=await doc(origin+'/?s='+encodeURIComponent(title));
 let shows=[...new Set([...search.querySelectorAll('a[href]')].filter(a=>matchTitle(a.getAttribute('title')||a.textContent)===matchTitle(title)).flatMap(a=>{try{let u=new URL(a.getAttribute('href'),origin);return u.hostname==='gogoanimes.cv'&&/^\/anime\/[a-z0-9-]+\/?$/i.test(u.pathname)?[u.href]:[]}catch(_){return []}}))];
 if(shows.length!==1)return [];let show=await doc(shows[0]);if(matchTitle(show.querySelector('h1')?.textContent)!==matchTitle(title))return [];
 let cats=[...new Set([...show.querySelectorAll('a[href]')].filter(a=>matchTitle(a.textContent)===matchTitle(title)).flatMap(a=>{try{let u=new URL(a.getAttribute('href'),origin);return u.hostname==='gogoanimes.cv'&&/^\/category\/[a-z0-9-]+\/?$/i.test(u.pathname)?[u.href]:[]}catch(_){return []}}))];if(cats.length!==1)return [];
 let links=[];
 for(let page=1;page<=3;page++){
  let cat=await doc(cats[0]+(page===1?'':'page/'+page+'/'));
  links.push(...[...cat.querySelectorAll('a[href]')].filter(a=>matchTitle(a.textContent)===matchTitle(title+' Episode '+Number(number))).flatMap(a=>{try{let u=new URL(a.getAttribute('href'),origin);return u.hostname==='gogoanimes.cv'&&/^\/[a-z0-9-]+-episode-\d+\/?$/i.test(u.pathname)?[u.href]:[]}catch(_){return []}}));
  links=[...new Set(links)];if(links.length)break;
 }
 if(links.length!==1)return [];let ep=await doc(links[0]);if(matchTitle(ep.querySelector('h1')?.textContent)!==matchTitle(title+' Episode '+Number(number)))return [];
 let out=[];for(const a of ep.querySelectorAll('[data-video]')){
  let d=parse(a.getAttribute('data-video')||''),src=d.querySelector('iframe[src]')?.getAttribute('src');try{let u=new URL(src);let lang=u.searchParams.get('type');if(u.protocol==='https:'&&u.hostname==='gogoanime.com.by'&&u.pathname==='/streaming.php'&&/^\d{1,10}$/.test(u.searchParams.get('ep')||'')&&['sub','dub'].includes(lang)){let url=validUrl(u.href,'player');if(url)out.push({name:'Gogoanimes',url,lang,referer:'gogo-cv'})}}catch(_){}
 }
 return out;
}
failoverAdapters.gogo575=requestedGogo575;

// Anime Village: exact title + episode fallback to its explicitly supplied
// MegaPlay embed. Do not treat the source response as executable HTML.
async function requestedVillage578(title,number,expected={}){
 if(!validEpisodeNumber(number)||!title||title.length>200)return [];
 const origin='https://www.animevillage.org';
 let data=JSON.parse(await get(origin+'/api/search?search='+encodeURIComponent(title)));
 let media=data?.data?.Page?.media;if(!Array.isArray(media))return [];
 let shows=media.filter(x=>[x?.title?.romaji,x?.title?.english,x?.title?.native].some(t=>t&&matchTitle(t)===matchTitle(title))).filter(x=>/^[a-z0-9-]{1,160}$/.test(x.slug||''));
 const slugs=[...new Set(shows.map(x=>x.slug))];if(slugs.length!==1)return [];let slug=slugs[0],out=[];
 for(const lang of ['sub','dub']){
  try{
   let list=JSON.parse(await get(origin+'/api/episodes/'+encodeURIComponent(slug)+'?dub='+(lang==='dub')));
   if(expected.anilistId&&/^\d+$/.test(String(list.animeId||''))&&Number(list.animeId)!==Number(expected.anilistId))continue;
   if(!Array.isArray(list.episodes))continue;
   let found=list.episodes.filter(x=>Number(x.number)===Number(number)&&typeof x.id==='string');if(found.length!==1)continue;
   let m=found[0].id.match(/^([a-z0-9-]{1,160})\?ep=(\d{1,10})$/);if(!m||m[1]!==slug)continue;
   let stream=JSON.parse(await get(origin+'/api/stream/'+encodeURIComponent(slug)+'?category='+lang+'&server=hd-1&ep='+m[2]));
   let u=new URL(stream.embedUrl||'');
   if(u.protocol!=='https:'||u.hostname!=='megaplay.buzz'||u.username||u.password||u.port||u.search||u.hash||u.pathname!=='/stream/s-2/'+m[2]+'/'+lang)continue;
   out.push({name:'Anime Village',url:u.href,lang,referer:'village578'});
  }catch(e){if(isVerification(e))throw e;}
 }
 return out;
}
failoverAdapters.village578=requestedVillage578;

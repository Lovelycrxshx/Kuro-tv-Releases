'use strict';
// One discovery surface; Library 13 is search-only and experimental.
// Results are progressive and bounded; every source keeps its own pagination.
const unifiedCodes=['ms','dk','nine','zoro','ani','salt','flix','zenkai','wixi','aw','miruro','kitsune','paradise'];
const unifiedQueue=[],unifiedVerificationBlocked=new Set();let unifiedActive=0,unifiedQueueSeq=0;
function unifiedSchedule(run,alive,priority=1){
 return new Promise((resolve,reject)=>{unifiedQueue.push({run,alive,priority,seq:unifiedQueueSeq++,resolve,reject});unifiedDrain()});
}
function unifiedDrain(){
 while(unifiedActive<2&&unifiedQueue.length){
  unifiedQueue.sort((a,b)=>b.priority-a.priority||a.seq-b.seq);
  const job=unifiedQueue.shift();if(!job.alive()){job.reject(Error('Cancelled'));continue}
  unifiedActive++;Promise.resolve().then(()=>{if(!job.alive())throw Error('Cancelled');return job.run()}).then(job.resolve,job.reject).finally(()=>{unifiedActive--;unifiedDrain()});
 }
}
function unifiedSpec(spec,code){return {...spec,source:code}}
function makeUnifiedPager(spec){
 const streams=unifiedCodes.flatMap(code=>catalogUrl(unifiedSpec(spec,code),1)?[{code,page:1,done:false,error:unifiedVerificationBlocked.has(code)?'Verification required':'',blocked:unifiedVerificationBlocked.has(code)}]:[]);
 return {spec,unified:true,items:[],groups:new Map(),seen:new Set(),streams,page:1,done:streams.length===0,loading:false,error:'',autoPaused:false,generation:0,checked:0,total:0};
}
function unifiedFormat(x){
 const m=String(x?.meta||'').match(/(?:^|[\s·|])(?:tv|movie|ova|ona|special)(?=$|[\s·|])/i);
 return m?m[0].trim().toLowerCase():'';
}
function unifiedCompatible(a,b){
 for(const name of ['anilistId','malId']){let x=Number(a?.[name])||0,y=Number(b?.[name])||0;if(x>0&&y>0&&x!==y)return false}
 const x=unifiedFormat(a),y=unifiedFormat(b);return !(x&&y&&x!==y);
}
function unifiedCopy(x){
 const out={...x};delete out.unifiedVariants;delete out.unified;delete out.unifiedRanked;delete out.imageTried;return out;
}
function compactItem(x){return unifiedCopy(x)}
function unifiedAdd(st,item){
 if(!item||!unifiedCodes.includes(item.source)||typeof item.title!=='string'||!item.title.trim()||!validUrl(item.url))return false;
 const title=matchTitle(item.title);if(!title)return false;
 const groups=st.groups.get(title)||[];
 const possible=groups.filter(g=>g.unifiedVariants.every(v=>unifiedCompatible(v,item))&&
  !g.unifiedVariants.some(v=>v.source===item.source&&v.url!==item.url));
 let group=possible.length===1?possible[0]:null;
 if(group){
  if(!group.unifiedVariants.some(v=>v.source===item.source&&v.url===item.url))group.unifiedVariants.push(unifiedCopy(item));
  if(!group.img&&item.img)group.img=item.img;
  if(popularityAvailable(item.source,'all'))group.unifiedRanked=true;
  return false;
 }
 group={...unifiedCopy(item),unified:true,unifiedVariants:[unifiedCopy(item)],unifiedRanked:popularityAvailable(item.source,'all')};
 groups.push(group);st.groups.set(title,groups);st.items.push(group);return true;
}
function unifiedKnownIdentity(a,b){
 if(!unifiedCompatible(a,b)||matchTitle(a?.title)!==matchTitle(b?.title))return false;
 return ['anilistId','malId'].some(k=>Number(a?.[k])>0&&Number(a[k])===Number(b?.[k]));
}
function unifiedPreferred(item){
 if(!item?.unified)return item;
 let entries=[];for(const key of ['kuro-library','kuro-recent']){const arr=stored(key);if(Array.isArray(arr))entries.push(...arr)}
 try{entries.push(...categoryEntries().map(x=>x.item),...historyEntries().map(x=>x.item))}catch(_){}
 const seen=new Set();entries=entries.filter(x=>x&&unifiedCodes.includes(x.source)&&validUrl(x.url)&&matchTitle(x.title)===matchTitle(item.title)&&item.unifiedVariants.every(v=>unifiedCompatible(x,v))).filter(x=>{let k=x.source+'|'+x.url;if(seen.has(k))return false;seen.add(k);return true});
 let preferred=entries.find(x=>item.unifiedVariants.some(v=>v.source===x.source&&v.url===x.url));
 if(!preferred&&entries.length===1&&item.unifiedVariants.some(v=>unifiedKnownIdentity(v,entries[0])))preferred=entries[0];
 // Watched/last-episode records from older versions can exist even without a bookmark.
 if(!preferred){const watched=watchedData(),last=lastEpisodes();preferred=item.unifiedVariants.find(v=>watched[v.source+'|'+v.url]||last[v.source+'|'+v.url])}
 if(!preferred)return item;
 const variants=[unifiedCopy(preferred),...item.unifiedVariants.filter(v=>v.source!==preferred.source||v.url!==preferred.url)];
 return {...unifiedCopy(preferred),unified:true,unifiedVariants:variants,unifiedRanked:item.unifiedRanked};
}
function unifiedProblem(error){return /HTTP\s*(?:403|429)\b|requested human verification|verification required/i.test(String(error?.message||error||''));}
function unifiedPagerStatus(p){
 if(activePager!==p||p.disposed)return;
 const st=p.state,box=p.status;if(p.onStatus)p.onStatus(st,p);
 if(st.loading){box.innerHTML=`<span class="pager-loading"><span class="pager-dot" aria-hidden="true"></span> Checking sources ${st.checked}/${st.total}…</span>`;return}
 const failed=st.streams.filter(s=>s.error),blocked=failed.filter(s=>s.blocked),more=st.streams.some(s=>!s.done&&!s.error);
 let message='';
 if(failed.length)message=`${failed.length} ${failed.length===1?'source is':'sources are'} unavailable${blocked.length?'; some may need verification':''}. Results may be incomplete.`;
 else if(st.done)message=st.items.length?'You’ve reached the end of the available results.':'No titles found in the available sources.';
 else if(st.autoPaused)message='No new titles on the last pages. You can try the next pages.';
 box.innerHTML=(message?`<p class="pager-message">${escapeHTML(message)}</p>`:'')+(more?'<button type="button" class="pager-button" data-unified-more>Load more <span aria-hidden="true">↓</span></button>':'')+(failed.length?'<button type="button" class="pager-button unified-retry" data-unified-retry>Retry unavailable sources</button>':'')+(blocked.some(s=>s.code==='miruro')&&window.KuroNative?.verifyLibrary11?'<button type="button" class="pager-button" data-miruro-verify>Verify Library 11</button>':'');
 const next=box.querySelector('[data-unified-more]');if(next)next.onclick=()=>{st.autoPaused=false;unifiedLoadMore(p,true,false)};
 const retry=box.querySelector('[data-unified-retry]');if(retry)retry.onclick=()=>unifiedLoadMore(p,true,true);
 const verify=box.querySelector('[data-miruro-verify]');if(verify)verify.onclick=()=>KuroNative.verifyLibrary11();
}
async function unifiedLoadMore(p,manual=false,retry=false){
 const st=p.state;if(activePager!==p||p.disposed||st.loading||(st.autoPaused&&!manual))return;
 let targets=st.streams.filter(s=>retry?!!s.error:!s.done&&!s.error);
 if(!targets.length){st.done=st.streams.every(s=>s.done||s.error);unifiedPagerStatus(p);return}
 if(retry)for(const s of targets){s.error='';s.blocked=false;unifiedVerificationBlocked.delete(s.code)}
 st.loading=true;st.done=false;st.checked=0;st.total=targets.length;st.error='';const generation=++st.generation;let cursor=0,added=0;
 const alive=()=>activePager===p&&!p.disposed&&st.generation===generation;
 unifiedPagerStatus(p);
 async function worker(){
  while(alive()){
   const s=targets[cursor++];if(!s)return;
   if(unifiedVerificationBlocked.has(s.code)){s.error='Verification required';s.blocked=true;st.checked++;unifiedPagerStatus(p);continue}
   try{
    const result=await unifiedSchedule(()=>{if(unifiedVerificationBlocked.has(s.code))throw Error('The library requested human verification.');return fetchCatalogPage(unifiedSpec(st.spec,s.code),s.page)},alive,st.spec.mode==='search'?3:2);
    if(!alive())return;
    if(st.spec.mode==='all'&&s.page===1&&!result.items.length&&!result.hasNext)throw Error('The source returned no readable catalogue.');
    for(const item of result.items)if(unifiedAdd(st,item))added++;
    s.page++;s.done=!result.hasNext;
    renderPagerCards(p,true);if(p.onData&&st.items.length)p.onData(st.items[0]);
   }catch(e){if(!alive())return;s.error=String(e?.message||'Source unavailable');s.blocked=unifiedProblem(e);if(s.blocked)unifiedVerificationBlocked.add(s.code)}
   if(alive()){st.checked++;unifiedPagerStatus(p)}
  }
 }
 await Promise.all([worker(),worker()]);if(!alive())return;
 st.loading=false;st.page++;st.done=st.streams.every(s=>s.done||s.error);st.autoPaused=added===0&&!st.done;
 unifiedPagerStatus(p);
 if(p.observer&&!st.done&&!st.autoPaused){p.observer.unobserve(p.sentinel);p.observer.observe(p.sentinel)}
}
function unifiedCard(item,index,isNew){
 return `<button class="card" type="button" data-card="${index}"><div class="poster">${item.img?`<img src="${escapeHTML(item.img)}" loading="lazy" decoding="async" alt="">`:'<span class="poster-fallback" aria-hidden="true">✦</span>'}${isNew?'<span class="poster-new581">NEW</span>':''}${badgeMarkup(item.counts)}</div><strong>${escapeHTML(item.title)}</strong><small>${escapeHTML(item.meta||'Anime')}</small></button>`;
}
function unifiedCards(items,isNew=false){return items.length?`<div class="grid">${items.map((x,i)=>unifiedCard(x,i,isNew)).join('')}</div>`:'<div class="empty">No results found.</div>'}
// 5.81: the unified home shares the swipeable hero deck (page dots, one pill per slide).
function unifiedSpotlight(items){
 const root=$('#spotlight');if(!root||!items)return;
 const list=(Array.isArray(items)?items:[items]).filter(x=>x&&x.url&&typeof x.title==='string');
 if(!list.length)return;
 renderSpotlight(list);
}
function unifiedHomeData(){
 const p=activePager,root=$('#home-popular');if(!p||!root||!p.state.unified)return;
 const ranked=p.state.items.filter(x=>x.unifiedRanked).slice(0,8);if(ranked.length){
  const key=ranked.map(x=>x.source+'|'+x.url).join('|');if(root.dataset.shelfKey!==key){root.dataset.shelfKey=key;root.innerHTML=unifiedCards(ranked);bindCards(ranked,root)}
  unifiedSpotlight(ranked.slice(0,5));p.excludeUrls=new Set(ranked.map(x=>x.url));renderPagerCards(p,true);
 }else if(p.state.items.length)unifiedSpotlight(p.state.items.slice(0,5));
}
function unifiedHomeStatus(st){
 const root=$('#home-popular');if(!root||root.querySelector('[data-card]'))return;
 if(st.loading)root.innerHTML='<div class="rail-message"><span class="pager-dot"></span> Loading popular titles…</div>';
 else if(st.done)root.innerHTML='<div class="rail-message">Popular lists are unavailable right now. Explore available titles below.</div>';
}
const unifiedShelfCache=new Map();
function unifiedNewShelf(marker){
 const root=$('#home-new');if(!root)return;
 const alive=()=>marker===window.renderSeq&&view==='home'&&root.isConnected;
 const cache=unifiedShelfCache.get('new');if(cache&&cache.expires>Date.now()){root.innerHTML=unifiedCards(cache.items,true);bindCards(cache.items,root);return}
 const st=makeUnifiedPager({source:'unified',mode:'new'}),streams=st.streams.slice();let cursor=0,checked=0,failed=0;
 root.innerHTML='<div class="rail-message"><span class="pager-dot"></span> Loading new additions…</div>';
 const paint=()=>{if(!alive())return;const items=st.items.slice(0,20);if(items.length){root.innerHTML=unifiedCards(items,true);bindCards(items,root)}else if(checked===streams.length)root.innerHTML='<div class="rail-message">New additions are unavailable right now.</div>';if(checked===streams.length&&failed){root.insertAdjacentHTML('beforeend','<div class="rail-message unified-shelf-note">Some sources could not be checked. <button type="button" data-new-retry>Retry</button></div>');root.querySelector('[data-new-retry]').onclick=()=>{for(const x of streams)unifiedVerificationBlocked.delete(x.code);unifiedShelfCache.delete('new');unifiedNewShelf(marker)}}};
 async function worker(){while(alive()){let s=streams[cursor++];if(!s)return;if(unifiedVerificationBlocked.has(s.code)){failed++;checked++;paint();continue}try{let result=await unifiedSchedule(()=>{if(unifiedVerificationBlocked.has(s.code))throw Error('The library requested human verification.');return fetchCatalogPage(unifiedSpec(st.spec,s.code),1)},alive,1);if(!alive())return;for(const x of result.items)unifiedAdd(st,x)}catch(e){if(!alive())return;failed++;if(unifiedProblem(e))unifiedVerificationBlocked.add(s.code)}checked++;paint()}}
 Promise.all([worker(),worker()]).then(()=>{if(alive()&&st.items.length&&!failed)unifiedShelfCache.set('new',{items:st.items.slice(0,20),expires:Date.now()+300000})});
}
function unifiedHome(){
 main.classList.add('home-surface576');detachPager();const marker=++window.renderSeq,recentAll=stored('kuro-recent').slice(0,20),recent=recentAll.filter(safeStoredItem);
 refreshStoredClassifications(recentAll,marker,()=>{if(view==='home')unifiedHome()});
 heroDeck581=[];heroIndex581=0;heroTouched581=0;clearInterval(heroTimer581);heroTimer581=0;
 main.innerHTML=`<div id="spotlight"><div class="hero"><div class="overline">YOUR NEXT STORY AWAITS</div><h1>Find your next obsession.</h1><p class="sub">Anime, all in one place.</p></div></div><div class="unified-banner"><span aria-hidden="true">✦</span><div><strong>One library</strong><small>Twelve connected sources · one place to explore</small></div></div><section class="home-rail" aria-labelledby="popular-heading"><div class="home-rail-heading"><div><div class="overline">FIRST UP · ONE LIBRARY</div><h2 id="popular-heading">Popular anime</h2></div><span class="home-rail-tag">SOURCE PICKS</span></div><p class="home-rail-caption">Popular titles from available source lists, not a combined ranking.</p><div id="home-popular" class="shelf" aria-live="polite"></div></section><section class="home-rail" aria-labelledby="new-heading"><div class="home-rail-heading"><div><div class="overline">JUST ADDED</div><h2 id="new-heading">New to the library</h2></div><span class="home-rail-tag">NEW</span></div><p class="home-rail-caption">Recently added by sources that publish a new-arrivals list; not necessarily new releases.</p><div id="home-new" class="shelf" aria-live="polite"></div></section><section class="home-rail" aria-labelledby="recent-heading"><div class="home-rail-heading"><div><div class="overline">PICK UP WHERE YOU LEFT OFF</div><h2 id="recent-heading">Recently watched</h2></div>${recent.length?'<button class="clear-recent" id="clear-recent">Clear all</button>':'<span class="home-rail-tag">ON THIS DEVICE</span>'}</div><div id="recent" class="shelf">${recent.length?unifiedCards(recent):'<div class="rail-message">Episodes you open will appear here.</div>'}</div></section><div class="heading home-more-heading"><div><div class="overline">KEEP EXPLORING</div><h2>Explore the library</h2><p class="home-rail-caption">A mix of available source catalogues.</p></div><span id="home-count">One library</span></div><div id="results"></div>`;
 // If the popularity lists are blocked, the hero still shows real titles from your history.
 if(recent.length){renderSpotlight(recent.slice(0,5).map(x=>x.item).filter(x=>x&&x.url))}
 if(recent.length){bindCards(recent,$('#recent'));hydrateStored('kuro-recent',recent,'recent',marker);let button=$('#clear-recent');const arm=()=>{button.textContent='Confirm clear';button.onclick=()=>{save('kuro-recent',[]);unifiedHome()};setTimeout(()=>{if(button.isConnected){button.textContent='Clear all';button.onclick=arm}},5000)};button.onclick=arm}
 const spec={source:'unified',mode:'all'};if(!sameSpec(homePagerState,spec))homePagerState=makePager(spec);
 mountPager(homePagerState,{renderCard:unifiedCard,onData:unifiedHomeData,onStatus:unifiedHomeStatus,count:$('#home-count')});
 unifiedNewShelf(marker);
}
function unifiedGenreTiles(filter=''){
 const term=String(filter).trim().toLocaleLowerCase(),all=supportedGenres('unified'),genres=all.filter(g=>(g.name+' '+g.note).toLocaleLowerCase().includes(term));
 if(!genres.length)return '<div class="genre-empty"><strong>No matching genres.</strong><span>Try another word.</span></div>';
 return `<div class="genre-grid">${genres.map(g=>`<button type="button" class="genre-tile" data-genre="${g.id}"><span class="genre-icon" aria-hidden="true">${g.icon}</span><span class="genre-copy"><strong>${g.name}</strong><small>${g.note}</small></span><span class="genre-arrow" aria-hidden="true">↗</span></button>`).join('')}</div>`;
}
function unifiedBrowseGenre(g){if(!supportedGenres('unified').some(x=>x.id===g))return;browseGenreId=g;browseQuery='';browseTab='genres';browsePagerState=null;browseSort='source';window.scrollTo(0,0);if(view==='simulcasts')nav('search');else unifiedSearchPage()}
function syncParadiseControls(){
 const status=document.getElementById('paradise-status'),toggle=document.getElementById('paradise-toggle'),retry=document.getElementById('paradise-retry');if(!status||!toggle||!retry)return;
 const enabled=paradiseEnabled(),blocked=paradiseBlocked();
 status.textContent=!enabled?'Library 13 · experimental search (off)':blocked?'Library 13 · access blocked. Check the site, then retry.':'Library 13 · experimental search; playback unverified';
 toggle.textContent=enabled?'Turn off':'Enable';toggle.setAttribute('aria-pressed',String(enabled));retry.hidden=!(enabled&&blocked);
}
function unifiedSearchPage(initial){
 detachPager();++window.renderSeq;
 if(typeof initial==='string'&&initial.trim()){browseQuery=initial.trim();browseTab='all';browseGenreId='';browsePagerState=null;browseSort='source'}
 const genre=discoveryGenres.find(g=>g.id===browseGenreId),gridOnly=browseTab==='genres'&&!genre;
 const mode=browseQuery?'search':browseTab==='music'?'music':genre?'genre':'all';
 const heading=browseQuery?'Results for “'+browseQuery+'”':genre?genre.name+' anime':browseTab==='music'?'Music anime':'All anime';
 const intro=mode==='search'?'Results from the available connected sources.':mode==='music'?'Anime from source music categories; not a standalone music player.':mode==='genre'?'Combined from sources that offer this category.':'A mix of source lists, not a global popularity ranking.';
 const genres=supportedGenres('unified'),genreArea=`<div class="discover-section genre-section"><div><div class="overline">FIND YOUR MOOD</div><h2>Explore by genre</h2><p class="sub">Choose a path through the collection.</p></div><span class="genre-count" id="genre-count">${genres.length} genres</span></div><label class="genre-search"><span aria-hidden="true">⌕</span><input id="genre-filter" type="search" autocomplete="off" aria-label="Find a genre" placeholder="Find a genre" value="${escapeHTML(genreFilter)}"></label><div id="genre-results">${unifiedGenreTiles(genreFilter)}</div>`;
 const sortButton=`<button type="button" class="sort-trigger" id="result-sort" aria-haspopup="dialog" aria-expanded="false"><svg aria-hidden="true" viewBox="0 0 24 24"><path d="M4 7h16M7 12h10M10 17h4"/></svg><span><small>Sort by</small><strong id="result-sort-label">${escapeHTML(currentSortLabel(mode))}</strong></span><b aria-hidden="true">⌄</b></button>`;
 main.innerHTML=`<div class="discover-head"><div><div class="overline">THE KURO CATALOG</div><h1>Browse anime</h1><p class="sub">One library. Available sources can change.</p></div><span class="discover-mark" aria-hidden="true">✦</span></div><div class="source-inline experimental-source"><span id="paradise-status" role="status"></span><span class="experimental-actions"><button type="button" id="paradise-toggle"></button><button type="button" id="paradise-retry" hidden>Retry</button></span></div><div class="open-sites"><span>Source sites · open separately</span><button type="button" data-open-site="anicult">AniCult ↗</button><button type="button" data-open-site="aniraku">Aniraku ↗</button><button type="button" data-open-site="justanime">JustAnime ↗</button><button type="button" data-open-site="paradise">Library 13 ↗</button></div><form class="search discover-search" id="discover-search"><input id="q" type="search" autocomplete="off" aria-label="Anime title" placeholder="Search all anime titles" value="${escapeHTML(browseQuery)}"><button id="go" class="btn primary" type="submit">Search</button></form><div class="discover-tabs" role="tablist" aria-label="Browse sections">${tabButton('all','All anime','✦')}${tabButton('airing','Simulcasts','◉')}${tabButton('genres','Genres','◇')}${tabButton('music','Music','♫')}</div><section id="browse-panel" role="tabpanel" aria-labelledby="discover-tab-${browseTab}">${gridOnly?genreArea:`<div class="discover-section"><div><div class="overline">ONE LIBRARY · EXPLORE</div><h2>${escapeHTML(heading)}</h2><p class="sub">${escapeHTML(intro)}</p></div>${sortButton}</div>${genre?'<button class="genre-back" id="genres-back" type="button">‹ All genres</button>':''}<div class="discover-list"><div id="filters581" class="chips581" role="group" aria-label="Filter loaded results"></div><div id="results"></div></div>`}</section>`;
 syncParadiseControls();$('#paradise-toggle').onclick=()=>{try{localStorage.setItem('kuro-paradise-enabled',paradiseEnabled()?'0':'1')}catch(_){placeholder('Source setting unavailable.');return}browsePagerState=null;unifiedSearchPage()};
 $('#paradise-retry').onclick=()=>{try{localStorage.removeItem('kuro-paradise-blocked')}catch(_){return}unifiedVerificationBlocked.delete('paradise');browsePagerState=null;unifiedSearchPage()};
 document.querySelectorAll('[data-open-site]').forEach(b=>b.onclick=()=>{let code=b.dataset.openSite;if(window.KuroNative?.openExternalSource)KuroNative.openExternalSource(code);else{const urls={anicult:'https://anicult.vercel.app/',aniraku:'https://www.aniraku.tech/',justanime:'https://justanime.to/',paradise:'https://www.animeparadise.moe/'};if(urls[code])window.open(urls[code],'_blank','noopener')}});
  $('#discover-search').onsubmit=e=>{e.preventDefault();doSearch($('#q').value)};
 document.querySelectorAll('[data-browse-tab]').forEach(b=>{b.onclick=()=>{browseTab=b.dataset.browseTab;browseGenreId='';browseQuery='';browsePagerState=null;browseSort='source';genreFilter='';window.scrollTo(0,0);if(browseTab==='airing'){browseTab='all';nav('simulcasts')}else unifiedSearchPage()};b.onkeydown=e=>{if(!['ArrowRight','ArrowLeft','Home','End'].includes(e.key))return;e.preventDefault();let tabs=[...document.querySelectorAll('[data-browse-tab]')],i=tabs.indexOf(b);i=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;let id=tabs[i].dataset.browseTab;tabs[i].click();document.querySelector('[data-browse-tab="'+id+'"]')?.focus()}});
 const bind=()=>document.querySelectorAll('[data-genre]').forEach(b=>b.onclick=()=>unifiedBrowseGenre(b.dataset.genre));bind();
 if(gridOnly){const input=$('#genre-filter');input.oninput=()=>{genreFilter=input.value;$('#genre-results').innerHTML=unifiedGenreTiles(genreFilter);const n=genres.filter(g=>(g.name+' '+g.note).toLocaleLowerCase().includes(genreFilter.trim().toLocaleLowerCase())).length;$('#genre-count').textContent=n+' '+(n===1?'genre':'genres');bind()};return}
 const back=$('#genres-back');if(back)back.onclick=()=>{browseGenreId='';browsePagerState=null;browseSort='source';window.scrollTo(0,0);unifiedSearchPage()};
 $('#result-sort').onclick=()=>openSortPicker(mode);
 const spec={source:'unified',mode};if(mode==='search')spec.query=browseQuery;if(mode==='genre')spec.genre=genre.id;if(mode==='music')spec.genre='music';
 if(!sameSpec(browsePagerState,spec))browsePagerState=makePager(spec);
 mountPager(browsePagerState,{renderCard:unifiedCard,sort:()=>browseSort});
 attachFilters581(browsePagerState);
}
// 5.81: filter chips over the results that have actually loaded. Facets are read
// from each title's own metadata, so a chip only appears when titles carry that data
// (no invented year, format or dub availability).
let chips581={format:'',year:''};
function facets581(item){
 const meta=String(item?.meta||'');
 const fmt=meta.match(/\b(TV|Movie|Movies|ONA|OVA|Special)\b/i);
 const year=meta.match(/\b(19|20)\d{2}\b/)||String(item?.title||'').match(/\((19|20)\d{2}\)/);
 return {format:fmt?fmt[1].toUpperCase().replace('MOVIES','MOVIE'):'',year:year?String(year[0]).replace(/[()]/g,''):''};
}
function chipMatch581(item){
 const f=facets581(item);
 if(chips581.format&&f.format!==chips581.format)return false;
 if(chips581.year&&f.year!==chips581.year)return false;
 return true;
}
function renderChips581(p){
 const root=$('#filters581');if(!root)return;
 const items=(p&&p.state&&p.state.items)||[];
 const formats=new Map(),years=new Map();
 for(const it of items){const f=facets581(it);if(f.format)formats.set(f.format,(formats.get(f.format)||0)+1);if(f.year)years.set(f.year,(years.get(f.year)||0)+1)}
 const fk=[...formats.keys()].sort((a,b)=>formats.get(b)-formats.get(a));
 const yk=[...years.keys()].sort((a,b)=>b.localeCompare(a)).slice(0,4);
 const active=!!(chips581.format||chips581.year);
 if(!fk.length&&!yk.length){
  root.innerHTML=`<p class="chips-note581">${items.length?'Filters appear when loaded titles report a format or year.':'Filters appear once results load.'}</p>`;
  return;
 }
 const shown=active?items.filter(chipMatch581).length:items.length;
 const chip=(kind,value,count,label)=>`<button type="button" class="chip small chips-chip581${chips581[kind]===value?' active':''}" data-chip-${kind}="${escapeHTML(value)}" aria-pressed="${chips581[kind]===value}">${escapeHTML(label||value)} <b>${count}</b></button>`;
 root.innerHTML=[
  fk.length?`<div class="chip-row581"><span class="chip-label581">Format</span>${fk.map(f=>chip('format',f,formats.get(f))).join('')}</div>`:'',
  yk.length?`<div class="chip-row581"><span class="chip-label581">Year</span>${yk.map(y=>chip('year',y,years.get(y))).join('')}</div>`:'',
  `<div class="chip-row581 chips-line581"><span class="chip-label581" role="status" aria-live="polite">${shown} of ${items.length} loaded</span>${active?'<button type="button" class="chip small chips-clear581" data-chip-clear="1">Clear filters</button>':''}</div>`
 ].join('');
 root.querySelectorAll('[data-chip-format]').forEach(b=>b.onclick=()=>{const v=b.dataset.chipFormat;chips581.format=chips581.format===v?'':v;renderPagerCards(p,true)});
 root.querySelectorAll('[data-chip-year]').forEach(b=>b.onclick=()=>{const v=b.dataset.chipYear;chips581.year=chips581.year===v?'':v;renderPagerCards(p,true)});
 const clear=root.querySelector('[data-chip-clear]');if(clear)clear.onclick=()=>{chips581={format:'',year:''};renderPagerCards(p,true)};
}
function attachFilters581(p){
 if(!p)return;
 p.itemFilter=item=>chipMatch581(item);
 p.afterRender=renderChips581;
 // The pager paints once before we attach, so re-apply any filter that is already on.
 if(chips581.format||chips581.year)renderPagerCards(p,true);
 renderChips581(p);
}
function unifiedAirRow(item,index){
 return `<button type="button" class="air-row" data-card="${index}" aria-label="${escapeHTML(item.title)}: view episodes"><span class="air-row-number">${String(index+1).padStart(2,'0')}</span><span class="air-poster poster">${item.img?`<img src="${escapeHTML(item.img)}" loading="lazy" decoding="async" alt="">`:'<span class="poster-fallback" aria-hidden="true">✦</span>'}</span><span class="air-row-info"><span class="air-row-kicker"><i></i> AIRING LIST</span><strong>${escapeHTML(item.title)}</strong><small>${escapeHTML(item.meta||'Anime')} · Source-reported</small><span class="air-badges">${airBadges(item.counts)}</span></span><span class="air-row-arrow" aria-hidden="true">↗</span></button>`;
}
function unifiedAirFeature(item){
 const root=$('#air-feature');if(!root||!item)return;const key=item.url+'|'+(item.img||'');if(root.dataset.key===key)return;root.dataset.key=key;
 root.innerHTML=`<article class="air-feature-card"><div class="air-feature-art">${item.img?`<img src="${escapeHTML(item.img)}" alt="">`:'<span class="air-art-fallback">✦</span>'}</div><div class="air-feature-shade"></div><div class="air-feature-copy"><span class="air-feature-label"><i></i> FEATURED FROM THE LIST</span><h2>${escapeHTML(item.title)}</h2><p>${escapeHTML(item.meta||'Anime')} · Source-reported</p><div class="air-feature-badges">${airBadges(item.counts)}</div><button type="button" id="air-feature-open">View episodes <span aria-hidden="true">↗</span></button></div><span class="air-feature-number" aria-hidden="true">01</span></article>`;
 $('#air-feature-open').onclick=()=>openShow(item);
}
function unifiedAirStatus(st){
 const root=$('#air-feature');if(!root||st.items.length)return;root.removeAttribute('data-key');
 const title=st.loading?'Finding something to watch':'No list to spotlight',message=st.loading?'Checking available airing lists…':'No readable titles were returned yet. Check the message below.';
 root.innerHTML=`<div class="air-feature-empty"><span class="air-empty-symbol">✦</span><div><strong>${title}</strong><small>${message}</small></div></div>`;
}
function unifiedSimulcasts(){
 ++window.renderSeq;
 main.innerHTML=`<section class="air-masthead" aria-labelledby="air-title"><div class="air-orbits" aria-hidden="true"><span></span><span></span><span></span><b>✳</b></div><div class="air-kicker"><span class="air-signal"><i></i><i></i><i></i></span> KURO / AIRING GUIDE</div><h1 id="air-title">Simulcasts<span>.</span></h1><p>Stories in motion.<br><b>Find your next episode.</b></p><div class="air-source-line"><div class="air-source-trigger unified-air-source"><span class="air-source-icon" aria-hidden="true">◈</span><span><small>SHOWING FROM</small><strong>One library</strong></span></div><span class="air-source-caption"><i></i> Combined source<br>airing lists</span></div></section><button type="button" class="btn seasonal-open573">Seasonal dashboard</button><button type="button" class="btn calendar-open573">Release calendar</button><div class="air-information"><span aria-hidden="true">i</span><p>Combined from sources that publish an airing list. Titles can be outdated or completed; this is not a live schedule.</p></div><section class="air-directory" aria-labelledby="air-spotlight-label"><div class="air-heading"><div><span class="air-section-kicker">THE AIRING EDIT</span><h2 id="air-spotlight-label">On your radar <span>✳</span></h2></div><span class="air-heading-number">FROM AVAILABLE LISTS</span></div><div id="air-feature" aria-live="polite"></div><div class="air-list-heading"><div><span class="air-section-kicker">KEEP EXPLORING</span><h2>More on the list</h2></div><span id="air-count">One library</span></div><div id="results"></div></section>`;
 document.querySelector('.seasonal-open573').onclick=()=>window.kuroSeason573?.();document.querySelector('.calendar-open573').onclick=()=>window.kuroCalendar573?.();
 const spec={source:'unified',mode:'airing'};if(!sameSpec(airPagerState,spec))airPagerState=makePager(spec);
 mountPager(airPagerState,{layout:'air',renderCard:unifiedAirRow,skip:1,onData:unifiedAirFeature,onStatus:unifiedAirStatus,count:$('#air-count')});
}
function unifiedSearchPopup(){
 if($('#search-popup')){closeSearchPopup();return}
 let box=document.createElement('section');box.id='search-popup';box.className='search-popup';box.setAttribute('aria-label','Search anime');box.innerHTML=`<div class="popup-top"><strong>Search anime</strong><button type="button" id="popup-close" aria-label="Close search">×</button></div><div class="popup-input"><input id="popup-query" type="search" autocomplete="off" maxlength="120" placeholder="Search all anime titles" aria-label="Anime title"><button id="popup-go" type="button">Search</button></div><div class="popup-label">One library · Suggestions</div><div id="popup-results" class="popup-results" aria-live="polite">Start typing a title.</div>`;document.querySelector('header').appendChild(box);$('#header-search').setAttribute('aria-expanded','true');let input=$('#popup-query');$('#popup-close').onclick=()=>{closeSearchPopup();$('#header-search').focus()};
 const showRecent=()=>{const result=$('#popup-results'),history=recentSearches();if(!history.length){result.textContent='Start typing a title.';return}result.innerHTML=`<div class="popup-label">Recent searches · saved on this device</div>${history.map((q,i)=>`<button type="button" class="popup-result" data-recent-search="${i}"><span>${escapeHTML(q)}</span><b>›</b></button>`).join('')}<button type="button" class="chip small" id="clear-search-history">Clear search history</button>`;result.querySelectorAll('[data-recent-search]').forEach(b=>b.onclick=()=>{input.value=history[Number(b.dataset.recentSearch)];rememberSearch(input.value);run()});result.querySelector('#clear-search-history').onclick=()=>{try{localStorage.removeItem(searchHistoryKey)}catch(_){}showRecent()}};
 const run=()=>{
  const query=input.value.trim(),token=++popupSequence,result=$('#popup-results');if(!query){showRecent();return}result.textContent='Searching…';
  const st=makeUnifiedPager({source:'unified',mode:'search',query}),streams=st.streams.slice();let cursor=0,finished=0,failed=0;
  const alive=()=>token===popupSequence&&box.isConnected;
  const render=()=>{if(!alive())return;let items=st.items.slice(0,8);result.innerHTML=items.length?items.map((x,i)=>`<button class="popup-result" data-suggestion="${i}">${x.img?`<img src="${escapeHTML(x.img)}" alt="">`:''}<span>${escapeHTML(x.title)}<small>${escapeHTML(x.meta||'Anime')}</small></span><b>›</b></button>`).join(''):(finished===streams.length?(failed===streams.length&&streams.length?'Search unavailable. Check your connection or try Browse again.':'No titles found.'):'Searching…');if(finished===streams.length&&failed&&failed<streams.length)result.insertAdjacentHTML('beforeend','<div class="popup-partial">Some sources were unavailable or need verification. Use Browse to retry.</div>');result.querySelectorAll('[data-suggestion]').forEach(b=>b.onclick=()=>{rememberSearch(query);let item=items[Number(b.dataset.suggestion)];selectSearchItem(item)})};
  async function worker(){while(alive()){let s=streams[cursor++];if(!s)return;if(unifiedVerificationBlocked.has(s.code)){failed++;finished++;render();continue}try{let data=await unifiedSchedule(()=>{if(unifiedVerificationBlocked.has(s.code))throw Error('The library requested human verification.');return fetchCatalogPage(unifiedSpec(st.spec,s.code),1)},alive,4);if(!alive())return;for(const x of data.items)unifiedAdd(st,x)}catch(e){if(!alive())return;failed++;if(unifiedProblem(e))unifiedVerificationBlocked.add(s.code)}finished++;render()}}
  Promise.all([worker(),worker()]);
 };
 input.oninput=()=>{popupSequence++;clearTimeout(popupTimer);if(!input.value.trim()){showRecent();return}popupTimer=setTimeout(run,450)};input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();clearTimeout(popupTimer);rememberSearch(input.value);run()}else if(e.key==='Escape'){closeSearchPopup();$('#header-search').focus()}};$('#popup-go').onclick=()=>{clearTimeout(popupTimer);rememberSearch(input.value);run()};showRecent();input.focus();
}

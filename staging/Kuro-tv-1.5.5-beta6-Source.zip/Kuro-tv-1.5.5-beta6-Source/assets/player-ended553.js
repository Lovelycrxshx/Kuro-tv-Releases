'use strict';
(()=>{
 if(window.__kuroEnded553)return;
 window.__kuroEnded553=true;
 let sent154=false,lastCheck154=0;
 function checkVideo154(v){
  if(sent154||!(v instanceof HTMLVideoElement))return;
  if(!Number.isFinite(v.duration)||v.duration<180)return;
  if(v.ended||v.currentTime>=v.duration*0.85){
   sent154=true;
   try{window.KuroFinished553?.postMessage('ended')}catch(_){}
  }
 }
 document.addEventListener('ended',e=>checkVideo154(e.target),true);
 document.addEventListener('timeupdate',e=>{
  const now=Date.now();
  if(now-lastCheck154<2000)return;
  lastCheck154=now;
  checkVideo154(e.target);
 },true);
})();

CURRENT RELEASE: Kuro.tv 5.70. Read README-5.70.txt first; all earlier release notes below are historical and may be superseded.

KURO.TV 5.64: See README-5.64.txt for current Discord presence setup, dual-account limitations, privacy and build instructions. All earlier sections below are historical.

KURO.TV 5.52: See README-5.52.txt for the current visual update and README-5.51.txt for local-only account details. Earlier sections below are historical and may describe removed services.

KURO.TV 5.41 — INSTALL AND CHANGES

INSTALL
Android 8.0 or newer. Open Kuro-tv-5.41.apk and install it as an update over your existing Kuro.tv. Do NOT uninstall the existing app or clear its data. The package name and signing certificate match the 5.40 build. Android may ask you to allow installation from the app you used to open the APK. This compatibility is verified from the APK identity and signature, not by an actual on-phone install.

NEWS AND PHONE ALERTS
- Replaced the broken official video-feed addresses with working official Aniplex Japan, KADOKAWA anime-related press, and TOHO animation Store blog sources; added Anime Trending and MyAnimeList alongside Crunchyroll and Anime Corner. Official updates and videos are labelled separately. Japanese official posts remain in Japanese. The TOHO Store feed may include merchandise; KADOKAWA filtering is best effort. These sources cannot guarantee every anime announcement.
- With phone alerts enabled, Kuro checks on app startup/resume (with a short throttle) and schedules periodic network checks, normally about hourly. Android may delay or stop work because of power restrictions, force-stop, lost connectivity or notification settings. Allow notifications in Android and check that Kuro's notification channel is enabled. The first successful check of each newly added source establishes a baseline, rather than notifying you about old posts. Newer items may produce an Android alert. Tap it to open News; where the existing player is alive, the overlay is designed to retain it.
- News can always be opened and refreshed manually when alerts are off. Cached articles remain visible if a feed fails. If a publisher returns 403 or 429, automatic checks for that source stop until you explicitly tap Refresh; no verification is bypassed. Sites and feeds can change or be unavailable again.

PLAYER AD AND POPUP PROTECTION
- Player WebViews now block a bundled set of known ad/tracker hosts and common popup networks, refuse new popup windows, and hide some explicitly marked ad containers or Ad-labelled message overlays. The list is used only inside the player; it does not change device-wide DNS. A MIT-licensed third-party hosts snapshot and its attribution are included in the app. Media paths, the current/known player origins and human-verification hosts have exceptions to reduce playback breakage.
- This is best effort: first-party or newly changing ads may still appear, and blocking can occasionally interfere with a source. It is not proven to remove the exact real popup in the supplied screenshot. It never solves or bypasses verification. If a source fails, try another available server; please report the show, episode and server if it still fails.

ADVANCED AND AI
The partial Advanced panel, live classic filter adjustments and optional, free on-device Anime4K-derived AI detail enhancement remain. AI stays off by default, needs compatible accessible video/WebGL2, and may be unavailable for protected, cross-origin or fullscreen video. GPU speed, battery use and picture improvement on your phone are not verified; the original video is the fallback.

TESTING AND LIMITS
The actual Java feed fetcher reached all seven sources in one host-side run with no failures and returned 150 cached items; publisher availability can change. Parser, cached/offline, permission, migration and job/notification behavior were tested with a fake Android/network harness. 21 browser/JavaScript suites, eight shell/Java suites, two Python suites, JavaScript parse checks and 38 Robolectric tests passed. One unrelated legacy unified-library browser test timed out once in an earlier run, then passed on an individual rerun and in the complete rerun. The ad overlay was tested with synthetic webpage/frame fixtures, not the actual source. No physical phone install, background delivery, real player playback, visual quality, rotation/touch or GPU/battery performance was tested. Android scheduling and every blocked ad cannot be guaranteed.

APK
Package: app.lovelycrxshx.kuro; version 5.41 (code 41)
APK SHA-256: a6b490684eb4e8ac6476d482c183087a90ec8524161805c7c1e74a29b00d0f20
Signing certificate SHA-256: 1d37c3ca28ed80cc484601a7a7907d5c43970a5d57d51aa4e91475a60703e93e


=== 5.40 HISTORICAL NOTES (SUPERSEDED BY 5.41 ABOVE) ===

KURO.TV 5.40 — HISTORICAL NOTES

ADVANCED OVERLAY
On the Watch page, Player options is now called Advanced. It opens a partial,
non-dimming panel over the existing page: at the bottom in portrait and at the
right in landscape. The panel scrolls and keeps its position when selecting a
preset. The playing WebView is not reloaded when opening, closing or changing
these options. Taps outside the panel can reach the underlying player/window;
Back or X closes the panel. If Watch search or News opens, Advanced closes first
and the current player is retained while those overlays are active. Layout,
flags, preferences, Back, and rotation are tested with simulated native views;
actual Android window/touch behavior and uninterrupted playback on a phone have
not been verified. Custom fullscreen players still pause enhancement while their
fullscreen view is showing. The original video/source itself is not changed.

EXPERIMENTAL OPTIONAL ON-DEVICE AI
Watch > Advanced > Video enhancement > AI detail (experimental). AI is OFF by
default. Switching it on also enables the parent video-enhancement setting.
AI strength is adjustable; 0% pauses inference. Existing classic filters,
presets, volume boost and saved options remain available. Settings are saved
locally. No AI server, signup, model download or cloud inference is needed.

The optional GPU inference uses adapted pretrained small Anime4K CNN shader
weights, four convolution stages and depth-to-space from the MIT-licensed
Anime4K_Upscale_CNN_x2_S.glsl (bloc97), commit
7684e9586f8dcc738af08a1cdceb024cc184f426. Kuro's WebGL2 integration limits
neural input to at most 480x270 and blends the learned detail residual with the
original-size frame. It is a modified detail enhancement, not the full Anime4K
suite, guaranteed native 4K output, or a promise of recovered source detail.
Copyright, full MIT license and original shader are in the source ZIP, and the
license and attribution are in APK assets/THIRD_PARTY_ANIME4K_LICENSE.txt and
assets/THIRD_PARTY_NOTICES.txt.

AI requires an accessible direct video, WebGL2, floating-point render targets
and a sufficiently capable GPU. No restricted frame, DRM, origin policy or
human verification is bypassed. Cross-origin, nested/third-party, protected,
custom fullscreen and other unsupported videos may not work; the original
video remains the fallback. Inference is limited to one queued frame. GPU
failures and sustained slowness trigger a fallback to the ordinary filter;
the Advanced header indicates AI unavailable/paused. Toggle AI off and on to
retry. The fallback is best effort and cannot guarantee zero stutter. Turning
AI off or setting strength to 0 releases its resources. AI can increase GPU,
battery and heat usage. Software-rendered browser tests do not demonstrate
real-time performance, visual quality or support on any particular phone.

TESTING / INSTALLATION
36 Robolectric native tests, 20 JavaScript/browser suites, six shell/Java suites,
two Python asset suites and JavaScript parse checks passed. The native tests
exercise Advanced layout flags, dimensions, landscape relayout, status, Back/X,
live preferences, retained player and notification/search interactions. Browser
tests compare all CNN output values
on an 8x8 fixture to an independently computed CPU reference, verify changed
video pixels and 0% strength, test resolution caps and resource cleanup, and
simulate unsupported GPU/context loss, tainted frames and slow-GPU fallback
while playing or paused. The shipped local HLS page is tested with synthetic
VP9/Opus media, not real streams. Physical Android hardware, real streams,
codecs, source access and AI speed/quality have not been verified. See the
historical notes below for source, news, autoplay and recovery limitations.
Android 8.0+; install over your prior Kuro.tv without uninstalling or clearing
data. Package ID and signing certificate are retained.

=== 5.39 HISTORICAL NOTES (SUPERSEDED BY 5.40 ABOVE) ===

KURO.TV 5.39 — HISTORICAL NOTES

NEWS / WATCH OVERLAY
The Watch bell and Android news notification still request the existing local
news overlay without intentionally navigating Home or destroying the player.
New in 5.39: the native layer checks that the overlay was actually created
before showing the underlying UI over the video. If creation fails it restores
the same live player/fullscreen surface and asks you to retry, rather than
exposing the underlying page. Search receives the same safeguard. Token checks
ignore late overlay callbacks. Tests simulate warm/cold notification intents,
Watch bell, overlay failure, Android Back and fullscreen. Actual notification
routing and playback on a physical Android phone remain untested. Android may
pause an app in the background. If Android kills Kuro, no code can preserve
that live player; the existing 5.38 metadata-only checkpoint can restore the
page under News and offer an exact-episode reload, but not playback position.

EXPERIMENTAL LIBRARY 13 (OFF BY DEFAULT)
Library 13 is an independently written, search-only connector for AnimeParadise,
plus a user-initiated separate-site link in Browse. It is experimental, not a
verified working source. An earlier ordinary search and episode-list request
succeeded and the official watch page returned a valid HLS master, but later
API requests returned HTTP 403. No further automated requests to that API were
made. No video frame, subtitles or audio were verified on Android or Chromium.
The connector is OFF by default. Browse > Enable turns it on; if the API returns
403, 429 or human verification, that block is remembered across app restarts
and no automatic API retry occurs. Open the site yourself; retry only after any
verification is resolved, using the explicit Retry button. No user-agent
rotation, proxy, alternate mirror, CAPTCHA solving or access bypass is used.
Turning it off prevents new API requests. This source may remain inaccessible.

Search accepts only the first page (up to 20 entries), and only titles with a
usable AniList image-ID hint are considered. The hint itself is untrusted;
AniList must confirm ID, a matching title, release year and a non-adult flag.
Unknown or mismatched classifications are hidden. Episode entries must report
the same source title ID, a valid UUID and one unambiguous number; the player
URL is constructed as the official website's exact watch URL. This does not
prove the source labels or numbers episodes correctly. The SUB label is
source-reported; no English dub claim is made. Library 13 uses the site's
third-party webpage inside Watch, not a verified standalone media decoder.
Some website controls, nested players, fullscreen, effects and autoplay may
not work. Third-party websites and their content, privacy practices and access
rights are independent of Kuro. The site's open-source status is unverified.

The API shape was researched from https://github.com/hexxt-git/anime-sdk at
commit 72d734f1f9bc6d59183ead2fcb0f172ad6018cdf. Its package metadata declares
MIT, but no LICENSE file was found in that repository; no SDK code is bundled
or copied. Kuro's connector is an independent implementation. Existing
Libraries 1–12 and saved data are retained. Hayase remains a separate optional
app/title-only handoff; its playback, extensions and episodes are NOT integrated
or tested on the phone. See the historical 5.38 notes below for its limitations.

TESTING
31 Robolectric tests, 19 browser/JavaScript fixture suites, six shell/Java
suites, two Python asset suites, and JavaScript parse checks passed. They use
simulated sources, notification intents, WebViews and media; no physical Android
or real source playback/audio/subtitles were verified. Source availability,
correct episode mapping, English/Japanese audio, full news coverage, background
jobs and smooth, uninterrupted playback cannot be guaranteed. Android 8.0+;
install over the existing Kuro.tv without uninstalling or clearing data.

=== 5.38 HISTORICAL NOTES (SUPERSEDED BY 5.39 ABOVE) ===

KURO.TV 5.38 — HISTORICAL NOTES

NOTIFICATIONS AND PAGE RECOVERY
Search and notifications are still overlays: when the Activity and player are
alive, they retain the existing page, DOM and player. The Android notification
intent now brings the existing task forward and prefers the existing top
Activity. Watch overlays leave the existing fullscreen surface in place in the
host lifecycle tests. Back closes the overlay before leaving fullscreen.

If Android has killed/recreated Kuro, the original video cannot remain alive.
Kuro now saves a bounded, local checkpoint of the last page, search/list state,
scroll position, selected title and episode. It stores no playable stream URL,
headers or cookies. On a fresh Android notification launch, it restores that
page under the notification overlay. A killed Watch player becomes a recovery
screen with a Reload episode button; this re-fetches the title and only opens
an exact, unambiguous episode number. Previous video position is not tracked and
may be lost. A missing/invalid checkpoint opens the news overlay on Home.
Adult classification is rechecked where required and fails closed; if the
network is unavailable, a previously selected gated-source title may remain
hidden until it can be classified. WebView storage being cleared will remove
this checkpoint. Scroll may clamp when the restored page has less content.

HAYASE AND OTHER LINKS
Browse > Open / get Hayase opens the installed official Hayase Android app
(package app.hayase), or the official download page if it is not installed.
When a source supplies an AniList ID, title details and the Watch page offer an
optional title-only hayase://anime/ID handoff. Hayase remains a separate app:
Kuro does not transfer an episode, stream, account, or playback position; pick
the episode there. Hayase is a bring-your-own-content client with extensions,
not a Kuro playback library. Its Android download was approximately 81 MB at
the time inspected and may need additional storage. The Hayase interface is
currently under Business Source License, not an OSI open-source licence. The
app handoff and deep link have not been tested on a physical phone.

JustAnime was added as an optional external website link in Browse. The site
homepage was reachable, but its API returned HTTP 403 to the development
request, so no further automated access or proxy bypass was attempted and it
is NOT counted as a working in-app library. AniCult and Aniraku are also
separate external sites and their playback is unverified. AniFlow's documented
API failed DNS; the tested AniKoto API deployment returned 402; no new numbered
in-app library is claimed. Existing Libraries 1–12 are retained unchanged.
No source or backend can promise every title, real Japanese/English audio,
reliability or zero buffering.

TESTING / INSTALLATION
Install over the prior Kuro.tv; never uninstall or clear data. The same package,
local storage origin and signing certificate are retained. 29 Robolectric
native tests plus browser/Java fixture and asset regressions passed. These use
simulated notifications, WebViews, media and sources; they do not establish
actual Android task behavior, Hayase handoff, live streaming, audio, codec,
rotation, fullscreen or background scheduling on a physical phone.

=== 5.37 HISTORICAL NOTES RETAINED BELOW (SUPERSEDED BY 5.38 ABOVE) ===

KURO.TV 5.37 — HISTORICAL NOTES

KEEP YOUR PLACE
Search and notifications on the Watch header now open temporary overlays on
top of the existing watch page. Dismissing the overlay or pressing Android
Back keeps the same player and underlying page. Tapping a search result is an
intentional transition to that title; the Kuro.tv logo is the Home shortcut.
An Android notification tap while a player is open uses the same news overlay.
The news button on other app pages also leaves that page and scroll in place.
The video is not intentionally destroyed when these overlays open; uninterrupted
playback through Android lifecycle changes still depends on the phone/player.

PLAYER OPTIONS
Watch > Player options opens an animated purple/black Options screen. Volume
boost is 100–300% for Kuro's compatible, accessible local direct HLS video
only; the native Web Audio graph cannot safely amplify unrelated embedded or
protected players. If it asks for a tap, tap the video. Amplification can
clip/distort. The Anime4K-style page offers a switch, presets, line effects,
5/9/13-sample performance tiers and functional tuning sliders. The WebGL2
filter is independently written and only runs when the video permits frame
access. It is inspired by Anime4K, NOT the official Anime4K shader suite and
NOT AI reconstruction; it cannot recover missing detail. It may consume more
GPU/battery and the 4K tier is capped by device/display limits. Third-party
iframes, protected/CORS-restricted media, some fullscreen surfaces and older
WebViews may be unavailable. The options status reports off, waiting, active,
paused or unavailable where possible. Enhancement pauses while an Android
custom fullscreen video surface is shown and resumes after leaving fullscreen.
System settings and actual WebView behavior may vary.

DISCOVERY — LIBRARY 12 (EXPERIMENTAL)
Kitsune (https://kitsunee.moe/) is included as Library 12 in combined discovery
and exact-ID/episode fallback. Its public catalogue and AniKoto episode JSON
were reachable during development. It reports AniList/MAL identity and
sub/dub labels; Kuro validates the catalogue IDs, episode IDs, reported audio,
and allowed embed URLs and avoids duplicating ambiguous language entries.
The 3.7MB One Piece sample is bounded and compacted by the native bridge.
Only supported MegaPlay embed links are used in-app; direct HLS URLs and
arbitrary headers are not forwarded. Playback, subtitles and actual language
were not successfully verified on a real phone: a valid embed is not proof that
a video plays. If no in-app server is returned for a Library 12 episode, an
optional link can open the source episode in a browser. On 403/429 Kuro stops automatic requests to the source;
retry is user initiated. Other sources may share providers and therefore do not
necessarily provide independent server coverage. All catalogue and source
availability can change, and exact matching cannot guarantee providers use the
same episode numbering. Original project: https://github.com/Dovakiin0/Kitsune
MIT licence: libs/kitsune-LICENSE.txt. This adapter is independently written.

Hayase is a separate bring-your-own-content application, not a drop-in stream
catalogue. Its official Android download opens outside Kuro. AniCult and Aniraku
are also optional external sites, not integrated Kuro libraries. We checked
AniCult's public embed wrappers, but browser playback failed/was blocked;
Aniraku's dub endpoint returned HTTP 403, so automated requests were stopped.
No challenge solving, rotating mirrors or user-supplied server is required.

NEWS AND EXISTING DATA
Feed coverage remains limited to the selected official channels and labelled
outlets, not every anime. Scheduling depends on Android; force-stop stops jobs.
Same package, local app origin and signing identity; existing bookmarks, watch
history, controls, saved settings and libraries are intended to remain intact.
Install directly over the previous Kuro.tv build; never uninstall or clear it.

TESTING AND LIMITATIONS
Synthetic local Chromium tests cover actual WebGL pixel changes, audio graph
and lifecycle behavior, local HLS loading and CORS restrictions. Robolectric
host tests cover native player identity, overlay tokens, notification intents,
options preferences, selectable presets/sliders and asset routing. Source and
UI fixtures cover fail-closed adult classification, exact-match cases, bounded
responses, duplicate episodes, pagination and 403/429 stop. These are not a
physical Android phone, real streaming, fullscreen, rotation, codec, battery or
background-job test. Playback and smoothness cannot be guaranteed. The options
previews are simulated native renders, not photos of a running device.

=== 5.36 HISTORICAL NOTES RETAINED BELOW (SUPERSEDED BY 5.37 ABOVE) ===

KURO.TV 5.36 — HISTORICAL NOTES

WATCH HEADER
The native watch page now uses the same Kuro.tv logo, search, notification and
Log in header style as the home page instead of the old Back / KURO ANIME.TV
bar. Tapping the logo closes the player and opens Home. Android's Back button
still closes the watch page as before. Search and notifications close the video
and open the corresponding existing app UI; the current Log in button still
only explains that login will be added later, and does not interrupt playback.
The regular in-app logo is also a Home button. Existing episode history,
controls, preferences, libraries and source-matching behavior are retained.

NEWS / NOTIFICATION STATUS
The status line now says which feeds could not update, that available or saved
items are shown, when the last check happened and that Refresh can try again.
The named sources are feed failures, not automatically a phone-notification
permission error. Phone alerts and their permission status remain in the
separate Phone alerts control. News checks are subject to connection, the
source's availability and Android background scheduling; force-stopping the
app stops its background jobs.

During development the official YouTube feeds for TOHO animation, Aniplex USA
and KADOKAWA Anime returned HTTP 404 or 500 on the test connection. The channel
IDs match their official public listings, but this does not establish why the
user's phone could not refresh them or when those feeds will recover. No
unverified feed substitute, server, bypass or claim of a fix is included.
Successful sources can still supply new items; previously saved entries remain
available. Refresh or later periodic checks may succeed if the source recovers.
News remains limited to its selected sources, not every anime announcement.

TESTING
Host Robolectric tests exercised the real native header and watch-page builder,
logo and action callbacks, touch targets, narrow/landscape-width layouts, large
text, Android Back, controls and saved state. Browser fixtures exercised the
matching Home/search/notification navigation, clearer news status, caching and
existing 11-source discovery. The header image is a simulated render, not a
phone screenshot. No real Android phone, streaming playback, battery, network
or rotation test was performed. Live Miruro catalog/playback remains unverified.
Install directly over the previously signed Kuro.tv build; do not uninstall it
or clear data. Android 8 or later and the same update signing key are used.

=== 5.35 HISTORICAL NOTES RETAINED BELOW (SUPERSEDED BY 5.36 ABOVE) ===

KURO.TV 5.35 — HISTORICAL NOTES

SMALLER PLAYBACK CONTROLS
The watch page retains Next episode, Autoplay video, Auto next and Skip
intro/outro, but the tiles now have a compact, server-button-like visible
height. Their hit targets remain at least 48dp, and labels reflow on narrow
screens and at large system text. The previous preference keys, defaults,
scrolling layout, disabled last-episode handling and listeners are preserved.
Autoplay may need a tap; auto-next and skip depend on third-party player
support. This is not a guarantee that every embed exposes those controls.

LIBRARY 11 — MIRURO (EXPERIMENTAL)
The combined catalogue and exact-match fallback now include
https://www.miruro.cx/ as Library 11. Search and catalog routing, cursor
pagination, bounded catalog decoding, episodes, source-reported sub/dub tracks,
and conservative title/identifier/episode checks were implemented against
publicly documented API shapes and synthetic fixtures, not the live .cx API.
Different formats or conflicting known AniList/MAL IDs are kept separate;
linking episode lists requires a shared ID. Fallback searches are bounded and
never intentionally select a different title, season or episode, but matching
cannot establish every site's episode-numbering conventions.

Only already-supported embed hosts with acceptable source referers are offered
inside Kuro. Unknown hosts, arbitrary headers, and direct HLS/MP4 streams from
Library 11 are not opened or proxied. Miruro may provide only unsupported
streams, in which case no in-app server may appear. When a Miruro-owned
episode cannot be played in-app, the user can open its source page in a browser.
This link uses the source's documented watch URL shape, which has not been
verified on the current .cx site. No new player host has been allowlisted.
The separate Simulcasts guide stays separate and does not invent a Miruro
airing list; the other libraries remain in place. Library 11 has no verified
adult-content gate; the existing Library 8/9 checks remain unchanged.

API shape reference: https://github.com/DefnoJae/Miruro-V2

During development, Miruro returned HTTP 403 and requested Cloudflare human
verification. The app stops automatic requests to Library 11 after 403/429 or a
verification page. If offered, use Verify Library 11, complete any check
personally, tap Done, then tap Retry unavailable sources. The verification
WebView shares that site's cookies with its own catalog requests. There is no
challenge bypass or automatic mirror rotation, and verification does not
guarantee access. Source availability and playback may change independently.

TESTING AND INSTALLATION
The fixture-only browser tests exercise the source adapter, blocking, retry,
identity checks, supported-embed filtering and original-site link. Host-side
Robolectric tests exercise native controls, state, hit targets, a manually
invoked verification window and link/host restrictions. Other existing browser
and host regression tests also passed. The included controls picture is a
simulated native render, not a photo or an Android-device test. Miruro's live
catalog, verification, subtitles and playback were not tested successfully;
no real Android phone, codec, fullscreen, frame, battery or player test was
performed. Report actual behavior after installing over the previous Kuro.tv
build; do not uninstall it or clear data. This version uses the same package,
local origin and update signing key; Android 8 or later is required.

=== 5.34 HISTORICAL NOTES RETAINED BELOW (SUPERSEDED BY 5.35 ABOVE) ===

KURO.TV 5.34 — HISTORICAL NOTES

PLAYBACK CONTROLS
The native watch page now has a purple-and-black Playback controls card with
separate Next episode, Autoplay video, Auto next and Skip intro/outro tiles.
The Next card shows the next episode number when the source supplies a simple
number. Toggles show ON/OFF; unavailable controls remain legible on the final
episode, and Auto next keeps its stored choice for future episodes. The whole
toggle tile can be tapped; each switch also has a 48dp touch target. Labels
reflow to one column on narrower screens or with larger system text. The card
and watch details now scroll together under the fixed video to leave the detail
area usable on smaller displays. Playback and existing settings are unchanged.

The original preference keys and defaults are retained: autoplay on, auto next
off and auto skip off for a fresh installation. The same package, local WebView
origin, versioned data and signing key make this an update-compatible build; no
uninstall is required. 5.33's combined ten-source catalogue, conservative
identity/episode matching and distinct Simulcasts guide are unchanged.

Autoplay is a request and can require a tap. Auto next works only if the player
reports a compatible ending; skip can only attempt accessible Skip controls in
supported players. Sources, frames and WebView versions differ. There is no new
18+ settings panel; prior Zenkai/Library 8 restrictions remain in force. Other
sources do not all have a complete 18+ gate.

TESTING
Host-side Robolectric tests exercised the actual watch-page builder with shadow
WebViews, saved preference wiring, navigation callback, last-episode state,
tap/slide switches and 48dp targets, and panel layouts at narrow widths and up
to 2x system text. Browser and host regression tests cover the combined
library, discovery, separate Simulcasts, dock, news, skip, player and assets.
A generated panel preview is a Robolectric render, not a phone screenshot.
No Android phone or emulator playback test was performed. Playback, fullscreen,
frame behavior and battery/network usage remain unverified on an Android device.

=== 5.33 HISTORICAL NOTES RETAINED BELOW (SUPERSEDED BY 5.34 ABOVE) ===

KURO.TV 5.33 — HISTORICAL NOTES

ONE LIBRARY FROM TEN CONNECTED SOURCES
Home, Browse, title search, header suggestions, genres, music anime and the
separate Simulcasts guide now use one combined catalogue. There is no visible
picker for ten separate libraries. Internally, the same ten independent
providers still exist; they are not physically merged or guaranteed online.
Browsing requests are progressive, with at most two combined discovery tasks
in flight at a time. Each provider keeps its own page cursor. Failed sources
produce an incomplete-results message and an explicit retry. A source that
requests verification is not automatically retried by discovery in this app
session; a user-initiated Retry can check again after manual verification.

Catalogue cards with the exact same normalized title may be visually grouped,
but conflicting known AniList/MAL IDs, known formats or same-provider URLs
are kept separate. This grouping is not proof that every provider's listing
is identical. Different spellings can still show more than once. Popular and
new shelves combine only available source lists and are not a global ranking.
Not every provider supplies each genre, airing or new-arrivals list. Airing
lists can be stale and are not a broadcast schedule.

EPISODES AND PLAYBACK
When a selected listing has an AniList or MAL identifier, the app can check
other sources in the foreground for additional episode numbers. An additional
listing is merged only if it has the exact normalized title, a shared matching
catalogue ID and no conflicting ID or format. Ambiguous repeated episode
numbers are skipped. If IDs are absent or inconsistent, the full episode lists
are not merged; episodes available only there might not appear. The check is
bounded to 60 seconds, stops scheduling on navigation, ignores late responses,
and stops on verification. An in-flight network request may still finish.
The per-episode best-effort playback fallback across the ten sources remains;
it checks episode numbers and available IDs but cannot guarantee source
metadata, playback, failure detection or seamless switching. Added episodes
retain their true source adapter. A source or player can be unavailable.

LOCAL DATA AND ADULT CONTENT
The same package, WebView origin and signing key are used, so an update can
retain existing bookmarks, categories, watched flags, recently watched and
history. Exact saved source URLs, or unambiguous matching catalogue IDs, are
preferred when opening a grouped title; ambiguous records are not silently
merged and remain in My Lists. No uninstall is required.
Zenkai/Library 8 and Library 9 still fail closed on adult or unknown
classifications; 18+ is off, with no new settings panel. The other sources do
not have a complete adult-content gate and may include 18+ titles.

PRIVACY AND TESTING
A combined search sends the query to the connected third-party source sites.
Detail/episode checks send the chosen title to other sources, and Zenkai and
Aniwixi classification uses AniList IDs. There is no account or cloud sync.

Browser fixtures exercised all ten source adapters, separate page cursors,
partial errors, explicit verification retry, cancellation, conservative
identity matching, additional ID-matched episodes, existing bookmarks/watched
state, the correct owner source on playback, and the distinct mobile airing UI.
A live desktop-browser search queried all ten sources and grouped nine
first-page exact-title candidates for One Piece; these are catalogue records,
not confirmed working streams. The live primary listing had 1,180 episode
numbers and no additional ID-verified numbers. Browser/host tests do not prove
Android WebView playback, automatic fallback, audio, codecs, fullscreen or
battery/network usage. No Android device or emulator test was performed.

=== 5.32 HISTORICAL NOTES RETAINED BELOW (SUPERSEDED BY 5.33 ABOVE) ===

KURO.TV 5.32 — CURRENT NOTES

LIBRARY 10 AND LINKED SOURCES
Library 10 uses https://aniwatch.co.at/. It exposes a real popular list,
search, category routes, a source-labelled Top Airing list and public episode
and server endpoints. Its search/catalogue cards often point to an episode;
Kuro resolves and verifies the matching series, series ID and episode number
before presenting servers. Conflicting duplicated episode numbers are skipped.
Where available, the source supplies SUB and DUB player options. The tested
One Piece episode exposed several 1anime.site wrappers around MegaPlay; source
labels and actual dub language are not independently guaranteed.

Library 10 participates in the bounded cross-library search, preserving exact
normalized title/season, verified episode numbers and IDs when supplied. It is
not a guarantee of seamless playback, correct provider metadata, playable
links or uninterrupted switching. Provider outages, ad blockers, networking,
codec support and verification differ across devices.

SIMULCASTS REDESIGN
The five-item navigation remains. Simulcasts now has its own purple-and-black
editorial airing guide with a library chooser, featured title and vertical
source-ordered rows rather than the Browse grid, tabs and search form. The
Browse Simulcasts tab opens the same new guide. The selected library's supplied
airing list may be inaccurate or include completed titles; it is not a live
schedule or a promise of new releases. The guide never fabricates days/times.
Libraries 1, 2, 3, 5, 7 and 10 have source-reported airing routes. Libraries
4, 6, 8 and 9 did not have a verified route here and show an unavailable
message instead of fabricated entries. Library 7's Top Airing route was
verified in this release, though its listings also contain completed shows.

NESTED PLAYER FAILURES
On Android WebViews supporting the AndroidX document-start and message-listener
features, a small detector checks the known MegaPlay frame twice (at four and
twelve seconds) for explicit visible player errors or verification. Only two
fixed messages from that origin for the current attempt are accepted; stale
frames cannot trigger a retry. The checks do not run continuously. Detection
stops on verification, does not bypass restrictions, and complements the
existing top-level checks. Other frame hosts, hidden errors, silent stalls,
unsupported WebViews and the Android retry itself remain unverified.

18+ REMAINS OFF FOR ZENKAI
The previously implemented Zenkai/Library 8 classification gate remains off
by default, with unknown classifications hidden; Library 9 is also gated.
There is no settings panel or adult toggle in this release. Other libraries,
including Library 10, do not have a complete 18+ filter and may contain adult
material; AniList/source age classifications are not a perfect guarantee.

TESTING
Browser tests covered 10-library routing, exact title and episode checks,
SUB/DUB server extraction, linked candidate discovery, the new UI, unavailable
lists, responsive widths, race cancellation, stale reports and verification
stops. Live HTTP/browser tests fetched Library 10 One Piece, 1,180 episode
links, six reported servers and matching fallback candidates. The sampled
MegaPlay SUB and DUB showed a playback error in desktop headless Chromium;
the frame detector observed that error in a separate browser test. The actual
Android WebView, automatic native switch, audio, codec and fullscreen behavior
have not been tested on a phone. Sources, links and browser codecs can change.

This update uses the same package and signing certificate as 5.31. Install over
the existing app rather than uninstalling to retain local data when possible.

=== 5.31 HISTORICAL NOTES RETAINED BELOW (SUPERSEDED BY 5.32 ABOVE) ===

KURO.TV 5.31 — CURRENT NOTES

THREE ADDITIONAL LIBRARIES
Library 7 is the catalogue/player reached from the Flixnet AniLab wrapper. As
of the test date, that iframe redirected several times to hianimeq.top, which
is used directly because the Android source bridge does not follow redirects.
It is not necessarily independent of other HiAnime-like sources, and the domain
may change. Its real New on Site list supplies the new-arrivals shelf.

Library 8 uses Zenkai's public catalogue/search and its AnimeAV1 playback
sources. Its catalogue is paginated using the supported scraped-catalog API,
not the oversized full catalogue. Playback from the tested Zenkai source is
Japanese audio with Spanish subtitles, explicitly labelled. HLS.js 1.6.16 and
the provider's advertised iframe mirrors are included as player options.
Hardware/codec, network, referer and host restrictions can prevent playback.

Library 9 uses Aniwixi's paginated JSON catalogue, exact AniList IDs, episode
lists and its player. The tested /dub route defaulted to Arabic even with an
English interface; it is not mislabelled as English dub here. Its Japanese/sub
player is offered, with English subtitles only when the source supplies them.
Genres, airing lists and new-series feeds are not claimed for Libraries 8/9
where their API did not establish those lists; their Home shelf is library
order, not a popularity ranking.

18+ DEFAULTS OFF — NO SETTINGS PANEL YET
In Libraries 8 and 9, only entries whose AniList classification explicitly says
isAdult=false are displayed or played. IDs and titles must agree; a missing,
conflicting, explicit adult or unavailable classification is hidden. Stored
entries are rechecked without deleting them. Classification relies on AniList
and source flags; it cannot guarantee a perfect age rating for every title.
Library 7 and the original six do not have a complete 18+ classification gate.
There is intentionally no 18+ switch or settings panel in this release; a
future settings panel must implement explicit consent and the separate adult
catalogue before anything adult can be enabled.

LINKED PLAYBACK
The selected source starts as soon as its supported servers resolve. Searches
for the other libraries run in the background, with at most three workers and
one bounded 60-second session, up to 50 deduplicated servers. This sends the
selected title and episode to other providers; classification sends catalogue
IDs to AniList. Matching is deliberately conservative: exact normalized title,
verified source episode number, and AniList/MyAnimeList IDs where available.
Library 7 searches up to three result pages. Ambiguous names, missing episodes,
unknown adult status and conflicting known IDs are not guessed. This can skip
an actually available alias; matching cannot guarantee that every provider's
numbering and metadata are correct.

On detectable main-frame connection errors, most HTTP errors, explicit
visible top-frame player errors, and fatal bundled HLS errors, the Android
player tries another already-resolved server or waits for the background search.
Existing language preference is retained where possible, with DUB preferred
initially and SUB fallback. Other-source switches restart the episode rather
than preserving its playback position. Human verification, HTTP 403 and 429
stop automatic retries. If all candidates fail, Kuro says so rather than
looping indefinitely. Silent stalls, embedded cross-origin failures, expired
links, inaccessible players and every ad/DRM condition cannot be detected.
Switches may take time or be visible; seamless or uninterrupted playback is not
guaranteed. The selected library can offer a linked episode-one/last-episode
retry if its episode list is missing. Never bypass verification.

TESTING AND UPDATE
Synthetic browser tests covered adult/unknown/mismatch handling, stored entries,
all nine chain adapters, de-duplication, wrong season/episode/ID rejection,
verification stop, race cancellation and HLS error signalling. Live browser
and HTTP smoke tests obtained catalogue/details/episode/player payloads for all
three new libraries and found several One Piece episode-one exact matches;
Libraries 3/4 did not expose that episode during that test. The test browser
lacked the codec for the sampled Zenkai AV1 stream; sampled Aniwixi/MP4Upload
videos also failed in that environment. None of those results proves what a
phone can play. No physical Android device was available for installation,
actual playback, fullscreen, retry, notifications or rotation testing.
This uses the same package and signing certificate as 5.30. Install as an
update without uninstalling so local data has the best chance of being kept.

=== 5.30 HISTORICAL NOTES RETAINED BELOW (SUPERSEDED BY 5.31 ABOVE) ===

KURO.TV 5.30 — CURRENT NOTES

HOME / GENRES / SORTING
Home puts a finite Popular shelf first, followed by New to the library and
Recently watched, then a separately paged catalogue. The Popular shelf uses
the selected library's own ranking: Libraries 1, 2 and 5 report popularity;
Library 3 reports most watched. Library 4 publishes only a finite top-10
all-time chart here, and Library 6 provides a finite top-25 most-watched
series chart. Their longer catalogues remain in library order rather than
being misrepresented as globally ranked. Library 6 also includes cartoons.
Top-shelf items already loaded are not repeated in the following grid.

New to the library is a source-provided recently-added list on Libraries 1, 2,
3 and 5, and the New Anime Arrivals shelf on Library 6. These are additions to
those libraries, not a promise that each anime first premiered recently. A
reliable new-series list was not available on Library 4 during testing; that
shelf says so. The Home shelves are finite so New remains reachable; the
catalogue beneath still loads additional pages until the source says it ends.
A brief in-memory cache reduces repeat requests, and stale or failed requests
are identified. Selecting another library never lets an older response replace
its Home results. No verification challenge is bypassed.

Browse offers 52 genre paths across the supported providers, with a searchable
library-specific list. Library 1 exposes 42, Library 2 34, Library 3 37,
Library 5 45 and Library 6 35 in this build; availability may change. Libraries
1, 2, 3 and 5 use their actual popularity/most-watched category filters, while
Library 6 provides a paginated category in library order because its
category-popularity sorting was not verified. Library 4's genre archive was
empty in testing, so the UI explains that categories are unavailable there.
Music means a genre, not a music player; Library 6 calls the genre Musical.
Simulcasts is the provider's airing list, not a confirmed release schedule.
Category tags and rankings originate with the selected library and can be
incomplete, mislabeled, changed or blocked by the source.

The new purple/black Sort sheet replaces the native light Android selection
popup. Popular first is the default wherever the source supplies that order.
The A–Z and Z–A choices reorder only currently loaded titles; changing to a
new category resets it to the library order. The sheet has an accessible
radio group, focus handling, Escape and Android Back support.

The package ID and signing certificate are unchanged from 5.29. This APK is
intended to install over 5.29 without clearing local data; do not uninstall an
existing Kuro app. The existing player, lists, news and five-item dock remain.
Browser/mock tests cover shelf order, race/retry handling, scrolling, category
filters, loaded-only sorting, keyboard/Back handling, screen widths and prior
news/Skip behavior. First and second pages, genre/action comparisons and finite
charts were checked against live provider snapshots. Providers may change;
not all 52 categories or live playback were independently verified. No physical
Android device was available to test installation, WebView, scrolling, player,
notifications, fullscreen, audio or rotation. Existing playback/Skip/news
limitations still apply; see historical notes below. The PNGs are browser
previews, not device screenshots. The key/password are not in this backup.

=== 5.29 HISTORICAL NOTES RETAINED BELOW (SUPERSEDED BY 5.30 ABOVE) ===

KURO.TV 5.29 — CURRENT NOTES

HOME AND DISCOVERY
Home and Browse load the next library page automatically when the end of the
loaded list approaches. They de-duplicate repeated source URLs, stop when the source has no
next page, and provide a manual Load more/Retry button. There is no fixed app
limit on how many provider pages can be loaded. If a source blocks access,
requests human verification, changes its markup or runs out of content, Kuro
cannot guarantee more results; it does not bypass verification. Leaving a
list for a title and returning restores the loaded items and scroll position
while the app remains open. Sorting is labelled "Sort loaded" because it only
reorders the titles already fetched, not the provider's entire catalogue.

Browse has its own Kuro-style All anime, Simulcasts, Genres and Music sections,
with original geometric category tiles instead of the reference's artwork or
layout. Simulcasts shows the library's airing/ongoing list; it is not a
verified broadcast schedule or proof of same-day availability. Music means
anime in the music genre, not a music-streaming service. Libraries 1, 2, 3 and
5 provide the tested genre/airing paths. Libraries 4 and 6 have paginated
catalogues/search but their genre/airing sections currently report unavailable
rather than inventing results. Coverage, category tags, dub labels and release
timing are supplied by the selected third-party library and can change.

Library 4's main archive returned an empty list during testing, so Kuro uses
that library's public paginated category index. It treats a corresponding anime
URL as a candidate and verifies the exact title/season against its detail page
before enabling bookmark or episode actions. Its posters are fetched only for
nearby visible cards and only after a title match. Some entries may remain
unavailable if the library's category and anime URLs do not agree.

The existing package, signing certificate, saved lists, player, notifications
and bottom dock are retained. The APK is intended to update 5.28 without
clearing data; do not uninstall an existing Kuro app. Automated tests cover
pagination, stale-response handling, duplicate suppression, retry, verification
stop, genre tabs, local data and existing news/Skip behavior. The first two and last two
catalogue pages of all six libraries and the first two genre/airing pages of
four libraries were tested against live source snapshots. Their entire
catalogues, live playback, Android WebView, real scrolling and installation have
not been tested on a physical phone. The screenshots in the package are browser
previews. This visual redesign is not a guarantee of copyright clearance.

=== 5.28 NOTES RETAINED BELOW ===

KURO.TV 5.28 — CURRENT NOTES

The five-item bottom navigation has a new floating purple-and-black dock,
individually drawn icons and an active-page highlight. The existing Home,
My Lists, Browse, Simulcasts and Account destinations retain their previous
order and behavior. Simulcasts and login remain placeholders. These changes
are intended to make the appearance more distinctive; they are not a legal
opinion or a guarantee that the whole application is free of IP concerns.

The app's package and signing certificate are unchanged from 5.27. This APK
is intended to install as an update without clearing app data. The new dock
and navigation transitions were browser-tested at multiple mobile and desktop
widths; the actual Android WebView, system insets and phone launcher were not
tested on a physical device. Existing notification, playback, auto-next and
Skip limitations remain as described below.

=== 5.27 NOTES RETAINED BELOW ===

KURO.TV 5.27 — CURRENT NOTES

The app label is now Kuro.tv. The user's supplied 2988 x 1408 logo has been
recreated as scalable paths with approximated gradients and clean edges. The
header uses the SVG; the entry screen uses an optimized PNG on black. The
adaptive launcher icon uses the K-and-blossom emblem on a black background so
the full wordmark is not crushed into a tiny icon. Android launchers choose
their own icon masks and may display the result differently. The optional
15,360-pixel-wide logo PNG is rendered from the vector; it is not native 16K
source detail. The app itself uses smaller optimized assets.

The package ID and signing certificate are unchanged from 5.26, so this build
is intended to update the existing Kuro app and keep its local data. Do not
uninstall the app to troubleshoot an install problem. The notification feed,
watchlists, libraries and existing player behavior are unchanged.

Assets in art/ include the supplied original and the generated SVGs; an optional
regeneration script is in scripts/generate_logo.py. Regenerating requires Pillow,
NumPy, OpenCV, CairoSVG and potrace; the ready-to-use logo assets are already
included. tests/test-logo-assets.py checks dimensions, safe-zone padding, vector
and app labels without requiring an Android device.

The APK signature, resource manifest, vector assets and browser UI were checked.
Actual launcher masks, installation over 5.26, splash, Android WebView, phone
notifications and playback have not been tested on a physical Android device.
The 5.26 notification and existing playback/Skip limitations below still apply.

=== 5.26 NOTES RETAINED BELOW ===

KURO ANIME.TV 5.26 — CURRENT NOTES

NEWS / NOTIFICATIONS
The header bell opens an in-app feed of general anime-related updates. It uses
five external RSS/Atom feeds: Crunchyroll News and Anime Corner (labelled news
reports), and the official TOHO animation, Aniplex USA and KADOKAWA Anime
YouTube channels (labelled official videos). An official video can be a clip,
episode preview, game-related post or other upload rather than an announcement;
some are in Japanese. These selected feeds do not cover every anime or every
announcement. No news-server account, PC or user-operated server is needed.

Each post only shows a headline, excerpt, publication time, image and source
link when provided and allowed. YouTube source buttons open the official video;
news buttons open the original report in another app. Publisher-provided URLs
and image hosts are restricted. No release dates are invented. For some
headlines the app asks the public AniList API for optional catalogue metadata,
including alternate names, series synopsis, genres, studio and poster. It is
labelled AniList, not the publisher's announcement. Only an unambiguous exact
match of a returned English, romaji, native or synonym title is used. Studio is
omitted for an apparent sequel when the extracted name does not identify that
season. This is a cautious best-effort match, not a guarantee of correctness;
information can be stale or absent. Data only loads for nearby visible cards.
The cache keeps up to 150 text entries; source images and optional AniList
details may need a connection. Up to 350 seen IDs per feed are retained.

On a feed's first successful check its current posts become a baseline, rather
than causing a flood of old notifications. Later unseen, dated posts are
batched in one Android notification; old/undated/far-future items still appear
in the feed but do not trigger alerts. The user can disable phone alerts in the
feed; in-app browsing still works. Android 13+ requires notification permission;
Android may also block the app or channel. Opening the app schedules an
internet-constrained persisted JobScheduler task at roughly hourly intervals,
when alerts are allowed. Android chooses actual execution times and may defer
jobs for Doze, battery or vendor restrictions. A force-stop prevents background
work until the app is opened again. Phone alerts cannot be guaranteed when the
OS restricts the app, the feeds are unavailable, or permissions are denied.
The notification opens the updates feed. The first launch also checks the feeds.

PRIVACY: The selected publishers, YouTube image hosts and AniList receive
network requests and can see the device's IP address. AniList lookups contain
candidate public titles; no Kuro watchlist, personal account or history is sent
to AniList. Article and video links open externally. RSS text, seen IDs and
settings are stored locally in the app. There is no Kuro-owned push server.

TESTING: Actual live feeds were parsed on a host; synthetic RSS/Atom fixtures,
security checks and baseline/deduplication were unit-tested. Browser tests
exercised the bell, card formatting, exact-match metadata, source attribution,
filters, toggle, cached failure handling, safe links, navigation and a mobile
layout. Android scheduling, permissions, cache, notification and job lifecycle
were exercised against a host-side fake framework, not a real Android device.
The APK signature and manifest were checked; phone/background timing, WebView,
real notification permission UI, Android fullscreen/player and rotation have
NOT been tested on a phone. Existing 5.25 playback/Skip limitations remain.

BUILD: build.sh uses Android build-tools 35, API 35 android.jar, Java 11+ and
the bundled AndroidX artifacts. Set TOOLS, SDK, JAVA_HOME, KEYSTORE and
KS_PASS; the private signing key/password are NOT in this source package.
Run tests/test-news-logic.sh for the host parser tests, and optionally supply a
directory of downloaded feed XMLs as its argument. Run the fake-framework test
with JSON_JAR pointing to org.json:json:20240303 (test-only dependency, not
bundled); it is a simulation, not an Android runtime. Browser tests need the
optional Playwright dependency and Chromium. See THIRD_PARTY_NOTICES.txt.

=== 5.25 NOTES RETAINED BELOW ===

Auto-skip is opt-in. While the watch player is open and the Activity is in the foreground, it checks roughly every two seconds for visible controls containing the word Skip, including generic controls and controls in player frames where supported. It may also activate unrelated Skip controls, including skip-ad controls. It is not an OCR/screen reader: canvas-only, video-rendered, closed shadow-DOM, or native controls are not readable. Synthetic clicks are not trusted physical touches, and a player may reject them. The script excludes common verification/challenge pages and verification-labelled controls; it does not solve CAPTCHAs.

On supporting Android System WebView versions, AndroidX WebKit registers the script at document start in all matching player frames, even if cross-origin. A minimal WebMessageListener, available to player frames, accepts only ready/bye and returns the on/off state; it exposes no filesystem, login, navigation, or arbitrary native execution. A frame can learn that state. If either WebView feature is unavailable, the fallback only checks the main document and accessible same-origin child frames. Switching off clears the scan timers; the small inactive frame listener remains. Backgrounding/closing the player stops active scanning. This is not an Android background service. CPU work is budgeted per scan but cannot be set or guaranteed as a percentage of application usage.

Synthetic Chromium tests exercised off/on/off boundaries, generic and labelled controls, hidden/disabled controls, a mock verification page, a separately injected cross-origin nested frame, and HTML fullscreen. These tests emulate the per-frame messaging, not Android WebView itself. There has been no Android phone, genuine server, native fullscreen, rotation, or actual playback test. Some players will still not work. Existing source matching, fallback, auto-next and provider limitations remain.

Build: build.sh uses Android build-tools 35, android.jar API 35, Java 11+, a private signing key, and the AndroidX artifacts in libs/. Set TOOLS, SDK, JAVA_HOME, KEYSTORE and KS_PASS. Original AndroidX binaries and source JARs and applicable notices are supplied; see assets/THIRD_PARTY_NOTICES.txt. The signing key is not included. Browser test fixtures in tests/ require the optional Playwright dependency and a local Chromium browser.

=== HISTORICAL VERSION NOTES BELOW (some initial descriptions were superseded) ===

Kuro Anime.tv 5.15 — experimental separate Android app
Package app.lovelycrxshx.kuro; min Android 8 (API 26), target 35. This does not replace the HiAnime apps. Placeholder K icon — user will provide a logo later.

Features: custom dark cyan UI, separate Library 1 / Library 2 browsing and search (backed by hianime.ms and hianime.dk respectively), basic genre browse, episodes and third-party server choices on a watch page, embedded 16:9 player WebView, local saved titles and recently opened titles. "Search title in other library" looks up a title on the second site; the user must manually choose the correct match and episode. Source lists can change and are not equivalent; no automatic matching or automatic failover is claimed. Opens the selected provider's player, not a custom extracted video stream. The player receives site/domain referer where supplied. Third party ads, popups, source restrictions, playback and DRM remain under provider control. Human verification isn't bypassed.

Not included: advanced multi-filter search, watch progress syncing, online accounts, shared profiles, comments/community, achievements, recommendations engine, auto-next, downloads, Discord RPC, comprehensive ad blocking, or site account integration. "Recently opened" records opening a player, not actual progress. Library and recent data stay in the local WebView and can be lost if app data is cleared; deleting the app removes that data.

Historical security/privacy at 5.1: The separate player originally had no native JavaScript bridge; the local UI initially fetched only two HTTPS sources with redirects disabled. See the current 5.25 notes above for the current player message listener and six sources. The remote hosts see the network requests. Player hosts and cover image hosts may receive requests. This is not an audit of the sites. No account credentials are requested by Kuro.

Testing: browser automation against live sites exercised home listings, episode lists and server extraction for both sites; also tested search, saving a title and searching the other source. This tests the browser-side prototype via a local test proxy, not Android's bridge or video playback. APK compiled, signature and alignment validated; no Android device, stream, full-screen, audio, or network challenge testing. Availability and website markup may change.

Build using build.sh with Android build-tools 35, android.jar API 35, Java 11+; set TOOLS, SDK, JAVA_HOME, KEYSTORE and KS_PASS. Android tooling and signing key are not included. Preserve signing key privately for future updates. Historical note: this was true before the AndroidX dependencies added in 5.25; see the current third-party notices.

Version 5.3 puts the player, servers and episode selector on the watch page; fullscreen is optional. 5.2 changed the app interface labels; the underlying providers and embedded third-party player pages are unchanged and may display their own branding.

5.3: tap an episode to load its first listed server in a 16:9 watch page; server chips below switch server/audio; episode buttons navigate to other episodes. The video still uses a third-party player, not Kuro native playback. It may require tapping play. Individual site labels remain hidden in Kuro UI, but player content is not under Kuro control. Native watch-page layout, player and Android actions have not been device-tested.

5.4: watch-page servers are separated into SUB and DUB columns, with other audio types shown separately. Episode lists are vertical and show source-provided episode titles where available; missing names fall back to Episode N. The native watch-page episode search matches number or name and pages lists longer than 100 results. Browser tests verified title extraction and watch payload using live catalog pages; Android layout and controls have not been tested on-device.

5.5: server choices display Server 1, Server 2 etc separately in each audio group, without changing the destination. Kuro injects a cosmetic dark/cyan YouTube-inspired CSS skin for compatible JW Player, Video.js and Plyr controls on a supported player page. It keeps the original controls and does not change sources, advertising or DRM. This is not a replacement player and provider scripts, CSP or nested cross-origin frames may prevent it from applying. A synthetic JW-style DOM was browser-tested; on the live provider test no JW controls initialized in the browser environment, so real-player styling and Android playback are not verified.

5.6: Poster overlays display CC for the source-reported subtitled episode count, a microphone for the source-reported dubbed count, and a number for the source-reported episode count. Unknown fields are omitted. Each catalog may define its episode count differently; it can represent released/listed episodes and is not independently verified. Older saved/recent entries without counts attempt one-time detail-page enrichment when shown. Counts do not prove that all videos work or that all dubbed episodes are English. Browser tests checked catalog badges and legacy hydration using live pages. Android build/signature checked; no Android device test.

5.7: Smaller episode count badges; compact header with functional search and explicitly nonfunctional notification/login placeholders; source-driven first-title spotlight; horizontally scrolling recently watched shelf and two-step Clear all. Recent entries track opened player sessions, not playback progress. Clear only removes local recent history, not saved titles. Browser-tested the two libraries and clear confirmation; Android phone test is still needed.

5.8: Updated bottom navigation with Home, My Lists, Browse, Simulcasts and Account, using vector icons. Simulcasts is a placeholder, not a schedule. My Lists, Browse and Account map to existing local library, search and profile screens. Browser navigation and watch bridge tested; Android device test still needed.

5.9: Native watch page includes an anime details card beneath the episode list: poster, title, source-provided episode counts, metadata, synopsis, and View details. No ratings or feedback. Browser mock-bridge verified details for two live sources; native Android UI, image loading and playback were not device tested. Descriptions and counts are source supplied and may be missing. Poster downloads limited to selected known image hosts.

5.10: Anime details screen displays source-provided synopsis, episode badges, and available facts including status, aired date and genres. Save button now uses a bookmark icon and label, retaining the existing local library. Facts can be missing or inaccurate in source listings. Browser tested two libraries, bookmark toggle and watch-payload continuity; no Android device testing.

5.11: User-supplied Kuro logo is fitted in header, centered animated native entry screen, and launcher icon. Original logo and generated PNG assets are included in source ZIP. Purple/black palette used for local UI, native watch page and experimental compatible player skin. Browser checked header/logo/theme and mock-bridge flow. Android splash animation, icon appearance and native watch page require device testing. Third-party players may ignore cosmetic styling.

5.12: Black launch window and Android 12+ system splash settings use a transparent splash icon to avoid the grey system screen and square launcher logo; then the centered, fitted logo fades and scales in, fading out into the app. This is intended to make the transition seamless but has not been tested on a physical Android device; vendor splash behavior can differ. Launcher icon unchanged.

5.13 PARTIAL: Existing libraries prefer first provider-labelled DUB server, otherwise SUB, otherwise first available. Provider language labels do not independently prove English. Best-effort initial unmute for same-page video elements on new player page, without overriding later manual mute; nested/cross-origin frames, host behavior, playback permissions and device volume may prevent it. Autoplay remains gesture-gated. Tested ordering on synthetic server arrays and mock bridges on live pages and unmute on synthetic video; Android untested. Four requested new sources, cross-source matching, automatic server failover and best-server measurement are NOT implemented. Do not bypass verification.

5.14 PARTIAL: When an existing library returns no servers for an already listed episode, exact-title/season match and exact episode number search is attempted against 9anime.or.at; only my.1anime.site embed is currently allowed. Ambiguous matches are rejected. No matching when original episode is absent; no fallback on original-source request errors. Native player retries each listed server at most once for main-frame connect, host lookup or timeout errors, preferring same audio type; no retry on HTTP/verification errors, nested player errors or stalled media. Chromium mock-bridge tested exact Black Clover Season 2 episode 1 and nonexistent season/episode rejection, but actual Android/player playback and native retry untested. zorotv.ba, aniwaves.ru and animesalt.cx NOT integrated. English labels unverified; no best-server speed test.

5.15: Adds Libraries 3–6 for 9anime.or.at, zorotv.ba, aniwaves.ru and animesalt.cx, including browsing/search, conservative episode lists, and third-party player adapters. For an opened episode lacking DUB, tries strict exact-title and episode matches across added libraries, then prefers provider-labelled dub and otherwise sub. Existing 5.14 bounded retries apply only to detectable top-level WebView connection/host/timeout errors; no bypass, cross-origin stall detection, quality measurement or verified playback. Does not automatically retrieve an episode absent from the selected library list. The sixth library currently exposes only its first-season list; movie/season layouts may be incomplete. Titles and episode numbering can differ and exact matching may refuse valid alternatives. Dub label is provider-supplied, language is not independently verified. Browser tests with live sources found episode 1 player URLs for all four libraries and rejected invalid season/episode; Android WebView playback, provider availability, unmute, native failover and layouts remain untested. 403/429 from extra fallback aborts with a message.

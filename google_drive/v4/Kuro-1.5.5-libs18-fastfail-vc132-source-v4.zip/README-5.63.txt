HISTORICAL 5.63 NOTES — superseded by README-5.64.txt for the current build.

Kuro.tv 5.63 — Discord Rich Presence
====================================

PHONE: INSTALL AND USE

• Install the signed 5.63 APK over your existing Kuro installation; keep its
  app data. Do not uninstall Kuro or clear storage. Minimum Android version:
  8.0 (API 26). An update requires the same package and signing key.
• Install/open the official Discord Android app and sign in to the account
  that should display activity. In Kuro open Settings → Discord Rich
  Presence → Share activity → On. The feature is OFF by default.
• Open an anime episode and check your Discord profile or ask a friend to
  check. Discord's activity privacy and availability determine visibility;
  a message that the SDK accepted an update does not prove anyone sees it.
• Kuro's Profile → Account connections screen and Discord account linking
  are separate from this opt-in presence feature. No bot, user token, client
  secret, special OAuth login or additional Kuro sign-in is needed for
  Android's SDK-to-Discord-app RPC.

WHAT IS SHARED

When enabled, Discord may receive your Kuro browsing state or anime title,
episode, SUB/DUB if known, playback state, and, where supported, elapsed/
remaining timing. A public HTTPS poster URL and show-page link can be shared
only if they pass Kuro's restricted host/path checks. URLs with queries,
credentials, ports, fragments or encoded paths are not shared. Stream URLs,
cookies, Kuro account credentials and tokens are not sent by this RPC code.
The data is shared with Discord and may be visible to others according to
your Discord settings. Discord controls the presentation, availability,
caching and audience.

Kuro samples observable playback approximately every three seconds, but
coalesces updates: changes can take about 15 seconds to appear. When native
Media3 playback or Kuro's validated direct HLS page actually exposes its
state, Kuro reports playing/paused/loading/completed and uses a timer only
when position and duration are valid. Other cross-origin embedded players
are marked "Selected" because their playback state cannot safely be observed;
a guessed timer is never shown. A public cover or show link is not available
for every provider, and Discord may choose not to display it.

Closing the player returns presence to browsing. Turning Share activity off
requests immediate removal. Kuro requests removal after approximately twelve
seconds in the background, and resumes when foregrounded; picture-in-picture
is treated as active. These are requests, not guarantees: Android force-stop,
process death, a closed Discord app or Discord caching can prevent timely
clearing. Force-stop or offline behavior was not tested on a real device.

TROUBLESHOOTING

Open and sign in to the official Discord app, enable activity sharing in its
privacy settings, reopen Kuro, and check Settings → Discord Rich Presence →
Connection status. Updates are retried while Kuro is active; if sharing is
unavailable the status may say it is waiting. An SDK-success callback only
means the SDK accepted the request. Developer Portal Social SDK enablement,
Discord version, account privacy, network, multiple accounts, competing
activities and Discord's app behavior can all affect visibility. The code
has not been tested against a live signed-in Android Discord session.

SOURCE AND REPRODUCIBLE BUILD

The source ZIP and text backup contain Kuro code, resources, licenses and
notices, not the proprietary Discord Social SDK AAR, headers, vendor binaries
or the private signing key. To build the same feature, obtain Discord Social
SDK 1.10.19337 from the Discord Developer Portal under your app's Games →
Social SDK → Downloads; extract discord_social_sdk/lib/release/
discord_partner_sdk.aar. Use it under the Discord Social SDK terms. The AAR
used here has SHA-256:
b1b2491f1e1848c79fd6f1986d5aa1e0c8019e88a6e62c7be06b89e8e4870933
The supplied full SDK ZIP has SHA-256:
d784097504685953849cc2842561d8a8013326fe0b8df65a1de63ddefde62045

Required tools: Linux x86_64, JDK 17 or 21, Android SDK platform 35 and build
tools 35.0.1, Android NDK r27c (27.2.12479018), Gradle 8.10.2, unzip and the
separately obtained release AAR. Exact bit-for-bit reproduction can also
depend on host toolchain, dependencies and archive timestamps. Example:

  export ANDROID_HOME=/path/to/android-sdk
  export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/27.2.12479018"
  export KURO_DISCORD_SDK_AAR=/path/to/discord_partner_sdk.aar
  ./scripts/build-discord-jni.sh
  ./gradlew --no-daemon --max-workers=1 assembleRelease lintRelease

The JNI script builds arm64-v8a, armeabi-v7a, x86_64 and x86, with 16 KiB
ELF alignment. Gradle packages Kuro's bridge and the externally supplied
SDK AAR. The generated unsigned APK is under build/outputs/apk/release/.
To install as an update it must be signed with the original private release
key; that key is not in this source bundle and must remain private.

This package integrates Discord's SDK under its license. The bundled notices
are available in Settings → Developer → Third-party notices and in
assets/DISCORD-SOCIAL-SDK-NOTICES.txt. Discord's Android setup and Direct Rich
Presence documentation:
https://docs.discord.com/developers/discord-social-sdk/core-concepts/mobile
https://docs.discord.com/developers/discord-social-sdk/development-guides/setting-rich-presence

Kuro application ID for this integration: 1569077670074122250.
Kuro Android package: app.lovelycrxshx.kuro; version code 63.

TESTING LIMITS

Host-side metadata/URL and scheduling tests, fake-bridge browser tests,
Android build/lint and APK/signature/manifest inspections do not substitute
for an actual Android install, playback, PiP, network interruption, Discord
reconnection or a second-account visibility test. Test those on the phone
without uninstalling or clearing the existing Kuro app/data.

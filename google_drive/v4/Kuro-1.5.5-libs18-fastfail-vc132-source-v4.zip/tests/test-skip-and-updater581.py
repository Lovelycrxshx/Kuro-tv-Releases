#!/usr/bin/env python3
"""Static checks for 5.81 rev 11.5: suggested skip windows and updater v2.

These read the sources that are actually compiled, so a refactor cannot quietly
drop the guarantees: a guess never skips on its own, and an update is only offered
when it carries the pinned Kuro release key.
"""
import pathlib, re, sys

root = pathlib.Path(__file__).resolve().parent.parent
src = root / "src/app/lovelycrxshx/kuro"
suggest = (src / "KuroSkipSuggestions581.java").read_text()
player = (src / "KuroNativePlayer561.java").read_text()
preflight = (src / "KuroApkPreflight572.java").read_text()
service = (src / "KuroUpdaterDownloadService.java").read_text()

# --- suggested skip windows -------------------------------------------------
for constant in ('MIN_EPISODE_MS = 120_000L', 'INTRO_START_MS = 8_000L',
                 'INTRO_END_MS = 98_000L', 'OUTRO_LENGTH_MS = 90_000L',
                 'OUTRO_TAIL_MS = 2_000L'):
    assert constant in suggest, constant
assert 'static KuroPlayback561.Range intro(long durationMs)' in suggest
assert 'static KuroPlayback561.Range outro(long durationMs)' in suggest
assert 'durationMs < MIN_EPISODE_MS' in suggest, 'short episodes must never get a guess'
assert 'end > INTRO_START_MS ? new KuroPlayback561.Range' in suggest

# window arithmetic, mirroring the source constants
MIN, I0, I1, OL, TAIL = 120_000, 8_000, 98_000, 90_000, 2_000
def intro(d):
    if d < MIN: return None
    end = min(I1, d - MIN // 2)
    return (I0, end) if end > I0 else None
def outro(d):
    if d < MIN: return None
    end = d - TAIL
    start = end - OL
    return (start, end) if start > I1 and end > start else None
assert intro(60_000) is None and outro(60_000) is None
assert intro(1_440_000) == (8_000, 98_000)
assert outro(1_440_000) == (1_348_000, 1_438_000)
assert intro(200_000) == (8_000, 98_000)
i, o = intro(1_440_000), outro(1_440_000)
assert i[1] < o[0], 'the two windows must never overlap'

# --- the player offers but never applies a guess ----------------------------
assert 'KuroSkipSuggestions581.intro(duration)' in player
assert 'KuroSkipSuggestions581.outro(duration)' in player
assert 'boolean auto=!activeSuggested&&' in player, 'auto skip must ignore suggested windows'
assert '(suggested window)' in player
assert 'if(intro==null||introSuggested)' in player, 'a real marker must never be replaced by a guess'
assert 'suggestedFor=-1;introSuggested=false;outroSuggested=false;' in player, 'a new item must recompute'

# --- updater: pinned signer -------------------------------------------------
pin = re.search(r'RELEASE_SIGNER = "([0-9a-f]{64})"', preflight)
assert pin, 'the release key must be pinned in the binary'
assert pin.group(1) == '1d37c3ca28ed80cc484601a7a7907d5c43970a5d57d51aa4e91475a60703e93e'
assert 'UNPINNED_SIGNER' in preflight and 'signers.contains(RELEASE_SIGNER)' in preflight
assert preflight.index('signers.contains(RELEASE_SIGNER)') < preflight.index('NOT_NEWER, packageName')
assert 'not signed by the Kuro release key' in preflight

# --- updater: resumable download -------------------------------------------
assert '"Range", "bytes=" + have + "-"' in service
assert 'code == 206 && have > 0' in service and 'code != 200 && code != 206' in service
assert 'hashExisting(md, part)' in service, 'a resumed file must still be checksummed'
assert 'new FileOutputStream(part, resumed)' in service
assert 'e instanceof BadUpdate' in service, 'only bad bytes may discard the partial file'
assert 'part.delete()' in service and 'BadUpdate(' in service

print("PASS skip suggestions are conservative and never auto-apply; updater pins the release key and resumes")

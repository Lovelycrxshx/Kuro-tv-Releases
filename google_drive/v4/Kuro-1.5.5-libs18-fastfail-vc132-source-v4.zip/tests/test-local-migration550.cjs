'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const code=fs.readFileSync(require('path').join(__dirname,'../assets/local-restore-safety550.js'),'utf8');
function run(initial){
 const m=new Map(Object.entries(initial)),window={},store={getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k)};
 vm.runInNewContext(code,{window,localStorage:store});return {m,window};
}
const journal='kuro-cloud-restore-journal-v1';
let normal=run({'kuro-library':'[{"title":"kept"}]','kuro-profile-v1':'{"name":"Kuro"}'});
assert.equal(normal.m.get('kuro-library'),'[{"title":"kept"}]');assert.equal(normal.m.get('kuro-profile-v1'),'{"name":"Kuro"}');
let previous='[{"title":"before merge"}]',restored=run({'kuro-library':'[{"title":"partial"}]','kuro-recent':'[]','kuro-profile-v1':'{"name":"kept"}',[journal]:JSON.stringify({v:1,before:{'kuro-library':previous,'kuro-recent':null}})});
assert.equal(restored.m.get('kuro-library'),previous);assert.equal(restored.m.has('kuro-recent'),false);assert.equal(restored.m.has(journal),false);assert.equal(restored.m.get('kuro-profile-v1'),'{"name":"kept"}');
let unsafe=run({'kuro-library':'[{"title":"kept"}]',[journal]:JSON.stringify({v:1,before:{'unrelated':'bad','kuro-library':'[]'}})});
assert.equal(unsafe.m.get('kuro-library'),'[{"title":"kept"}]');assert.equal(unsafe.m.has(journal),true);assert(unsafe.window.kuroLocalRestoreWarning);
let malformed=run({'kuro-library':'[1]',[journal]:'{'});assert.equal(malformed.m.get('kuro-library'),'[1]');assert(malformed.window.kuroLocalRestoreWarning);
assert.equal(restored.window.KuroCloud,undefined);console.log('PASS local-only rollback, unchanged data, malformed journal safety, no backup service');

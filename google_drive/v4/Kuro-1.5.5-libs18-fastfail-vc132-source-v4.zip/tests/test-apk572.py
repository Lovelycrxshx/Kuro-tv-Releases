#!/usr/bin/env python3
"""Check the signed 5.72 APK: assets, architecture, CRC, ELF alignment and new wiring.

Usage: python3 tests/test-apk572.py path/to/Kuro-tv-5.72.apk
Optional KURO_DISCORD_SDK_AAR verifies the separately licensed vendor binaries.
Signature, certificate and ZIP alignment additionally require apksigner/zipalign.
"""
import json, os, pathlib, struct, subprocess, sys, zipfile

root = pathlib.Path(__file__).resolve().parents[1]
if len(sys.argv) != 2: raise SystemExit(__doc__)
abi = {'arm64-v8a', 'armeabi-v7a', 'x86', 'x86_64'}


def load_alignments(data):
    if data[:4] != b'\x7fELF' or data[5] != 1: raise AssertionError('invalid or non-little-endian ELF')
    if data[4] == 2:
        phoff = struct.unpack_from('<Q', data, 32)[0]; entsize, num = struct.unpack_from('<HH', data, 54)
        align_offset = 48; fmt = '<Q'
    elif data[4] == 1:
        phoff = struct.unpack_from('<I', data, 28)[0]; entsize, num = struct.unpack_from('<HH', data, 42)
        align_offset = 28; fmt = '<I'
    else:
        raise AssertionError('unexpected ELF class')
    result = []
    for i in range(num):
        entry = phoff + i * entsize
        if struct.unpack_from('<I', data, entry)[0] == 1:
            result.append(struct.unpack_from(fmt, data, entry + align_offset)[0])
    return result


with zipfile.ZipFile(sys.argv[1]) as z:
    assert z.testzip() is None, 'ZIP CRC failure'
    names = z.namelist()
    libs = [n for n in names if n.startswith('lib/') and n.endswith('.so')]
    assert {n.split('/')[1] for n in libs} == abi
    assert len(libs) == 8 and all(len(load_alignments(z.read(n))) > 0 and min(load_alignments(z.read(n))) >= 16384 for n in libs), 'ELF must support 16 KiB pages'

    # Every asset that 5.72 changed must be byte-identical to the source tree.
    changed = ['assets/accounts542.js', 'assets/accounts542.css', 'assets/settings560.js',
               'assets/profile-presets571.js', 'assets/profile-presets571.css', 'assets/index.html',
               'assets/preset-manifest571.js', 'assets/profile-default571.png']
    for path in changed:
        assert z.read(path) == (root / path).read_bytes(), path + ' differs from source'

    manifest = json.loads((root / 'assets/preset-manifest571.json').read_text())
    assert len(manifest['entries']) == 160
    for row in manifest['entries']:
        for kind in ['avatar', 'banner']:
            path = 'assets/' + row[kind]
            assert z.read(path) == (root / path).read_bytes(), path + ' differs from source'

    dex = b''.join(z.read(n) for n in names if n.startswith('classes') and n.endswith('.dex'))
    for marker in [b'KuroUpdater572', b'KuroUpdaterJobService', b'KuroUpdaterDownloadService',
                   b'KuroApkPreflight572', b'KuroResume572', b'KuroVideoFit572',
                   b'ImAuraxSiva/Kuro-tv-Releases', b'kuro_updates572', b'updates572',
                   b'player-restart-572', b'player-fit-572', b'KuroCaptionStyle571', b'KuroPipControls571']:
        assert marker in dex, 'missing compiled class or wiring: ' + marker.decode()
    for stale in [b'Kuro.tv 5.71']:
        assert stale not in dex, 'stale version string present'

    for a in abi:
        compiled = root / f'build/kuro-discord-jni/{a}/libkuro_discord_rpc563.so'
        if compiled.is_file():
            assert z.read(f'lib/{a}/libkuro_discord_rpc563.so') == compiled.read_bytes(), 'JNI library mismatch ' + a
    aar = os.environ.get('KURO_DISCORD_SDK_AAR', '')
    if aar:
        with zipfile.ZipFile(aar) as vendor:
            for a in abi:
                assert z.read(f'lib/{a}/libdiscord_partner_sdk.so') == vendor.read(f'jni/{a}/libdiscord_partner_sdk.so'), 'Discord SDK binary mismatch ' + a

# Binary manifest checks through aapt2 when available.
aapt2 = os.environ.get('AAPT2', '')
if aapt2 and pathlib.Path(aapt2).is_file():
    dump = subprocess.run([aapt2, 'dump', 'xmltree', '--file', 'AndroidManifest.xml', sys.argv[1]],
                          capture_output=True, text=True, check=True).stdout
    for needed in ['REQUEST_INSTALL_PACKAGES', 'app.lovelycrxshx.kuro.updates572',
                   'KuroUpdaterJobService', 'KuroUpdaterDownloadService',
                   'android.support.FILE_PROVIDER_PATHS', '"5.72"',
                   'BIND_JOB_SERVICE']:
        assert needed in dump, 'manifest is missing ' + needed
    assert 'versionCode(0x0101021b)=72' in dump, 'wrong versionCode'
    assert 'foregroundServiceType' in dump
    # The FileProvider path resource is compiled into resources.arsc; resolve it by name.
    resources = subprocess.run([aapt2, 'dump', 'resources', sys.argv[1]],
                               capture_output=True, text=True, check=True).stdout
    assert 'kuro_updates572_paths' in resources, 'FileProvider paths resource is missing'
    assert 'updates' in resources
    # No new dangerous permissions were added for the updater.
    for banned in ['READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE', 'MANAGE_EXTERNAL_STORAGE',
                   'REQUEST_DELETE_PACKAGES', 'SYSTEM_ALERT_WINDOW']:
        assert banned not in dump, 'unexpected permission ' + banned

print('PASS APK CRC, four ABIs, eight 16 KiB ELF binaries, 5.72 updater/resume/fit classes, '
      'changed assets byte-identical to source, no extra permissions and optional SDK checks')

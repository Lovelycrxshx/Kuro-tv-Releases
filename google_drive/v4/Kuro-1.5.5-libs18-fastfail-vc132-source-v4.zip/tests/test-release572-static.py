#!/usr/bin/env python3
"""Kuro 5.72 static release checks: features 35, 44, 45, 48 and the updater.

This inspects sources only. It proves wiring and documented limits, not runtime
behaviour on a phone.
"""
from pathlib import Path
import json, re

r = Path(__file__).resolve().parents[1]


def text(name):
    return (r / name).read_text(encoding='utf-8')


build = text('build.gradle')
android = text('AndroidManifest.xml')
java = text('src/app/lovelycrxshx/kuro/MainActivity.java')
native = text('src/app/lovelycrxshx/kuro/KuroNativePlayer561.java')
updater = text('src/app/lovelycrxshx/kuro/KuroUpdater572.java')
download = text('src/app/lovelycrxshx/kuro/KuroUpdaterDownloadService.java')
preflight = text('src/app/lovelycrxshx/kuro/KuroApkPreflight572.java')
resume = text('src/app/lovelycrxshx/kuro/KuroResume572.java')
fit = text('src/app/lovelycrxshx/kuro/KuroVideoFit572.java')
presets = text('assets/profile-presets571.js')
presets_css = text('assets/profile-presets571.css')
accounts = text('assets/accounts542.js')
accounts_css = text('assets/accounts542.css')
settings = text('assets/settings560.js')
paths = text('res/xml/kuro_updates572_paths.xml')

# --- version metadata -------------------------------------------------------
assert 'versionCode 72' in build and "versionName '5.72'" in build
assert 'android:versionCode="72"' in android and 'android:versionName="5.72"' in android
assert 'Kuro.tv 5.72' in java

# --- feature 35: exact resume and Restart ----------------------------------
assert 'KuroPlayback561.save(activity,key,engine.getCurrentPosition(),engine.getDuration())' in native
assert 'boolean restart572()' in native and 'KuroPlayback561.completed(activity,key)' in native
assert 'KuroResume572.restartable(position,duration)' in native
assert 'WEB_RESTART_JS' in resume and 'v.length!==1' in resume
assert 'restartEpisode572' in java and '"player-restart-572"' in java
assert 'not Kuro’s own player' in resume
# A third-party embed is never restarted on Kuro's word alone.
assert 'player.getUrl().startsWith("https://kuro.local/stream-player.html?")' in java

# --- feature 44: independent Anime/History dim and soften -------------------
for token in ["clampDim", "clampSoft", "cardAdjust", "applyCardStyle", "preset-adjust571", "adjustTouched"]:
    assert token in presets, token
assert "p[kind+'Dim']" in presets and "p[kind+'Soften']" in presets
assert 'Adjusting the\n    // dim or soften of an older background must never force a new picture' in presets
assert '--profile-card-dim571' in accounts_css and '--profile-card-soften571' in accounts_css
assert '--profile-card-zoom571' in accounts_css
assert 'applyCardStyle' in accounts and "cardAdjust('anime')" in accounts and "cardAdjust('history')" in accounts
assert '.preset-adjust571' in presets_css and 'height:48px' in presets_css
# Preview and Cancel existed before; Apply still commits through the journal.
assert 'data-apply' in presets and 'data-cancel' in presets and 'JOURNAL' in presets

# --- feature 45: fit/crop only on Kuro's own native surface ----------------
assert 'setResizeMode' in native and 'AspectRatioFrameLayout.RESIZE_MODE_ZOOM' in native
assert 'AspectRatioFrameLayout.RESIZE_MODE_FIT' in native
assert '"player-fit-572"' in java and 'toggleFit572' in java
assert 'static String normalize' in fit and fit.count('CROP') >= 2
# Fullscreen and cutout handling must not be touched by the fit control.
assert 'setResizeMode' not in java
assert 'enterEnhancedFullscreen' in java and ('layoutInDisplayCutoutMode' in java or 'CUTOUT' in java.upper())

# --- feature 48: APK preflight --------------------------------------------
for status in ['WRONG_PACKAGE', 'NOT_NEWER', 'SIGNER_MISMATCH', 'UNREADABLE', 'MISSING', 'OK']:
    assert status in preflight, status
assert 'GET_SIGNING_CERTIFICATES' in preflight and 'GET_SIGNATURES' in preflight
assert 'installedSigners.equals(signers)' in preflight
assert 'getPackageArchiveInfo' in preflight
assert 'KuroApkPreflight572.inspect(this,apk)' in java
assert 'canRequestPackageInstalls' in java and 'ACTION_MANAGE_UNKNOWN_APP_SOURCES' in java

# --- updater --------------------------------------------------------------
assert 'ImAuraxSiva/Kuro-tv-Releases' in updater
assert 'https://api.github.com/repos/" + REPO + "/releases/latest' in updater
assert 'MAX_NOTIFICATIONS = 3' in updater and 'MIN_GAP_MS' in updater
assert 'MAX_DOWNLOAD_FAILURES = 3' in updater
assert 'setPeriodic' in updater and 'setPersisted(true)' in updater
assert 'NETWORK_TYPE_ANY' in updater
# No prompt, no browser, no snooze: the updater never opens a page or adds a button.
for banned in ['ACTION_VIEW', 'snooze', 'play.google.com', 'Remind me', 'remind me later.']:
    assert banned not in updater, banned
assert 'addAction(' not in updater  # no notification action button
assert 'no download prompt' in updater and 'no fourth reminder' in updater
assert 'cannot install silently' in updater
assert 'startForegroundService' in updater
assert 'installDownloadedUpdate572' in java and 'ACTION_INSTALL' in updater
assert 'FileProvider.getUriForFile' in java
assert '"application/vnd.android.package-archive"' in java
assert 'REQUEST_INSTALL_PACKAGES' in android
assert 'app.lovelycrxshx.kuro.updates572' in android and 'kuro_updates572_paths' in android
assert 'KuroUpdaterJobService' in android and 'KuroUpdaterDownloadService' in android
assert 'foregroundServiceType="dataSync"' in android
assert '<files-path name="kuro_updates572" path="updates/" />' in paths
assert 'STOP_FOREGROUND_REMOVE' in download and 'startForeground(' in download
assert 'START_NOT_STICKY' in download
# The APK is only accepted from GitHub over HTTPS, and only inside the app folder.
assert 'allowedHost' in updater and 'objects.githubusercontent.com' in updater
assert 'updates/' in updater or '"updates"' in updater
assert 'case "updates572":showUpdater572();' in java
assert 'updates572' in settings and 'Kuro updates' in settings

# --- no secrets or licensed binaries in this source tree ------------------
for name in ['keystore', '.jks', '.keystore', '.p12', 'discord_partner_sdk.aar']:
    assert not list(r.rglob('*' + name)), 'unexpected secret/vendor file ' + name
for leak in ['KS_PASS=', 'storePassword ', '.sfz', 'BEGIN PRIVATE KEY']:
    assert leak not in build and leak not in updater

print('PASS 5.72: exact resume/Restart bound to trustworthy players, independent card dim/soften with '
      'preview+apply+cancel, native-only fit/crop, package/version/signer preflight, three reminders then '
      'in-app download, and no installer or browser shortcut')

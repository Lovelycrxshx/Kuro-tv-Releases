'use strict';
// Simulates the AndroidX frame-local message contract in real cross-origin
// Chromium iframes. This is not an Android WebView or a live-provider test.
const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const dir=path.resolve(__dirname,'../assets'),movie=fs.readFileSync(path.join(__dirname,'fixtures/fx-controls559.webm'));
const ai=fs.readFileSync(path.join(dir,'ai-upscale540.js'),'utf8'),fx=fs.readFileSync(path.join(dir,'video-effects537.js'),'utf8'),bridge=fs.readFileSync(path.join(dir,'fx-frame559.js'),'utf8');
const cfg={enabled:true,ai:true,aiStrength:100,preset:'A+A',detail:8,gain:100,visible:true};
(async()=>{const browser=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--autoplay-policy=no-user-gesture-required']});try{
 const page=await browser.newPage({viewport:{width:320,height:180}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript({content:`if(location.origin==='https://megaplay.buzz'){window.__kuroFxEpoch559=42;window.__messages559=[];window.KuroFx559={postMessage:function(s){window.__messages559.push(s)}};${ai}\n${fx}\n${bridge}\n}`});
 await page.route('**/*',r=>{let u=new URL(r.request().url());if(u.pathname==='/movie.webm')return r.fulfill({status:200,contentType:'video/webm',body:movie});if(u.pathname==='/parent')return r.fulfill({status:200,contentType:'text/html',body:'<style>html,body,iframe{margin:0;border:0;width:320px;height:180px}</style><iframe src="https://megaplay.buzz/player"></iframe>'});if(u.pathname==='/player')return r.fulfill({status:200,contentType:'text/html',body:'<style>html,body{margin:0}video{display:block;width:320px;height:180px}</style><video controls src="/movie.webm"></video>'});return r.abort()});
 await page.goto('https://kuro.local/parent');let frame=page.frames().find(f=>f.url().includes('megaplay.buzz'));assert(frame);await frame.waitForFunction(()=>document.querySelector('video').readyState>=2&&window.__messages559.includes('ready:42'));
 assert.equal(await page.evaluate(()=>typeof window.__kuroFx537),'undefined','parent cannot access/owns no child video');assert.equal(await frame.evaluate(()=>window.__messages559.filter(x=>x==='ready:42').length),1);
 const send=async command=>frame.evaluate(command=>window.KuroFx559.onmessage({data:JSON.stringify(command)}),command);
 await send({version:558,settings:cfg});assert.equal(await frame.locator('canvas[data-kuro-fx]').count(),0,'wrong protocol is ignored');
 await send({version:559,settings:[]});assert.equal(await frame.locator('canvas[data-kuro-fx]').count(),0,'malformed command is ignored');
 await send({version:559,settings:cfg});await frame.waitForFunction(()=>JSON.parse(window.__kuroFx537.status()).ai==='active');assert.equal(await frame.locator('canvas[data-kuro-fx]').count(),1);
 const st=await frame.evaluate(()=>window.__messages559.filter(x=>x.startsWith('status:42:')).map(x=>JSON.parse(x.slice('status:42:'.length))));assert(st.some(x=>x.video==='active'&&x.ai==='active'),'epoch-bound child status reports actual renderer');
 const processed=await page.screenshot();await send({version:559,settings:{...cfg,compare:true}});await page.waitForTimeout(80);const original=await page.screenshot();assert(!processed.equals(original),'nested enhancement is visible in the actual compositor');assert.equal(await frame.evaluate(()=>JSON.parse(window.__kuroFx537.status()).video),'compare');
 await send({version:559,settings:{...cfg,compare:false}});assert.equal(await frame.evaluate(()=>JSON.parse(window.__kuroFx537.status()).video),'active');
 await send({version:559,settings:{...cfg,visible:false}});assert.equal(await frame.evaluate(()=>JSON.parse(window.__kuroFx537.status()).video),'paused');await send({version:559,settings:{...cfg,enabled:false}});assert.equal(await frame.locator('canvas[data-kuro-fx]').count(),0);
 // A readable frame-local origin does not authorize the video CDN's pixels.
 await frame.evaluate(()=>{let v=document.querySelector('video');v.src='https://foreign.example/movie.webm';v.load()});await frame.waitForFunction(()=>document.querySelector('video').readyState>=2);await send({version:559,settings:cfg});assert.equal(await frame.evaluate(()=>JSON.parse(window.__kuroFx537.status()).video),'color');assert.equal(await frame.evaluate(()=>JSON.parse(window.__kuroFx537.status()).ai),'unavailable');assert.equal(await frame.locator('canvas[data-kuro-fx]').count(),0);assert((await frame.locator('video').evaluate(v=>getComputedStyle(v).filter)).includes('saturate'));
 await frame.evaluate(()=>window.dispatchEvent(new Event('pagehide')));assert(await frame.evaluate(()=>window.__messages559.includes('bye:42')));
 assert.deepEqual(errors,[]);console.log('PASS epoch-bound frame-local message contract, real nested-frame compositing, compare, cleanup and CORS color-only fallback');
 }finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});

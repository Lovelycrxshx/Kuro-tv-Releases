const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const guard=path.resolve(__dirname,'../assets/player-ad-guard541.js');
const root=http.createServer((req,res)=>{
 res.setHeader('Content-Type','text/html; charset=utf-8');
 if(req.url==='/challenge')return res.end('<!doctype html><title>Verify you are human</title><div id="challenge-form">Human verification</div><div class="ad-popup" id="must-stay">Challenge content</div>');
 if(req.url==='/nested')return res.end('<!doctype html><video id="nested-video"></video><div class="ad-overlay" id="nested-ad">ad panel</div>');
 return res.end(`<!doctype html><title>Player fixture</title><style>
  #player{position:relative;width:360px;height:240px;background:#111}
  #fake-message{position:absolute;top:8px;left:8px;width:280px;height:65px;background:white}
  #protected-player{position:absolute;width:160px;height:70px}
  </style><div id="player"><video id="video" controls></video><div class="video-controls" id="controls"><button aria-label="Play">Play</button><span>Ad</span></div><div id="subtitle"><span>Ad</span></div></div>
  <div id="legit-modal"><span>Welcome</span><button>×</button></div>
  <div class="ad-overlay" id="protected-player"><video id="another-video"></video></div>
  <iframe id="frame" src="http://localhost:${root.address().port}/nested"></iframe>`);
});
(async()=>{
 await new Promise(r=>root.listen(0,'127.0.0.1',r));let browser;
 try{
  browser=await chromium.launch({headless:true,args:['--no-sandbox']});
  const ctx=await browser.newContext({viewport:{width:393,height:852}});await ctx.addInitScript({path:guard});const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.goto(`http://127.0.0.1:${root.address().port}/`);
  await page.evaluate(()=>{let ad=document.createElement('div');ad.id='fake-message';ad.innerHTML='<span>Ad</span><strong>1 Message from [Missy]</strong><p>Hi dear! Wanna meet today?</p><button>×</button>';document.querySelector('#player').appendChild(ad)});
  await page.waitForFunction(()=>document.querySelector('#fake-message')?.getAttribute('data-kuro-ad-hidden')==='1');
  assert.equal(await page.locator('#fake-message').evaluate(e=>getComputedStyle(e).display),'none','screenshot-style ad hidden');
  assert.equal(await page.locator('#video').count(),1,'video retained');assert.equal(await page.locator('#controls').evaluate(e=>getComputedStyle(e).display),'block','playback controls kept');
  assert.equal(await page.locator('#subtitle').evaluate(e=>getComputedStyle(e).display),'block','ordinary subtitle not hidden');
  assert.equal(await page.locator('#legit-modal').evaluate(e=>getComputedStyle(e).display),'block','unlabelled legitimate popup retained');
  assert.equal(await page.locator('#protected-player').evaluate(e=>getComputedStyle(e).display),'block','never hide container that owns video');
  const nested=page.frameLocator('#frame');await nested.locator('#nested-ad').waitFor({state:'hidden'});assert.equal(await nested.locator('#nested-video').count(),1,'per-frame video kept');
  const challenge=await ctx.newPage();await challenge.goto(`http://127.0.0.1:${root.address().port}/challenge`);await challenge.waitForTimeout(400);
  assert.equal(await challenge.locator('#must-stay').evaluate(e=>getComputedStyle(e).display),'block','verification document left alone');
  assert.deepEqual(errors,[],'guard must not throw in page');
  console.log('PASS synthetic ad overlay, close-labelled fake message, nested frame, player controls and verification protection');
 }finally{if(browser)await browser.close();root.close()}
})().catch(e=>{console.error(e);process.exitCode=1});

'use strict';
// Headless WebView-like regression for the independent Anime/History background
// dim and soften controls. No real phone, provider or Discord account is used.
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path'), assert = require('assert');
const root = path.resolve(__dirname, '../assets');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.jpg': 'image/jpeg', '.png': 'image/png', '.svg': 'image/svg+xml' };
const server = http.createServer((req, res) => {
  const name = new URL(req.url, 'http://localhost').pathname.slice(1) || 'index.html', file = path.resolve(root, name);
  if (!file.startsWith(root + path.sep)) return res.writeHead(403).end();
  fs.readFile(file, (e, data) => e ? res.writeHead(404).end() : res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream' }).end(data));
});
(async () => {
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  let browser;
  try {
    browser = await chromium.launch({ headless: true, executablePath: process.env.KURO_CHROMIUM || undefined, args: ['--no-sandbox'] });
    const ctx = await browser.newContext({ viewport: { width: 393, height: 852 }, isMobile: true, hasTouch: true });
    const page = await ctx.newPage(), errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.addInitScript(() => {
      const replies = {}, actualFetch = window.fetch.bind(window);
      if (!localStorage.getItem('fixture572')) {
        localStorage.setItem('fixture572', 'yes');
        localStorage.setItem('kuro-profile-v1', JSON.stringify({ name: 'Test User', avatar: 'profile-avatar547-b.jpg', banner: 'profile-banner547.jpg', customField: 'keep me' }));
        // One card already has saved values; the other must stay independent.
        localStorage.setItem('kuro-profile-card-art-v1', JSON.stringify({
          anime: 'profile-card548-anime-b.jpg', history: 'profile-card548-history-b.jpg',
          historyDim: 20, historySoften: 6, unrelatedKey: { keep: true }
        }));
        localStorage.setItem('kuro-library', JSON.stringify([{ source: 'ms', title: 'Saved', url: 'https://hianime.ms/anime/saved' }]));
      }
      window.fetch = (input, opts) => { let u = typeof input === 'string' ? input : input.url; if (u.startsWith('/result/')) return Promise.resolve(new Response(replies[decodeURIComponent(u.slice(8))] || '', { status: 200 })); return actualFetch(input, opts); };
      const finish = (id, data, error = '') => { if (!error) replies[id] = typeof data === 'string' ? data : JSON.stringify(data); setTimeout(() => window.__nativeResult(id, error), 0); };
      const con = { local: { connected: true, exists: true, name: 'fixture@example.invalid' }, discord: { connected: false }, mal: { connected: false }, anilist: { connected: false } };
      window.KuroNative = {
        account(id, action) { if (action === 'status') finish(id, { config: { mal: '', discord: '', anilist: '' }, connections: con }); else finish(id, null, 'Unsupported fixture'); },
        get(id) { finish(id, '<html><body></body></html>'); }, news(id) { finish(id, { items: [], failed: [], checkedAt: Date.now() }); },
        newsSettings() { return JSON.stringify({ enabled: false, allowed: false }); },
        adultMetadata(id) { finish(id, { data: { a: { media: [] }, m: { media: [] } } }); },
        profileHeader560() { }, applySettings560() { }, settingsAction560() { }, discordRpcEnabled563() { return false; },
        discordOptions564() { return '{}'; }, setDiscordOption564() { return true; }, backupFile560() { }
      };
    });
    await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);
    await page.waitForSelector('#header-login.is-profile560 img');

    const cardVars = () => page.evaluate(() => {
      const read = sel => { const el = document.querySelector(sel); return { dim: el.style.getPropertyValue('--profile-card-dim571'), soften: el.style.getPropertyValue('--profile-card-soften571'), zoom: el.style.getPropertyValue('--profile-card-zoom571') }; };
      return { anime: read('#profile-anime'), history: read('#profile-history') };
    });

    // Saved values are painted on load, and each card keeps its own.
    await page.evaluate(() => nav('profile'));
    await page.waitForSelector('#profile-characters549');
    let vars = await cardVars();
    assert.deepEqual(vars.anime, { dim: '1.000', soften: '0px', zoom: '1.000' });
    assert.deepEqual(vars.history, { dim: '0.800', soften: '6px', zoom: '1.024' });

    // The picker only offers the sliders on the Anime and History tabs.
    await page.click('#profile-characters549');
    await page.waitForSelector('#profile-presets571 .preset-choice571');
    assert.equal(await page.locator('.preset-adjust571').isVisible(), false);
    await page.locator('.preset-tabs571 [data-tab=anime]').click();
    assert.equal(await page.locator('.preset-adjust571').isVisible(), true);
    assert.equal(await page.textContent('[data-adjust-title]'), 'Anime background');
    assert.equal(await page.inputValue('[data-adjust="dim"]'), '0');
    assert.equal(await page.inputValue('[data-adjust="soft"]'), '0');
    await page.locator('.preset-tabs571 [data-tab=history]').click();
    assert.equal(await page.textContent('[data-adjust-title]'), 'History background');
    assert.equal(await page.inputValue('[data-adjust="dim"]'), '20');
    assert.equal(await page.inputValue('[data-adjust="soft"]'), '6');
    await page.locator('.preset-tabs571 [data-tab=avatar]').click();
    assert.equal(await page.locator('.preset-adjust571').isVisible(), false);

    // Moving the Anime sliders previews live, without writing anything.
    await page.locator('.preset-tabs571 [data-tab=anime]').click();
    await page.locator('[data-adjust="dim"]').fill('45');
    await page.locator('[data-adjust="soft"]').fill('8');
    let preview = await page.evaluate(() => ({
      anime: getComputedStyle(document.querySelector('[data-preview="anime"]')).filter,
      animeTransform: getComputedStyle(document.querySelector('[data-preview="anime"]')).transform,
      history: getComputedStyle(document.querySelector('[data-preview="history"]')).filter
    }));
    const brightness = text => { const m = /brightness\(([0-9.]+)\)/.exec(text); return m ? parseFloat(m[1]) : NaN; };
    assert(Math.abs(brightness(preview.anime) - 0.65 * 0.55) < 0.002, 'anime preview brightness ' + preview.anime);
    assert(preview.anime.includes('blur(8px)'), 'anime preview blur ' + preview.anime);
    assert(Math.abs(brightness(preview.history) - 0.65 * 0.8) < 0.002, 'history preview brightness ' + preview.history);
    assert(preview.history.includes('blur(6px)'), 'history preview blur ' + preview.history);
    assert.notEqual(preview.animeTransform, 'none');
    assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('kuro-profile-card-art-v1')).animeDim), undefined);
    assert.equal(await page.textContent('[data-adjust-value="dim"]'), '45%');
    assert.equal(await page.textContent('[data-adjust-value="soft"]'), '8px');

    // Apply stores both cards' values and touches nothing else.
    await page.click('#profile-presets571 [data-apply]');
    await page.waitForSelector('#profile-characters549');
    const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('kuro-profile-card-art-v1')));
    assert.equal(saved.animeDim, 45);
    assert.equal(saved.animeSoften, 8);
    assert.equal(saved.historyDim, 20);
    assert.equal(saved.historySoften, 6);
    // Adjusting an older background must not force a new picture to be chosen.
    assert.equal(saved.anime, 'profile-card548-anime-b.jpg');
    assert.equal(saved.history, 'profile-card548-history-b.jpg');
    assert.deepEqual(saved.unrelatedKey, { keep: true });
    const profile = await page.evaluate(() => JSON.parse(localStorage.getItem('kuro-profile-v1')));
    assert.equal(profile.customField, 'keep me');
    assert.equal(profile.avatar, '');

    vars = await cardVars();
    assert.deepEqual(vars.anime, { dim: '0.550', soften: '8px', zoom: '1.032' });
    assert.deepEqual(vars.history, { dim: '0.800', soften: '6px', zoom: '1.024' });

    // Reopening shows the saved values.
    await page.click('#profile-characters549');
    await page.locator('.preset-tabs571 [data-tab=anime]').click();
    assert.equal(await page.inputValue('[data-adjust="dim"]'), '45');
    assert.equal(await page.inputValue('[data-adjust="soft"]'), '8');

    // Choosing a new picture and adjusting it in the same visit saves both.
    await page.locator('.preset-choice571').nth(2).click();
    await page.locator('[data-adjust="dim"]').fill('30');
    await page.click('#profile-presets571 [data-apply]');
    await page.waitForSelector('#profile-characters549');
    const combined = await page.evaluate(() => JSON.parse(localStorage.getItem('kuro-profile-card-art-v1')));
    assert.equal(combined.anime, 'preset571-b-003.jpg');
    assert.equal(combined.animeDim, 30);
    assert.equal(combined.animeSoften, 8);
    assert.equal(combined.historyDim, 20);
    assert.equal(combined.history, 'profile-card548-history-b.jpg');
    vars = await cardVars();
    assert.equal(vars.anime.dim, '0.700');

    // Cancel discards the preview and leaves storage alone.
    await page.click('#profile-characters549');
    await page.locator('.preset-tabs571 [data-tab=anime]').click();
    const before = await page.evaluate(() => localStorage.getItem('kuro-profile-card-art-v1'));
    await page.locator('[data-adjust="dim"]').fill('10');
    await page.locator('[data-adjust="soft"]').fill('20');
    await page.click('#profile-presets571 [data-cancel]');
    assert.equal(await page.evaluate(() => localStorage.getItem('kuro-profile-card-art-v1')), before);
    vars = await cardVars();
    assert.deepEqual(vars.anime, { dim: '0.700', soften: '8px', zoom: '1.032' });

    // Out-of-range and unclamped values fall back to the allowed steps.
    const clamped = await page.evaluate(() => ({
      dim: kuroPresets571.clampDim(999), soft: kuroPresets571.clampSoft(999),
      neg: kuroPresets571.clampDim(-20), odd: kuroPresets571.clampDim(43), oddSoft: kuroPresets571.clampSoft(7)
    }));
    assert.deepEqual(clamped, { dim: 80, soft: 20, neg: 0, odd: 45, oddSoft: 8 });

    // The 5.71 contract still holds: a two-argument commit keeps existing values.
    const legacy = await page.evaluate(() => {
      kuroPresets571.commit({ history: 'preset571-b-006.jpg' }, new Set(['history']));
      return JSON.parse(localStorage.getItem('kuro-profile-card-art-v1'));
    });
    assert.equal(legacy.historyDim, 20);
    assert.equal(legacy.historySoften, 6);
    assert.equal(legacy.animeDim, 30);
    assert.equal(legacy.animeSoften, 8);

    // Small screens keep the panel usable and inside the dialog.
    for (const [w, h] of [[280, 640], [320, 640], [393, 852]]) {
      await page.setViewportSize({ width: w, height: h });
      await page.waitForSelector('#profile-characters549');
      await page.click('#profile-characters549');
      await page.waitForSelector('#profile-presets571 .preset-choice571');
      await page.locator('.preset-tabs571 [data-tab=anime]').click();
      const box = await page.locator('#account-overlay .account-dialog').boundingBox();
      assert(box.x >= 0 && box.x + box.width <= w + 1, 'dialog overflow at ' + w);
      for (const sel of ['[data-adjust="dim"]', '[data-adjust="soft"]']) {
        const rect = await page.locator(sel).boundingBox();
        assert(rect.height >= 47.5, sel + ' touch height ' + JSON.stringify(rect));
      }
      assert(await page.evaluate(() => document.documentElement.scrollWidth) <= w + 1);
      await page.click('.artwork-picker571 .account-x');
    }
    assert.deepEqual(errors, []);
    console.log('PASS independent Anime/History dim and soften, live preview, apply/cancel, preserved values, clamping and small screens');
  } finally { if (browser) await browser.close(); server.close(); }
})().catch(e => { console.error(e); process.exitCode = 1; });

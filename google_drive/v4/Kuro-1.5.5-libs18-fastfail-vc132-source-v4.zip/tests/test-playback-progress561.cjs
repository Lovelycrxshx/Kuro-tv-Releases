'use strict';
// Exercises the actual bundled HLS script with a synthetic video; no provider is contacted.
const vm=require('vm'),fs=require('fs'),assert=require('assert'),path=require('path');
const script=fs.readFileSync(path.join(__dirname,'../assets/stream-player.js'),'utf8');
function run(startMs=45200,attempt=12,autoplay=1){
 const events={},windowEvents={},sent=[];
 const video={currentTime:0,duration:1200,ended:false,muted:true,volume:0,autoplay:false,canPlayType:()=>'',play:()=>Promise.resolve(),addEventListener:(name,fn)=>events[name]=fn};
 class Hls{constructor(){this.events={}}static isSupported(){return true}on(n,f){this.events[n]=f}attachMedia(){this.events.attached()}loadSource(){}}
 Hls.Events={ERROR:'error',MEDIA_ATTACHED:'attached',MANIFEST_PARSED:'manifest'};
 const src='https://www.zenkaitv.com/api/source?url='+encodeURIComponent('https://player.zilla-networks.com/m3u8/fixture');
 const location={search:'?src='+encodeURIComponent(src)+'&startMs='+startMs+'&attempt='+attempt+'&autoplay='+autoplay,href:'ok'};
 const window={Hls,KuroProgress561:{postMessage:data=>sent.push(JSON.parse(data))},addEventListener:(n,f)=>windowEvents[n]=f};
 vm.runInNewContext(script,{document:{getElementById:()=>video},window,Hls,location,URL,URLSearchParams,Number,Date,Math,JSON,encodeURIComponent});
 return {video,events,windowEvents,sent,location,window};
}
let x=run();x.events.pause();assert.equal(x.sent.length,0,'early pause must not erase an unapplied resume');x.events.loadedmetadata();assert.equal(x.video.currentTime,45.2);x.video.currentTime=47;x.events.timeupdate();assert.equal(x.sent.length,1);assert.deepEqual(x.sent[0],{attempt:12,position:47000,duration:1200000,ended:false});x.events.timeupdate();assert.equal(x.sent.length,1,'timeupdate reports are throttled');x.video.currentTime=60;x.events.pause();assert.equal(x.sent.at(-1).position,60000);x.video.currentTime=1200;x.video.ended=true;x.events.ended();assert.equal(x.sent.at(-1).ended,true);x.windowEvents.pagehide();assert.equal(x.sent.at(-1).ended,true,'pagehide must not restore a completed resume entry');
let paused=run(0,13,0);assert.equal(paused.video.autoplay,false,'autoplay off must not start new Web videos');paused.window.__kuroSetAutoplay561(true);assert.equal(paused.video.autoplay,true,'the live switch updates pending playback');paused.window.__kuroSetAutoplay561(false);assert.equal(paused.video.autoplay,false);let bad=run(100000000);bad.events.loadedmetadata();assert.equal(bad.video.currentTime,0);let negative=run(-40);negative.events.loadedmetadata();assert.equal(negative.video.currentTime,0);
console.log('PASS direct-player resume, throttled progress, completed and invalid resume fixtures');

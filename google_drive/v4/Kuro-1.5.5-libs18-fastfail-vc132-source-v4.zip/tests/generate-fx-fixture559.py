#!/usr/bin/env python3
"""Generate the original synthetic test image; no anime or third-party art.
The committed WebM was made from this JPEG using libvpx/VP8. This generator
is optional for running the tests (which use the committed WebM).
"""
from pathlib import Path
from PIL import Image, ImageDraw
import random

random.seed(559)
w, h = 320, 180
im = Image.new('RGB', (w, h))
p = im.load()
for y in range(h):
    for x in range(w):
        if y < 58 and x < 105:  # Fine, deterministic luminance noise.
            n = random.randint(-38, 38)
            p[x, y] = (max(0,min(255,122+n)),)*3
        elif y < 58 and x < 210:  # Moderate saturated colors.
            p[x,y] = ((145 + x//10)%225+20, 75+(y//3), 145+(x%20))
        elif y < 58:  # Gradient useful for contrast and brightness.
            v = 48 + (x-210)*150//109
            p[x,y] = (v, min(255,v+20), max(0,v-25))
        elif y < 120:
            p[x,y] = (180, 180, 180)
        else:
            p[x,y] = (78+(x//24)%3*45, 70+(y//14)%3*38, 120+(x//38)%3*40)
d = ImageDraw.Draw(im)
# Narrow dark outlines on a light background; line center is measurable.
for x in range(10, 311, 12):
    d.line((x, 62, x, 115), fill=(38,38,38), width=2)
d.rectangle((44,125,116,171), fill=(185,105,84), outline=(18,18,24), width=2)
d.ellipse((141,125,193,172), fill=(86,162,200), outline=(22,19,25), width=2)
d.polygon([(219,170),(244,122),(275,170)], fill=(173,106,190), outline=(24,18,25))
out = Path(__file__).parent/'fixtures'/'fx-controls559.jpg'
im.save(out, quality=96, subsampling=0)
print(out)

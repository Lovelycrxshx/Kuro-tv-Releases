const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const script=fs.readFileSync(path.resolve(__dirname,'../assets/player-ended553.js'),'utf8');
(async()=>{let browser=await chromium.launch({headless:true,args:['--no-sandbox']});try{
 const page=await browser.newPage();
 async function run(count,ended,duration,current){
  await page.goto('data:text/html,<html><body>'+Array(count).fill('<video></video>').join('')+'</body></html>');
  await page.evaluate(()=>{window.reports=[];window.KuroFinished553={postMessage:x=>reports.push(x)}});await page.addScriptTag({content:script});
  await page.evaluate(({ended,duration,current})=>{const v=document.querySelector('video');Object.defineProperties(v,{ended:{configurable:true,value:ended},duration:{configurable:true,value:duration},currentTime:{configurable:true,value:current}});v.dispatchEvent(new Event('ended'))},{ended,duration,current});return page.evaluate(()=>reports);
 }
 assert.deepEqual(await run(1,true,1440,1440),['ended']);assert.deepEqual(await run(1,false,1440,1440),[]);assert.deepEqual(await run(1,true,100,100),[]);assert.deepEqual(await run(1,true,1440,300),[]);assert.deepEqual(await run(2,true,1440,1440),[]);
 await page.goto('data:text/html,<html><body></body></html>');await page.setContent('<iframe srcdoc="<video></video>"></iframe>');const frame=page.frames().find(f=>f!==page.mainFrame());await frame.waitForSelector('video');await frame.evaluate(()=>{window.reports=[];window.KuroFinished553={postMessage:x=>reports.push(x)}});await frame.addScriptTag({content:script});await frame.evaluate(()=>{let v=document.querySelector('video');Object.defineProperties(v,{ended:{configurable:true,value:true},duration:{configurable:true,value:1440},currentTime:{configurable:true,value:1440}});v.dispatchEvent(new Event('ended'))});assert.deepEqual(await frame.evaluate(()=>reports),[],'child frames do not signal completion');
 console.log('PASS event-driven single top-frame completed video guard; short, unfinished, multiple and child videos ignored');
 }finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});

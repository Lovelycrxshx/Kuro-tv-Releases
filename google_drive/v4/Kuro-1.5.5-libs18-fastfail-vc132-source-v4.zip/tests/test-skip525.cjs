const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const assert = require('assert');
const listen = server => new Promise(resolve => server.listen(0, '127.0.0.1', () => resolve(server.address().port)));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
(async () => {
  let p1, p2;
  const serverA = http.createServer((req,res) => {
    res.setHeader('Content-Type','text/html');
    if (req.url === '/deep') {
      res.end(`<!doctype html><title>Deep player</title><button id="deep">Skip Ending</button><script>window.count=0;document.querySelector('button').onclick=()=>count++</script>`);
    } else {
      res.end(`<!doctype html><title>Player outer</title><iframe id="cross" allowfullscreen style="width:850px;height:580px" src="http://127.0.0.1:${p2}/player"></iframe><iframe style="width:250px;height:100px" src="http://127.0.0.1:${p2}/verification"></iframe>`);
    }
  });
  const serverB = http.createServer((req,res) => {
    res.setHeader('Content-Type','text/html');
    if (req.url === '/verification') {
      res.end(`<!doctype html><title>Verify you are human</title><div class="g-recaptcha"></div><button id="challenge">Skip</button><script>window.count=0;document.querySelector('button').onclick=()=>count++</script>`); return;
    }
    res.end(`<!doctype html><title>Cross origin player</title><style>button,.plain{display:block;margin:8px;height:28px} iframe{width:400px;height:80px} .hidden{display:none}</style>
      <button id="intro">Skip Intro</button><button id="bare">Skip</button><button id="credits">Skip credits »</button>
      <button id="ad">Skip ad</button><button id="hidden" class="hidden">Skip outro</button><button id="disabled" disabled>Skip intro</button><button id="verify">Skip verification</button>
      <div class="skip-plain"><span id="plain">Skip recap</span></div><div class="video-player"><video></video><div style="opacity:0"><button id="faded">Skip Intro</button><button id="faded-ad">Skip ad</button><button id="faded-bare">Skip</button></div></div><button id="fullscreen">Enter fullscreen</button>
      <iframe id="deepframe" src="http://127.0.0.1:${p1}/deep"></iframe>
      <script>Object.defineProperty(document.querySelector('video'),'paused',{get:()=>false});Object.defineProperty(document.querySelector('video'),'readyState',{get:()=>4});window.counts={};for(const e of document.querySelectorAll('button,.skip-plain')){e.addEventListener('click',()=>{counts[e.id||'plain']=(counts[e.id||'plain']||0)+1})};document.querySelector('#fullscreen').onclick=()=>document.documentElement.requestFullscreen();</script>`);
  });
  p1 = await listen(serverA); p2 = await listen(serverB);
  const browser = await chromium.launch({headless:true,args:['--no-sandbox']});
  const ctx = await browser.newContext({viewport:{width:1200,height:1000}});
  let peerList = [];
  await ctx.exposeBinding('__nativeReady', async ({frame}, request) => {
    if (request === 'ready') {
      if (!peerList.includes(frame)) peerList.push(frame);
      try { await frame.evaluate(() => window.KuroSkipState.onmessage({data:'off'})); } catch(_) {}
    } else if (request === 'bye') peerList = peerList.filter(peer => peer !== frame);
  });
  const prefix = `window.__kuroFrameMode=true;window.KuroSkipState={postMessage:function(message){window.__nativeReady(message)}};
    (function(){let pending=new Set();let set=window.setTimeout.bind(window),clear=window.clearTimeout.bind(window);window.setTimeout=function(cb,ms){let id=set(function(){pending.delete(id);cb()},ms);pending.add(id);return id};window.clearTimeout=function(id){pending.delete(id);clear(id)};window.__pendingTimerCount=function(){return pending.size}})();\n`;
  await ctx.addInitScript({content:prefix + fs.readFileSync('assets/auto-skip.js','utf8')});
  const page = await ctx.newPage();
  await page.goto(`http://127.0.0.1:${p1}/`); await delay(500);
  const player=page.frames().find(f=>f.url().endsWith('/player'));
  const deep=page.frames().find(f=>f.url().endsWith('/deep'));
  const verification=page.frames().find(f=>f.url().endsWith('/verification'));
  assert(player && deep && verification,'test frames loaded');
  assert(peerList.length>=4,`expected each frame to register: ${peerList.length}`);
  await delay(2200);
  assert.deepStrictEqual(await player.evaluate(()=>window.counts),{},'off: no player clicks');
  assert.equal(await deep.evaluate(()=>window.count),0,'off: no deep clicks');
  assert.equal(await player.evaluate(()=>window.__pendingTimerCount()),0,'off: no running detector timer');
  for(const f of peerList) await f.evaluate(()=>window.KuroSkipState.onmessage({data:'on'}));
  await delay(2500);
  let c=await player.evaluate(()=>window.counts), deepCount=await deep.evaluate(()=>window.count), blockedCount=await verification.evaluate(()=>window.count);
  console.log('enabled counts:',c,'cross-origin nested:',deepCount,'verification:',blockedCount);
  for(const id of ['intro','bare','credits','ad','plain','faded']) assert.equal(c[id],1,`${id} clicked once`);
  for(const id of ['hidden','disabled','verify','faded-ad','faded-bare']) assert(!c[id],`${id} must not be clicked`);
  assert.equal(deepCount,1,'independently injected cross-origin grandchild clicked');
  assert.equal(blockedCount,0,'verification frame left alone');
  await player.locator('#fullscreen').click();
  assert.equal(await player.evaluate(()=>!!document.fullscreenElement),true,'HTML fullscreen active');
  await player.evaluate(()=>{let e=document.createElement('button');e.id='late';e.textContent='Skip opening';e.onclick=()=>{window.counts.late=(window.counts.late||0)+1};document.body.prepend(e)});
  await delay(2300);
  assert.equal((await player.evaluate(()=>window.counts)).late,1,'late fullscreen Skip control clicked');
  for(const f of peerList) await f.evaluate(()=>window.KuroSkipState.onmessage({data:'off'}));
  await player.evaluate(()=>{let e=document.createElement('button');e.id='offlate';e.textContent='Skip';e.onclick=()=>{window.counts.offlate=(window.counts.offlate||0)+1};document.body.prepend(e)});
  await delay(2300);
  c=await player.evaluate(()=>window.counts);
  assert(!c.offlate,'off again: no clicks');
  assert.equal(await player.evaluate(()=>window.__pendingTimerCount()),0,'off again: detector timer cleared');
  console.log('PASS: frame registration, toggle off/on/off, generic labels, hidden/disabled/verification, HTML fullscreen, pending timers');
  await browser.close();await new Promise(r=>serverA.close(r));await new Promise(r=>serverB.close(r));
})().catch(err=>{console.error(err);process.exit(1)});

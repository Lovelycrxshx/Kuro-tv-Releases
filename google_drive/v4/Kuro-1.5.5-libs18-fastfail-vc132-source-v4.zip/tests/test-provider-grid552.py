#!/usr/bin/env python3
"""Static and packaged asset checks. Browser geometry is tested separately."""
from pathlib import Path
import sys,zipfile
root=Path(__file__).resolve().parents[1]
css=(root/'assets/accounts542.css').read_text();js=(root/'assets/accounts542.js').read_text()
assert '.account-provider-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}' in css
provider_grid=css.split('.account-provider-grid{',1)[1].split('}',1)[0]
assert 'repeat(4,' not in provider_grid
for provider in ('discord','mal','anilist'):assert js.count(f'data-signin="{provider}"')==1
assert 'data-signin="google"' not in js and 'supabase' not in js.lower()
if len(sys.argv)>1:
 with zipfile.ZipFile(sys.argv[1]) as z:
  for name in ('accounts542.css','accounts542.js'):
   assert z.read('assets/'+name)==(root/'assets'/name).read_bytes(),name
  assert z.testzip() is None
print('PASS three equal provider columns and (if supplied) exact packaged assets')

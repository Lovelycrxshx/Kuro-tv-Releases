const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets');
const types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html';const file=path.resolve(root,name);if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return}fs.readFile(file,(e,data)=>e?res.writeHead(404).end():res.writeHead(200,{'content-type':types[path.extname(file)]||'application/octet-stream'}).end(data))});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});let ctx=await browser.newContext({viewport:{width:393,height:852},deviceScaleFactor:1,isMobile:true,hasTouch:true});const page=await ctx.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  const responses={},nativeFetch=window.fetch.bind(window);
  window.fetch=(input,opts)=>{let u=typeof input==='string'?input:input.url;if(u.startsWith('/result/'))return Promise.resolve(new Response(responses[decodeURIComponent(u.slice(8))]||'',{status:200}));return nativeFetch(input,opts)};
  window.KuroNative={get(id){responses[id]='<html><body></body></html>';setTimeout(()=>window.__nativeResult(id,''),0)},news(id){responses[id]=JSON.stringify({items:[],failed:[],checkedAt:Date.now()});setTimeout(()=>window.__nativeResult(id,''),0)},newsSettings(){return JSON.stringify({enabled:true,allowed:true})},setNewsAlerts(){},openNewsUrl(){}};
 });
 await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);await page.waitForSelector('nav.kuro-dock');
 const expected=[['home','Home','Find your next obsession'],['library','My Lists','My library'],['search','Browse','Browse anime'],['simulcasts','Simulcasts','Simulcasts'],['profile','Account','Profile']];
 assert.deepEqual(await page.locator('nav button span').allTextContents(),expected.map(x=>x[1]),'five labels and order retained');
 assert.equal(await page.locator('nav button[aria-current="page"]').getAttribute('data-nav'),'home','home has current-page state');
 for(let [route,,heading] of expected){await page.locator(`nav button[data-nav="${route}"]`).click();assert((await page.locator('main h1').first().innerText()).includes(heading),route+' opens the expected page');assert.equal(await page.locator('nav button[aria-current="page"]').count(),1);assert.equal(await page.locator('nav button[aria-current="page"]').getAttribute('data-nav'),route)}
 for(const [width,height] of [[280,640],[320,640],[360,740],[393,852],[768,1024],[640,360]]){
  await page.setViewportSize({width,height});const result=await page.evaluate(()=>{let d=document.querySelector('nav.kuro-dock').getBoundingClientRect();return {dock:{left:d.left,right:d.right,top:d.top,bottom:d.bottom},vw:innerWidth,vh:innerHeight,document:document.documentElement.scrollWidth,buttons:[...document.querySelectorAll('nav.kuro-dock button')].map(b=>{let r=b.getBoundingClientRect(),t=b.querySelector('span').getBoundingClientRect();return {w:r.width,h:r.height,left:r.left,right:r.right,tw:t.width,center:t.left+t.width/2}})}});
  assert(result.dock.left>=0&&result.dock.right<=width&&result.dock.bottom<=height,`dock visible at ${width}x${height}`);assert(result.document<=width+1,`no horizontal overflow at ${width}`);
  for(let i=0;i<result.buttons.length;i++){const b=result.buttons[i];assert(b.w>=48&&b.h>=48,`touch target ${i} at ${width} is ${b.w}x${b.h}`);assert(b.tw<=b.w+0.2&&b.center>=b.left&&b.center<=b.right,`label ${i} fits at ${width}`);if(i>0)assert(b.left>=result.buttons[i-1].right-0.2,`buttons don't overlap at ${width}`)}
 }
 await page.emulateMedia({reducedMotion:'reduce'});assert.equal(await page.locator('nav button').first().evaluate(x=>getComputedStyle(x).transitionDuration),'0s','reduced-motion preference');await page.emulateMedia({reducedMotion:'no-preference'});
 await page.setViewportSize({width:393,height:852});await page.locator('nav button[data-nav="home"]').click();
 if(process.env.KURO_DOCK_SCREENSHOT){let b=await page.locator('nav.kuro-dock').boundingBox();await page.screenshot({path:process.env.KURO_DOCK_SCREENSHOT,animations:'disabled',clip:{x:0,y:Math.max(0,b.y-10),width:393,height:Math.min(852,852-Math.max(0,b.y-10))}})}
 await page.locator('nav button[data-nav="profile"]').click();await page.click('#header-notice');await page.waitForSelector('#news-posts');assert.equal(await page.locator('nav button[aria-current="page"]').getAttribute('data-nav'),'profile','news overlay preserves underlying tab');await page.click('#news-back');assert.equal(await page.locator('nav button[aria-current="page"]').getAttribute('data-nav'),'profile','back from bell restores tab');
 assert.deepEqual(errors,[],'no uncaught JS errors');console.log('PASS custom dock: five destinations, active/ARIA state, news back, safe widths, touch targets and reduced motion');
 }finally{if(browser)await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

#!/usr/bin/env python3
"""5.60 packaging and preference schema contract; real-device behavior is separate."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
assets=root/'assets';main=(root/'src/app/lovelycrxshx/kuro/MainActivity.java').read_text();prefs=(root/'src/app/lovelycrxshx/kuro/KuroPreferences560.java').read_text();js=(assets/'settings560.js').read_text();backup=(assets/'backup560.js').read_text()
native_keys=set()
for name in ('BOOLEANS','STRINGS','INTS'):
 match=re.search(r'String\[\]\s+'+name+r'=\{([^}]*)\}',prefs);assert match,name
 native_keys.update(re.findall(r'"([\w]+)"',match.group(1)))
js_choices=re.search(r'const choices=\{(.*?)\};',js,re.S);assert js_choices
js_keys=set(re.findall(r'(?:^|,)([A-Za-z][A-Za-z0-9]*):\[',js_choices.group(1)))
assert len(native_keys)==19 and native_keys==js_keys,(native_keys-js_keys,js_keys-native_keys)
for filename in ('settings560.js','backup560.js','profile-settings560.css'):
 assert (assets/filename).is_file() and ('"/'+filename+'"') in main
html=(assets/'index.html').read_text();assert all(name in html for name in ('settings560.js','backup560.js','profile-settings560.css'))
ns='{http://schemas.android.com/apk/res/android}';manifest=ET.parse(root/'AndroidManifest.xml').getroot();activity=manifest.find('./application/activity')
assert manifest.attrib[ns+'versionCode']=='71' and manifest.attrib[ns+'versionName']=='5.71'
assert activity.attrib[ns+'supportsPictureInPicture']=='true' and activity.attrib[ns+'resizeableActivity']=='true'
assert all(name in activity.attrib[ns+'configChanges'] for name in ('orientation','screenSize'))
assert any(x.attrib.get(ns+'name')=='android.permission.POST_NOTIFICATIONS' for x in manifest.findall('uses-permission'))
assert 'windowLightNavigationBar' not in (root/'res/values/styles.xml').read_text()
assert 'windowLightNavigationBar' in (root/'res/values-v27/styles.xml').read_text()
assert "group('Player and alerts'" not in js
assert all(k in js for k in ('server1','server2','server3','audio','errorAlerts','keepOn'))
assert 'Discord Rich Presence' in js and 'data-rpc563' in js and 'Off by default' in js and 'not included here' not in js
assert 'kuro-local-import-journal560-v1' in backup and 'options.applySettings===true' in backup
assert 'POST_NOTIFICATIONS' in main and 'isInPictureInPictureMode()' in main
print('PASS 5.71 removed section, retained old preferences, packaged settings assets, 19-field JS/native schema, PiP and notification declarations, local backup and honest presence notice')

const installLegacy532=require('./legacy-ui-harness.cjs');
const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets'),types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png'};
const server=http.createServer((req,res)=>{let p=path.resolve(root,new URL(req.url,'http://localhost').pathname.slice(1)||'index.html');if(!p.startsWith(root+path.sep))return res.writeHead(403).end();fs.readFile(p,(e,b)=>e?res.writeHead(404).end():res.writeHead(200,{'content-type':types[path.extname(p)]||'text/plain'}).end(b))});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});let page=await browser.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true});let errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  let replies={},nativeFetch=window.fetch.bind(window);window.__fixture={plays:[],updates:[],calls:[],map:{}};
  window.fetch=(input,opts)=>{let u=typeof input==='string'?input:input.url;return u.startsWith('/result/')?Promise.resolve(new Response(replies[decodeURIComponent(u.slice(8))]||'',{status:200})):nativeFetch(input,opts)};
  const entries={20:{id:20,idMal:20,isAdult:false,title:{romaji:'NARUTO',english:'Naruto'},synonyms:[]},21:{id:21,idMal:21,isAdult:false,title:{romaji:'ONE PIECE',english:'ONE PIECE'},synonyms:[]},135584:{id:135584,idMal:49430,isAdult:true,title:{romaji:'Mignon'},synonyms:[]},88:{id:88,idMal:88,isAdult:null,title:{romaji:'Unknown'},synonyms:[]},195604:{id:195604,idMal:61967,isAdult:false,title:{romaji:'Black Clover 2nd Season',english:'Black Clover Season 2'},synonyms:[]}};
  window.KuroNative={get(id,url){window.__fixture.calls.push(url);let out=window.__fixture.map[url];if(out===undefined)out='<div></div>';setTimeout(()=>{if(out&&out.error)window.__nativeResult(id,out.error);else{replies[id]=typeof out==='string'?out:JSON.stringify(out);window.__nativeResult(id,'')}},0)},adultMetadata(id,encoded){let ids=JSON.parse(encoded),a=(ids.anilist||[]).map(n=>entries[n]).filter(Boolean),m=(ids.mal||[]).map(n=>Object.values(entries).find(x=>x.idMal===n)).filter(Boolean);setTimeout(()=>{replies[id]=JSON.stringify({data:{a:{media:a},m:{media:m}}});window.__nativeResult(id,'')},0)},play(payload){window.__fixture.plays.push(JSON.parse(payload))},addServers(id,payload){window.__fixture.updates.push({session:id,...JSON.parse(payload)})}};
 });
 await installLegacy532(page);await page.goto(`http://127.0.0.1:${server.address().port}/`);await page.waitForFunction(()=>typeof classifyAdded==='function'&&typeof failoverAdapters==='object');
 assert.equal(await page.locator('[data-source]').count(),13,'all thirteen selectable libraries');
 for(const width of [280,320,393,768]){await page.setViewportSize({width,height:852});assert((await page.evaluate(()=>document.documentElement.scrollWidth))<=width+1,'source buttons do not overflow at '+width)}
 const gates=await page.evaluate(async()=>{
  const rows=[{title:'Naruto',anilistId:20},{title:'Mignon',anilistId:135584},{title:'Unknown',anilistId:88},{title:'Impersonator',anilistId:20},{title:'Naruto',anilistId:20,adultSource:true},{title:'Naruto',anilistId:20,genres:['Hentai']}];
  return (await classifyAdded(rows)).map(x=>x.title);
 });assert.deepEqual(gates,['Naruto'],'adult, unknown, title mismatch and explicit adult flags are all hidden');
 await page.evaluate(()=>{let saved=[{title:'Naruto',source:'zenkai',anilistId:20,url:'https://www.zenkaitv.com/api/anilist/media?id=20'},{title:'Mignon',source:'zenkai',anilistId:135584,url:'https://www.zenkaitv.com/api/anilist/media?id=135584'}];localStorage.setItem('kuro-library',JSON.stringify(saved));listFilter='bookmarks';nav('library')});
 assert((await page.locator('main').innerText()).includes('Naruto'));assert(!(await page.locator('main').innerText()).includes('Mignon'),'stored adult entry remains hidden');assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-library')).length),2,'hiding adult entries does not erase stored data');

 const wixi=await page.evaluate(async()=>{
  let item={title:'Naruto',titles:['NARUTO'],url:'https://aniwixi.xyz/wp-json/aniwixi/v1/anilist/20',source:'wixi',anilistId:20};
  let data={status:'success',data:{info:{anilist_id:'20',title:{english:'Naruto',romaji:'NARUTO'},synopsis:'Story',genres:['Action']},episodes:[{episode_no:'1',title:'Episode 1',embed_url_short:'https://aniwixi.xyz/20/1'},{episode_no:'2',embed_url_short:'https://aniwixi.xyz/20/2'}]}};
  let detail=await addedDetails(item,JSON.stringify(data));window.__fixture.map['https://aniwixi.xyz/20/1/sub?lang=en']='var videoUrl = "https:\\/\\/video.example\\/one.m3u8"; var reqFormat = "sub";';
  let servers=await wixiServers(item,detail.episodes[0]);let mismatch=false;try{data.data.info.anilist_id='21';await addedDetails(item,JSON.stringify(data))}catch(_){mismatch=true}return {detail,servers,mismatch};
 });assert.equal(wixi.detail.episodes.length,2);assert.equal(wixi.servers.length,1);assert.equal(wixi.servers[0].lang,'sub');assert(!wixi.servers.some(x=>x.lang==='dub'),'an Arabic-default dub must not be labelled English');assert(wixi.mismatch,'detail ID mismatch rejected');
 const zen=await page.evaluate(async()=>{
  let item={title:'Naruto',titles:['NARUTO'],url:'https://www.zenkaitv.com/api/anilist/media?id=20',source:'zenkai',anilistId:20,zslug:'naruto'};
  window.__fixture.map['https://animeav1.com/media/naruto']='<h1>Naruto</h1><script>episodes:[{id:11,number:1},{id:12,number:2}]</script>';
  let d=await addedDetails(item,'{}'),url='https://www.zenkaitv.com/api/animeav1/sources?slug=naruto&episode=1&variant=SUB';
  let source='/api/source?url='+encodeURIComponent('https://player.zilla-networks.com/m3u8/abcdef')+'&refererHost=player.zilla-networks.com';
  window.__fixture.map[url]={ok:true,slug:'naruto',episode:1,variant:'SUB',sources:[{type:'direct',language:'es',videoUrl:source,skip:{intro:{start:12.5,end:90},outro:{start:1100,end:1200},bad:{start:-1,end:9}}}]};let servers=await zenkaiServers(item,d.episodes[0]);
  window.__fixture.map[url].episode=2;let wrongEpisode=await zenkaiServers(item,d.episodes[0]);return {d,servers,wrongEpisode};
 });assert.equal(zen.d.episodes.length,2);assert.equal(zen.servers[0].type,'hls');assert.equal(zen.servers[0].note,'Spanish subtitles');assert.deepEqual(zen.servers[0].skip,{intro:{start:12.5,end:90},outro:{start:1100,end:1200}},'only explicit valid source markers are passed through');assert.equal(zen.wrongEpisode.length,0,'wrong episode in resolver is rejected');
 const flix=await page.evaluate(async()=>{
  let b='https://hianimeq.top',item={title:'Black Clover Season 2',url:b+'/black-clover-season-2-episode-6/',source:'flix'};
  let original='<div class="anisc-detail"><h2 class="film-name"><a href="'+b+'/anime/black-clover-season-2/">Black Clover Season 2</a></h2></div>';
  window.__fixture.map[b+'/anime/black-clover-season-2/']='<div class="anisc-detail"><h2 class="film-name">Black Clover Season 2</h2></div><a class="btn-play" href="'+b+'/black-clover-season-2-episode-1/">Play</a>';
  window.__fixture.map[b+'/black-clover-season-2-episode-1/']='<div id="ani_detail" data-anime-id="123" data-id="101"></div>';
  window.__fixture.map[b+'/wp-json/v1/otakuthemes/episode/list/123']={status:true,html:'<a class="ep-item" data-number="1" data-id="101" href="'+b+'/black-clover-season-2-episode-1/">Episode 1</a><a class="ep-item" data-number="2" data-id="102" href="'+b+'/black-clover-season-2-episode-2/">Episode 2</a>'};
  window.__fixture.map[b+'/wp-json/v1/otakuthemes/episode/servers?episodeId=102']={status:true,html:'<a class="server-item" data-type="sub" data-hash="'+btoa('https://megaplay.buzz/stream/mal/61967/2/sub')+'"></a>'};
  let d=await flixDetail(item,original),eps=await flixEpisodes(d),play=await flixServers(eps[1]),rejected=false;try{await flixDetail({...item,title:'Black Clover'},original)}catch(_){rejected=true}return {eps,play,rejected};
 });assert.deepEqual(flix.eps.map(x=>x.number),['1','2']);assert.equal(flix.play.length,1);assert(flix.rejected,'different season is rejected');
 const chain=await page.evaluate(async()=>{
  let calls=[];legacyPrimary=async()=>[{url:'https://megaplay.buzz/start',lang:'dub',referer:'ms'}];
  for(const [s,_] of Object.entries(failoverAdapters))failoverAdapters[s]=async(title,num)=>{calls.push([s,title,num]);await new Promise(r=>setTimeout(r,5));return [{url:'https://megaplay.buzz/'+s,lang:'sub',referer:s},{url:'https://megaplay.buzz/'+s,lang:'sub',referer:s}]};
  selected={source:'ms',title:'Black Clover Season 2',url:'https://hianime.ms/details/black-clover',img:''};source='ms';episodes=[{number:'2',name:'A New Journey',url:'https://hianime.ms/watch/2'}];await openEpisode(episodes[0]);await new Promise(r=>setTimeout(r,90));
  return {calls,play:window.__fixture.plays.at(-1),updates:window.__fixture.updates,serverCount:servers.length,done:currentWatchChain.done};
 });assert.equal(chain.play.episode,'2');assert.equal(chain.play.episodeName,'A New Journey');assert.equal(chain.play.episodeIdentity,'https://hianime.ms/watch/2');assert.equal(chain.play.servers[0].lang,'dub','first available primary dub starts without waiting for other libraries');assert.equal(chain.calls.length,12,'all other adapters are considered in this synthetic harness');assert(chain.calls.every(x=>x[1]==='Black Clover Season 2'&&x[2]==='2'),'exact title and episode passed to every adapter');assert.equal(chain.serverCount,13,'duplicate server URLs are suppressed');assert(chain.done&&chain.updates.at(-1).done,'bounded search sends completion');
 const blocked=await page.evaluate(async()=>{
  window.__fixture.plays=[];window.__fixture.updates=[];let calls=[];legacyPrimary=async()=>[{url:'https://megaplay.buzz/start2',lang:'sub',referer:'ms'}];
  for(const s of Object.keys(failoverAdapters))failoverAdapters[s]=async()=>{calls.push(s);if(s==='dk')throw Error('Source returned HTTP 403');await new Promise(r=>setTimeout(r,25));return [{url:'https://megaplay.buzz/'+s,lang:'sub',referer:s}]};
  selected={source:'ms',title:'Naruto',url:'https://hianime.ms/details/naruto'};source='ms';episodes=[{number:'1',url:'https://hianime.ms/watch/1'}];await openEpisode(episodes[0]);await new Promise(r=>setTimeout(r,90));return {calls,updates:window.__fixture.updates,done:currentWatchChain.done,blocked:currentWatchChain.blocked,serverCount:servers.length};
 });assert(blocked.done&&blocked.blocked);assert(blocked.updates.some(x=>x.done&&x.blocked),'human verification stops the chain');assert(blocked.calls.length<=3,'no scheduling after blocked response');assert.equal(blocked.serverCount,1,'late in-flight results are ignored after verification');
 const prefetch=await page.evaluate(async()=>{
  window.__fixture.plays=[];unifiedVerificationBlocked.clear();legacyPrimary=async()=>{await new Promise(r=>setTimeout(r,40));return [{url:'https://megaplay.buzz/preferred-sub',lang:'sub',referer:'ms'}]};
  for(const s of Object.keys(failoverAdapters))failoverAdapters[s]=async()=>s==='dk'?[{url:'https://megaplay.buzz/prefetched-dub',lang:'dub',referer:'dk'}]:[];
  selected={source:'ms',title:'Naruto',url:'https://hianime.ms/details/naruto'};source='ms';episodes=[{number:'1',url:'https://hianime.ms/watch/1'}];await openEpisode(episodes[0]);await new Promise(r=>setTimeout(r,20));return window.__fixture.plays.at(-1);
 });assert.equal(prefetch.servers[prefetch.index].lang,'dub','already-resolved exact English dub is preferred without waiting for late sources');
 const race=await page.evaluate(async()=>{
  window.__fixture.plays=[];window.__fixture.updates=[];legacyPrimary=async(_s,ep)=>{if(ep.number==='1')await new Promise(r=>setTimeout(r,80));return [{url:'https://megaplay.buzz/ep'+ep.number,lang:'sub',referer:'ms'}]};
  for(const s of Object.keys(failoverAdapters))failoverAdapters[s]=async()=>[];
  selected={source:'ms',title:'Naruto',url:'https://hianime.ms/details/naruto'};source='ms';episodes=[{number:'1',name:'Older episode',url:'https://hianime.ms/watch/1'},{number:'2',name:'Newer episode',url:'https://hianime.ms/watch/2'}];let a=openEpisode(episodes[0]);await new Promise(r=>setTimeout(r,3));let b=openEpisode(episodes[1]);await Promise.all([a,b]);await new Promise(r=>setTimeout(r,100));return window.__fixture.plays.map(x=>({number:x.episode,name:x.episodeName,identity:x.episodeIdentity}));
 });assert.deepEqual(race,[{number:'2',name:'Newer episode',identity:'https://hianime.ms/watch/2'}],'stale first episode never starts or gives its metadata to the second');
 assert.deepEqual(errors,[]);console.log('PASS legacy-source adapter harness: thirteen-library legacy UI, fail-closed adult checks, source parsing, exact season/episode, Spanish label, bounded chain, verification stop and race cancellation');
 }finally{if(browser)await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

'use strict';
// Verifies the actually composited canvas respects the browser video fit/crop.
const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const fx=fs.readFileSync(path.join(__dirname,'../assets/video-effects537.js'),'utf8'),movie=fs.readFileSync(path.join(__dirname,'fixtures/fx-controls559.webm'));
const config={enabled:true,preset:'A',line:'off',detail:8,sharpen:0,denoise:0,saturation:100/1.04,contrast:100/1.04,brightness:100,deband:0,gain:100};
(async()=>{const b=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});try{
 let p=await b.newPage({viewport:{width:240,height:180},deviceScaleFactor:1}),errors=[];p.on('pageerror',e=>errors.push(e.message));
 await p.route('**/*',r=>{let u=new URL(r.request().url());if(u.pathname==='/movie.webm')return r.fulfill({status:200,contentType:'video/webm',body:movie});if(u.pathname==='/page')return r.fulfill({status:200,contentType:'text/html',body:'<style>html,body{margin:0;background:black}#box{position:relative;width:240px;height:180px}video{width:240px;height:180px;display:block;background:black}</style><div id="box"><video src="/movie.webm"></video></div>'});return r.abort()});
 await p.goto('https://kuro.local/page');await p.waitForFunction(()=>document.querySelector('video').readyState>=2);await p.addScriptTag({content:fx});
 async function decode(buf){return p.evaluate(async data=>{let im=new Image();im.src='data:image/png;base64,'+data;await im.decode();let c=document.createElement('canvas');c.width=im.width;c.height=im.height;let x=c.getContext('2d');x.drawImage(im,0,0);const d=x.getImageData(0,0,c.width,c.height).data;let s='';for(let i=0;i<d.length;i+=32768)s+=String.fromCharCode(...d.subarray(i,i+32768));return btoa(s)},buf.toString('base64')).then(x=>Buffer.from(x,'base64'))}
 for(const [fit,position] of [['fill','50% 50%'],['contain','50% 50%'],['cover','0% 50%'],['cover','100% 50%'],['none','50% 50%'],['scale-down','50% 50%']]){
  await p.evaluate(([fit,position])=>{let v=document.querySelector('video');v.style.objectFit=fit;v.style.objectPosition=position},[fit,position]);
  await p.evaluate(c=>window.__kuroFx537.configure({...c,compare:true}),config);await p.waitForTimeout(50);let raw=await decode(await p.screenshot());
  await p.evaluate(c=>window.__kuroFx537.configure({...c,compare:false}),config);await p.waitForTimeout(50);let out=await decode(await p.screenshot());
  // Headless Chrome can display an unrelated temporary cast button in the
  // top-left. Ignore that browser UI; half-pixel letterbox edges and decoder
  // color conversion account for small remaining rasterization differences.
  let sum=0,changed=0,count=0;for(let i=0;i<raw.length;i+=4){let n=i/4,x=n%240,y=Math.floor(n/240);if(x<60&&y<60)continue;let d=(Math.abs(raw[i]-out[i])+Math.abs(raw[i+1]-out[i+1])+Math.abs(raw[i+2]-out[i+2]))/3;sum+=d;count++;if(d>8)changed++}let avg=sum/count,portion=changed/count;assert(avg<4&&portion<.09,`${fit} ${position}: composite does not align with original (mean ${avg.toFixed(2)}, differing ${(portion*100).toFixed(1)}%)`);
 }
 assert.deepEqual(errors,[]);console.log('PASS displayed canvas matches video fill, contain, cover/position, none and scale-down geometry');
 }finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});

const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets'),types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml'};
const server=http.createServer((req,res)=>{const file=path.resolve(root,new URL(req.url,'http://localhost').pathname.slice(1)||'index.html');if(!file.startsWith(root+path.sep))return res.writeHead(403).end();fs.readFile(file,(e,b)=>e?res.writeHead(404).end():res.writeHead(200,{'content-type':types[path.extname(file)]||'text/plain'}).end(b))});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  const results={},fetch0=window.fetch.bind(window),offline=()=>({connected:false});
  const db=window.__fake553={connections:{local:offline(),discord:offline(),mal:offline(),anilist:offline()},sent:[],searches:[],conflict:true};
  window.fetch=(input,opts)=>{const u=typeof input==='string'?input:input.url;return u.startsWith('/result/')?Promise.resolve(new Response(results[decodeURIComponent(u.slice(8))]||'',{status:200})):fetch0(input,opts)};
  const finish=(id,data,error='')=>{if(!error)results[id]=typeof data==='string'?data:JSON.stringify(data);setTimeout(()=>window.__nativeResult(id,error),0)};
  window.KuroNative={
   get(id){finish(id,'<html><body></body></html>')},news(id){finish(id,{items:[],failed:[]})},newsSettings(){return '{}'},play(){},
   account(id,action,raw){const p=JSON.parse(raw);
    if(action==='status')return finish(id,{config:{},connections:JSON.parse(JSON.stringify(db.connections))});
    if(action==='trackerSearch'){db.searches.push(p.query);return finish(id,{items:[{title:'Beta Season 2',romaji:'Beta 2',year:2024,format:'TV',episodes:12,anilistId:301,malId:401}]})}
    if(action==='trackerSync'){
     db.sent.push(p);const conflict=db.conflict&&p.intent==='backfill'&&p.title==='Alpha';return finish(id,{updated:true,conflict,status:'CURRENT',progress:p.watched.length,anilistId:p.anilistId||301,malId:p.malId||401});
    }
    finish(id,null,'Unsupported fake operation');
   }
  };
 });
 await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);await page.waitForSelector('nav.kuro-dock');
 const alpha={title:'Alpha',source:'ms',url:'https://hianime.ms/details/alpha',anilistId:101,malId:201},beta={title:'Beta',source:'ms',url:'https://hianime.ms/details/beta'};
 await page.evaluate(({alpha,beta})=>{window.__alpha=alpha;window.__beta=beta;setCategory(alpha,'on_hold');setCategory(beta,'planned');setCategory({title:'Hidden adult',source:'ms',url:'https://hianime.ms/details/hidden',adult:true},'dropped');watchedSet(alpha,1,true)}, {alpha,beta});
 assert.equal(await page.evaluate(()=>getCategory(window.__alpha)),'on_hold');
 await page.evaluate(()=>openStatusPicker(window.__alpha));assert.equal(await page.locator('[data-status="on_hold"]').innerText(),'On hold');await page.click('.status-close');
 await page.evaluate(()=>{__fake553.connections.anilist={connected:true,name:'Alice',method:'anilist',syncOwner:'AAAAAAAAAAAAAAAAAAAAAAAA'};window.kuroSyncConnections553(__fake553.connections)});
 await page.waitForFunction(()=>JSON.parse(localStorage.getItem('kuro-tracker-sync-v1')||'{}').queue?.some(j=>j.state==='conflict'));
 assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-tracker-sync-v1')).queue.some(j=>j.item.title==='Hidden adult')),false,'explicitly adult items are not synced while disabled');
 let first=await page.evaluate(()=>__fake553.sent[0]);assert.equal(first.intent,'backfill');assert.equal(first.status,'on_hold');assert.deepEqual(first.watched,[1]);assert.equal(first.owner,'AAAAAAAAAAAAAAAAAAAAAAAA');
 await page.click('[data-nav="profile"]');await page.waitForSelector('#tracker-sync553 .tracker553');assert((await page.locator('#tracker-sync553').innerText()).includes('need a match'));assert((await page.locator('#tracker-sync553').innerText()).includes('status conflicts'));
 await page.click('[data-sync-match553]');await page.click('#tracker-search553');await page.waitForSelector('[data-candidate553]');await page.click('[data-candidate553]');assert((await page.locator('.tracker-result-note553').innerText()).includes('exact season'));await page.click('#tracker-confirm553');
 let st=await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-tracker-sync-v1')));assert.equal(st.links['ms|https://hianime.ms/details/beta'].confirmed,true);assert.equal(st.links['ms|https://hianime.ms/details/beta'].anilistId,301);
 await page.click('[data-sync-apply553]');st=await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-tracker-sync-v1')));assert(st.queue.some(j=>j.item.title==='Alpha'&&j.intent==='status'&&j.state==='pending'),'explicit resolution applies Kuro status');
 await page.waitForFunction(()=>__fake553.sent.some(x=>x.title==='Beta'),null,{timeout:10000});let betaSent=await page.evaluate(()=>__fake553.sent.find(x=>x.title==='Beta'));assert.equal(betaSent.userMatched,true);assert.equal(betaSent.anilistId,301);assert.equal(betaSent.malId,401);
 await page.waitForFunction(()=>__fake553.sent.some(x=>x.title==='Alpha'&&x.intent==='status'),null,{timeout:10000});
 assert.equal((await page.evaluate(()=>__fake553.sent.find(x=>x.title==='Alpha'&&x.intent==='status'))).status,'on_hold');
 // Opening a player is not a watched event; stale session reports are rejected.
 await page.evaluate(()=>{window.kuroSyncSuspend553();window.__gamma={title:'Gamma',source:'ms',url:'https://hianime.ms/details/gamma',anilistId:501,malId:601};selected=window.__gamma;episode={number:'2'};view='episode';currentWatchChain={id:'watch-gamma',number:'2',launched:true,blocked:false,alive:()=>true}});
 assert.equal(await page.evaluate(()=>watchedHas(__gamma,2)),false);await page.evaluate(()=>window.kuroEpisodeEnded553('stale-session','2'));assert.equal(await page.evaluate(()=>watchedHas(__gamma,2)),false);
 await page.evaluate(()=>window.kuroEpisodeEnded553('watch-gamma','2'));assert.equal(await page.evaluate(()=>watchedHas(__gamma,2)),true);await page.waitForTimeout(30);
 st=await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-tracker-sync-v1')));assert(st.queue.some(j=>j.item.title==='Gamma'&&j.intent==='watch'));
 // A disconnected/replaced account never receives another account's pending work.
 const sentBefore=await page.evaluate(()=>__fake553.sent.length);await page.evaluate(()=>{__fake553.connections.anilist={connected:true,name:'Bob',method:'anilist',syncOwner:'BBBBBBBBBBBBBBBBBBBBBBBB'};window.kuroSyncConnections553(__fake553.connections)});await page.waitForTimeout(60);assert.equal(await page.evaluate(()=>__fake553.sent.length),sentBefore,'suspended app does not start background uploads');
 st=await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-tracker-sync-v1')));assert(st.queue.some(j=>j.owner==='AAAAAAAAAAAAAAAAAAAAAAAA'&&j.item.title==='Gamma'));assert(st.queue.every(j=>j.owner!=='BBBBBBBBBBBBBBBBBBBBBBBB'||j.item.title!=='Gamma'),'old pending episode is not assigned to a new account');
 // Local category removal cancels pending work and does not send a remote delete.
 await page.evaluate(()=>setCategory(__gamma,''));st=await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-tracker-sync-v1')));assert(!st.queue.some(j=>j.item.title==='Gamma'));assert(!await page.evaluate(()=>__fake553.sent.some(x=>x.intent==='delete')));
 assert.deepEqual(errors,[]);console.log('PASS five-status UI, safe backfill/conflicts, manual exact match, progress event, account isolation and suspended queue');
 }finally{if(browser)await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

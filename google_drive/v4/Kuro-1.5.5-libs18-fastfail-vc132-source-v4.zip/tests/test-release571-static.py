#!/usr/bin/env python3
"""Kuro 5.71 local-artwork, migration, storage and native-boundary checks."""
from pathlib import Path
from PIL import Image
import hashlib,json,re
r=Path(__file__).resolve().parents[1]
def text(name):return (r/name).read_text(encoding='utf-8')
manifest=json.loads(text('assets/preset-manifest571.json'))
assert manifest['version']==1 and len(manifest['sources'])==6 and len(manifest['entries'])==160
js=text('assets/preset-manifest571.js')
assert js.startswith('window.KURO_PRESETS571=Object.freeze(') and js.endswith(');\n')
assert json.loads(js[len('window.KURO_PRESETS571=Object.freeze('):-3])==manifest['entries']
assert len({x['sha256'] for x in manifest['sources']})==6
for source in manifest['sources']:
 p=Path('/home/user/uploads')/source['file']
 if p.exists():assert hashlib.sha256(p.read_bytes()).hexdigest()==source['sha256']
for i,e in enumerate(manifest['entries'],1):
 assert e['id']==i and e['avatar']==f'preset571-a-{i:03}.jpg' and e['banner']==f'preset571-b-{i:03}.jpg'
 for kind in ('avatar','banner'):
  with Image.open(r/'assets'/e[kind]) as im:assert im.format=='JPEG' and im.width>=100 and im.height>=100;im.verify()
assert {x['label'].split(',')[0] for x in manifest['entries']}=={f'Sheet {i}' for i in range(1,7)}
accounts=text('assets/accounts542.js');presets=text('assets/profile-presets571.js');backup=text('assets/backup560.js');java=text('src/app/lovelycrxshx/kuro/MainActivity.java');android=text('AndroidManifest.xml');build=text('build.gradle')
assert 'versionCode 71' in build and "versionName '5.71'" in build
assert 'android:versionCode="71"' in android and 'android:versionName="5.71"' in android
assert 'KuroNative.pickProfileImage(' not in accounts and '@JavascriptInterface public void pickProfileImage' not in java
assert '[data-avatar-preset]' not in accounts and 'id="character-grid549"' not in accounts
assert "p.avatar='';p.banner='';p.presetSchema571=1" in presets and "if(existing===null){localStorage.setItem(MIGRATION,'1');return false}" in presets
assert 'recover(); // Never overwrite a prior interrupted Apply.' in presets
for key in ('kuro-watch-queue571-v1','kuro-anime-preferences571-v1'):assert key in backup
assert 'preset571-[ab]-[0-9]{3}' in java and '/profile-default571.png' in java
assert '.KuroPipControls571$Receiver" android:exported="false"' in android
assert 'isInPictureInPictureMode()||nativePlayer561==null' in java
caption=text('src/app/lovelycrxshx/kuro/KuroCaptionStyle571.java');assert 'setApplyEmbeddedStyles' in caption and 'not included in the local backup' in caption
queue=text('assets/watch-queue571.js');privacy=text('assets/privacy571.js');assert 'Automatic queue advancement is not included.' in queue and 'does not send a status or make a network request' in privacy
assert 'Kuro.tv 5.71' in java and 'Available device storage (approx.)' in java
print('PASS 5.71: six source sheets, 320 valid JPEGs, no profile upload controls, migration/backup boundaries, private queue, PiP and captions')

'use strict';
// Chromium's real WebGL/compositor and a local VP8 fixture. Android's separate
// custom view and physical GPUs still require device testing.
const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const fx=fs.readFileSync(path.join(__dirname,'../assets/video-effects537.js'),'utf8');
const movie=fs.readFileSync(path.join(__dirname,'fixtures/fx-controls559.webm'));
const settings={enabled:true,ai:false,preset:'A+A',detail:8,sharpen:180,denoise:100,lineStrength:100,edge:100,saturation:150,contrast:130,brightness:100,deband:0,gain:100,visible:true};
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.KURO_CHROMIUM||'/usr/bin/chromium',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
 try{
  const page=await browser.newPage({viewport:{width:320,height:180},deviceScaleFactor:1});let errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.route('**/*',r=>{let u=new URL(r.request().url());if(u.pathname==='/movie.webm')return r.fulfill({contentType:'video/webm',body:movie});if(u.pathname==='/player')return r.fulfill({contentType:'text/html',body:`<!doctype html><style>html,body{margin:0;background:black;width:100%;height:100%}#a,#b{position:static;width:100%;height:100%}#b{display:none}video{display:block;width:100%;height:100%;object-fit:contain}#site{position:absolute;right:0;top:0;width:18px;height:18px;background:#ff0;z-index:1;pointer-events:none}#enter{position:absolute;left:0;top:0;z-index:2}</style><div id="a"><video src="/movie.webm" controls></video><div id="site"></div><button id="enter">Fullscreen</button></div><div id="b"></div><script>document.querySelector('#enter').onclick=()=>document.querySelector('#a').requestFullscreen()</script>`});return r.abort()});
  await page.goto('https://kuro.local/player');await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:fx});
  let state=await page.evaluate(s=>JSON.parse(window.__kuroFx537.configure(s)),settings);assert.equal(state.video,'active');
  async function overlay(){return page.locator('canvas[data-kuro-fx]')}
  assert.equal(await (await overlay()).evaluate(e=>getComputedStyle(e).pointerEvents),'none');
  // Enlarging the same WebView-like viewport keeps actual altered pixels.
  let before=await page.screenshot();await page.evaluate(s=>window.__kuroFx537.configure({...s,compare:true}),settings);let raw=await page.screenshot();assert(!before.equals(raw),'real canvas changes the composited pixels');await page.evaluate(s=>window.__kuroFx537.configure(s),settings);
  await page.setViewportSize({width:640,height:360});await page.waitForFunction(()=>{let c=document.querySelector('canvas[data-kuro-fx]'),v=document.querySelector('video');return c&&Math.round(c.getBoundingClientRect().width)===640&&Math.round(v.getBoundingClientRect().width)===640});
  assert.equal(await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()).video),'active');assert.equal(await (await overlay()).evaluate(e=>getComputedStyle(e).visibility),'visible');
  // HTML element fullscreen includes canvas descendants, just as a supported
  // container fullscreen does; no enhancement configuration UI is created.
  await page.locator('#enter').click();await page.waitForFunction(()=>!!document.fullscreenElement);assert(await page.evaluate(()=>document.fullscreenElement.contains(document.querySelector('canvas[data-kuro-fx]'))));assert.equal(await page.locator('[data-kuro-fx]').count(),1);assert.equal(await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()).video),'active');
  await page.evaluate(()=>document.exitFullscreen());
  // Some players move the same video into a new wrapper on mode changes.
  // The non-interactive canvas and readable captions must follow it.
  await page.evaluate(()=>{const b=document.querySelector('#b');b.style.display='block';b.append(document.querySelector('video'));document.querySelector('#a').style.display='none';document.dispatchEvent(new Event('fullscreenchange'))});
  await page.waitForFunction(()=>{let v=document.querySelector('video'),c=document.querySelector('canvas[data-kuro-fx]');return !!c&&c.parentElement===v.parentElement&&c.getBoundingClientRect().width===v.getBoundingClientRect().width});
  assert.equal(await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()).video),'active');assert.equal(await page.locator('#b canvas[data-kuro-fx]').count(),1);assert.equal(await page.locator('#b [data-kuro-captions]').count(),1);
  state=await page.evaluate(s=>JSON.parse(window.__kuroFx537.configure({...s,visible:false})),settings);assert.equal(state.video,'paused');state=await page.evaluate(s=>JSON.parse(window.__kuroFx537.configure({...s,visible:true})),settings);assert.equal(state.video,'active');
  state=await page.evaluate(()=>JSON.parse(window.__kuroFx537.configure({enabled:false,gain:100})));assert.equal(state.video,'off');assert.equal(await page.locator('canvas[data-kuro-fx]').count(),0);assert.equal(await page.evaluate(()=>document.querySelector('#b').style.position),'');
  assert.deepEqual(errors,[]);console.log('PASS 5.69 real WebGL overlay, resizing, container fullscreen, moved video, pause/resume and cleanup');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});

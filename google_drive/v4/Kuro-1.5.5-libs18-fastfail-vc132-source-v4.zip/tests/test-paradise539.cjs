'use strict';
// Offline synthetic fixtures; this is not a real stream or Android playback test.
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets');
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://x').pathname.slice(1)||'index.html',p=path.resolve(root,name);if(!p.startsWith(root+path.sep)){res.writeHead(403).end();return}fs.readFile(p,(err,data)=>{if(err)return res.writeHead(404).end();res.writeHead(200,{'content-type':name.endsWith('.js')?'application/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'text/html'}).end(data)})});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({headless:true,args:['--no-sandbox']});try{
 const page=await browser.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  window.__responses={};window.__results={};window.__calls=[];window.__plays=[];window.__external=[];
  function done(id,value,error=''){window.__results[id]=typeof value==='string'?value:JSON.stringify(value);setTimeout(()=>window.__nativeResult?.(id,error),0)}
  window.KuroNative={
   get(id,url){window.__calls.push(url);const r=window.__responses[url];done(id,r?.value??{},r?.error||'')},
   adultMetadata(id,input){const ids=JSON.parse(input),recs=ids.anilist.map(n=>({id:n,idMal:n,isAdult:n===22,title:{english:n===25?'Different title':'One Piece',romaji:n===25?'DIFFERENT TITLE':'ONE PIECE'},startDate:{year:n===23?2005:n===24?null:1999},synonyms:[]}));done(id,{data:{a:{media:recs},m:{media:[]}}})},
   play(json){window.__plays.push(JSON.parse(json))},openExternalSource(x){window.__external.push(x)}
  };
  const real=fetch.bind(window);window.fetch=(input,opts)=>{const u=typeof input==='string'?input:input.url;return u.startsWith('/result/')?Promise.resolve(new Response(window.__results[decodeURIComponent(u.slice(8))]||'',{status:200})):real(input,opts)};
 });
 await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);await page.waitForTimeout(250);
 const disabled=await page.evaluate(async()=>{window.__calls=[];let error='';try{await get('https://api.animeparadise.moe/search?q=x')}catch(e){error=e.message}return {enabled:paradiseEnabled(),error,calls:window.__calls.length,url:paradiseCatalogUrl({mode:'search',query:'x'},1)}});
 assert(!disabled.enabled);assert(disabled.error.includes('turned off'));assert.equal(disabled.calls,0);assert.equal(disabled.url,'');
 await page.evaluate(()=>nav('search'));assert((await page.locator('#paradise-status').innerText()).includes('off'));await page.click('#paradise-toggle');assert(await page.evaluate(()=>paradiseEnabled()));
 const rows=await page.evaluate(async()=>{
  const row=(id,animeid=21,year=1999)=>({_id:id,title:'One Piece',alternativeTitle:{english:'One Piece'},animeSeason:{year},posterImage:{large:`https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx${animeid}-cover.jpg`},genres:['Action']});
  const body={success:true,data:[row('good'),row('adult',22),row('wrongYear',23),row('unknownYear',24),row('wrongTitle',25),{...row('badHost'),posterImage:{large:'https://s4.anilist.co.evil.example/file/anilistcdn/media/anime/cover/large/bx21-x.jpg'}},{...row('adultGenre'),genres:['Hentai']},{...row('../bad'),_id:'../bad'}]};
  const result=await paradiseCatalog({mode:'search'},1,JSON.stringify(body));return {result,hint:paradiseAniListHint(row('good').posterImage.large),bad:paradiseAniListHint('https://example.com/bx21-x.jpg'),noSearch:paradiseCatalogUrl({mode:'search',query:''},1),noFeed:paradiseCatalogUrl({mode:'popularShelf'},1),noPage:paradiseCatalogUrl({mode:'search',query:'One Piece'},2),search:paradiseCatalogUrl({mode:'search',query:'One Piece'},1),known:unifiedCodes.includes('paradise')};
 });
 assert.equal(rows.result.items.length,1,'only exact title, ID, year and non-adult classification survive');assert.equal(rows.result.items[0].paradiseId,'good');assert(!rows.result.hasNext);assert.equal(rows.hint,21);assert.equal(rows.bad,0);assert.equal(rows.noSearch,'');assert.equal(rows.noFeed,'');assert.equal(rows.noPage,'');assert(rows.search.endsWith('/search?q=One%20Piece&limit=20'));assert(rows.known);
 const detail=await page.evaluate(async item=>{
  const good='11111111-2222-3333-4444-555555555555',other='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';
  const body={success:true,data:[{origin:'good',number:1,uid:good,title:'Episode 1'},{origin:'good',number:1,uid:good,title:'duplicate same row'},{origin:'good',number:2,uid:good},{origin:'good',number:2,uid:other},{origin:'wrong',number:3,uid:good},{origin:'good',number:4,uid:'bad/path'},{origin:'good',number:0,uid:good}]};
  const d=await paradiseDetails(item,JSON.stringify(body)),server=await paradiseServers(item,d.episodes[0]),wrongId=await paradiseServers({...item,paradiseId:'other'},d.episodes[0]),wrongEp=await paradiseServers(item,{...d.episodes[0],url:'https://evil.example/'});
  let unsafe=false;try{await paradiseDetails({...item,sourceYear:2000},JSON.stringify(body))}catch(_){unsafe=true}
  return {d,server,wrongId,wrongEp,unsafe};
 },rows.result.items[0]);
 assert.deepEqual(detail.d.episodes.map(x=>x.number),['1'],'duplicate numbered alternatives, wrong origin and invalid IDs fail closed');assert.equal(detail.server.length,1);assert.equal(detail.server[0].lang,'sub');assert.equal(detail.server[0].note,'Source-reported');assert.equal(detail.server[0].url,'https://www.animeparadise.moe/watch/11111111-2222-3333-4444-555555555555?origin=good');assert.equal(detail.wrongId.length,0);assert.equal(detail.wrongEp.length,0);assert(detail.unsafe);
 const fallback=await page.evaluate(async item=>{
  unifiedVerificationBlocked.clear();const query=paradiseCatalogUrl({mode:'search',query:'One Piece'},1);
  window.__responses[query]={value:{success:true,data:[{_id:'good',title:'One Piece',animeSeason:{year:1999},posterImage:{large:'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx21-cover.jpg'},genres:[]}]}};
  window.__responses[item.url]={value:{success:true,data:[{origin:'good',number:1,uid:'11111111-2222-3333-4444-555555555555',title:'Episode 1'}]}};
  const good=await fallbackParadise('One Piece',1,{anilistId:21}),noId=await fallbackParadise('One Piece',1,{}),wrongId=await fallbackParadise('One Piece',1,{anilistId:22}),wrongEp=await fallbackParadise('One Piece',2,{anilistId:21});
  const union=await unifiedReadOtherEpisodes(item,{title:'One Piece',anilistId:21});return {good,noId,wrongId,wrongEp,union};
 },rows.result.items[0]);
 assert.equal(fallback.good.length,1);assert.equal(fallback.noId.length,0);assert.equal(fallback.wrongId.length,0);assert.equal(fallback.wrongEp.length,0);assert.equal(fallback.union.episodes[0].number,'1');
 const plays=await page.evaluate(async item=>{
  // Exercise the real show and Watch flow, but prevent scans of other sources.
  unifiedBeginEpisodeScan=()=>{};seekFallbacks=async()=>{};await openShow(item);await openEpisode(episodes[0]);return window.__plays;
 },rows.result.items[0]);
 assert.equal(plays.length,1);assert.equal(plays[0].source,'paradise');assert.equal(plays[0].episode,'1');assert(plays[0].servers[0].url.startsWith('https://www.animeparadise.moe/watch/'));assert.equal(plays[0].servers[0].lang,'sub');
 for(const status of [403,429]){
  const stop=await page.evaluate(async status=>{localStorage.removeItem('kuro-paradise-blocked');unifiedVerificationBlocked.clear();window.__calls=[];const u=paradiseCatalogUrl({mode:'search',query:'One Piece'},1);window.__responses[u]={error:'HTTP '+status};let error='';try{await fetchCatalogPage({source:'paradise',mode:'search',query:'One Piece'},1)}catch(e){error=e.message}try{await get(u)}catch(_){}return {error,calls:window.__calls.length,blocked:unifiedVerificationBlocked.has('paradise'),remembered:paradiseBlocked()};},status);
  assert(stop.error.includes('HTTP '+status));assert.equal(stop.calls,1);assert(stop.blocked&&stop.remembered);
 }
 await page.reload();assert(await page.evaluate(()=>paradiseBlocked()),'source block persists after a fresh UI');
 const retained=await page.evaluate(async()=>{window.__calls=[];try{await get('https://api.animeparadise.moe/search?q=One%20Piece&limit=20')}catch(_){}return window.__calls.length});assert.equal(retained,0,'no automatic request after a remembered block');
 await page.evaluate(()=>nav('search'));assert(await page.locator('#paradise-retry').isVisible());await page.click('#paradise-retry');assert(!(await page.evaluate(()=>paradiseBlocked())),'only explicit retry clears the block');
 await page.click('[data-open-site="paradise"]');assert.deepEqual(await page.evaluate(()=>window.__external),['paradise']);
 assert.deepEqual(errors,[]);console.log('PASS Library 13 offline: search-only, trusted-ID/year/adult gate, exact episode/player URL, failover, 403/429 stop and separate site link');
 }finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

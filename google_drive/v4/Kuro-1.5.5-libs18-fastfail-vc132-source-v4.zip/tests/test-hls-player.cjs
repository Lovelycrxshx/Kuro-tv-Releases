const vm=require('vm'),fs=require('fs'),assert=require('assert');
const script=fs.readFileSync(require('path').resolve(__dirname,'../assets/stream-player.js'),'utf8');
function simulate({url,status=0,videoError=false}){
 let handlers={},capture={},video={muted:true,volume:0,autoplay:false,canPlayType:()=>'',play:()=>Promise.resolve(),addEventListener:(n,fn)=>handlers['video-'+n]=fn};
 class Hls{constructor(){capture.instance=this;this.events={}}static isSupported(){return true}on(e,f){this.events[e]=f}attachMedia(v){capture.attached=v;this.events.attached()}loadSource(s){capture.source=s}}
 Hls.Events={ERROR:'error',MEDIA_ATTACHED:'attached',MANIFEST_PARSED:'manifest'};
 let location={search:'?src='+encodeURIComponent(url),href:'start'};
 const context={document:{getElementById:()=>video},window:{Hls,addEventListener:()=>{}},Hls,location,URL,URLSearchParams,encodeURIComponent};vm.runInNewContext(script,context);
 if(status)capture.instance.events.error(null,{fatal:true,response:{code:status}});else if(videoError)handlers['video-error']();
 return {capture,location,video};
}
let url='https://www.zenkaitv.com/api/source?url='+encodeURIComponent('https://player.zilla-networks.com/m3u8/abc')+'&refererHost=player.zilla-networks.com';
let ok=simulate({url});assert.equal(ok.capture.source,url);assert.equal(ok.video.muted,false);assert.equal(ok.video.volume,1);assert.equal(ok.video.autoplay,true);
assert(simulate({url,status:401}).location.href.endsWith('type=verification'));assert(simulate({url,status:403}).location.href.endsWith('type=verification'));assert(simulate({url,status:429}).location.href.endsWith('type=verification'));assert(simulate({url,status:500}).location.href.endsWith('type=fatal'));assert(simulate({url,videoError:true}).location.href.endsWith('type=fatal'));
assert(simulate({url:'https://www.zenkaitv.com/api/source?url='+encodeURIComponent('https://not-allowed.example/m3u8/foo')}).location.href.endsWith('type=fatal'));
console.log('PASS bundled HLS player validates source, starts unmuted, signals fatal errors and stops for verification');

const installLegacy532=require('./legacy-ui-harness.cjs');
const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets'),types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.svg':'image/svg+xml','.png':'image/png'};
const server=http.createServer((req,res)=>{const p=path.resolve(root,new URL(req.url,'http://localhost').pathname.slice(1)||'index.html');if(!p.startsWith(root+path.sep)){res.writeHead(403).end();return}fs.readFile(p,(e,b)=>e?res.writeHead(404).end():res.writeHead(200,{'content-type':types[path.extname(p)]||'application/octet-stream'}).end(b))});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  window.__fixture={calls:[],delayMsNew:true,failNextMsNew:false};const replies={},nativeFetch=window.fetch.bind(window);
  window.fetch=(input,opts)=>{const u=typeof input==='string'?input:input.url;return u.startsWith('/result/')?Promise.resolve(new Response(replies[decodeURIComponent(u.slice(8))]||'',{status:200})):nativeFetch(input,opts)};
  const cards=(src,mode,n,host)=>Array.from({length:12},(_,i)=>{
   const k=(n-1)*12+i,name=src+' '+mode+' '+String(k).padStart(2,'0'),url=`https://${host}/details/${mode}-${k}`;
   return src==='MS'?`<article class="hk-tile"><img src="https://img.example/${k}.jpg"><h3 class="hk-tile__name"><a href="${url}">${name}</a></h3></article>`:`<div class="flw-item"><img src="https://img.example/${k}.jpg"><h3 class="film-name"><a href="${url}">${name}</a></h3></div>`;
  }).join('');
  const special=(u)=>{
   if(u.hostname==='zorotv.ba'&&u.pathname==='/anime/')return `<div class="serieslist wpop-alltime">${[0,1].map(i=>`<li><div class="leftseries"><h4><a href="https://zorotv.ba/anime/zoro-${i}/">ZORO top ${i}</a></h4></div><img src="https://img.example/z${i}.jpg"></li>`).join('')}</div>`;
   if(u.hostname==='animesalt.cx'&&u.pathname==='/')return `<ul data-tbs="series-chart"><li><a data-post="series" data-category="all"></a></li></ul><div id="series-chart">${[0,1,2].map(i=>`<div class="chart-item"><a href="https://animesalt.cx/series/salt-${i}/"><img src="https://img.example/s${i}.jpg"></a><div class="chart-title">SALT top ${i}</div></div>`).join('')}</div><section class="widget_list_movies_series"><h3>New Anime Arrivals</h3>${[0,1].map(i=>`<article class="post"><a href="https://animesalt.cx/series/new-${i}/"><img alt="Image SALT new ${i}" src="https://img.example/n${i}.jpg"></a></article>`).join('')}</section>`;
   return '';
  };
  window.KuroNative={get(id,url){
   const u=new URL(url),src=u.hostname==='hianime.ms'?'MS':u.hostname==='hianime.dk'?'DK':u.hostname==='animesalt.cx'?'SALT':'ZORO';
   window.__fixture.calls.push(url);let body=special(u),page=Number(u.searchParams.get('page')||((u.pathname.match(/\/page\/(\d+)/)||[])[1])||1),mode=u.pathname==='/new-releases'||u.searchParams.get('sort')==='recently_added'?'new':u.pathname==='/browse'?'genre':'all';
   if(!body&&src==='ZORO'&&u.pathname.includes('/wp-json/'))body=JSON.stringify([0,1,2].map(i=>({name:'ZORO top '+i,slug:'zoro-'+i,link:'https://zorotv.ba/category/zoro-'+i+'/'})));
   else if(!body&&src==='SALT'){
    body=Array.from({length:12},(_,i)=>{let k=(page-1)*12+i;return `<article class="post"><h2 class="entry-title">SALT list ${k}</h2><a href="https://animesalt.cx/series/salt-${k}/"><img src="https://img.example/s${k}.jpg"></a></article>`}).join('');
    if(page<3)body+=`<nav class="pagination"><a href="https://animesalt.cx/series/page/${page+1}/">${page+1}</a></nav>`;
   }else if(!body){
    body=cards(src,mode,page,u.hostname);const next=new URL(url);next.searchParams.set('page',page+1);if(page<3)body+=`<div class="pagination"><a href="${next.href}">${page+1}</a></div>`;
   }
   if(src==='MS'&&mode==='new'&&window.__fixture.failNextMsNew){window.__fixture.failNextMsNew=false;setTimeout(()=>window.__nativeResult(id,'Source returned HTTP 403'),0);return}
   let delay=src==='MS'&&mode==='new'&&window.__fixture.delayMsNew?650:0;
   setTimeout(()=>{replies[id]=body;window.__nativeResult(id,'')},delay);
  }};
 });
 await installLegacy532(page);await page.goto(`http://127.0.0.1:${server.address().port}/`);
 await page.waitForSelector('#home-popular .card');assert.equal(await page.locator('#home-popular .card strong').first().innerText(),'MS all 00');
 assert.equal(await page.locator('#home-popular .card').count(),8);assert.equal(await page.locator('.pager-grid .card strong').first().innerText(),'MS all 08','popular shelf is not repeated in the infinite grid');
 await page.locator('[data-source="dk"]').click();await page.waitForSelector('#home-new .card');assert.equal(await page.locator('#home-new .card strong').first().innerText(),'DK new 00');
 await page.waitForTimeout(800);assert.equal(await page.locator('#home-new .card strong').first().innerText(),'DK new 00','slow previous-library new response cannot overwrite the current source');
 await page.evaluate(()=>{window.__fixture.delayMsNew=false;window.__fixture.failNextMsNew=true;homeShelves.delete('ms|new')});
 await page.locator('[data-source="ms"]').click();await page.waitForSelector('#home-new [data-shelf-retry]');assert((await page.locator('#home-new').innerText()).includes('blocked'));
 let newCalls=await page.evaluate(()=>window.__fixture.calls.filter(x=>x.includes('/new-releases')).length);await page.waitForTimeout(300);assert.equal(await page.evaluate(()=>window.__fixture.calls.filter(x=>x.includes('/new-releases')).length),newCalls,'new shelf does not automatically retry blocked requests');
 await page.locator('#home-new [data-shelf-retry]').click();await page.waitForSelector('#home-new .card');assert.equal(await page.locator('#home-new .card strong').first().innerText(),'MS new 00');
 const ordering=await page.evaluate(()=>['popular-heading','new-heading','recent-heading'].map(x=>document.getElementById(x).getBoundingClientRect().top));assert(ordering[0]<ordering[1]&&ordering[1]<ordering[2],'popular, new, recent are finite shelves in that order');
 await page.locator('[data-source="zoro"]').click();await page.waitForSelector('#home-popular .card');assert.equal(await page.locator('#home-popular .card strong').first().innerText(),'ZORO top 0');assert((await page.locator('#home-new').innerText()).includes('aren’t available'));assert((await page.locator('.home-more-heading').innerText()).includes('library'));
 await page.locator('[data-source="salt"]').click();await page.waitForSelector('#home-popular .card');await page.waitForSelector('#home-new .card');assert.equal(await page.locator('#home-popular .card strong').first().innerText(),'SALT top 0');assert.equal(await page.locator('#home-new .card strong').first().innerText(),'SALT new 0');
 await page.waitForFunction(()=>document.querySelectorAll('.pager-grid .card').length===9);assert(!(await page.locator('.pager-grid .card strong').allTextContents()).includes('SALT list 0'),'finite most-watched shelf is excluded from the following catalogue');
 assert.equal(await page.evaluate(()=>window.__fixture.calls.filter(x=>x==='https://animesalt.cx/').length),1,'both Library 6 shelves share one homepage request');
 // Browse exposes only source-supported categories and resets the custom sort for a new category.
 await page.locator('nav [data-nav="search"]').click();await page.locator('[data-source="ms"]').click();await page.locator('[data-browse-tab="genres"]').click();assert((await page.locator('.genre-tile').count())>=40);
 await page.fill('#genre-filter','hist');assert.equal(await page.locator('.genre-tile').count(),1);assert((await page.locator('.genre-tile').innerText()).includes('Historical'));await page.fill('#genre-filter','not-a-genre');assert((await page.locator('.genre-empty').innerText()).includes('No matching'));await page.fill('#genre-filter','');
 await page.locator('[data-genre="action"]').click();await page.waitForSelector('.pager-grid .card');assert.equal(await page.locator('#result-sort-label').innerText(),'Popular first');
 const actionUrl=await page.evaluate(()=>window.__fixture.calls.find(x=>x.includes('/browse?')));const action=new URL(actionUrl);assert.equal(action.searchParams.get('genres[]'),'Action');assert.equal(action.searchParams.get('sort'),'popularity');
 await page.click('#result-sort');assert.equal(await page.locator('#sort-modal [role="dialog"]').getAttribute('aria-modal'),'true');assert.equal(await page.locator('[data-sort-choice="source"]').getAttribute('aria-checked'),'true');assert.equal(await page.evaluate(()=>document.activeElement.dataset.sortChoice),'source');
 await page.keyboard.press('ArrowDown');assert.equal(await page.locator('[data-sort-choice="az"]').getAttribute('aria-checked'),'true');assert.equal(await page.locator('#result-sort-label').innerText(),'Title A–Z');
 await page.keyboard.press('Tab');assert.equal(await page.evaluate(()=>document.activeElement.className),'sort-close','focus remains in the sheet');await page.keyboard.press('Escape');assert.equal(await page.locator('#sort-modal').count(),0);assert.equal(await page.evaluate(()=>document.activeElement.id),'result-sort');assert.equal(await page.evaluate(()=>document.body.style.overflow),'');
 await page.click('#result-sort');await page.evaluate(()=>window.kuroBack());assert.equal(await page.locator('#sort-modal').count(),0);assert.equal(await page.locator('[data-browse-tab="genres"]').getAttribute('aria-selected'),'true');
 await page.locator('#genres-back').click();await page.locator('[data-genre="romance"]').click();assert.equal(await page.locator('#result-sort-label').innerText(),'Popular first','a new category starts in source popularity order');
 await page.click('#result-sort');await page.click('[data-sort-choice="za"]');let a=await page.locator('.pager-grid .card strong').allTextContents();assert.deepEqual(a,a.slice().sort((x,y)=>y.localeCompare(x,undefined,{sensitivity:'base'})));
 // A library without verified category ranking is labelled honestly, not "popular".
 await page.locator('[data-source="salt"]').click();await page.waitForSelector('.pager-grid .card');assert.equal(await page.locator('#result-sort-label').innerText(),'Library order');assert((await page.locator('.discover-section .sub').innerText()).includes('popularity sort'));
 await page.locator('#genres-back').click();await page.locator('[data-source="zoro"]').click();assert((await page.locator('.genre-empty').innerText()).includes('aren’t available'));
 const routes=await page.evaluate(()=>({
  ms:catalogUrl({source:'ms',mode:'genre',genre:'sci-fi'},2),dk:catalogUrl({source:'dk',mode:'genre',genre:'slice-of-life'},2),nine:catalogUrl({source:'nine',mode:'genre',genre:'action'},2),ani:catalogUrl({source:'ani',mode:'genre',genre:'action'},2),salt:catalogUrl({source:'salt',mode:'genre',genre:'horror'},2),zoro:catalogUrl({source:'zoro',mode:'genre',genre:'action'},1)
 }));
 assert.equal(new URL(routes.ms).searchParams.get('genres[]'),'Sci-Fi');assert.equal(new URL(routes.dk).searchParams.get('genre'),'Slice of Life');assert(routes.nine.includes('/filter/page/2/?genre=3&sort=mostWatched'));assert.equal(new URL(routes.ani).searchParams.get('sort_by'),'popularity');assert(routes.salt.includes('/category/horror-genre/page/2/?type=series'));assert.equal(routes.zoro,'');
 for(const width of [280,320,393,768]){await page.setViewportSize({width,height:852});assert((await page.evaluate(()=>document.documentElement.scrollWidth))<=width+1,'no genre page horizontal overflow at '+width)}
 assert.deepEqual(errors,[]);console.log('PASS legacy-source adapter harness: popular/new shelves, finite charts, source races/retry, no duplicate ranked titles, category routes, accessible themed sort, filter and mobile widths');
 }finally{if(browser)await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

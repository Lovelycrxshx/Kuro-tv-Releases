5.68 CURRENT TESTS: See TESTS-5.68.txt in the project root. GitHubAdmin568HostTest
uses a fake identity provider and checks exact owner ID, no-scope tokens, polling,
slow-down, cancellation races and expiration. AccountBridge542Test exercises the
native gate with shadow Android. test-accounts542.cjs exercises the hidden gesture,
wrong-account error, owner form and UI expiration with a fake bridge. None performs
real GitHub authorization or tests a physical phone. The sections below are historical.

5.52 HISTORICAL TESTS: See TESTS-5.52.txt in the project root. The entries below are historical and may describe removed integrations.

5.50 CURRENT TESTS

Native: AccountFlows542Test checks real-session-only email login/signup with
fake providers, no-confirmation preflight, old Google-session exclusion and
optional secure recovery. AccountBridge542Test checks the Android bridge.
Browser: test-accounts542.cjs checks no Google/Drive UI, password flows, local
profile, image/gallery, imports and navigation. test-local-migration550.cjs
checks journal rollback without network. test-account550-static.py checks
removed integration and APK packaging. These use fakes, not a real phone or
real provider. Earlier notes below are historical; removed Google/Drive tests
no longer apply to this release.

---------------- HISTORICAL TEST NOTES ----------------

5.46 ACCOUNT-COPY REGRESSIONS — FAKES ONLY

- BackupCopy546Test covers legacy 5.45 owner/status migration, a one-use
  target-bound ticket, confirmed copy, mismatched Drive subject, stale account
  or denied consent, atomic pending state, failed upload, separate simulated
  Drive folders and privacy-safe error classification.
- The existing browser fake bridge additionally tests the visible confirmation,
  cancellation, local-wins merge and pending-on-storage-failure.
- These simulations never use a real Google account, Drive or Android phone.

5.45 BACKUP TESTS — FAKE GOOGLE/DRIVE ONLY

- Backup545Test exercises the whitelist, credential exclusion, identity guard,
  immutable snapshots, per-device retention, failed uploads and ownership.
- BackupCoordinator545Test exercises pending/complete activation, Google
  mismatch and sign-in switches with a fake authorization client.
- node tests/test-cloud545.cjs covers opt-in, simulated clean-device restore,
  non-destructive local-wins merge, offline retry, account boundary, race and
  rollback. These do not connect to a Google account or an Android device.
- Run bash tests/native-panel/run.sh with JDK 17+ and Android SDK 35, and run
  browser tests sequentially on low-memory hosts. See README-5.46.txt.

5.44 GOOGLE CRASH REGRESSION

- GoogleNative544Test exercises the actual AndroidX Play Services provider
  and its hidden activity under Robolectric, plus controlled synchronous and
  asynchronous provider errors, cancellation races, and malformed results.
  A real Google account/phone is not simulated or tested.
- The old 5.43 APK has Activity 1.5.1 implementing multiple interfaces not
  present in the packaged Core 1.1.0 DEX. Recreating that dependency set in
  Robolectric reproduced NoClassDefFoundError in HiddenActivity.onCreate.
  With Core 1.13.1 and Loader 1.1.0 the same provider test passes.
- python3 tests/test-google-apk-classes.py path/to/release.apk examines actual
  DEX class definitions and critical supertype/interface dependencies. It is
  expected to fail on 5.43 and pass on 5.44. It does not test live login.

5.43 TEST NOTES

The supported native suite is now Gradle/Robolectric, not the older Maven
runner described in the historical sections below. Set ANDROID_HOME and
JAVA_HOME (JDK 17+) then run bash tests/native-panel/run.sh. The new
GoogleDirect543Test and GoogleBridge543Test use generated signing keys and a
fake native chooser: they do not test real Google accounts or a phone.
The prior route, Watch, account, import and player tests remain included.
Run browser tests sequentially on memory-limited machines.

5.38 TESTS — NO PHYSICAL PHONE OR REAL PROVIDER PLAYBACK

- node tests/test-route-state538.cjs exercises mocked warm overlays and cold
  checkpoints, browse filters/scroll, exact-episode recovery, storage privacy,
  unsafe identifiers, reclassification, stale async cancellation and optional
  Hayase/JustAnime links. The Chromium run uses synthetic pages, not streams.
- bash tests/native-panel/run.sh covers cold creation and pending-intent
  consumption, warm player preservation, fullscreen overlay/back order, and
  installed/missing Hayase app intents, including validated title-only links.
  Its WebViews, package manager and lifecycle are Robolectric shadows, not an
  actual Android task, installed Hayase instance or notification tray.
- JSON_JAR=/path/to/org.json.jar bash tests/test-news-android-fake.sh verifies
  notification PendingIntent flags as well as the existing fake scheduling.
- 5.37 browser, shell/Java, Python and JavaScript parsing regressions still run.

=== 5.37 TEST NOTES RETAINED BELOW ===

5.37 TESTS — NO PHYSICAL PHONE OR REAL PROVIDER PLAYBACK

- node tests/test-overlays537.cjs checks the production browser-side Watch
  Search/news overlays, token callbacks, stale search, DOM/scroll preservation
  and mobile widths with mocked bridges and provider data.
- bash tests/native-panel/run.sh checks native overlay/player lifecycle,
  notification intents, validation, preferences, selectable controls and
  local asset interception with shadow WebViews. Set -Dkuro.options.preview=
  PATH and -Dkuro.options.video.preview=PATH for simulated native renders.
- node tests/test-kitsune537.cjs checks synthetic 12th-source catalogue,
  paging, adult filtering, duplicate episodes, exact title/ID/episode/audio,
  safe embeds, preference, fallback and verification stop. It makes no source
  requests. node tests/test-miruro535.cjs covers the prior source.
- JSON_JAR=/path/to/org.json.jar bash tests/test-kitsune-catalog.sh checks a
  generated >2.5MB sample, bounded compacting and malformed input. Optionally
  pass a local JSON filename to test a saved response; never store expiring
  stream URLs in the release or tests.
- node tests/test-effects537.cjs exercises real Chromium WebGL pixel changes,
  Web Audio gain, suspended-context tap recovery, CORS rejection and cleanup.
  node tests/test-hls-effects537.cjs uses the shipped local player, bundled
  Hls.js and generated VP9/Opus fixtures; the CORS failure test stubs the
  custom-scheme failure navigation only. These are synthetic, not live streams.

Run npm ci and install Playwright Chromium before browser tests. Java 11+
for host JSON tests; Java 17+, Maven and AndroidX/Maven first-run dependencies
for Robolectric. Platform codec support and real Android playback can differ.

=== 5.36 TEST NOTES RETAINED BELOW ===

5.36 TESTS

Run bash tests/native-panel/run.sh for host-side Robolectric tests of the native
PlaybackPanel and the actual watch-page builder. These exercise callbacks,
saved preferences, last-episode disabled state, touch and swipe on switches,
reflow at several widths and font scales, and 48dp control targets. The test
uses shadow WebViews and a no-network executor: it is not a device, codec,
stream playback or WebView-engine test. Java 17+, Maven, unzip and first-run
network downloads are needed. Set M2_REPO if the Maven local repository is not
$HOME/.m2/repository. Optional -Dkuro.panel.preview=/path/to/file.png creates a
Robolectric render of the controls, not a phone screenshot.

Run node tests/test-unified-library.cjs against the production one-library UI.
Run python3 tests/test-webview-assets.py to check native WebView asset routes.
The dock/news/skip/player/frame/report/logo/Java tests also cover current code.

The 5.32 per-provider regression fixtures use legacy-ui-harness.cjs to restore
old source pickers in the test browser only. They exercise individual source
parsers, route and failover logic; they do NOT represent the 5.33/5.34 production UI.
The production APK does not include this harness.

5.35 Library 11 fixture tests:
- node tests/test-miruro535.cjs checks synthetic catalog pages and cursors,
  exact matches and episode numbers, unsupported-embed filtering, 403/429
  stop behavior, the manual verification/retry UI and original-site link.
  This test does not contact Miruro or any stream.
- bash tests/test-miruro-catalog.sh tests bounded gzip/XOR JSON decoding,
  malformed input and decompression limits without the network.
- The Robolectric suite also exercises narrow native host/link validation and
  a user-initiated verification window with a shadow WebView. It does not
  establish that a real challenge, cookie or player will work on Android.

5.36 watch header and feed status:
- The Robolectric suite also exercises the production WatchHeader artwork,
  responsive touch targets, actual taps, accessibility labels, Home/search/
  notification callbacks, Android Back, saved controls and player cleanup.
  Set -Dkuro.header.preview=/path/to/file.png for a simulated header render.
- node tests/test-news-ui.cjs covers the web Home action, watch-header
  navigation, clearer partial-failure message, cached items and manual refresh.
  It uses fixtures, not live YouTube or a real device.

=== 5.42 ACCOUNT TESTS ===
node tests/test-accounts542.cjs tests the local UI with mock Android/provider
responses: modal/Watch preservation, config, fake sign-in, local profile,
imports, adult/unknown gate, duplicate handling, saved-data retention, and
manual title search. It never contacts an account provider.

bash tests/native-panel/run.sh runs the prior native regression suite plus
AccountFlows542Test and AccountBridge542Test: fake OAuth PKCE/state, identity
checks, unsafe redirects, encrypted-vault interface, registration/recovery,
read-only paginated imports and controlled HTTP failures. These run under
Robolectric with an in-memory fake vault; real Android Keystore and real
provider flows still require a configured project and a physical phone.

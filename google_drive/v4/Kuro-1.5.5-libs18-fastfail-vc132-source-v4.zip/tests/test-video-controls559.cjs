'use strict';
// Real decoded local VP8 frames and the shipped WebGL2 shader in Chromium.
// No real provider, Android WebView, or phone GPU is exercised here.
const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets'),fixture=path.resolve(__dirname,'fixtures/fx-controls559.webm');
const fx=fs.readFileSync(path.join(root,'video-effects537.js'),'utf8'),ai=fs.readFileSync(path.join(root,'ai-upscale540.js'),'utf8'),movie=fs.readFileSync(fixture);
const W=320,H=180;
const base={enabled:true,ai:false,aiStrength:100,preset:'A',line:'off',detail:8,sharpen:100,denoise:100,lineStrength:100,edge:100,saturation:100,contrast:100,brightness:100,deband:0,gain:100,visible:true};
function mad(a,b){let n=0;for(let i=0;i<a.length;i+=4)n+=Math.abs(a[i]-b[i])+Math.abs(a[i+1]-b[i+1])+Math.abs(a[i+2]-b[i+2]);return n/(W*H*3)}
// readPixels rows run bottom to top; these region helpers use screen coordinates.
function pix(a,x,y,c=0){return a[((H-1-y)*W+x)*4+c]}
function region(a,x1,y1,x2,y2,fun=(r,g,b)=>(r+g+b)/3){let z=[];for(let y=y1;y<y2;y++)for(let x=x1;x<x2;x++)z.push(fun(pix(a,x,y,0),pix(a,x,y,1),pix(a,x,y,2)));return z}
function mean(a){return a.reduce((x,y)=>x+y,0)/a.length}
function variance(a){const m=mean(a);return mean(a.map(v=>(v-m)**2))}
function diff(a,b){return Math.round(mad(a,b)*1000)/1000}
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--autoplay-policy=no-user-gesture-required']});
 try{
  const page=await browser.newPage({viewport:{width:W,height:H},deviceScaleFactor:1}),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.route('**/*',route=>{const u=new URL(route.request().url());if(u.pathname==='/fixture.webm')return route.fulfill({status:200,contentType:'video/webm',body:movie});if(u.pathname==='/frame.html')return route.fulfill({status:200,contentType:'text/html',body:`<!doctype html><style>html,body{margin:0;background:#000;width:100%;height:100%}#wrap{position:relative;width:100%;height:100%}video{display:block;width:100%;height:100%;object-fit:contain}</style><div id="wrap"><video id="video" src="/fixture.webm" controls></video><div id="site-overlay" style="position:absolute;right:0;top:0;width:24px;height:24px;background:rgb(255,220,0);z-index:1;pointer-events:none"></div></div>`});return route.abort()});
  await page.goto('https://kuro.local/frame.html');await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:ai});await page.addScriptTag({content:fx});
  const sample=async config=>page.evaluate(config=>{let state=JSON.parse(window.__kuroFx537.configure(config));let c=document.querySelector('canvas[data-kuro-fx]');if(!c)return {state,pixels:''};let gl=c.getContext('webgl2'),p=new Uint8Array(c.width*c.height*4);gl.readPixels(0,0,c.width,c.height,gl.RGBA,gl.UNSIGNED_BYTE,p);let encoded='';for(let i=0;i<p.length;i+=32768)encoded+=String.fromCharCode(...p.subarray(i,i+32768));return {state,pixels:btoa(encoded)}},config).then(o=>({state:o.state,pixels:Buffer.from(o.pixels,'base64')}));
  const raw=await page.evaluate(()=>{const v=document.querySelector('video'),c=document.createElement('canvas');c.width=320;c.height=180;const ctx=c.getContext('2d');ctx.translate(0,180);ctx.scale(1,-1);ctx.drawImage(v,0,0,320,180);const p=ctx.getImageData(0,0,320,180).data;let s='';for(let i=0;i<p.length;i+=32768)s+=String.fromCharCode(...p.subarray(i,i+32768));return btoa(s)}).then(s=>Buffer.from(s,'base64'));
  let off=await page.evaluate(()=>JSON.parse(window.__kuroFx537.configure({enabled:false,gain:100})));assert.equal(off.video,'off');assert.equal(await page.locator('canvas[data-kuro-fx]').count(),0);
  const samples={};for(const preset of ['A','B','C','A+A','B+B','C+A']){let r=await sample({...base,preset});assert.equal(r.state.video,'active');samples[preset]=r.pixels;assert.equal(r.pixels.length,W*H*4)}
  const pairs={};for(const a of Object.keys(samples))for(const b of Object.keys(samples))if(a<b){pairs[`${a}/${b}`]=diff(samples[a],samples[b]);assert(pairs[`${a}/${b}`]>1.5,`preset ${a}/${b} not meaningfully different: ${pairs[`${a}/${b}`]}`)}
  assert(mad(raw,samples.A)>1,'master-on output must differ visibly from source on the varied frame');
  const lineBase={...base,sharpen:0,denoise:0,lineStrength:200};
  const lo=(await sample(lineBase)).pixels,ld=(await sample({...lineBase,line:'dark'})).pixels,lt=(await sample({...lineBase,line:'thin'})).pixels;
  let lineLum=a=>{let n=[];for(let x=10;x<311;x+=12)for(let y=65;y<115;y++)n.push((pix(a,x,y,0)+pix(a,x,y,1)+pix(a,x,y,2))/3);return mean(n)};
  const lines=[lineLum(ld),lineLum(lo),lineLum(lt)];assert(lines[0]<lines[1]-.5,`darken must lower line luminance ${lines}`);assert(lines[2]>lines[1]+.5,`thin must lighten dark line pixels ${lines}`);assert(mad(ld,lt)>.4,'line modes visibly differ');
  const noLine=(await sample({...lineBase,line:'dark',lineStrength:0})).pixels;assert.deepEqual(noLine,lo,'zero line strength matches off');
  const smoothBase={...base,preset:'C',sharpen:0,denoise:0,edge:0};
  const sharp0=(await sample({...smoothBase,preset:'A',denoise:0,sharpen:0})).pixels,sharpMax=(await sample({...smoothBase,preset:'A',denoise:0,sharpen:200})).pixels;
  assert(mad(sharp0,sharpMax)>1,'sharpen changes real edges');
  const noise0=(await sample(smoothBase)).pixels,noiseMax=(await sample({...smoothBase,denoise:200})).pixels;
  const noisyVariance=variance(region(noise0,3,3,100,54)),smoothVariance=variance(region(noiseMax,3,3,100,54));assert(smoothVariance<noisyVariance*.8,`denoise lowers textured-patch variance ${noisyVariance} -> ${smoothVariance}`);
  const protect=(await sample({...smoothBase,denoise:200,edge:200})).pixels;assert(variance(region(protect,3,3,100,54))>smoothVariance,'edge preservation reduces smoothing at edges');
  const grey=(await sample({...base,saturation:0})).pixels;for(let i=0;i<grey.length;i+=4)assert(Math.abs(grey[i]-grey[i+1])<=1&&Math.abs(grey[i]-grey[i+2])<=1,'saturation zero is monochrome');
  const sat=(await sample({...base,saturation:200})).pixels;assert(mad(sat,samples.A)>2,'saturation has substantial effect');
  const contrast0=(await sample({...base,contrast:0})).pixels,contrast200=(await sample({...base,contrast:200})).pixels;assert(variance(region(contrast0,0,0,W,H))<1,'contrast zero flattens luma');assert(variance(region(contrast200,0,0,W,H))>variance(region(samples.A,0,0,W,H)),'higher contrast increases luma variance');
  const darker=(await sample({...base,brightness:50})).pixels,brighter=(await sample({...base,brightness:150})).pixels;assert(mean(region(darker,0,0,W,H))+30<mean(region(brighter,0,0,W,H)),'brightness direction');
  const dith0=(await sample({...base,deband:0})).pixels,dith100=(await sample({...base,deband:100})).pixels;assert(mad(dith0,dith100)>.3,'dither has measurable fine-grain output');
  const d8=(await sample({...base,detail:8})).pixels,d16=(await sample({...base,detail:16})).pixels,d32=(await sample({...base,detail:32})).pixels;assert(mad(d8,d16)>.2&&mad(d16,d32)>.1,'all sample tiers have different output on texture');
  const clean={...base,sharpen:0,denoise:0};const noAi=(await sample(clean)).pixels;let enhanced=await sample({...clean,ai:true});assert.equal(enhanced.state.ai,'active',JSON.stringify(enhanced.state));let aiDifference=mad(noAi,enhanced.pixels);assert(aiDifference>5,`100% AI+vivid finish should be clearly different on this test frame, got ${aiDifference}`);
  await page.waitForTimeout(150);let quarter=await sample({...clean,ai:true,aiStrength:25});await page.waitForTimeout(150);quarter=await sample({...clean,ai:true,aiStrength:25});assert.equal(quarter.state.ai,'active');assert(mad(noAi,quarter.pixels)<aiDifference*.65,'AI strength scales the visible finish');
  let zero=await sample({...clean,ai:true,aiStrength:0});assert.equal(zero.state.ai,'paused');assert.deepEqual(zero.pixels,noAi,'zero AI is exactly neutral');
  // Composition, not just readPixels: browser screenshots must show the canvas,
  // while a site-owned overlay on top remains visible. Native controls are
  // temporarily revealed by the shipped pointer behavior.
  await sample({...base,preset:'A+A'});await page.waitForTimeout(70);const enhancedShot=await page.screenshot();
  let comp=await page.evaluate(base=>JSON.parse(window.__kuroFx537.configure({...base,preset:'A+A',compare:true})),base);assert.equal(comp.video,'compare');assert.equal(await page.locator('canvas[data-kuro-fx]').evaluate(c=>getComputedStyle(c).visibility),'hidden');await page.waitForTimeout(70);const originalShot=await page.screenshot();assert(!enhancedShot.equals(originalShot),'enhancement is actually composited on screen, not merely rendered offscreen');
  const yellow=await page.evaluate(async data=>{let image=new Image();image.src='data:image/png;base64,'+data;await image.decode();let c=document.createElement('canvas');c.width=image.width;c.height=image.height;let x=c.getContext('2d');x.drawImage(image,0,0);return Array.from(x.getImageData(310,10,1,1).data)},enhancedShot.toString('base64'));assert(yellow[0]>240&&yellow[1]>200&&yellow[2]<20,`site overlay remains above video canvas ${yellow}`);
  comp=await page.evaluate(base=>JSON.parse(window.__kuroFx537.configure({...base,preset:'A+A',compare:false})),base);assert.equal(comp.video,'active');assert.equal(await page.locator('canvas[data-kuro-fx]').evaluate(c=>getComputedStyle(c).visibility),'visible');
  // Browser-native captions remain selected; readable active WebVTT cues are
  // mirrored above the canvas and disappear during comparison or disable.
  await page.evaluate(()=>{let v=document.querySelector('video');let t=v.addTextTrack('subtitles','English','en');t.mode='showing';t.addCue(new VTTCue(0,10,'Hello <i>world</i>'));v.currentTime=0;v.dispatchEvent(new Event('timeupdate'))});
  await page.waitForFunction(()=>document.querySelector('[data-kuro-captions]')?.textContent.includes('Hello'));assert(await page.locator('[data-kuro-captions]').evaluate(e=>getComputedStyle(e).visibility==='visible'));assert.equal(await page.evaluate(()=>document.querySelector('video').textTracks[0].mode),'showing');
  await page.evaluate(base=>window.__kuroFx537.configure({...base,compare:true}),base);assert.equal(await page.locator('[data-kuro-captions]').evaluate(e=>getComputedStyle(e).visibility),'hidden');
  await page.evaluate(base=>window.__kuroFx537.configure({...base,compare:false}),base);assert.equal(await page.locator('[data-kuro-captions]').evaluate(e=>getComputedStyle(e).visibility),'visible');
  await page.evaluate(()=>window.__kuroFx537.configure({enabled:false,gain:100}));assert.equal(await page.locator('[data-kuro-captions]').count(),0);assert.equal(await page.evaluate(()=>document.querySelector('video').textTracks[0].mode),'showing');
  // Simulate an EME-associated video: never sample or overlay protected media.
  await page.evaluate(()=>Object.defineProperty(document.querySelector('video'),'mediaKeys',{configurable:true,value:{}}));const protectedState=await page.evaluate(base=>JSON.parse(window.__kuroFx537.configure({...base,ai:true})),base);assert.equal(protectedState.video,'unavailable');assert.equal(protectedState.reason,'Protected video');assert.equal(protectedState.ai,'unavailable');assert.equal(await page.locator('canvas[data-kuro-fx]').count(),0);assert.equal(await page.locator('video').evaluate(v=>v.style.filter),'','known protected video is not styled');await page.evaluate(()=>delete document.querySelector('video').mediaKeys);
  assert.deepEqual(errors,[]);
  console.log('PASS 5.59 real decoded-frame control directions, six preset differences, AI/strength, visible compositing, compare and subtitles');
  console.log(JSON.stringify({presetMeanAbsoluteRgbDifferences:pairs,lineLuminanceDarkOffThin:lines.map(x=>+x.toFixed(2)),noiseVarianceBeforeAfter:[+noisyVariance.toFixed(2),+smoothVariance.toFixed(2)],aiMeanAbsoluteRgbDifference:+aiDifference.toFixed(2)}));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});

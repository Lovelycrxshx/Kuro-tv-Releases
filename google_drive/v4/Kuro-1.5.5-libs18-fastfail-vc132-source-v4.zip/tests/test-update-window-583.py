#!/usr/bin/env python3
"""Static checks for 5.83: the update window.

The guarantees, checked against the sources that are actually compiled:

  * a release waits its window (24 h default, 48 h, or none) measured from GitHub's own
    publish time — not from when the device happened to notice;
  * a window that has already passed never means another wait: the next check updates;
  * the wait can never strand an update — a one-shot job sits at the end of it, the daily
    check and the on-resume catch-up both act if the job was dropped;
  * "Update now" is a person asking, so it skips the window;
  * the delay change is a real setting with exactly three values;
  * nothing about verification, the network setting or Android's confirmation changed.
"""
import pathlib

root = pathlib.Path(__file__).resolve().parent.parent
src = root / "src/app/lovelycrxshx/kuro"
schedule = (src / "KuroUpdateSchedule583.java").read_text()
center = (src / "KuroUpdateCenter582.java").read_text()
dialog = (src / "KuroUpdateDialog582.java").read_text()
updater = (src / "KuroUpdater572.java").read_text()
main = (src / "MainActivity.java").read_text()
service = (src / "KuroUpdaterDownloadService.java").read_text()
manifest = (root / "AndroidManifest.xml").read_text()
due_job = (src / "KuroUpdateDueJob583.java").read_text()

# --- the window -------------------------------------------------------------
assert "static final int DEFAULT_HOURS = 24;" in schedule
assert "static final int MAX_HOURS = 48;" in schedule
assert "static long dueAt(long publishedAt, int hours)" in schedule
assert "return publishedAt + hours * HOUR_MS;" in schedule
assert "if (publishedAt <= 0 || hours <= 0) return 0L;" in schedule, \
    "an unknown publish time must never mean an unknown wait"
assert "static boolean due(long now, long publishedAt, int hours)" in schedule
assert "return due <= 0 || now >= due;" in schedule
assert "setDelayHours" in schedule and "putInt(\"delay583\", hours)" in schedule
assert "if (hours != 0 && hours != DEFAULT_HOURS && hours != MAX_HOURS)" in schedule

# publish time comes from GitHub, not from the first sighting
assert 'optString("published_at", "")' in updater
assert 'optString("created_at", "")' in updater
assert "static long parseTime(String iso)" in updater
assert 'new java.text.SimpleDateFormat("yyyy-MM-dd\'T\'HH:mm:ss", Locale.US)' in updater
assert "getTimeZone(\"UTC\")" in updater

# --- the automatic path honours it -----------------------------------------
assert "static boolean autoStep(Context c, KuroUpdater572.Release release)" in center
assert "KuroUpdateSchedule583.dueNow(c, release.publishedAt)" in center
assert "KuroUpdateSchedule583.defer(c, release);" in center
assert "if (KuroUpdateCenter582.autoStep(c, release)) return;" in updater, \
    "the scheduled pass must go through the window"
assert center.index("autoStep") < len(center)

# a person asking skips the wait
assert "static boolean checkNow(Context c, boolean immediate)" in center
assert "if (immediate || KuroUpdateSchedule583.dueNow(c, release.publishedAt))" in center
assert "KuroUpdateCenter582.checkNow(this,true)" in main, \
    "Update now must skip the window"

# --- the wait cannot strand an update --------------------------------------
assert "static void scheduleJob(Context c, long dueAt)" in schedule
assert "setMinimumLatency(latency)" in schedule and "setPersisted(true)" in schedule
assert "KuroUpdateDueJob583.class" in schedule
assert "public final class KuroUpdateDueJob583 extends JobService" in due_job
assert "KuroUpdater572.run(app);" in due_job
assert 'android:name=".KuroUpdateDueJob583"' in manifest, "the due job must be declared"
assert "static boolean claimCatchUp(Context c)" in schedule
assert "KuroUpdateSchedule583.claimCatchUp(MainActivity.this)" in main
assert "KICK_GAP_MS" in schedule, "the catch-up must be throttled"

# --- surfacing --------------------------------------------------------------
assert 'SCHEDULED = "scheduled"' in center
assert "scheduledLine" in center and "scheduledLine" in main
assert '"SCHEDULED"' in dialog and "Update now" in dialog
assert '"updatesDelay583"' in main
assert "updatesDelay583" in (root / "assets/settings560.js").read_text()

# --- nothing loosened -------------------------------------------------------
assert "KuroApkPreflight572.inspect(this, target)" in service
assert "did not match the published checksum" in service
assert "wifiOnly" in service and "WaitForWifi" in service
assert "canRequestPackageInstalls" in main
assert "autoOffered582" in center

# --- arithmetic mirrored from the source ------------------------------------
HOUR = 3600 * 1000
PUBLISHED = 1_766_000_000_000  # arbitrary fixed instant

def due_at(published, hours):
    if published <= 0 or hours <= 0:
        return 0
    return published + hours * HOUR

def is_due(now, published, hours):
    d = due_at(published, hours)
    return d <= 0 or now >= d

# inside the window: waits
assert not is_due(PUBLISHED + 23 * HOUR, PUBLISHED, 24)
# exactly at the end of the window: installs
assert is_due(PUBLISHED + 24 * HOUR, PUBLISHED, 24)
# a device that was off for three days: due immediately, never another wait
assert is_due(PUBLISHED + 72 * HOUR, PUBLISHED, 24)
assert is_due(PUBLISHED + 72 * HOUR, PUBLISHED, 48)
# 48-hour choice waits longer than 24
assert not is_due(PUBLISHED + 30 * HOUR, PUBLISHED, 48)
assert is_due(PUBLISHED + 48 * HOUR, PUBLISHED, 48)
# "as soon as it is found"
assert is_due(PUBLISHED, PUBLISHED, 0)
# unknown publish time is never a wait
assert is_due(PUBLISHED, 0, 24)
assert due_at(0, 24) == 0

def human_left(millis):
    if millis <= 0: return "now"
    minutes = millis // 60000
    if minutes < 1: return "in under a minute"
    if minutes < 60: return f"in {minutes} min"
    hours = minutes // 60
    if hours < 48: return f"in {hours} h"
    return f"in {hours // 24} days"

assert human_left(24 * HOUR) == "in 24 h"
assert human_left(45 * 60000) == "in 45 min"
assert human_left(30 * 1000) == "in under a minute"
assert human_left(0) == "now"
assert human_left(3 * 24 * HOUR) == "in 3 days"

print("test-update-window-583: PASS")

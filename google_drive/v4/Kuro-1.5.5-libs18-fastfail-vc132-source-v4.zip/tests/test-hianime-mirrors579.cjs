const fs=require('fs'),vm=require('vm'),assert=require('assert');
const mirrors=fs.readFileSync('assets/mirrors579.js','utf8');
const app=fs.readFileSync('assets/app.js','utf8');
const failover=fs.readFileSync('assets/failover531.js','utf8');
const activity=fs.readFileSync('src/app/lovelycrxshx/kuro/MainActivity.java','utf8');

const ctx={URL};vm.runInNewContext(mirrors+';globalThis.H=({HI_MIRRORS,HI_MIRROR_HOSTS,hiIsMirrorHost,hiCurrentOrigin,hiRotateMirror,hiRememberMirror})',ctx);
const H=ctx.H;

// the three requested domains are present, in order, after the 5.75 domain
assert.deepEqual(Array.from(H.HI_MIRRORS),['https://hianime.dk','https://hianime.fm','https://hianime.al','https://hianimes.es']);

// host matching accepts the domain and its subdomains, and nothing else
for(const h of ['hianime.dk','hianime.fm','hianime.al','hianimes.es','cdn.hianime.dk'])assert.equal(H.hiIsMirrorHost(h),true,h);
for(const h of ['hianimeq.top','evil.example','hianime.fm.evil.example','xhianimes.es'])assert.equal(H.hiIsMirrorHost(h),false,h);

// rotation walks the list and stops being useful once it wraps
assert.equal(H.hiCurrentOrigin(),'https://hianime.dk');
assert.equal(H.hiRotateMirror('https://hianime.dk'),'https://hianime.fm');
assert.equal(H.hiRotateMirror('https://hianime.fm'),'https://hianime.al');
assert.equal(H.hiRotateMirror('https://hianime.al'),'https://hianimes.es');
assert.equal(H.hiCurrentOrigin(),'https://hianimes.es');
// a mirror that worked is remembered, and an unknown origin cannot rotate
ctx.H.hiRememberMirror('https://hianime.al');
assert.equal(H.hiCurrentOrigin(),'https://hianime.al');
assert.equal(H.hiRotateMirror('https://not-a-mirror.example'),'');

// the allowlists in the browser layer carry every mirror
assert.ok(app.includes("'dk':(typeof hiCurrentOrigin==='function'?hiCurrentOrigin():'https://hianime.dk')"),'base(dk) follows the active mirror');
assert.ok(app.includes("...HI_MIRROR_HOSTS"),'source/player allowlists use the shared list');
assert.ok(!app.includes("'dk':'https://hianime.dk',"),'the dk origin is no longer hardcoded');

// and so do the native gates
assert.ok(activity.includes('"hianime.fm","hianime.al","hianimes.es"'),'native mirror list');
assert.ok(activity.includes('HI_MIRROR_HOSTS.contains(h)'),'native sourceHost accepts mirrors');
assert.ok(activity.includes('"/mirrors579.js".equals(u.getPath())'),'the new asset is served to the WebView');
assert.ok(activity.includes('HI_MIRROR_ORIGINS.get(referer)+"/"'),'player Referer covers every mirror');

// the failover path keeps using the dk code path but walks the mirrors
assert.ok(failover.includes('hiIsMirrorHost(new URL(first).hostname)'),'failover accepts mirror hosts');
assert.ok(failover.includes('fallbackMainOne'),'failover splits rotation from the single-mirror attempt');
assert.ok(failover.includes('hiRotateMirror(origin)'),'failover rotates');
console.log('PASS HiAnime mirrors: list, host matching, rotation, browser and native allowlists');

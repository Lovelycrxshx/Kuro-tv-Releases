'use strict';
// Headless WebView-like regression; no real phone, provider or Discord account.
const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets');
const types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.jpg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml'};
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html',file=path.resolve(root,name);if(!file.startsWith(root+path.sep))return res.writeHead(403).end();fs.readFile(file,(e,data)=>e?res.writeHead(404).end():res.writeHead(200,{'content-type':types[path.extname(file)]||'application/octet-stream'}).end(data))});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;try{
 browser=await chromium.launch({headless:true,executablePath:process.env.KURO_CHROMIUM||'/usr/bin/chromium',args:['--no-sandbox']});
 const ctx=await browser.newContext({viewport:{width:393,height:852},isMobile:true,hasTouch:true}),page=await ctx.newPage(),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  const replies={},actualFetch=window.fetch.bind(window);
  if(!localStorage.getItem('fixture571')){
   localStorage.setItem('fixture571','yes');
   localStorage.setItem('kuro-profile-v1',JSON.stringify({name:'Test User',avatar:'profile-avatar547-b.jpg',banner:'profile-banner547.jpg',customField:'keep me'}));
   localStorage.setItem('kuro-profile-card-art-v1',JSON.stringify({anime:'profile-card548-anime-b.jpg',history:'profile-card548-history-b.jpg'}));
   localStorage.setItem('kuro-library',JSON.stringify([{source:'ms',title:'Saved',url:'https://hianime.ms/anime/saved'}]));
  }
  window.fetch=(input,opts)=>{let u=typeof input==='string'?input:input.url;if(u.startsWith('/result/'))return Promise.resolve(new Response(replies[decodeURIComponent(u.slice(8))]||'',{status:200}));return actualFetch(input,opts)};
  const finish=(id,data,error='')=>{if(!error)replies[id]=typeof data==='string'?data:JSON.stringify(data);setTimeout(()=>window.__nativeResult(id,error),0)};
  const con={local:{connected:true,exists:true,name:'fixture@example.invalid'},discord:{connected:false},mal:{connected:false},anilist:{connected:false}};
  window.KuroNative={
   account(id,action){if(action==='status')finish(id,{config:{mal:'',discord:'',anilist:''},connections:con});else finish(id,null,'Unsupported fixture')},
   get(id){finish(id,'<html><body></body></html>')},news(id){finish(id,{items:[],failed:[],checkedAt:Date.now()})},newsSettings(){return JSON.stringify({enabled:false,allowed:false})},adultMetadata(id){finish(id,{data:{a:{media:[]},m:{media:[]}}})},
   profileHeader560(){},applySettings560(){},settingsAction560(){},discordRpcEnabled563(){return false},discordOptions564(){return '{}'},setDiscordOption564(){return true},backupFile560(){}
  };
 });
 await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);await page.waitForSelector('#header-login.is-profile560 img');
 let initial=await page.evaluate(()=>({p:JSON.parse(localStorage.getItem('kuro-profile-v1')),cards:JSON.parse(localStorage.getItem('kuro-profile-card-art-v1')),library:JSON.parse(localStorage.getItem('kuro-library'))}));
 assert.equal(initial.p.name,'Test User');assert.equal(initial.p.avatar,'');assert.equal(initial.p.banner,'');assert.equal(initial.p.customField,'keep me');assert.equal(initial.p.presetSchema571,1);
 assert.deepEqual(initial.cards,{anime:'profile-card548-anime-b.jpg',history:'profile-card548-history-b.jpg'});assert.equal(initial.library.length,1);
 await page.evaluate(()=>nav('profile'));await page.waitForSelector('#profile-characters549');
 assert.equal(await page.locator('[data-avatar-preset]').count(),0);assert.equal(await page.locator('#profile-avatar-pick').count(),1);
 await page.click('#profile-characters549');await page.waitForSelector('#profile-presets571 .preset-choice571');
 assert.deepEqual(await page.locator('.preset-tabs571 button').allTextContents(),['PFP','Banner','Anime','History']);assert.equal(await page.locator('.preset-choice571').count(),160);
 assert.equal(await page.locator('#profile-presets571 input[type=file]').count(),0);
 for(const [w,h] of [[280,640],[320,640],[393,852],[640,360]]){await page.setViewportSize({width:w,height:h});let box=await page.locator('#account-overlay .account-dialog').boundingBox();assert(box.x>=0&&box.x+box.width<=w+1);for(const sel of ['.preset-tabs571 button','.preset-choice571','.artwork-picker571 .account-x']){let rect=await page.locator(sel).first().boundingBox();assert(rect.width>=47.5&&rect.height>=47.5,sel+' touch target '+JSON.stringify(rect))}assert(await page.evaluate(()=>document.documentElement.scrollWidth)<=w+1)}await page.setViewportSize({width:393,height:852});if(process.env.KURO571_SCREENSHOT)await page.screenshot({path:process.env.KURO571_SCREENSHOT,animations:'disabled'});await page.locator('.artwork-picker571 .account-x').focus();await page.keyboard.press('Shift+Tab');assert.equal(await page.evaluate(()=>document.activeElement.hasAttribute('data-apply')),true);await page.keyboard.press('Tab');assert.equal(await page.evaluate(()=>document.activeElement.classList.contains('account-x')),true);
 await page.locator('.preset-choice571').nth(0).click();assert.equal(await page.locator('.preset-preview-avatar571').getAttribute('src'),'preset571-a-001.jpg');
 assert.equal((await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-profile-v1')))).avatar,'');
 await page.click('#profile-presets571 [data-cancel]');assert.equal((await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-profile-v1')))).avatar,'');
 await page.click('#profile-characters549');await page.locator('.preset-choice571').nth(2).click();
 await page.locator('.preset-tabs571 [data-tab=profile]').click();await page.locator('.preset-choice571').nth(3).click();
 await page.locator('.preset-tabs571 [data-tab=anime]').click();await page.locator('.preset-choice571').nth(4).click();
 assert.equal((await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-profile-card-art-v1')))).anime,'profile-card548-anime-b.jpg');
 await page.click('#profile-presets571 [data-apply]');await page.waitForSelector('#profile-characters549');
 let saved=await page.evaluate(()=>({p:JSON.parse(localStorage.getItem('kuro-profile-v1')),cards:JSON.parse(localStorage.getItem('kuro-profile-card-art-v1'))}));
 assert.equal(saved.p.avatar,'preset571-a-003.jpg');assert.equal(saved.p.banner,'preset571-b-004.jpg');assert.equal(saved.p.customField,'keep me');assert.equal(saved.cards.anime,'preset571-b-005.jpg');assert.equal(saved.cards.history,'profile-card548-history-b.jpg');
 const exported=await page.evaluate(()=>{let t=kuroBackup560.exportText();return {summary:kuroBackup560.preview(t).summary,data:JSON.parse(t).data}});assert.equal(exported.data['kuro-profile-v1'].avatar,'preset571-a-003.jpg');
 await page.reload();await page.waitForSelector('#header-login.is-profile560 img');assert.equal((await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-profile-v1')))).avatar,'preset571-a-003.jpg');
 // Fail the card write during a two-key apply: both keys must roll back.
 const rolled=await page.evaluate(()=>{let p=localStorage.getItem('kuro-profile-v1'),c=localStorage.getItem('kuro-profile-card-art-v1');let f=Storage.prototype.setItem,once=true,failed=false;Storage.prototype.setItem=function(k,v){if(k==='kuro-profile-card-art-v1'&&once){once=false;throw Error('quota')}return f.call(this,k,v)};try{kuroPresets571.commit({avatar:'preset571-a-006.jpg',anime:'preset571-b-006.jpg'},new Set(['avatar','anime']))}catch(_){failed=true}finally{Storage.prototype.setItem=f}return {failed,p:localStorage.getItem('kuro-profile-v1')===p,c:localStorage.getItem('kuro-profile-card-art-v1')===c,j:localStorage.getItem('kuro-profile-preset-journal571-v1')}});
 assert.deepEqual(rolled,{failed:true,p:true,c:true,j:null});
 // A crash after the journal is written is rolled back on the next document load.
 const beforeCrash=await page.evaluate(()=>{let p=localStorage.getItem('kuro-profile-v1'),c=localStorage.getItem('kuro-profile-card-art-v1');localStorage.setItem('kuro-profile-preset-journal571-v1',JSON.stringify({version:1,before:{'kuro-profile-v1':p,'kuro-profile-card-art-v1':c}}));localStorage.setItem('kuro-profile-v1',JSON.stringify({name:'partial',avatar:'preset571-a-009.jpg',banner:''}));localStorage.setItem('kuro-profile-card-art-v1',JSON.stringify({anime:'preset571-b-009.jpg',history:'preset571-b-009.jpg'}));return {p,c}});
 await page.reload();await page.waitForSelector('#header-login.is-profile560 img');const afterCrash=await page.evaluate(()=>({p:localStorage.getItem('kuro-profile-v1'),c:localStorage.getItem('kuro-profile-card-art-v1'),j:localStorage.getItem('kuro-profile-preset-journal571-v1')}));assert.deepEqual(afterCrash,{...beforeCrash,j:null});
 // If rollback itself fails, keep the journal and block edits until recovery succeeds.
 const delayed=await page.evaluate(()=>{let p=localStorage.getItem('kuro-profile-v1'),c=localStorage.getItem('kuro-profile-card-art-v1'),f=Storage.prototype.setItem,broken=false;Storage.prototype.setItem=function(k,v){if(k==='kuro-profile-card-art-v1'){broken=true;throw Error('storage failure')}if(k==='kuro-profile-v1'&&broken)throw Error('storage failure');return f.call(this,k,v)};try{kuroPresets571.commit({avatar:'preset571-a-010.jpg',anime:'preset571-b-010.jpg'},new Set(['avatar','anime']))}catch(_){}finally{Storage.prototype.setItem=f}let pending=!!localStorage.getItem('kuro-profile-preset-journal571-v1'),recovered=kuroPresets571.prepare();return {pending,recovered,p:localStorage.getItem('kuro-profile-v1')===p,c:localStorage.getItem('kuro-profile-card-art-v1')===c}});assert.deepEqual(delayed,{pending:true,recovered:true,p:true,c:true});
 assert.deepEqual(errors,[]);
 console.log('PASS profile migration, 160 pairs, four categories, preview/cancel/apply, independent cards, backup, restart recovery and storage-failure rollback');
 }finally{if(browser)await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

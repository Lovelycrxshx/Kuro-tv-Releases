'use strict';
// Offline, synthetic test of the bundled MIT Anime4K CNN and Kuro's actual
// WebGL2 integration. It does not establish phone GPU speed or source access.
const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets'),libs=path.resolve(__dirname,'../libs');
const ai=fs.readFileSync(path.join(root,'ai-upscale540.js'),'utf8'),fx=fs.readFileSync(path.join(root,'video-effects537.js'),'utf8');
const movie=fs.readFileSync(path.join(__dirname,'fixtures/fx-demo.webm'));
// Independent scalar reference for the 8x8 network. The license and original
// shader are shipped alongside the modified WebGL2 implementation.
function cpuExpected(){
 const text=fs.readFileSync(path.join(libs,'Anime4K_Upscale_CNN_x2_S.glsl'),'utf8'),chunks=text.split('//!DESC ').slice(1,5);let image=[];
 for(let y=0;y<8;y++)for(let x=0;x<8;x++)image.push([x*31/255,y*31/255,(x+y)*15/255,1]);
 for(const part of chunks){
  const ops=[...part.matchAll(/mat4\(([^)]*)\)\s*\*\s*go_([01])\((-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)\)/g)].map(m=>({m:m[1].split(',').map(Number),sign:Number(m[2]),x:Number(m[3]),y:Number(m[4])}));
  const bias=part.match(/result \+= vec4\(([^)]*)\)/)[1].split(',').map(Number);assert([9,18].includes(ops.length));const out=[];
  for(let y=0;y<8;y++)for(let x=0;x<8;x++){
   let r=bias.slice();for(const op of ops){let sx=Math.max(0,Math.min(7,x+op.x)),sy=Math.max(0,Math.min(7,y+op.y)),v=image[sy*8+sx];
    if(ops.length===18)v=v.map(n=>Math.max(op.sign===0?n:-n,0));
    for(let row=0;row<4;row++)for(let col=0;col<4;col++)r[row]+=op.m[col*4+row]*v[col];
   }out.push(r);
  }image=out;
 }
 const result=[];for(let y=0;y<16;y++)for(let x=0;x<16;x++)result.push(image[Math.floor(y/2)*8+Math.floor(x/2)][(y%2)*2+x%2]);return result;
}
(async()=>{const browser=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--autoplay-policy=no-user-gesture-required']});try{
 const page=await browser.newPage({viewport:{width:640,height:360}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('data:text/html,<canvas id="test"></canvas>');await page.addScriptTag({content:ai});
 const numerical=await page.evaluate(()=>{
  const canvas=document.querySelector('canvas');canvas.width=32;canvas.height=32;const gl=canvas.getContext('webgl2');if(!gl)return {error:'no WebGL2'};
  const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);for(const k of [gl.TEXTURE_MIN_FILTER,gl.TEXTURE_MAG_FILTER])gl.texParameteri(gl.TEXTURE_2D,k,gl.NEAREST);for(const k of [gl.TEXTURE_WRAP_S,gl.TEXTURE_WRAP_T])gl.texParameteri(gl.TEXTURE_2D,k,gl.CLAMP_TO_EDGE);
  const pixels=new Uint8Array(8*8*4);for(let y=0;y<8;y++)for(let x=0;x<8;x++){let i=(y*8+x)*4;pixels[i]=x*31;pixels[i+1]=y*31;pixels[i+2]=(x+y)*15;pixels[i+3]=255}gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,8,8,0,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
  const net=window.__kuroAI540.create(gl),out=net.render(tex,8,8),fb=gl.createFramebuffer();gl.bindFramebuffer(gl.FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,out.texture,0);const rgba=new Float32Array(16*16*4);gl.readPixels(0,0,16,16,gl.RGBA,gl.FLOAT,rgba);const err=gl.getError(),values=Array.from(rgba).filter((_,i)=>i%4===0);const wide=net.render(tex,1920,1080),tall=net.render(tex,1080,1920),bounds=[wide.width,wide.height,tall.width,tall.height];net.destroy();return {values,err,w:out.width,h:out.height,bounds};
 });
 assert.equal(numerical.err,0);assert.equal(numerical.w,8);assert.equal(numerical.h,8);assert.deepEqual(numerical.bounds,[480,270,151,270]);const expected=cpuExpected();assert.equal(numerical.values.length,expected.length);const maxError=Math.max(...expected.map((v,i)=>Math.abs(v-numerical.values[i])));assert(maxError<.001,'all GPU CNN pixels match independent pretrained-network CPU reference; max error '+maxError);
 await page.route('**/*',route=>{const url=new URL(route.request().url());if(url.pathname.endsWith('.webm'))return route.fulfill({status:200,contentType:'video/webm',body:movie});if(url.pathname==='/stream-player.html')return route.fulfill({status:200,contentType:'text/html',body:'<!doctype html><html><style>html,body{margin:0}video{width:640px;height:360px;display:block}</style><video id="video" src="/movie.webm" controls></video></html>'});return route.abort()});
 await page.goto('https://kuro.local/stream-player.html');await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:ai});await page.evaluate(()=>{const real=window.__kuroAI540.create;window.__aiCreated=0;window.__aiDestroyed=0;window.__kuroAI540.create=function(gl){window.__aiCreated++;const engine=real(gl),destroy=engine.destroy;engine.destroy=function(){window.__aiDestroyed++;destroy()};return engine}});await page.addScriptTag({content:fx});
 const sample=async config=>page.evaluate(config=>{const state=JSON.parse(window.__kuroFx537.configure(config));const c=document.querySelector('canvas[data-kuro-fx]');if(!c)return {state,pixels:[]};let gl=c.getContext('webgl2'),bytes=new Uint8Array(c.width*c.height*4);gl.readPixels(0,0,c.width,c.height,gl.RGBA,gl.UNSIGNED_BYTE,bytes);let pixels=[];for(let i=0;i<bytes.length;i+=64)pixels.push(bytes[i],bytes[i+1],bytes[i+2]);return {state,pixels}},config);
 const base={enabled:true,ai:false,aiStrength:100,sharpen:0,denoise:0,lineStrength:100,edge:100,saturation:100,contrast:100,brightness:100,deband:0,detail:8,gain:100};
 const original=await sample(base),enhanced=await sample({...base,ai:true});assert.equal(original.state.video,'active');assert.equal(original.state.ai,'off');assert.equal(enhanced.state.video,'active',JSON.stringify(enhanced.state));assert.equal(enhanced.state.ai,'active',JSON.stringify(enhanced.state));assert.equal(enhanced.state.aiWidth,320);assert.equal(enhanced.state.aiHeight,180);
 assert(original.pixels.some((n,i)=>n!==enhanced.pixels[i]),'AI changes rendered pixels for a real video frame');
 // Let the fence settle before requesting a zero-strength comparison.
 await page.waitForTimeout(120);const zero=await sample({...base,ai:true,aiStrength:0});assert.equal(zero.state.ai,'paused');assert.deepEqual(zero.pixels,original.pixels,'zero AI strength preserves the normal rendered image');assert.deepEqual(await page.evaluate(()=>[window.__aiCreated,window.__aiDestroyed]),[1,1],'disabling AI releases its engine');
 const off=await sample(base);assert.equal(off.state.ai,'off');assert.equal(off.state.video,'active');
 // Absent engine must leave the classic renderer alive, not silently call it AI.
 await page.goto('https://kuro.local/stream-player.html');await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:fx});const missing=await sample({...base,ai:true});assert.equal(missing.state.video,'active');assert.equal(missing.state.ai,'unavailable');
 // A GPU without floating-point render targets keeps the classic filter.
 await page.goto('https://kuro.local/stream-player.html');await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:ai});await page.addScriptTag({content:fx});await page.evaluate(()=>{const real=WebGL2RenderingContext.prototype.getExtension;WebGL2RenderingContext.prototype.getExtension=function(name){return name==='EXT_color_buffer_float'?null:real.call(this,name)}});const noFloats=await sample({...base,ai:true});assert.equal(noFloats.state.video,'active');assert.equal(noFloats.state.ai,'unavailable');
 // A lost WebGL context removes the canvas and makes no false AI claim.
 await page.goto('https://kuro.local/stream-player.html');await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:ai});await page.addScriptTag({content:fx});await sample({...base,ai:true});await page.evaluate(()=>{const gl=document.querySelector('canvas[data-kuro-fx]').getContext('webgl2');gl.getExtension('WEBGL_lose_context').loseContext()});await page.waitForFunction(()=>JSON.parse(window.__kuroFx537.status()).reason==='GPU context lost');const lost=await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()));assert.equal(lost.video,'unavailable');assert.equal(lost.ai,'unavailable');assert.equal(await page.locator('canvas[data-kuro-fx]').count(),0);
 // Tainted third-party frames remain untouched; there is no CORS bypass.
 await page.goto('https://kuro.local/stream-player.html');await page.evaluate(()=>{let v=document.querySelector('video');v.src='https://foreign.example/movie.webm';v.load()});await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:ai});await page.addScriptTag({content:fx});const restricted=await sample({...base,ai:true});assert.equal(restricted.state.video,'unavailable');assert.equal(restricted.state.ai,'unavailable');assert.equal(await page.locator('canvas[data-kuro-fx]').count(),0);
 // Simulate a GPU that never completes. A single queued inference is allowed;
 // the fallback must stop AI and keep the ordinary video renderer alive.
 await page.goto('https://kuro.local/stream-player.html');await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:ai});await page.addScriptTag({content:fx});
 await page.evaluate(base=>{const glp=WebGL2RenderingContext.prototype;glp.clientWaitSync=function(){return this.TIMEOUT_EXPIRED};document.querySelector('video').play();window.__kuroFx537.configure({...base,ai:true})},base);
 await page.waitForFunction(()=>{const s=JSON.parse(window.__kuroFx537.status());return s.ai==='unavailable'&&s.aiReason.includes('speed')},null,{timeout:12000});const fallback=await page.evaluate(()=>({state:JSON.parse(window.__kuroFx537.status()),time:document.querySelector('video').currentTime,paused:document.querySelector('video').paused}));assert.equal(fallback.state.video,'active');assert(!fallback.paused);assert(fallback.time>0);
 // A stalled GPU must also fall back when the video is paused and supplies no
 // future frame callbacks. The watchdog itself is asynchronous and bounded.
 await page.goto('https://kuro.local/stream-player.html');await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:ai});await page.addScriptTag({content:fx});await page.evaluate(base=>{WebGL2RenderingContext.prototype.clientWaitSync=function(){return this.TIMEOUT_EXPIRED};window.__kuroFx537.configure({...base,ai:true})},base);
 await page.waitForFunction(()=>JSON.parse(window.__kuroFx537.status()).aiReason.includes('speed'),null,{timeout:12000});const pausedFallback=await page.evaluate(()=>({state:JSON.parse(window.__kuroFx537.status()),paused:document.querySelector('video').paused}));assert.equal(pausedFallback.state.video,'active');assert(pausedFallback.paused);
 assert.deepEqual(errors,[]);console.log('PASS offline pretrained CNN CPU/GPU parity, real video-pixel changes, strength/cleanup, blocked-frame safety and playing/paused slow-GPU fallback');
 }finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});

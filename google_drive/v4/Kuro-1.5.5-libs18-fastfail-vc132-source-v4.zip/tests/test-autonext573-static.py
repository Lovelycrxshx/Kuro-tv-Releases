from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'src/app/lovelycrxshx/kuro/MainActivity.java').read_text()
assert 'Playing the next episode in 10 seconds.' in s
assert '.setNegativeButton("Cancel",(dialog,which)->cancelAutoNext573())' in s
assert '.setPositiveButton("Play now",(dialog,which)->advance.run())' in s
assert s.count('offerAutoNext573(session,current+1)') == 2
assert 'void closePlayer(){cancelAutoNext573();' in s
assert '@Override protected void onPause(){cancelAutoNext573();' in s
assert 'android.os.SystemClock.elapsedRealtime()+10000' in s
assert 'isInPictureInPictureMode()' in s[s.index('private void offerAutoNext573'):s.index('private void notifyPlayerError560')]
assert 'session.equals(watchSession)' in s[s.index('private void offerAutoNext573'):s.index('private void notifyPlayerError560')]
print('PASS auto-next countdown static wiring (not an Android runtime test)')

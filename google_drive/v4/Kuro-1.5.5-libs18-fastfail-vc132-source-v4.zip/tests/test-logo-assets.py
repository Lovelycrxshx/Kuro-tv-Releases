#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
from xml.etree import ElementTree as ET
root=Path(__file__).resolve().parents[1]
ns={'a':'http://schemas.android.com/apk/res/android'}
manifest=ET.parse(root/'AndroidManifest.xml').getroot()
assert manifest.attrib['package']=='app.lovelycrxshx.kuro'
assert manifest.attrib['{http://schemas.android.com/apk/res/android}versionCode']=='70'
assert manifest.attrib['{http://schemas.android.com/apk/res/android}versionName']=='5.70'
app=manifest.find('application');assert app.attrib['{http://schemas.android.com/apk/res/android}label']=='Kuro.tv'
assert app.attrib['{http://schemas.android.com/apk/res/android}icon']=='@mipmap/ic_launcher'
icon=ET.parse(root/'res/mipmap-anydpi-v26/ic_launcher.xml').getroot()
assert icon.tag=='adaptive-icon' and icon.find('background').attrib['{http://schemas.android.com/apk/res/android}drawable']=='@android:color/black'
img=Image.open(root/'res/drawable-nodpi/icon_foreground.png').convert('RGBA');assert img.size==(1080,1080)
assert img.getpixel((0,0))[3]==0
left,top,right,bottom=img.getbbox();assert 210<=left<right<=870 and 210<=top<bottom<=870,(left,top,right,bottom)
splash=Image.open(root/'res/drawable-nodpi/splash_logo.png').convert('RGBA');assert splash.size==(2740,950) and splash.getpixel((0,0))[3]==0
svg=ET.parse(root/'assets/kuro-logo.svg').getroot();assert svg.tag.endswith('svg') and svg.attrib['viewBox']=='110 180 2740 950'
assert not any(el.tag.endswith(('script','image')) for el in svg.iter()),'Logo contains raster or script elements'
html=(root/'assets/index.html').read_text();assert '<title>Kuro.tv</title>' in html and 'src="kuro-logo.svg" alt="Kuro.tv"' in html
assert 'image/svg+xml' in (root/'src/app/lovelycrxshx/kuro/MainActivity.java').read_text()
print('PASS app label, adaptive launcher safe zone, transparent splash artwork, scalable SVG and asset route')

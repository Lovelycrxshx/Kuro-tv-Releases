'use strict';
// Chromium exercises the shipped local UI with fake native/network responses.
// This does not run Android or play real anime.
const {chromium}=require('playwright'),http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets');
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://x').pathname.slice(1)||'index.html',file=path.resolve(root,name);if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return}fs.readFile(file,(err,data)=>{if(err){res.writeHead(404).end();return}res.writeHead(200,{'content-type':name.endsWith('.js')?'application/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'text/html'}).end(data)})});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({headless:true,args:['--no-sandbox']});try{
 const ctx=await browser.newContext({viewport:{width:393,height:800},isMobile:true,hasTouch:true}),page=await ctx.newPage(),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  window.__result={};window.__external=[];
  function done(id,value,error=''){window.__result[id]=typeof value==='string'?value:JSON.stringify(value);setTimeout(()=>window.__nativeResult?.(id,error),0)}
  window.KuroNative={get(id){done(id,'{}')},news(id){done(id,{items:[],failed:[],checkedAt:Date.now()})},newsSettings(){return '{"enabled":false,"allowed":false}'},adultMetadata(id){done(id,{data:{a:{media:[]},m:{media:[]}}})},openExternalSource(x){window.__external.push(x)}};
  const original=window.fetch.bind(window);window.fetch=(input,opts)=>{let u=typeof input==='string'?input:input.url;if(u.startsWith('/result/'))return Promise.resolve(new Response(window.__result[decodeURIComponent(u.slice(8))]||'',{status:200}));return original(input,opts)};
 });
 const url=`http://127.0.0.1:${server.address().port}/index.html`;
 await page.goto(url);await page.evaluate(()=>{fetchCatalogPage=async()=>({items:[],hasNext:false})});
 // Warm in-app news retains the same live DOM and typed value.
 await page.click('[data-nav="search"]');await page.fill('#q','Cowboy Bebop');await page.click('#go');
 await page.fill('#q','Cowboy Bebop typed');await page.evaluate(()=>{window.__kept=document.querySelector('#q');window.kuroNewsOpen()});
 assert.equal(await page.evaluate(()=>view),'search');await page.click('#news-back');
 assert(await page.evaluate(()=>document.querySelector('#q')===window.__kept));assert.equal(await page.locator('#q').inputValue(),'Cowboy Bebop typed');
 await page.evaluate(()=>window.kuroSavePage());let snap=await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-page-checkpoint-v1')));
 assert.equal(snap.view,'search');assert.equal(snap.browse.query,'Cowboy Bebop');assert.equal(snap.browse.typed,'Cowboy Bebop typed');
 // Fresh UI starts home; native cold-intent hook restores browse underneath news.
 await page.reload();assert.equal(await page.evaluate(()=>view),'home');await page.evaluate(()=>window.kuroRestoreForNews());
 assert.equal(await page.evaluate(()=>view),'search');assert.equal(await page.locator('#news-overlay').count(),1);
 await page.click('#news-back');assert.equal(await page.locator('#q').inputValue(),'Cowboy Bebop typed');assert.equal(await page.evaluate(()=>browseQuery),'Cowboy Bebop');
 assert.equal(await page.locator('[data-nav="search"]').getAttribute('aria-current'),'page');
 // A scrollable locally saved list comes back at the same place after cold launch.
 await page.evaluate(()=>{localStorage.setItem('kuro-library',JSON.stringify(Array.from({length:55},(_,i)=>({source:'ms',title:'Saved '+i,url:'https://hianime.ms/details/saved-'+i,img:''}))));listFilter='all';nav('library');window.scrollTo(0,950)});
 await page.waitForFunction(()=>window.scrollY>800);await page.waitForTimeout(260);const beforeY=await page.evaluate(()=>window.scrollY);
 await page.reload();await page.evaluate(()=>window.kuroRestoreForNews());await page.click('#news-back');await page.waitForTimeout(400);assert(Math.abs(await page.evaluate(()=>window.scrollY)-beforeY)<5,'cold list scroll restored');
 // Filter state is updated by normal UI events, and restored after recreation.
 await page.click('[data-nav="library"]');await page.click('[data-list-filter="history"]');
 snap=await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-page-checkpoint-v1')));assert.equal(snap.view,'library');assert.equal(snap.listFilter,'history');
 await page.reload();await page.evaluate(()=>window.kuroRestoreForNews());await page.click('#news-back');assert.equal(await page.evaluate(()=>view),'library');assert.equal(await page.evaluate(()=>listFilter),'history');assert((await page.locator('main').innerText()).includes('History'));
 // Save a watch state, not a playable stream URL or cookie/header data.
 await page.evaluate(async()=>{selected={source:'ms',title:'Safe title',url:'https://hianime.ms/details/safe',img:'',anilistId:123,malId:456,streamUrl:'https://private.example/signed.m3u8?secret=yes',headers:{Cookie:'private'},unifiedVariants:[{url:'https://private.example'}]};view='detail';episodes=[{number:'5',name:'Episode five',url:'https://private.example/raw-stream'}];showOrigin={view:'search',y:25};legacyPrimary=async()=>[];seekFallbacks=async()=>{};await openEpisode(episodes[0])});
 snap=await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-page-checkpoint-v1')));assert.equal(snap.view,'episode');assert.equal(snap.episode.number,'5');assert(!JSON.stringify(snap).includes('private.example'));assert(!JSON.stringify(snap).includes('Cookie'));
 await page.reload();await page.evaluate(()=>window.kuroRestoreForNews());assert.equal(await page.locator('#news-overlay').count(),1);assert.equal(await page.evaluate(()=>view),'episode');
 await page.click('#news-back');assert((await page.locator('main').innerText()).includes('Safe title'));assert((await page.locator('main').innerText()).includes('Episode 5'));assert((await page.locator('main').innerText()).includes('Android closed the player'));assert.equal(await page.locator('#recovery-resume').count(),1);
 // Reload only the same numbered episode from a newly loaded exact series.
 await page.evaluate(()=>{window.__resumed=[];openShow=async function(item){selected=item;view='detail';episodes=[{number:'4',url:item.url},{number:'5',url:item.url},{number:'6',url:item.url}]};openEpisode=async function(ep){window.__resumed.push(ep.number)}});
 await page.click('#recovery-resume');assert.deepEqual(await page.evaluate(()=>window.__resumed),['5']);
 // Foreign hosts and broken snapshots fail closed instead of being loaded.
 await page.evaluate(()=>localStorage.setItem('kuro-page-checkpoint-v1',JSON.stringify({v:1,view:'episode',item:{source:'ms',title:'Unsafe',url:'https://evil.example/'},episode:{number:'1'}})));
 // Prevent this test page's pagehide from replacing the intentionally bad value.
 await page.evaluate(()=>{view='news'});await page.reload();await page.evaluate(()=>window.kuroRestoreForNews());assert.equal(await page.evaluate(()=>view),'home');await page.click('#news-back');assert.equal(await page.locator('text=Unsafe').count(),0);
 // A gated title is not shown until the 18+ classification is confirmed.
 await page.evaluate(()=>{view='news';localStorage.setItem('kuro-page-checkpoint-v1',JSON.stringify({v:1,view:'episode',origin:{view:'search'},item:{source:'kitsune',title:'Unverified title',url:'https://kitsunee.moe/api/info/123',anilistId:123},episode:{number:'1'}}))});
 await page.reload();await page.evaluate(()=>window.kuroRestoreForNews());await page.waitForTimeout(100);await page.click('#news-back');assert.equal(await page.evaluate(()=>view),'episode');assert(!(await page.locator('main').innerText()).includes('Unverified title'));assert((await page.locator('main').innerText()).includes('classification'));
 // A slow classification cannot drag a user back to an old title after navigation.
 await page.evaluate(()=>{view='news';localStorage.setItem('kuro-page-checkpoint-v1',JSON.stringify({v:1,view:'episode',origin:{view:'search'},item:{source:'kitsune',title:'Slow verified title',url:'https://kitsunee.moe/api/info/123',anilistId:123},episode:{number:'1'}}))});
 await page.reload();await page.evaluate(()=>{KuroNative.adultMetadata=(id)=>setTimeout(()=>{window.__result[id]=JSON.stringify({data:{a:{media:[{id:123,idMal:0,isAdult:false,title:{english:'Slow verified title'},synonyms:[]}]},m:{media:[]}}});window.__nativeResult(id,'')},450);window.kuroRestoreForNews()});
 await page.click('#news-back');await page.click('[data-nav="profile"]');await page.waitForTimeout(550);assert.equal(await page.evaluate(()=>view),'profile');assert(!(await page.locator('main').innerText()).includes('Slow verified title'));
 // New source is explicitly an external website, not a numbered library.
 await page.click('[data-nav="search"]');assert.equal(await page.locator('[data-open-site]').count(),4);await page.click('[data-open-site="justanime"]');assert.equal(await page.locator('#hayase-open').count(),0);assert.deepEqual(await page.evaluate(()=>window.__external),['justanime']);
 // Source-reported IDs and unknown IDs do not generate an external-app promotion.
 await page.evaluate(async()=>{get=async()=>'<html><body><h1>Test series</h1><a class="hk-ep" data-ep="1" href="/watch-test"></a></body></html>';unifiedBeginEpisodeScan=()=>{};await openShow({source:'ms',title:'Test series',url:'https://hianime.ms/details/test',anilistId:21})});
 assert.equal(await page.locator('#hayase-title-link').count(),0);assert.deepEqual(await page.evaluate(()=>window.__external),['justanime']);
 await page.evaluate(async()=>{await openShow({source:'ms',title:'Unknown ID',url:'https://hianime.ms/details/unknown'})});assert.equal(await page.locator('#hayase-title-link').count(),0);
 assert.deepEqual(errors,[]);console.log('PASS 5.38 mocked browser: warm overlay preservation, cold route recovery, exact episode reload, privacy, gated-content and links');
 }finally{await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

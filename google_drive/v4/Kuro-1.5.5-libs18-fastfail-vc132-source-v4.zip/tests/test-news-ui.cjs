const {chromium} = require('playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '../assets');
const types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};
const server=http.createServer((req,res)=>{
 const name=new URL(req.url,'http://127.0.0.1').pathname==='/'?'index.html':new URL(req.url,'http://127.0.0.1').pathname.slice(1);
 const file=path.resolve(root,name);if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return}
 fs.readFile(file,(err,bytes)=>{if(err){res.writeHead(404).end();return}res.writeHead(200,{'content-type':types[path.extname(file)]||'application/octet-stream'}).end(bytes)});
});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;
 try{
  browser=await chromium.launch({headless:true,args:['--no-sandbox']});
  const context=await browser.newContext({viewport:{width:393,height:852},deviceScaleFactor:1,isMobile:true,hasTouch:true});
  const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript(()=>{
   const now=Date.now();window.__opened=[];window.__toggles=[];window.__results={};window.__settings={enabled:true,allowed:true};window.__failNews=false;window.__delayNews=0;
   const items=[
    {id:'outlet-1',source:'Anime Corner',kind:'news',title:'Gacha Girls Corps Anime Premieres January 7',summary:'The anime announces its premiere date.',published:now-1000,url:'https://animecorner.me/a-story/',image:'https://a.storyblok.com/test.jpg'},
    {id:'official-1',source:'TOHO animation',kind:'official',title:'Official trailer for a new anime',summary:'A new video from the official channel.',published:now-2000,url:'https://www.youtube.com/watch?v=abc123',image:'https://i2.ytimg.com/vi/abc/hqdefault.jpg'},
    {id:'unsafe-1',source:'Test News',kind:'news',title:'Malicious <img src=x onerror=alert(1)> Anime update',summary:'<script>window.bad=true</script>',published:now-3000,url:'https://evil.example/unsafe',image:'https://evil.example/tracker.png'}
   ];
   window.__newsItems=items;
   const realFetch=window.fetch.bind(window);window.fetch=(input,opts)=>{let u=typeof input==='string'?input:input.url;if(u.startsWith('/result/')){let id=decodeURIComponent(u.slice('/result/'.length));return Promise.resolve(new Response(window.__results[id]||'',{status:200,headers:{'content-type':'text/plain'}}))}return realFetch(input,opts)};
   function done(id,data){window.__results[id]=JSON.stringify(data);setTimeout(()=>window.__nativeResult&&window.__nativeResult(id,''),0)}
   window.KuroNative={
    get(id,url){window.__results[id]='<html><body></body></html>';setTimeout(()=>window.__nativeResult&&window.__nativeResult(id,''),0)},
    news(id,mode){let send=()=>done(id,{items,failed:window.__failNews?['Anime Corner']:[],checkedAt:now});if(mode!=='cache'&&window.__delayNews)setTimeout(send,window.__delayNews);else send()},
    newsSettings(){return JSON.stringify(window.__settings)},
    setNewsAlerts(value){window.__toggles.push(value);window.__settings.enabled=value;window.__settings.allowed=true;window.kuroNewsPermissionsChanged()},
    openNewsUrl(url){window.__opened.push(url)},
    newsMetadata(id,input){let names=JSON.parse(input),data={};names.forEach((name,i)=>{let match=name==='Gacha Girls Corps'?[{id:42,title:{english:null,romaji:'Gacha wo Mawashite',native:'ガチャ'},synonyms:['Gacha Girls Corps'],description:'A catalog synopsis of the series.',genres:['Action','Comedy'],studios:{nodes:[{name:'Zero-G',isAnimationStudio:true}]},coverImage:{large:'https://s4.anilist.co/poster.jpg'},siteUrl:'https://anilist.co/anime/42'}]:[];data['m'+i]={media:match}});done(id,{data})}
   };
  });
  await page.route('https://a.storyblok.com/**',route=>route.fulfill({path:path.join(root,'kuro-logo.png'),contentType:'image/png'}));
  await page.route('https://s4.anilist.co/**',route=>route.fulfill({path:path.join(root,'kuro-logo.png'),contentType:'image/png'}));
  await page.route('https://i2.ytimg.com/**',route=>route.fulfill({path:path.join(root,'kuro-logo.png'),contentType:'image/png'}));
  await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);assert.equal(await page.title(),'Kuro.tv','renamed browser title');
  await page.waitForFunction(()=>{let logo=document.querySelector('.brand-logo');return logo&&logo.complete&&logo.naturalWidth>0});
  assert.equal(await page.locator('.brand-logo').getAttribute('alt'),'Kuro.tv','accessible new logo');
  assert((await page.locator('.brand-logo').getAttribute('src')).endsWith('.svg'),'header uses scalable logo');
  for(const width of [320,360,393,768]){
   await page.setViewportSize({width,height:852});
   const layout=await page.evaluate(()=>{let a=document.querySelector('.brand-logo').getBoundingClientRect(),b=document.querySelector('.header-actions').getBoundingClientRect();return {right:a.right,actions:b.left,scroll:document.documentElement.scrollWidth,viewport:innerWidth}});
   assert(layout.right<=layout.actions+1&&layout.scroll<=layout.viewport+1,`logo/header overlaps or overflows at ${width}px`);
  }
  await page.setViewportSize({width:393,height:852});if(process.env.KURO_HEADER_SCREENSHOT)await page.screenshot({path:process.env.KURO_HEADER_SCREENSHOT});
  assert.equal(await page.locator('nav button').count(),5,'five navigation buttons intact');
  await page.click('#header-notice');await page.waitForSelector('.news-post');await page.waitForSelector('.news-alt');
  assert.equal(await page.locator('.news-post').count(),3);assert(await page.locator('.news-post').nth(0).innerText().then(s=>s.includes('NEWS REPORT')));
  assert(await page.locator('.news-post').nth(1).innerText().then(s=>s.includes('OFFICIAL VIDEO')));
  assert(await page.locator('.news-post').nth(0).innerText().then(s=>s.includes('Alternate titles:')));
  assert(await page.locator('.news-post').nth(0).innerText().then(s=>s.includes('A catalog synopsis')));
  assert(await page.locator('.news-post').nth(0).innerText().then(s=>s.includes('Genres:')&&s.includes('Production:')));
  assert.equal(await page.locator('.news-post').nth(2).locator('img').count(),0,'untrusted image URL ignored');assert.equal(await page.evaluate(()=>window.bad),undefined,'feed HTML not executed');
  await page.locator('.news-post').nth(0).locator('[data-news-open]').last().click();assert.equal((await page.evaluate(()=>window.__opened)).at(-1),'https://animecorner.me/a-story/');
  await page.locator('.news-post').nth(2).locator('[data-news-open]').last().click();assert.equal((await page.evaluate(()=>window.__opened)).length,1,'unsafe outgoing URL blocked');
  await page.locator('[data-news-filter="official"]').click();assert.equal(await page.locator('.news-post').count(),1);await page.locator('.news-actions [data-news-open]').click();assert.equal((await page.evaluate(()=>window.__opened)).at(-1),'https://www.youtube.com/watch?v=abc123');
  await page.evaluate(()=>{window.__newsItems.push({id:'jp-1',source:'Aniplex official · Japan',kind:'official',title:'公式のお知らせ',summary:'作品',published:Date.now(),url:'https://www.aniplex.co.jp/news/detail/?id=123',image:''});window.kuroNewsAutoUpdated()});
  await page.waitForFunction(()=>document.querySelectorAll('.news-post').length===2);let publisher=page.locator('.news-post').last();assert((await publisher.innerText()).includes('OFFICIAL UPDATE')&&(await publisher.innerText()).includes('Read official update'),'official publisher post is not mislabeled as a video');await publisher.locator('[data-news-open]').last().click();assert.equal((await page.evaluate(()=>window.__opened)).at(-1),'https://www.aniplex.co.jp/news/detail/?id=123');
  await page.evaluate(()=>{window.__newsItems.pop();window.kuroNewsAutoUpdated()});await page.waitForFunction(()=>document.querySelectorAll('.news-post').length===1);
  let clean=await page.evaluate(()=>({good:newsCleanLink('https://myanimelist.net/news/1'),bad:newsCleanLink('https://myanimelist.net.evil.test/a'),image:newsCleanImage('https://i0.wp.com/evil.test/x.jpg')}));assert(clean.good&&clean.bad===''&&clean.image==='','publisher URL and restricted image allowlists');
  await page.click('#news-alert-toggle');assert((await page.locator('#news-alerts').innerText()).includes('Off'));await page.click('#news-alert-toggle');assert((await page.locator('#news-alerts').innerText()).includes('On'));
  await page.locator('[data-news-filter="all"]').click();await page.evaluate(()=>window.__delayNews=700);await page.click('#news-refresh');await page.click('#news-back');await page.click('#header-notice');await page.waitForFunction(()=>!document.querySelector('#news-refresh').disabled);assert.equal(await page.locator('.news-post').count(),3,'navigating away during refresh does not lock the feed');await page.evaluate(()=>window.__delayNews=0);
  await page.evaluate(()=>window.__failNews=true);await page.click('#news-refresh');await page.waitForFunction(()=>document.querySelector('#news-status').textContent.includes('Couldn’t update'));let message=await page.locator('#news-status').innerText();assert(message.includes('Anime Corner')&&message.includes('available or saved')&&message.includes('Tap Refresh')&&message.includes('Last checked'),'partial-feed message explains affected source, cache, retry, and check time');assert.equal(await page.locator('.news-post').count(),3,'cached entries survive offline/partial failure');
  const checks=await page.evaluate(()=>{
   let exact=exactNewsMeta('Same',[{id:1,title:{english:'Same'},synonyms:[],studios:{nodes:[]}},{id:2,title:{english:'Same'},synonyms:[],studios:{nodes:[]}}]);
   let fake={candidate:'Same',alternate:[],synopsis:'Old series',genres:['Action'],studios:['Old Studio']};
   return {ambiguous:exact,sequel:newsDetailsMarkup(fake,{title:'Same Anime Gets Season 2'}),overflow:document.documentElement.scrollWidth>innerWidth};
  });
  assert.equal(checks.ambiguous,null,'ambiguous catalogue matches omitted');assert(!checks.sequel.includes('Old Studio'),'old-season production not assigned to a sequel');assert(!checks.overflow,'mobile page does not overflow horizontally');
  if(process.env.KURO_NEWS_SCREENSHOT)await page.screenshot({path:process.env.KURO_NEWS_SCREENSHOT,fullPage:true});
  await page.click('#news-back');assert(await page.locator('nav button[data-nav="home"]').evaluate(x=>x.classList.contains('active')),'back returns home');
  await page.evaluate(()=>{view='episode';window.kuroWatchHeader('home')});assert(await page.locator('nav button[data-nav="home"]').evaluate(x=>x.classList.contains('active')),'watch logo routes home');
  await page.evaluate(()=>{view='episode';window.kuroWatchHeader('search')});assert.equal(await page.locator('#search-popup').count(),1,'watch search opens existing unified search');await page.locator('#popup-close').click();
  await page.evaluate(()=>{view='episode';window.kuroWatchNewsOpen(7)});await page.waitForSelector('#news-back');await page.click('#news-back');assert.equal(await page.evaluate(()=>view),'episode','watch notifications leave the current page intact');assert.equal(await page.locator('#news-overlay').count(),0);
  await page.click('#header-notice');await page.waitForSelector('#news-back');await page.click('#news-back');await page.click('#header-home');assert(await page.locator('nav button[data-nav="home"]').evaluate(x=>x.classList.contains('active')),'regular Kuro.tv header also goes Home');
  assert.deepEqual(errors,[],'no uncaught JS errors');console.log('PASS news cards, exact metadata, source labels, filters, safe links, alerts toggle, offline cache, navigation, mobile layout');
 } finally {if(browser)await browser.close();server.close()}
})().catch(e=>{console.error(e);process.exitCode=1});

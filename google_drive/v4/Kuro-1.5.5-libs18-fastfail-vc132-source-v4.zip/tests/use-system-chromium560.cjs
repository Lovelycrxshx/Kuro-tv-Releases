const {chromium}=require('playwright');const launch=chromium.launch.bind(chromium);
chromium.launch=options=>launch({...options,executablePath:process.env.KURO_CHROMIUM||'/usr/bin/chromium'});

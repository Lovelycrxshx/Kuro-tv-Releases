package android.content.pm; public class ApplicationInfo {public int icon=12;}

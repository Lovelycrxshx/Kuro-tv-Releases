const installLegacy532=require('./legacy-ui-harness.cjs');
const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets');
const types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};
const server=http.createServer((req,res)=>{const name=new URL(req.url,'http://localhost').pathname.slice(1)||'index.html',file=path.resolve(root,name);if(!file.startsWith(root+path.sep)){res.writeHead(403).end();return}fs.readFile(file,(e,data)=>e?res.writeHead(404).end():res.writeHead(200,{'content-type':types[path.extname(file)]||'application/octet-stream'}).end(data))});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});const context=await browser.newContext({viewport:{width:393,height:852},isMobile:true,hasTouch:true});const page=await context.newPage();let errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.route('https://pictures.example/**',r=>r.fulfill({status:200,contentType:'image/svg+xml',body:'<svg xmlns="http://www.w3.org/2000/svg" width="200" height="300"><rect width="200" height="300" fill="#352342"/><circle cx="100" cy="130" r="45" fill="#a96ce0"/></svg>'}));
 await page.addInitScript(()=>{
  window.__fixture={calls:[],failPage2:false,delayPage2:false};const responses={},nativeFetch=window.fetch.bind(window);
  window.fetch=(input,opts)=>{let u=typeof input==='string'?input:input.url;if(u.startsWith('/result/'))return Promise.resolve(new Response(responses[decodeURIComponent(u.slice(8))]||'',{status:200}));return nativeFetch(input,opts)};
  const markup=(url)=>{const u=new URL(url),s=u.hostname==='hianime.dk'?'dk':'ms',n=Number(u.searchParams.get('page')||1),q=u.searchParams.get('keyword')||'',mode=(u.pathname.startsWith('/genre')||u.pathname==='/browse')?'genre':u.pathname==='/top-airing'?'airing':u.pathname==='/search'?'search':'all';
   if(u.pathname.startsWith('/details/')){let t=decodeURIComponent(u.pathname.split('/').pop()).replace(/-/g,' ');return `<html><title>Details</title><h1>${t}</h1><a class="hk-ep" data-ep="1" href="/watch-one"></a></html>`}
   if(q==='challenge')return '<html><title>Just a moment...</title><div id="challenge-stage">Verify</div></html>';
   if(n>3)return '<html><title>End</title></html>';
   let start=(n-1)*12+(n===2?-1:0),items=Array.from({length:12},(_,i)=>start+i);
   let label=(s==='dk'?'DK':'MS')+' '+mode+' ';
   let cards=items.map(i=>s==='ms'?`<article class="hk-tile"><img src="https://pictures.example/${i}.svg"><h3 class="hk-tile__name"><a href="https://hianime.ms/details/${mode}-${i}">${label}${i}</a></h3><p class="hk-tile__meta">TV</p></article>`:`<div class="flw-item"><img src="https://pictures.example/${i}.svg"><h3 class="film-name"><a href="https://hianime.dk/details/${mode}-${i}">${label}${i}</a></h3><p class="fd-infor">TV</p></div>`).join('');
   const next=new URL(url);next.searchParams.set('page',String(n+1));let nav=n<3?`<ul class="pagination"><li><a aria-label="Next" href="${next.href}">Next</a></li></ul>`:'';
   return '<html><title>Catalogue</title><body>'+cards+nav+'</body></html>';
  };
  window.KuroNative={get(id,url){const u=new URL(url),p=Number(u.searchParams.get('page')||1);window.__fixture.calls.push(url);
   if(window.__fixture.failPage2&&u.hostname==='hianime.ms'&&p===2){window.__fixture.failPage2=false;setTimeout(()=>window.__nativeResult(id,'Source returned HTTP 403'),0);return}
   let delay=window.__fixture.delayPage2&&u.hostname==='hianime.ms'&&p===2?550:0;setTimeout(()=>{responses[id]=markup(url);window.__nativeResult(id,'')},delay)},news(id){responses[id]=JSON.stringify({items:[],failed:[],checkedAt:Date.now()});setTimeout(()=>window.__nativeResult(id,''),0)},newsSettings(){return JSON.stringify({enabled:true,allowed:true})},setNewsAlerts(){},openNewsUrl(){}};
  localStorage.setItem('kuro-library',JSON.stringify([{title:'Saved before test',url:'https://hianime.ms/details/saved',source:'ms'}]));
 });
 await installLegacy532(page);await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);
 const count=async n=>page.waitForFunction(n=>document.querySelectorAll('.pager-grid [data-card]').length===n,n,{timeout:8000});
 const down=async()=>page.evaluate(()=>window.scrollTo(0,document.documentElement.scrollHeight));
 await count(4);await down();await count(15);await down();await count(27);
 assert((await page.locator('.pager-message').innerText()).includes('end of this library'),'genuine end state after page three');
 const urls=await page.evaluate(()=>window.__fixture.calls.filter(x=>x.includes('/most-popular')));assert.deepEqual(urls.map(x=>Number(new URL(x).searchParams.get('page')||1)),[1,2,3],'one request per actual page');
 // A detail page should return to the same filled list and approximate scroll position.
 await page.locator('.pager-grid [data-card]').nth(23).scrollIntoViewIfNeeded();let yBefore=await page.evaluate(()=>scrollY);let clickedTitle=await page.locator('.pager-grid [data-card]').nth(23).locator('strong').innerText();await page.locator('.pager-grid [data-card]').nth(23).click();assert.equal(await page.locator('main h1').innerText(),clickedTitle);await page.click('#back');await count(27);await page.waitForFunction(y=>Math.abs(scrollY-y)<150,yBefore);assert.equal(await page.locator('nav button[aria-current="page"]').getAttribute('data-nav'),'home');
 assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('kuro-library'))[0].title),'Saved before test','existing saved data untouched');
 // Browse immediately loads its own catalogue and continues on reaching the end.
 await page.locator('nav button[data-nav="search"]').click();await count(12);assert((await page.locator('main h1').innerText()).includes('Browse'));await down();await count(23);
 // Search uses the provider query, continues, and sorts only the loaded titles.
 await page.fill('#q','Naruto');await page.click('#go');await count(12);assert(await page.locator('main h2').first().innerText().then(t=>t.includes('Naruto')));await down();await count(23);assert((await page.evaluate(()=>window.__fixture.calls)).some(x=>x.includes('/search?keyword=Naruto&page=2')));
 await page.click('#result-sort');await page.click('[data-sort-choice="za"]');let sorted=await page.locator('.pager-grid [data-card] strong').allTextContents();let correct=sorted.slice().sort((a,b)=>b.localeCompare(a,undefined,{sensitivity:'base'}));assert.deepEqual(sorted,correct,'sort is explicit and applies to loaded titles');await page.click('#result-sort');await page.click('[data-sort-choice="source"]');
 // Reference features: distinct tabs, keyboard-accessible selection, real airing route, genres and music anime.
 await page.locator('[data-browse-tab="all"]').focus();await page.keyboard.press('ArrowRight');await count(11);assert((await page.locator('main h1').innerText()).includes('Simulcasts'));assert.equal(await page.locator('.discover-head').count(),0,'airing uses a different layout from Browse');assert((await page.locator('.air-information').innerText()).includes('not a live schedule'));await page.locator('nav button[data-nav="search"]').click();await count(12);
 await page.locator('[data-browse-tab="genres"]').click();assert(await page.locator('.genre-tile').count()>=16);await page.locator('[data-genre="action"]').click();await count(12);assert((await page.locator('main h2').first().innerText()).includes('Action'));await down();await count(23);assert((await page.evaluate(()=>window.__fixture.calls)).some(x=>x.includes('/browse?')&&new URL(x).searchParams.get('genres[]')==='Action'&&new URL(x).searchParams.get('page')==='2'&&new URL(x).searchParams.get('sort')==='popularity'));
 await page.locator('[data-browse-tab="music"]').click();await count(12);assert((await page.locator('main h2').first().innerText()).includes('Music'));assert((await page.locator('.discover-section .sub').innerText()).includes('not a standalone music player'));
 // Unavailable source sections don't invent data or offer an endless retry.
 await page.locator('[data-source="zoro"]').click();await page.waitForSelector('.pager-message');assert((await page.locator('.pager-message').innerText()).includes('not available'));assert.equal(await page.locator('[data-pager-retry]').count(),0);
 // Verification must stop automatic loading until the user intervenes.
 await page.locator('[data-source="ms"]').click();await page.fill('#q','challenge');await page.click('#go');await page.waitForSelector('[data-pager-retry]');assert((await page.locator('.pager-message').innerText()).includes('verification'));let attempts=await page.evaluate(()=>window.__fixture.calls.filter(x=>x.includes('keyword=challenge')).length);await down();await page.evaluate(()=>window.scrollBy(0,-50));assert.equal(await page.evaluate(()=>window.__fixture.calls.filter(x=>x.includes('keyword=challenge')).length),attempts);
 // Retry a blocked second page without silently looping or losing already loaded cards.
 await page.locator('[data-browse-tab="all"]').click();await count(12);await page.evaluate(()=>{window.__fixture.failPage2=true});await down();await page.waitForSelector('[data-pager-retry]');assert((await page.locator('.pager-message').innerText()).includes('blocked'));assert.equal(await page.locator('.pager-grid [data-card]').count(),12);await page.locator('[data-pager-retry]').click();await count(23);
 // A delayed old-source response cannot overwrite a newly selected library.
 await page.locator('[data-browse-tab="all"]').click();await count(12);let previousPage2=await page.evaluate(()=>window.__fixture.calls.filter(x=>x.includes('/most-popular?page=2')).length);await page.evaluate(()=>{window.__fixture.delayPage2=true});await down();await page.waitForFunction(n=>window.__fixture.calls.filter(x=>x.includes('/most-popular?page=2')).length>n,previousPage2);await page.locator('[data-source="dk"]').click();await count(12);assert((await page.locator('.pager-grid [data-card] strong').first().innerText()).startsWith('DK'));await page.waitForTimeout(700);assert((await page.locator('.pager-grid [data-card] strong').allTextContents()).every(x=>x.startsWith('DK')),'stale old-source response ignored');
 await page.locator('nav button[data-nav="simulcasts"]').click();await count(11);assert((await page.locator('main h1').innerText()).includes('Simulcasts'));assert.equal(await page.locator('nav button[aria-current="page"]').getAttribute('data-nav'),'simulcasts');
 for(const width of [280,320,393,768]){await page.setViewportSize({width,height:852});assert((await page.evaluate(()=>document.documentElement.scrollWidth))<=width+1,'no browse horizontal overflow at '+width)}
 assert.deepEqual(errors,[]);console.log('PASS legacy-source adapter harness: infinite Home/Browse, provider pages, de-duplication, detail return, search/genre/airing/music, end, manual retry, verification stop, source race and layout');
 }finally{if(browser)await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

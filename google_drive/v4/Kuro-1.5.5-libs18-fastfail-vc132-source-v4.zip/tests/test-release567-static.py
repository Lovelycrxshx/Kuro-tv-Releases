#!/usr/bin/env python3
"""Release invariants: static checks complement, but never replace, device tests."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
main=(r/'src/app/lovelycrxshx/kuro/MainActivity.java').read_text()
accounts=(r/'src/app/lovelycrxshx/kuro/KuroAccounts.java').read_text()
ui=(r/'assets/accounts542.js').read_text();settings=(r/'assets/settings560.js').read_text();css=(r/'assets/profile-settings560.css').read_text()
model=(r/'src/app/lovelycrxshx/kuro/KuroPresence563.java').read_text();art=(r/'src/app/lovelycrxshx/kuro/KuroArtwork567.java').read_text();native=(r/'native/kuro_discord_rpc563.cpp').read_text();rpc=(r/'src/app/lovelycrxshx/kuro/KuroDiscordRpc563.java').read_text()
assert 'id="account-settings"' not in ui and 'id="account-setup-open"' not in ui
assert 'synchronized(githubAdmin568)' in main and 'if(!githubAdmin568.verified())' in main and 'result=accounts.saveConfig(p)' in main
for item in ('1569077670074122250','37160cd5a180308c9009afb7faa4e341','56440'):assert item in accounts
assert 'if(str(c,"discord").isEmpty())' in accounts and 'if(str(c,"mal").isEmpty())' in accounts and 'if(str(c,"anilist").isEmpty())' in accounts
assert 'if(o.title&&o.poster&&discordArtwork567!=null)' in main and 'suppliedCover' in main and 'info.optString("episodeImage","")' not in main
assert 'if(discordRpc563==null||!discordEnabled563()||!discordVisible563()||info==null)return;' in main
for name in ('https://graphql.anilist.co','https://kitsu.io/api/edge/anime','pickKitsuCover','posterImage','MAX_PENDING=2','LOOKUP_INTERVAL=5000L','NEGATIVE_TTL'):
 assert name in art
assert 'media.kitsu.app' in model and '/anime/poster_images/' in model and 'episodes/thumbnails' not in model and 'media.kitsu.app' in native
assert 'MIN_SEND_MS=3000, REFRESH_MS=3000' in model and 'retry567.ready' in rpc
assert 'NO_PRESENCE_LINK,NO_PRESENCE_LINK' in rpc and 'AddButton(' not in native
assert 'mountChoices567(root)' in settings and 'aria-modal' in settings and 'settings-choice567' in css
print('PASS 5.70 owner-gated native setup, non-destructive public defaults, opt-in exact neutral anime cover art, 3-second SDK gate/backoff, no buttons and themed choices')

'use strict';
// Production browser code against synthetic, locally generated API responses.
// No requests to Miruro or any player are made by this test.
const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets'),types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};
const server=http.createServer((req,res)=>{let p=path.resolve(root,new URL(req.url,'http://localhost').pathname.slice(1)||'index.html');if(!p.startsWith(root+path.sep))return res.writeHead(403).end();fs.readFile(p,(e,b)=>e?res.writeHead(404).end():res.writeHead(200,{'content-type':types[path.extname(p)]||'text/plain'}).end(b))});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true});
 let errors=[];page.on('pageerror',e=>errors.push(e.message));await page.route('https://**',r=>r.abort());
 await page.addInitScript(()=>{
  const responses={},realFetch=window.fetch.bind(window),root='https://www.miruro.cx';
  const title={id:'one-piece-21',title:{english:'One Piece',romaji:'ONE PIECE'},external_ids:{anilist:[21],mal:[21]},format:'TV',episode_count:1180,description:'A <b>pirate</b> story.',cover_url:'https://images.example/cover.jpg'};
  const other={id:'other-22',title:{english:'Other Anime'},external_ids:{anilist:[22]},format:'TV'};
  window.__miruro={calls:[],block:false,blockCode:403,ambiguous:false,wrongEpisode:false,wrongAnime:false,unsupported:false,plays:[],updates:[],verified:0,external:[]};
  window.fetch=(u,o)=>typeof u==='string'&&u.startsWith('/result/')?Promise.resolve(new Response(responses[decodeURIComponent(u.slice(8))]||'',{status:200})):realFetch(u,o);
  function answer(id,body,error=''){if(!error)responses[id]=typeof body==='string'?body:JSON.stringify(body);setTimeout(()=>window.__nativeResult(id,error),0)}
  function track(kind,url){return {track:kind,providers:[{servers:[{headers:{Referer:root+'/'},streams:[{format:'embed',url},{format:'embed',url:'https://evil.example/embed'},{format:'hls',url:'https://megaplay.buzz/video.m3u8'}]},{headers:{referer:'https://evil.example/'},streams:[{format:'embed',url:'https://megaplay.buzz/bad-referer'}]}]}]};}
  window.KuroNative={
   get(id,url){window.__miruro.calls.push(url);const u=new URL(url);if(u.hostname!=='www.miruro.cx')return answer(id,'<html><title>Empty</title></html>');
    if(window.__miruro.block)return answer(id,'','Source returned HTTP '+window.__miruro.blockCode+' (no verification bypass)');
    if(u.pathname==='/api/v1/anime'){
     let second=u.searchParams.has('cursor'),query=u.searchParams.get('q');let data=second?[other]:query&&query!=='One Piece'?[]:[title];
     if(window.__miruro.ambiguous&&!second&&query==='One Piece')data=[title,{...title,id:'duplicate-21'}];
     return answer(id,{data,has_more:!second,next_cursor:second?null:'abc &evil=1'});
    }
    if(u.pathname==='/api/v1/anime/one-piece-21')return answer(id,{data:title});
    if(u.pathname==='/api/v1/anime/one-piece-21/episodes')return answer(id,{data:[{episode_number:1,title:'The first episode'},{episode_number:2},{episode_number:3},{episode_number:3},{episode_number:1.5},{episode_number:5001},{episode_number:0}]});
    if(u.pathname==='/api/v1/anime/one-piece-21/episodes/1/play'){
     let tracks=window.__miruro.unsupported?[{track:'sub',providers:[{servers:[{streams:[{format:'hls',url:'https://unknown.example/master.m3u8'}]}]}]}]:[track('sub','https://megaplay.buzz/stream/mal/21/1/sub'),track('dub','https://megaplay.buzz/stream/mal/21/1/dub')];
     return answer(id,{data:{anime_id:window.__miruro.wrongAnime?'another-anime':'one-piece-21',episode_number:window.__miruro.wrongEpisode?2:1,tracks}});
    }
    if(u.pathname==='/api/v1/anime/one-piece-21/episodes/2/play')return answer(id,{data:{anime_id:'one-piece-21',episode_number:2,tracks:[]}});
    return answer(id,'','Unexpected mock route');
   },
   play(payload){window.__miruro.plays.push(JSON.parse(payload))},addServers(id,payload){window.__miruro.updates.push(JSON.parse(payload))},newsSettings(){return JSON.stringify({enabled:false,allowed:false})},
   verifyLibrary11(){window.__miruro.verified++},openLibrary11Episode(id,number){window.__miruro.external.push([id,number])}
  };
 });
 await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);await page.waitForFunction(()=>typeof miruroItem==='function'&&typeof fetchCatalogPage==='function');
 // Restrict all other source fixtures to empty data; production Miruro remains intact.
 await page.evaluate(()=>{let real=fetchCatalogPage;fetchCatalogPage=(spec,p)=>spec.source==='miruro'?real(spec,p):Promise.resolve({items:[],hasNext:false});for(const k of Object.keys(failoverAdapters))if(k!=='miruro')failoverAdapters[k]=async()=>[];homePagerState=null;window.__miruro.calls=[]});
 let inventory=await page.evaluate(()=>({codes:unifiedCodes.slice(),label:label('miruro'),source:validUrl('https://www.miruro.cx/api/v1/anime'),unknown:validUrl('https://evil.example/api/v1/anime')}));
 assert.equal(inventory.codes.length,13);assert(inventory.codes.includes('miruro'));assert.equal(inventory.codes.at(-1),'paradise');assert.equal(inventory.label,'Library 11');assert(inventory.source);assert.equal(inventory.unknown,'');
 const result=await page.evaluate(async()=>{
  let spec={source:'miruro',mode:'search',query:'One Piece'},first=await fetchCatalogPage(spec,1),url2=catalogUrl(spec,2),second=await fetchCatalogPage(spec,2),item=first.items[0],data=await miruroDetails(item,await get(item.url)),servers=await miruroServers(item,data.episodes[0]);
  let match=await fallbackMiruro('One Piece','1',{anilistId:21,malId:21}),missing=await fallbackMiruro('One Piece','9',{anilistId:21}),wrongID=await fallbackMiruro('One Piece','1',{anilistId:99}),wrongSeason=await fallbackMiruro('One Piece Season 2','1',{});
  window.__miruro.wrongEpisode=true;let wrongEpisode=await miruroServers(item,data.episodes[0]);window.__miruro.wrongEpisode=false;window.__miruro.wrongAnime=true;let wrongAnime=await miruroServers(item,data.episodes[0]);window.__miruro.wrongAnime=false;
  window.__miruro.ambiguous=true;let ambiguous=await fallbackMiruro('One Piece','1',{anilistId:21});window.__miruro.ambiguous=false;
  let linked=await unifiedReadOtherEpisodes({...item},{source:'ms',title:'One Piece',anilistId:21,malId:21});
  let badTitle=false,badId=false,malformed=false;try{await miruroDetails({...item,title:'One Piece Season 2'},JSON.stringify({data:{id:'one-piece-21',title:{english:'One Piece'}}}))}catch(_){badTitle=true}try{await miruroDetails(item,JSON.stringify({data:{id:'wrong',title:{english:'One Piece'}}}))}catch(_){badId=true}try{miruroCatalog(spec,1,'{oops')}catch(_){malformed=true}
  return {first,second,url2,data,servers,match,missing,wrongID,wrongSeason,wrongEpisode,wrongAnime,ambiguous,linked,badTitle,badId,malformed};
 });
 assert.equal(result.first.items[0].title,'One Piece');assert.equal(result.first.items[0].anilistId,21);assert.equal(result.first.items[0].malId,21);assert.equal(result.first.items[0].counts.total,'1180');assert.equal(result.first.items[0].description,'A pirate story.');
 const u=new URL(result.url2);assert.equal(u.searchParams.get('cursor'),'abc &evil=1');assert(!u.searchParams.has('evil'));assert.equal(result.second.items[0].title,'Other Anime');assert(!result.second.hasNext);
 assert.deepEqual(result.data.episodes.map(x=>x.number),['1','2'],'reject duplicate, noninteger and out-of-bounds episodes');assert.deepEqual(result.servers.map(x=>x.lang),['sub','dub']);assert(result.servers.every(x=>x.url.startsWith('https://megaplay.buzz/')));assert.equal(result.match.length,2);
 for(const key of ['missing','wrongID','wrongSeason','wrongEpisode','wrongAnime','ambiguous'])assert.equal(result[key].length,0,key+' must not cross-link');
 assert.deepEqual(result.linked.episodes.map(x=>x.number),['1','2']);assert(result.badTitle&&result.badId&&result.malformed);
 // 403 stops subsequent requests to this source; an unrelated source is unaffected.
 const blocking=await page.evaluate(async()=>{unifiedVerificationBlocked.delete('miruro');window.__miruro.block=true;let before=window.__miruro.calls.filter(x=>x.startsWith('https://www.miruro.cx')).length,errors=[];for(let i=0;i<2;i++)try{await get('https://www.miruro.cx/api/v1/anime?limit=15')}catch(e){errors.push(e.message)};let after=window.__miruro.calls.filter(x=>x.startsWith('https://www.miruro.cx')).length;let other=await get('https://hianime.ms/');return {before,after,errors,blocked:unifiedVerificationBlocked.has('miruro'),other}});
 assert.equal(blocking.after-blocking.before,1,'no automatic repeat after 403');assert.equal(blocking.errors.length,2);assert(blocking.blocked&&blocking.other.includes('Empty'));
 const rateLimit=await page.evaluate(async()=>{unifiedVerificationBlocked.delete('miruro');window.__miruro.blockCode=429;let before=window.__miruro.calls.length;for(let i=0;i<2;i++)try{await get('https://www.miruro.cx/api/v1/anime?limit=15')}catch(_){}let count=window.__miruro.calls.length-before;window.__miruro.blockCode=403;return {count,blocked:unifiedVerificationBlocked.has('miruro')}});assert.equal(rateLimit.count,1,'no automatic repeat after 429');assert(rateLimit.blocked);
 // User can open the manual challenge and explicitly retry once it is resolved.
 await page.evaluate(()=>{view='search';browseQuery='One Piece';browsePagerState=null;unifiedSearchPage()});await page.waitForSelector('[data-miruro-verify]');await page.click('[data-miruro-verify]');assert.equal(await page.evaluate(()=>window.__miruro.verified),1);
 await page.evaluate(()=>{window.__miruro.block=false});await page.click('[data-unified-retry]');await page.waitForFunction(()=>!activePager.state.loading&&document.querySelectorAll('.pager-grid .card').length>=1,null,{timeout:10000});assert(!await page.evaluate(()=>unifiedVerificationBlocked.has('miruro')));
 await page.locator('.pager-grid .card').first().click();await page.waitForFunction(()=>document.querySelectorAll('#eps [data-ep]').length===2,null,{timeout:10000});await page.locator('#eps [data-ep]').first().click();
 await page.waitForFunction(()=>window.__miruro.plays.length>0,null,{timeout:10000});let play=await page.evaluate(()=>window.__miruro.plays.at(-1));assert.equal(play.episode,'1');assert.equal(play.servers[play.index].lang,'dub');assert(play.servers.every(s=>s.url.includes('/21/1/')));
 // If the source only supplies unsupported media, present a user-initiated
 // original-site link rather than pretending that an in-app stream works.
 await page.evaluate(()=>{window.__miruro.unsupported=true;failoverAdapters.miruro=async()=>[];openEpisode(episodes[0])});await page.waitForSelector('[data-miruro-open]',{timeout:10000});await page.click('[data-miruro-open]');assert.deepEqual(await page.evaluate(()=>window.__miruro.external.at(-1)),['one-piece-21','1']);
 // A challenge in an already opened Miruro title also provides verify/retry.
 await page.evaluate(()=>{window.__miruro.block=true;unifiedVerificationBlocked.delete('miruro');openShow(selected)});await page.waitForSelector('#eps [data-miruro-verify]');await page.click('#eps [data-miruro-verify]');assert.equal(await page.evaluate(()=>window.__miruro.verified),2);await page.evaluate(()=>{window.__miruro.block=false});await page.click('#eps [data-miruro-retry]');await page.waitForFunction(()=>document.querySelectorAll('#eps [data-ep]').length===2,null,{timeout:10000});
 assert.deepEqual(errors,[]);console.log('PASS fixture-only Library 11 discovery, cursors, exact identities/episodes, supported embeds, block isolation, manual verification and original-site link');
 }finally{if(browser)await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

from pathlib import Path
from html.parser import HTMLParser
root=Path(__file__).resolve().parents[1]
class Assets(HTMLParser):
 def __init__(self):super().__init__();self.paths=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='script' and a.get('src'):self.paths.append(a['src'])
  if tag=='link' and a.get('rel')=='stylesheet':self.paths.append(a.get('href',''))
parser=Assets();parser.feed((root/'assets/index.html').read_text())
java=(root/'src/app/lovelycrxshx/kuro/MainActivity.java').read_text()
for name in parser.paths:
 assert (root/'assets'/name).is_file(), f'missing packaged asset: {name}'
 assert f'"/{name}".equals(u.getPath())' in java, f'missing Android WebView asset route: {name}'
assert '"aniwatch.co.at".equals(h)' in java and '"1anime.site"' in java, 'Library 10 native hosts missing'
assert '"www.miruro.cx".equals(h)' in java and 'MiruroCatalog.decode' in java, 'Library 11 native decoder or exact host missing'
assert 'verifyLibrary11' in java and 'openLibrary11Episode' in java, 'Library 11 user actions missing'
assert 'frame-errors532.js' in java and 'FrameReport.currentEvent' in java, 'nested-player error support missing'
player=Assets();player.feed((root/'assets/stream-player.html').read_text())
assert 'video-effects537.js' in player.paths and 'hls-1.6.16.min.js' in player.paths and 'ai-upscale540.js' in player.paths, 'local player must load bundled HLS, effects and optional AI'
assert player.paths.index('ai-upscale540.js') < player.paths.index('video-effects537.js'), 'AI engine must load before its integration'
assert 'evaluateJavascript(aiScript,aiIgnored->' in java and 'evaluateJavascript(fxScript,ignored->' in java, 'injected player must load AI before effects'
assert (root/'assets/THIRD_PARTY_ANIME4K_LICENSE.txt').is_file(), 'MIT license must ship in the APK'
for name in player.paths:
 assert (root/'assets'/name).is_file() and f'"/{name}".equals(u.getPath())' in java, f'local player route missing: {name}'
assert '"kitsunee.moe".equals(h)' in java and 'KitsuneCatalog.compact' in java, 'Library 12 exact host or compactor missing'
assert '"api.animeparadise.moe".equals(h)' in java and '/providers539.js' in java and 'Source path not allowed' in java, 'Library 13 API or bounded route missing'
assert 'watchSearchClosed' in java and 'watchNewsClosed' in java and 'NewsSync.ACTION_OPEN' in java, 'watch overlay or notification routing missing'
print('PASS WebView UI/local-HLS assets, Libraries 10–13, frame reports and native overlay routes')

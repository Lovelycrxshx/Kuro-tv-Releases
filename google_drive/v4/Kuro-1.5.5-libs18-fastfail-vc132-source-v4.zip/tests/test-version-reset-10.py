#!/usr/bin/env python3
"""Checks for the 1.0 renumbering.

The APK's version name restarts at 1.0 while versionCode keeps climbing (86 -> 87), so
the updater has to be told one thing it cannot infer: the 1.x line follows the 5.x line.
Everything else about the comparison has to stay exactly as it was.
"""
import pathlib, re

root = pathlib.Path(__file__).resolve().parent.parent
updater = (root / "src/app/lovelycrxshx/kuro/KuroUpdater572.java").read_text()
gradle = (root / "build.gradle").read_text()
manifest = (root / "AndroidManifest.xml").read_text()

assert "versionCode 87" in gradle, "the renumbered build must still move versionCode forward"
assert "versionName '1.0'" in gradle
assert 'android:versionCode="87" android:versionName="1.0"' in manifest

assert "if (a[0] == 1 && b[0] >= 5) return true;" in updater, \
    "without the 5.x -> 1.x rule every installed 5.x build refuses 1.0"

# the rule must sit before the ordinary comparison, and be the only special case
body = updater[updater.index("static boolean isNewer"):]
body = body[:body.index("\n    }")]
assert body.index("a[0] == 1") < body.index("for (int i = 0; i < length; i++)")
assert body.count("return true;") == 1, "the reset is the only early acceptance"
assert "return left > right;" in body, "the ordinary comparison must be untouched"

# --- arithmetic mirrored from the comparisons -------------------------------
def numbers(v):
    out = []
    for part in v.split("."):
        try:
            out.append(int(part))
        except ValueError:
            out.append(0)
    return out

def is_newer(candidate, installed):
    a, b = numbers(candidate), numbers(installed)
    if a[0] == 1 and b[0] >= 5:
        return True
    for i in range(max(len(a), len(b))):
        left = a[i] if i < len(a) else 0
        right = b[i] if i < len(b) else 0
        if left != right:
            return left > right
    return False

assert is_newer("1.0", "5.83"), "the whole point: 5.83 upgrades to 1.0"
assert is_newer("1.0", "5.72")
assert not is_newer("1.0", "1.0"), "same version is not newer"
assert is_newer("1.1", "1.0")
assert not is_newer("1.0", "1.1"), "1.0 is never offered over 1.1"
assert is_newer("1.10", "1.9"), "numeric, not lexical"
assert is_newer("1.0.1", "1.0")
assert not is_newer("2.0", "2.0.0")
assert is_newer("2.0", "1.9")
assert not is_newer("1.0", "2.0"), "the rule must not make 1.x newer than a later 2.x"

print("test-version-reset-10: PASS")

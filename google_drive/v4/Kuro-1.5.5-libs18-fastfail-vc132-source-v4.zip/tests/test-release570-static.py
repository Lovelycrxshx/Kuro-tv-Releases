#!/usr/bin/env python3
"""Release contracts supplement unit tests; they do not test Discord itself."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
main=(r/'src/app/lovelycrxshx/kuro/MainActivity.java').read_text()
art=(r/'src/app/lovelycrxshx/kuro/KuroArtwork567.java').read_text()
model=(r/'src/app/lovelycrxshx/kuro/KuroPresence563.java').read_text()
native=(r/'native/kuro_discord_rpc563.cpp').read_text()
settings=(r/'assets/settings560.js').read_text()
manifest=(r/'AndroidManifest.xml').read_text();gradle=(r/'build.gradle').read_text()
assert 'info.optString("episodeImage","")' not in main
assert 'discordArtwork567.resolve(info.optString("title",""),suppliedCover' in main
assert 'pickKitsuCover' in art and 'posterImage' in art and 'coverImage' in art
assert 'requestEpisode' not in art and '/episodes?filter' not in art and 'pickKitsuEpisode' not in art
assert '/anime/poster_images/' in model and '/episodes/thumbnails/' not in model
assert 'episodes/thumbnails/' not in native and 'anime/poster_images/' in native
assert 'anime cover, not an episode thumbnail' in settings
assert 'MIN_SEND_MS=3000, REFRESH_MS=3000' in model
assert 'AddButton(' not in native and 'ActivityTypes::Watching' in native
assert 'android:versionCode="71"' in manifest and 'android:versionName="5.71"' in manifest
assert 'versionCode 71' in gradle and "versionName '5.71'" in gradle
print('PASS 5.71 anime-cover-only RPC, opt-in title-only lookup, no buttons and version invariants')

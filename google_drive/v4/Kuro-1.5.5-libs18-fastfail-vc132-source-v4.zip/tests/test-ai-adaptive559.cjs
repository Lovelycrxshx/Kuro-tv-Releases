'use strict';
// A real decoder and WebGL2 program with a simulated slow fence. Confirms that
// workload is reduced before a safe, honest classic-only fallback.
const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets'),ai=fs.readFileSync(path.join(root,'ai-upscale540.js'),'utf8'),fx=fs.readFileSync(path.join(root,'video-effects537.js'),'utf8'),movie=fs.readFileSync(path.join(__dirname,'fixtures/fx-controls559.webm'));
const config={enabled:true,ai:true,aiStrength:100,preset:'A',detail:8,gain:100};
(async()=>{const browser=await chromium.launch({headless:true,args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--autoplay-policy=no-user-gesture-required']});try{
 const page=await browser.newPage({viewport:{width:320,height:180}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.route('**/*',r=>{const u=new URL(r.request().url());if(u.pathname==='/movie.webm')return r.fulfill({status:200,contentType:'video/webm',body:movie});if(u.pathname==='/player')return r.fulfill({status:200,contentType:'text/html',body:'<style>html,body{margin:0}video{width:320px;height:180px;display:block}</style><video controls src="/movie.webm"></video>'});return r.abort()});
 async function open(){await page.goto('https://kuro.local/player');await page.waitForFunction(()=>document.querySelector('video').readyState>=2);await page.addScriptTag({content:ai});await page.addScriptTag({content:fx});await page.evaluate(()=>{let real=WebGL2RenderingContext.prototype.clientWaitSync;window.__slowFence=true;WebGL2RenderingContext.prototype.clientWaitSync=function(sync,flags,timeout){return window.__slowFence?this.TIMEOUT_EXPIRED:real.call(this,sync,flags,timeout)}})}
 // Backgrounding with an in-flight frame must not count hidden time as a
 // slow GPU or force an unnecessary quality downgrade on resume.
 await open();await page.evaluate(config=>{window.__kuroFx537.configure(config);window.__kuroFx537.configure({...config,visible:false})},config);await page.waitForTimeout(400);await page.evaluate(()=>window.__slowFence=false);await page.evaluate(config=>window.__kuroFx537.configure(config),config);await page.waitForTimeout(100);let resumed=await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()));assert.equal(resumed.ai,'active');assert.equal(resumed.aiTier,0);
 await open();await page.evaluate(config=>window.__kuroFx537.configure(config),config);
 await page.waitForFunction(()=>{let s=JSON.parse(window.__kuroFx537.status());return s.aiTier===1&&s.ai==='active'},null,{timeout:10000});
 await page.evaluate(()=>window.__slowFence=false);await page.waitForTimeout(120);let lighter=await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()));assert.equal(lighter.video,'active');assert.equal(lighter.ai,'active');assert.equal(lighter.aiTier,1);assert(lighter.aiWidth<=240&&lighter.aiHeight<=135,JSON.stringify(lighter));
 // Compare/restore must never misclassify the deliberate pause as a slow GPU.
 await page.evaluate(config=>window.__kuroFx537.configure({...config,compare:true}),config);let compare=await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()));assert.equal(compare.video,'compare');assert.equal(compare.ai,'paused');
 await page.evaluate(config=>window.__kuroFx537.configure(config),config);await page.waitForTimeout(100);let restored=await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()));assert.equal(restored.video,'active');assert.equal(restored.ai,'active');
 await open();await page.evaluate(config=>window.__kuroFx537.configure(config),config);await page.waitForFunction(()=>{const s=JSON.parse(window.__kuroFx537.status());return s.ai==='unavailable'&&s.aiReason.includes('speed')},null,{timeout:12000});
 let fallback=await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()));assert.equal(fallback.video,'active');assert.equal(fallback.ai,'unavailable');assert.equal(fallback.aiTier,2);assert.equal(await page.locator('canvas[data-kuro-fx]').count(),1,'classic renderer remains available');
 await page.evaluate(config=>window.__kuroFx537.configure({...config,visible:false}),config);await page.evaluate(config=>window.__kuroFx537.configure(config),config);fallback=await page.evaluate(()=>JSON.parse(window.__kuroFx537.status()));assert.equal(fallback.ai,'unavailable','known GPU failure is not mislabeled paused after resume');
 assert.deepEqual(errors,[]);console.log('PASS adaptive AI downshifts resolution and honestly falls back on a simulated stalled GPU, including paused comparison lifecycle');
 }finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});

#!/usr/bin/env python3
"""5.58 regression: no runtime Hayase handoff; existing source controls remain.

This checks shipped source strings, not a real Android installation or stream.
"""
from pathlib import Path

root = Path(__file__).resolve().parent.parent
runtime = (root / 'AndroidManifest.xml').read_text()
for folder, suffixes in [('assets', {'.js', '.html'}), ('src', {'.java'})]:
    for path in (root / folder).rglob('*'):
        if path.is_file() and path.suffix in suffixes:
            runtime += '\n' + path.read_text()
for forbidden in ('hayase.watch/download', 'hayase://', 'app.hayase', 'openHayase', 'hayase-title-link', 'hayase-open'):
    assert forbidden.lower() not in runtime.lower(), f'external-app handoff survived: {forbidden}'
assert 'id="paradise-toggle"' in runtime
assert 'data-open-site="anicult"' in runtime
assert 'window.kuroSavePage=capture' in runtime
manifest = (root / 'AndroidManifest.xml').read_text()
gradle = (root / 'build.gradle').read_text()
assert 'android:versionCode="71"' in manifest and 'android:versionName="5.71"' in manifest
assert 'versionCode 71' in gradle and "versionName '5.71'" in gradle
print('PASS 5.58 runtime contains no Hayase handoff; existing other source and saved-route controls remain')

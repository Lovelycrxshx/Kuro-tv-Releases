const fs=require('fs'),vm=require('vm'),assert=require('assert');
const code=fs.readFileSync('assets/failover531.js','utf8');
const fn=code.slice(code.indexOf('async function seekFallbacks('),code.indexOf('async function openEpisode('));
async function run(hasServer){
 const blocked=new Set(),found=[];let result;
 const adapters={};for(const name of ['wave575','koto575','gogo575','ms','dk','nine','zoro','ani','salt','flix','wixi','zenkai','aw','miruro','kitsune','paradise']) adapters[name]=async()=>[];
 adapters.wave575=async()=>{throw Error('HTTP 403')};adapters.koto575=async()=>hasServer?[{url:'ok'}]:[];
 const context={unifiedVerificationBlocked:blocked,failoverAdapters:adapters,servers:found,isVerification:e=>/403/.test(e.message),addChainServers:(c,items)=>found.push(...items),finishChain:(c,b)=>{c.done=true;result=b},Promise};
 vm.runInNewContext(fn+';globalThis.go=seekFallbacks',context);
 await context.go({alive:()=>true,done:false,fallbackStop:false,source:'',title:'x',number:'1',identity:{},buffer:[]});
 assert(blocked.has('wave575'));assert.equal(found.length,hasServer?1:0);assert.equal(result,!hasServer);
}
(async()=>{await run(true);await run(false);console.log('fallback restriction isolation: OK')})().catch(e=>{console.error(e);process.exit(1)});

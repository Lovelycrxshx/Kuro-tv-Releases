// Test-only harness for the 5.32 provider regressions. It restores the old
// per-source selectors in the served script, solely so those unchanged fixtures
// can exercise individual provider adapters. The shipped app does not use it;
// test-unified-library.cjs tests the actual 5.33 discovery UI.
const assert=require('assert');
module.exports=async function installLegacy532(page){
 await page.route('**/app.js',async route=>{
  const response=await route.fetch();let body=await response.text();
  const modern='home=unifiedHome;searchPage=unifiedSearchPage;simulcasts=unifiedSimulcasts;toggleSearchPopup=unifiedSearchPopup;browseGenre=unifiedBrowseGenre;';
  assert(body.includes(modern),'unified UI assignment is present in production source');body=body.replace(modern,'');
  body=body.replace("function sourceSortLabel(mode){return 'Source mix'}","function sourceSortLabel(mode){return popularityAvailable(source,mode)?'Popular first':'Library order'}");
  body=body.replace("const first=sourceSortLabel(mode),detail='A mix of available source lists; not a global ranking.';","const first=sourceSortLabel(mode),detail=popularityAvailable(source,mode)?`Ranked by ${label(source)} for this section.`:'The order returned by this library.';");
  await route.fulfill({response,body});
 });
};

'use strict';
// All provider replies and saved lists are synthetic. No actual phone/accounts are touched.
const {chromium}=require('playwright');
const http=require('http'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'../assets');
const server=http.createServer((req,res)=>{let name=new URL(req.url,'http://test').pathname.slice(1)||'index.html',file=path.resolve(root,name);if(!file.startsWith(root+path.sep))return res.writeHead(403).end();fs.readFile(file,(e,b)=>e?res.writeHead(404).end():res.writeHead(200,{'Content-Type':name.endsWith('.js')?'application/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':name.endsWith('.jpg')?'image/jpeg':'text/html'}).end(b))});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:393,height:852},isMobile:true,hasTouch:true}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.addInitScript(()=>{
  const results={},orig=window.fetch.bind(window);window.fetch=(v,o)=>{let u=typeof v==='string'?v:v.url;return u.startsWith('/result/')?Promise.resolve(new Response(results[decodeURIComponent(u.slice(8))]||'',{status:200})):orig(v,o)};
  const finish=(id,value)=>{results[id]=typeof value==='string'?value:JSON.stringify(value);setTimeout(()=>window.__nativeResult?.(id,''),0)};
  window.KuroNative={get(id){finish(id,'{}')},news(id){finish(id,{items:[],failed:[],checkedAt:Date.now()})},newsSettings(){return '{"enabled":false,"allowed":false}'},account(id,action){if(action==='status')finish(id,{config:{},connections:{local:{connected:false},discord:{connected:false},mal:{connected:false},anilist:{connected:false}}});else finish(id,{})}};
  if(!localStorage.getItem('grid-seeded')){
   const item=(title)=>({title,source:'ms',url:'https://hianime.ms/anime/'+title.toLowerCase().replaceAll(' ','-'),img:''});
   const watching=item('Local Watching'),bookmark=item('Bookmark only'),completed=item('Category Completed'),held=item('Category On Hold'),planned=item('Category Planned');
   const rows=[{provider:'mal',sourceId:'1',title:'Import Watching',status:'watching',adult:false},{provider:'mal',sourceId:'2',title:'Import Complete',status:'completed',adult:false},{provider:'mal',sourceId:'3',title:'Import Planned',status:'plan_to_watch',adult:false},{provider:'mal',sourceId:'4',title:'Restricted Adult',status:'dropped',adult:true},{provider:'mal',sourceId:'5',title:'Unclassified Adult',status:'on_hold',adult:null}];
   localStorage.setItem('kuro-library',JSON.stringify([watching,bookmark]));localStorage.setItem('kuro-categories-v1',JSON.stringify([{item:watching,status:'watching'},{item:completed,status:'completed'},{item:held,status:'on_hold'},{item:planned,status:'planned'}]));localStorage.setItem('kuro-imports-v1',JSON.stringify(rows));localStorage.setItem('kuro-episode-history-v1',JSON.stringify([{item:watching,ep:{number:'4',name:'',url:watching.url}}]));localStorage.setItem('kuro-profile-v1',JSON.stringify({name:'Existing profile',avatar:'',banner:''}));localStorage.setItem('grid-seeded','1');
  }
 });
 await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);await page.waitForSelector('nav.kuro-dock');
 const keys=['kuro-library','kuro-categories-v1','kuro-imports-v1','kuro-episode-history-v1','kuro-profile-v1'];const baseline=await page.evaluate(ks=>Object.fromEntries(ks.map(k=>[k,localStorage.getItem(k)])),keys);
 const ids=['all','watching','completed','on_hold','dropped','planned','imported','bookmarks','history'],labels=['All','Watching','Completed','On hold','Dropped','Planned to watch','Imported','Bookmark','History'];
 await page.click('[data-nav="library"]');assert.equal(await page.evaluate(()=>listFilter),'all');assert.deepEqual(await page.locator('.category-tabs [data-list-filter]').evaluateAll(bs=>bs.map(b=>b.dataset.listFilter)),ids);assert.deepEqual(await page.locator('.category-tabs button').allTextContents(),labels);
 assert.equal(await page.locator('.category-tabs [aria-pressed="true"]').count(),1);assert.equal(await page.locator('.category-tabs [aria-pressed="true"]').getAttribute('data-list-filter'),'all');
 const local=await page.locator('#saved [data-card] strong').allTextContents();assert.deepEqual(local,['Local Watching','Bookmark only','Category Completed','Category On Hold','Category Planned'],'All is a non-destructive union, deduplicated by source+URL');assert.equal(await page.locator('.import-card').count(),3);assert.equal(await page.locator('text=Restricted Adult').count(),0);assert.equal(await page.locator('text=Unclassified Adult').count(),0);
 // Four per row at every supported width, equal columns, no cropped labels or page overflow.
 for(const width of [280,320,360,393,620,768]){
  await page.setViewportSize({width,height:852});let grid=await page.locator('.category-tabs').evaluate(el=>({page:document.documentElement.scrollWidth,overflow:getComputedStyle(el).overflowX,buttons:[...el.querySelectorAll('button')].map(b=>{let r=b.getBoundingClientRect(),surface=getComputedStyle(b,'::before'),range=document.createRange();range.selectNodeContents(b);let text=range.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height,cw:b.clientWidth,sw:b.scrollWidth,ch:b.clientHeight,sh:b.scrollHeight,surfaceH:r.height-parseFloat(surface.top)-parseFloat(surface.bottom),surfaceColor:surface.backgroundColor,textTop:text.top-r.top,textBottom:text.bottom-r.top}})}));
  assert(grid.page<=width+1,`no horizontal page overflow at ${width}`);assert.equal(grid.buttons.length,9);
  const close=(a,b)=>Math.abs(a-b)<1.1,bs=grid.buttons;
  for(let i=0;i<4;i++){assert(close(bs[i].y,bs[0].y),`first row at ${width}`);assert(close(bs[i+4].y,bs[4].y),`second row at ${width}`);assert(close(bs[i].x,bs[i+4].x),`columns aligned at ${width}`)}
  assert(bs[4].y>bs[0].y&&bs[8].y>bs[4].y&&close(bs[8].x,bs[0].x),`4-4-1 order at ${width}`);
  for(const b of bs){assert(b.w>=47.9&&b.h>=47.9,`touch target ${width}: ${b.w}x${b.h}`);assert(b.sw<=b.cw+1&&b.sh<=b.ch+1,`label fits ${width}`);assert(b.surfaceH>=35.9&&b.surfaceH<=36.1,`compact visible surface ${width}: ${b.surfaceH}`);assert(b.textTop>=5-0.5&&b.textBottom<=b.h-5+0.5,`label stays in compact surface ${width}: ${b.textTop}..${b.textBottom}`)}
  assert.equal(bs[0].surfaceColor,'rgb(172, 107, 232)',`active colour ${width}`);assert.equal(bs[1].surfaceColor,'rgb(36, 23, 46)',`inactive colour ${width}`);
 }
 await page.setViewportSize({width:393,height:852});if(process.env.KURO_GRID_SCREENSHOT)await page.screenshot({path:process.env.KURO_GRID_SCREENSHOT,animations:'disabled'});
 // Taps in the transparent margin still activate the 48px touch target.
 await page.locator('[data-list-filter="watching"]').click({position:{x:3,y:3}});assert.equal(await page.evaluate(()=>listFilter),'watching');
 await page.locator('[data-list-filter="all"]').click({position:{x:3,y:3}});assert.equal(await page.evaluate(()=>listFilter),'all');
 for(const id of ids){await page.click(`[data-list-filter="${id}"]`);assert.equal(await page.evaluate(()=>listFilter),id);assert.equal(await page.locator('.category-tabs .active').count(),1);assert.equal(await page.locator('.category-tabs [aria-pressed="true"]').getAttribute('data-list-filter'),id);assert.deepEqual(await page.locator('.category-tabs [data-list-filter]').evaluateAll(bs=>bs.map(b=>b.dataset.listFilter)),ids);if(id==='watching'){assert((await page.locator('#saved').innerText()).includes('Local Watching'));assert.equal(await page.locator('.import-card').count(),1)}if(id==='bookmarks'){assert.deepEqual(await page.locator('#saved [data-card] strong').allTextContents(),['Local Watching','Bookmark only']);assert.equal(await page.locator('.import-card').count(),0)}if(id==='history')assert.equal(await page.locator('.history-card').count(),1);if(id==='imported')assert.equal(await page.locator('.import-card').count(),3)}
 // Generic library buttons return to All; explicit history/imported routes remain explicit.
 await page.click('[data-nav="library"]');assert.equal(await page.evaluate(()=>listFilter),'all');
 await page.click('[data-nav="profile"]');await page.waitForSelector('#profile-anime');await page.click('#profile-anime');assert.equal(await page.evaluate(()=>listFilter),'all');
 await page.click('[data-nav="profile"]');await page.waitForSelector('#profile-bookmarks');await page.click('#profile-bookmarks');assert.equal(await page.evaluate(()=>listFilter),'all');
 await page.click('[data-nav="profile"]');await page.waitForSelector('#profile-imported');await page.click('#profile-imported');assert.equal(await page.evaluate(()=>listFilter),'imported');
 await page.click('[data-nav="profile"]');await page.waitForSelector('#profile-history');await page.click('#profile-history');assert.equal(await page.evaluate(()=>listFilter),'history');
 let after=await page.evaluate(ks=>Object.fromEntries(ks.map(k=>[k,localStorage.getItem(k)])),keys);assert.deepEqual(after,baseline,'opening and switching tabs does not change saved account/profile/lists/history data');assert.deepEqual(errors,[]);
 console.log('PASS 5.58 compact surfaces, 48px targets, 4-4-1 order, All default, non-destructive union and 280–768 px layouts');
 }finally{if(browser)await browser.close();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});

#!/usr/bin/env python3
"""Check the signed APK's source assets, architecture, CRC and ELF alignment.

Usage: python3 tests/test-apk570.py path/to/Kuro-tv-5.70.apk
Optional KURO_DISCORD_SDK_AAR verifies separately licensed vendor binaries.
Signature/certificate and ZIP alignment additionally require apksigner/zipalign.
"""
import os,pathlib,struct,sys,zipfile
root=pathlib.Path(__file__).resolve().parents[1]
if len(sys.argv)!=2: raise SystemExit(__doc__)
abi={'arm64-v8a','armeabi-v7a','x86','x86_64'}
def load_alignments(data):
    if data[:4]!=b'\x7fELF' or data[5]!=1: raise AssertionError('invalid or non-little-endian ELF')
    if data[4]==2:
        phoff=struct.unpack_from('<Q',data,32)[0]; entsize,num=struct.unpack_from('<HH',data,54); align_offset=48; fmt='<Q'
    elif data[4]==1:
        phoff=struct.unpack_from('<I',data,28)[0]; entsize,num=struct.unpack_from('<HH',data,42); align_offset=28; fmt='<I'
    else: raise AssertionError('unexpected ELF class')
    result=[]
    for i in range(num):
        entry=phoff+i*entsize
        if struct.unpack_from('<I',data,entry)[0]==1:result.append(struct.unpack_from(fmt,data,entry+align_offset)[0])
    return result
with zipfile.ZipFile(sys.argv[1]) as z:
    assert z.testzip() is None,'ZIP CRC failure'
    names=z.namelist();libs=[n for n in names if n.startswith('lib/') and n.endswith('.so')]
    assert {n.split('/')[1] for n in libs}==abi
    assert len(libs)==8 and all(len(load_alignments(z.read(n)))>0 and min(load_alignments(z.read(n)))>=16384 for n in libs),'ELF must support 16 KiB pages'
    for path in ['assets/accounts542.js','assets/accounts542.css','assets/index.html','assets/settings560.js','assets/video-effects537.js','assets/kuro-logo.png','assets/kuro-logo.svg']:
        assert z.read(path)==(root/path).read_bytes(),path+' differs from source'
    dex=b''.join(z.read(n) for n in names if n.startswith('classes') and n.endswith('.dex'))
    for marker in [b'GitHubAdmin568',b'Ov23li2LjGiWV0VW2K7p',b'https://github.com/login/device',b'https://api.github.com/user']:
        assert marker in dex,'missing compiled owner guard'
    for a in abi:
        compiled=root/f'build/kuro-discord-jni/{a}/libkuro_discord_rpc563.so'
        if compiled.is_file(): assert z.read(f'lib/{a}/libkuro_discord_rpc563.so')==compiled.read_bytes(),'JNI library mismatch '+a
    aar=os.environ.get('KURO_DISCORD_SDK_AAR','')
    if aar:
        with zipfile.ZipFile(aar) as vendor:
            for a in abi: assert z.read(f'lib/{a}/libdiscord_partner_sdk.so')==vendor.read(f'jni/{a}/libdiscord_partner_sdk.so'),'Discord SDK binary mismatch '+a
print('PASS APK CRC, four ABIs, eight 16 KiB ELF binaries, compiled owner guard, matching UI assets and optional SDK hash checks')

#!/usr/bin/env python3
"""Static contract complements Chromium/Robolectric; it cannot test a phone."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
main=(r/'src/app/lovelycrxshx/kuro/MainActivity.java').read_text()
settings=(r/'assets/settings560.js').read_text();accounts=(r/'assets/accounts542.js').read_text()
fx=(r/'assets/video-effects537.js').read_text();dialog=(r/'src/app/lovelycrxshx/kuro/PlayerOptionsDialog.java').read_text()
manifest=(r/'AndroidManifest.xml').read_text();gradle=(r/'build.gradle').read_text();native=(r/'native/kuro_discord_rpc563.cpp').read_text()
assert 'MainActivity.this.discordAction564(action)' in main
assert 'if(!isFinishing()&&!isDestroyed())MainActivity.this.discordAction564(action)' in main
assert 'main.post(()->discordAction564(action))' not in main
assert all(s in settings for s in ['presenceGroup569()','customizationGroup569()','openDiscord569','rpcReconnectCurrent564','rpcReconnectLinked564','rpcLink564','rpcUnlink564','rpcClear564'])
assert all(s in accounts for s in ['discordPresence','discordCustomize','data-discord-shortcut569','discord-overlay569'])
assert 'preferOverlayFullscreen569()' in main and 'cb.onCustomViewHidden();enterEnhancedFullscreen();return;' in main
assert 'setTag("enhanced-fullscreen-options")' not in main and 'setTag("enhanced-fullscreen-exit")' in main
assert 'if(enhancedFullscreen||customView!=null)' in main and 'hideFullscreenExit569' in main
assert all(s in fx for s in ['adoptOverlayParent569','pointerEvents:\'none\'','fullscreenchange','restoreColor569','applyColor569','Color only; frame access is restricted'])
assert "if(v.mediaKeys)return 'protected'" in fx and 'if(!v||v.mediaKeys||' in fx
assert 'Color only' in dialog and 'restricted' in dialog.lower()
assert 'android:versionCode="70"' in manifest and 'android:versionName="5.70"' in manifest
assert 'versionCode 70' in gradle and "versionName '5.70'" in gradle
assert 'AddButton(' not in native and 'ActivityTypes::Watching' in native
print('PASS 5.70 native action dispatch, shared shortcuts, fullscreen routing, honest color-only fallback and no Discord buttons')

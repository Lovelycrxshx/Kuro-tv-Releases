#!/usr/bin/env python3
"""Static checks for 5.82 cut 2: automatic updating with an in-app download screen.

The guarantees, checked against the sources that are actually compiled:

  * a found release goes straight to a download — no reminder cadence in the way;
  * the release is still verified (published SHA-256 + pinned certificate) before the
    installer is offered, and Android still owns the confirmation;
  * automatic mode never loops: a cancelled install is not re-offered for that version;
  * the progress screen reads byte counts from prefs only, never a path or a token;
  * the Wi-Fi-only setting still gates the transfer.
"""
import pathlib, re, sys

root = pathlib.Path(__file__).resolve().parent.parent
src = root / "src/app/lovelycrxshx/kuro"
center = (src / "KuroUpdateCenter582.java").read_text()
dialog = (src / "KuroUpdateDialog582.java").read_text()
service = (src / "KuroUpdaterDownloadService.java").read_text()
updater = (src / "KuroUpdater572.java").read_text()
main = (src / "MainActivity.java").read_text()

# --- automatic path ---------------------------------------------------------
assert "static boolean shouldDownloadNow(Context c, KuroUpdater572.Release release)" in center
assert "!autoEnabled(c)" in center, "automatic mode must be switchable off"
assert "READY.equals(p.getString(\"stage\", \"\"))" in center, "a ready file must not be re-downloaded"
assert "isNewer(release.version, KuroUpdater572.installedVersionName(c))" in center, \
    "automatic downloads must still require a strictly newer version"
assert "if (KuroUpdateCenter582.autoStep(c, release)) return;" in updater, \
    "the scheduled pass must hand a found release to automatic mode"
assert updater.index("autoStep(c, release)") < updater.index("advance(p,"), \
    "automatic mode must short-circuit before the reminder state machine"

# --- still verified ---------------------------------------------------------
assert "KuroApkPreflight572.inspect(this, target)" in service
assert "markReady(this, version)" in service
assert "did not match the published checksum" in service
assert "ACTION_VIEW" in main and "application/vnd.android.package-archive" in main
assert "canRequestPackageInstalls" in main, "Android's unknown-sources gate must be honoured"
assert "cannot install silently" in center or "Android asks before it installs" in center

# --- no install loop --------------------------------------------------------
assert "autoOffered582" in center
assert "static boolean autoOfferAllowed" in center and "markAutoOffered" in center
assert "autoOfferAllowed(activity, s.version)" in dialog

# --- progress plumbing ------------------------------------------------------
for key in ('"dlBytes"', '"dlTotal"', '"dlSpeed"', '"dlUpdatedAt"'):
    assert key in service, key + " must be written by the download service"
    assert key in center, key + " must be read by the update screen"
assert '"verifying"' in service, "the signature check must be visible on screen"
assert "STOP_FOREGROUND_REMOVE" in service

# the screen never invents progress and never shows a path
assert "s.percent >= 0 && !s.scheduled() ? s.percent" in dialog
assert '".part"' not in dialog and "getFilesDir" not in dialog

# --- network setting and cancellation still apply ---------------------------
assert "WaitForWifi" in service and "wifiOnly" in service
assert "static void cancel()" in service and "cancelRequested" in service
assert "catch (Cancelled" in service or "instanceof Cancelled" in service
assert "stopDownload(activity)" in dialog

# --- screen wiring ----------------------------------------------------------
assert "checkAndMaybeInstall582" in main and "openUpdateDialog582" in main
assert "KuroUpdateDialog582.Host updateHost582" in main
assert '"updatesAuto582"' in main
assert "updateWatch582" in main and "main.removeCallbacks(updateWatch582)" in main, \
    "the watcher must stop when the app leaves the foreground"

settings_js = (root / "assets/settings560.js").read_text()
assert "updatesAuto582" in settings_js, "the setting needs a row in the settings list"

# --- arithmetic mirrored from KuroUpdateCenter582 ----------------------------
def percent(bytes_done, total):
    return -1 if total <= 0 else max(0, min(100, bytes_done * 100 // total))

assert percent(0, 44008672) == 0
assert percent(22004336, 44008672) == 50
assert percent(44008672, 44008672) == 100
assert percent(99999999, 44008672) == 100, "a longer file must never read over 100%"
assert percent(1024, 0) == -1, "unknown total must stay indeterminate"

def eta(bytes_done, total, speed):
    if total <= 0 or speed <= 0 or bytes_done >= total:
        return ""
    seconds = max(1, (total - bytes_done) // max(1, speed))
    if seconds >= 3600:
        return f"{seconds // 3600} h left"
    if seconds >= 60:
        return f"{seconds // 60} min left"
    return f"{seconds} s left"

assert eta(0, 44008672, 22004336) == "2 s left"
assert eta(44008672, 44008672, 1000) == ""
assert eta(0, 44008672, 0) == ""
assert eta(0, 44008672, 100) == "122 h left"

# a size must never claim more precision than it has
def size(n):
    if n <= 0: return "0 MiB"
    mib = n / 1048576.0
    if mib >= 1000: return f"{round(mib / 100) * 100} MiB"
    if mib >= 100: return f"{mib:.0f} MiB"
    return f"{mib:.2f} MiB"

assert size(44008672) == "41.97 MiB"
assert size(0) == "0 MiB"
assert size(1048576) == "1.00 MiB"
assert size(157286400) == "150 MiB"

print("test-auto-update-582: PASS")

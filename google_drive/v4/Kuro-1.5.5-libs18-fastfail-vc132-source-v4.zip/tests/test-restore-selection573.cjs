'use strict';
// Exercise the actual restore-preview handler with a small DOM/storage harness.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('assets/settings560.js','utf8');
const code=source.slice(source.indexOf(' const restoreGroups560='),source.indexOf('\n window.kuroSettings560='));
let html='',checked=new Set(),notices=[],mergeCalls=[];
const cancel={},confirm={};
const box={hidden:true,textContent:'',set innerHTML(v){html=v},get innerHTML(){return html},querySelector(q){if(q==='[data-cancel]')return cancel;if(q==='[data-confirm]')return confirm;const m=q.match(/^\[data-restore-group="(.+)"\]$/);if(m)return {checked:checked.has(m[1])};return null}};
const backup={format:'kuro-local-backup-1',data:{'kuro-library':[{title:'example'}],'kuro-episode-history-v1':[{}],'kuro-profile-v1':{name:'example'},'kuro-settings560-v1':{orientation:'portrait'}}};
const window={kuroBackup560:{preview:()=>({backup,summary:2}),merge:(b,opts)=>{mergeCalls.push({b,opts});return {added:1,kept:0,updated:0}}}};
const ctx=vm.createContext({window,document:{querySelector:()=>box},notice:x=>notices.push(x),hooks:{},loadedBackup:null});vm.runInContext(code,ctx);
window.kuroBackupLoaded560('fixture','');assert.match(html,/Library and lists/);assert.match(html,/Viewing history/);assert.match(html,/Profile and artwork/);assert.match(html,/Menu settings/);assert.match(html,/data-apply-settings/);
checked=new Set(['library']);confirm.onclick();assert.deepStrictEqual(Object.keys(mergeCalls[0].b.data),['kuro-library']);assert.equal(mergeCalls[0].opts.applySettings,false);
window.kuroBackupLoaded560('fixture','');checked=new Set();confirm.onclick();assert.match(notices.at(-1),/Select at least one/);assert.equal(mergeCalls.length,1);
checked=new Set(['settings']);confirm.onclick();assert.deepStrictEqual(Object.keys(mergeCalls[1].b.data),['kuro-settings560-v1']);assert.equal(mergeCalls[1].opts.applySettings,true);
window.kuroBackupLoaded560('fixture','');cancel.onclick();assert.equal(box.hidden,true);assert.equal(mergeCalls.length,2);
console.log('PASS selective backup preview: group selection, settings opt-in, empty selection and cancel');

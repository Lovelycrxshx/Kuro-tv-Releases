#!/usr/bin/env python3
"""Release invariants; no GitHub account, Android device or secrets are used."""
from pathlib import Path
import os,zipfile
r=Path(__file__).resolve().parents[1]
gh=(r/'src/app/lovelycrxshx/kuro/GitHubAdmin568.java').read_text()
main=(r/'src/app/lovelycrxshx/kuro/MainActivity.java').read_text()
ui=(r/'assets/accounts542.js').read_text()
manifest=(r/'AndroidManifest.xml').read_text()
assert 'OWNER_ID=226603888L' in gh and 'CLIENT_ID="Ov23li2LjGiWV0VW2K7p"' in gh
assert 'AccountOAuth.map("client_id",CLIENT_ID,"scope","")' in gh
assert 'client_secret' not in gh and 'identity.optLong("id",0)!=OWNER_ID' in gh
assert 'r.remove("access_token");r.remove("refresh_token")' in gh
assert '"scope")&&!r.isNull("scope")' in gh and 'trim().isEmpty()' in gh
assert 'new URL(address).openConnection()' in gh and 'setInstanceFollowRedirects(false)' in gh
assert all(x in gh for x in ['https://github.com/login/device','https://api.github.com/user','status==429','status==401||status==403','authorization_pending','slow_down'])
assert 'AtomicLong generation' in gh and 'pendingGeneration!=generation.get()' in gh and 'verifiedGeneration!=generation.get()' in gh
assert 'synchronized(githubAdmin568)' in main and 'if(!githubAdmin568.verified())' in main and main.count('accounts.saveConfig(p)')==1
assert 'githubAdmin568.invalidate();pool.execute' in main and 'githubAdmin568.close()' in main
assert 'githubAdmin568.currentCode()' in main and 'openAccountBrowser(GitHubAdmin568.VERIFY_URL)' in main
assert 'android:allowBackup="false"' in manifest and 'android:versionCode="70"' in manifest and 'android:versionName="5.70"' in manifest
assert '1600' in ui and "bindAdminGesture568(o.querySelector('.profile-brand561'))" in ui and "bindAdminGesture568(o.querySelector('#account-dialog-title'))" in ui
assert "request('adminStatus')" in ui and "request('adminPoll')" in ui and "request('adminCancel')" in ui
assert 'account-setup-open' not in ui and 'account-settings' not in ui
baseline=os.environ.get('KURO_567_BASELINE_ZIP','')
if baseline:
    must_match=['src/app/lovelycrxshx/kuro/KuroAccounts.java','src/app/lovelycrxshx/kuro/KuroDiscordRpc563.java','assets/index.html','assets/profile-settings560.css','assets/kuro-logo.png','assets/kuro-logo.svg']
    with zipfile.ZipFile(baseline) as z:
        names={n.split('/',1)[1]:n for n in z.namelist() if '/' in n and not n.endswith('/')}
        for f in must_match: assert z.read(names[f])==(r/f).read_bytes(),f+' changed unexpectedly'
print('PASS 5.70 retained native owner gate, no-scope identity, fixed HTTPS endpoints, cancellation, hidden UI, version and retained unaffected 5.67 invariants')

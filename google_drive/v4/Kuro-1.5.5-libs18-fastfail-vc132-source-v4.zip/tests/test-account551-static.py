#!/usr/bin/env python3
"""Static packaging checks; these are not device or live-provider tests."""
from pathlib import Path
import re,sys,zipfile
root=Path(__file__).resolve().parents[1]
accounts=(root/'assets/accounts542.js').read_text();app=(root/'assets/app.js').read_text(); main=(root/'src/app/lovelycrxshx/kuro/MainActivity.java').read_text(); native=(root/'src/app/lovelycrxshx/kuro/KuroAccounts.java').read_text();local=(root/'src/app/lovelycrxshx/kuro/LocalEmail551.java').read_text();oauth=(root/'src/app/lovelycrxshx/kuro/AccountOAuth.java').read_text();transport=(root/'src/app/lovelycrxshx/kuro/AccountHttp.java').read_text()
for text in (accounts,app,main,native,local,oauth,transport):
 assert 'supabase' not in text.lower(), 'old email service appears in active source'
assert 'data-signin="google"' not in accounts and 'Drive backup' not in accounts+app
assert 'KuroCloud' not in accounts and 'BackupCoordinator545' not in main and 'public void cloud(' not in main
assert 'case "recover"' not in main and 'case "password"' not in main
assert 'new LocalEmail551(v)' in native and 'localEmail.signup' in native and 'localEmail.login' in native and 'localEmail.signOut' in native
assert 'PBKDF2WithHmacSHA256' in local and 'ITERATIONS=310000' in local and 'SecureRandom' in local and 'MessageDigest.isEqual' in local
assert 'not verified' in accounts and 'does not lock' in accounts and 'email recovery is unavailable' in accounts
for provider in ('discord','mal','anilist'):assert f'data-signin="{provider}"' in accounts
for f in ['NativeGoogleSignIn.java','GoogleTokenVerifier.java','DriveAuthorization545.java','DriveBackup545.java','BackupCoordinator545.java','BackupCodec545.java']:
 assert not (root/'src/app/lovelycrxshx/kuro'/f).exists(),f
assert not (root/'assets/cloud545.js').exists()
if len(sys.argv)>1:
 with zipfile.ZipFile(sys.argv[1]) as z:
  names=set(z.namelist());assert 'assets/accounts542.js' in names and 'assets/local-restore-safety550.js' in names
  assert 'assets/cloud545.js' not in names
  for name in ('assets/accounts542.js','assets/app.js'):assert z.read(name)==(root/name).read_bytes(),f'{name} differs from source'
  dex=b''.join(z.read(n) for n in names if re.fullmatch(r'classes\d*\.dex',n));assert dex
  for banned in [b'Lapp/lovelycrxshx/kuro/NativeGoogleSignIn;',b'Lapp/lovelycrxshx/kuro/DriveBackup545;',b'Lapp/lovelycrxshx/kuro/BackupCoordinator545;',b'supabase.co',b'/auth/v1/signup',b'/auth/v1/recover']:
   assert banned not in dex,banned
  for required in [b'Lapp/lovelycrxshx/kuro/KuroAccounts;',b'Lapp/lovelycrxshx/kuro/LocalEmail551;',b'PBKDF2WithHmacSHA256']:
   assert required in dex,required
  assert z.testzip() is None
print('PASS local account structure, no old integration in active source and (if supplied) APK assets/DEX')

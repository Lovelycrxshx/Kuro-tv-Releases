'use strict';
// 5.81 offline smoke test: boots the real page in jsdom, opens the profile view and
// proves that no profile picture or banner markup survives anywhere.
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const root = path.join(__dirname, '..', 'assets');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const stripped = html.replace(/<script src="[^"]+"><\/script>/g, '');
const dom = new JSDOM(stripped, { url: 'https://kuro.test/', runScripts: 'dangerously', pretendToBeVisual: true });
const { window } = dom;

window.matchMedia = window.matchMedia || (() => ({ matches: false, addEventListener() {}, removeEventListener() {} }));
const errors = [];
window.addEventListener('unhandledrejection', e => errors.push('promise: ' + (e.reason && e.reason.message)));
window.addEventListener('error', e => errors.push(String(e.message)));

for (const tag of html.matchAll(/<script src="([^"]+)"><\/script>/g)) {
  const file = path.join(root, tag[1]);
  if (!fs.existsSync(file)) { errors.push('missing script ' + tag[1]); continue; }
  const el = window.document.createElement('script');
  el.textContent = fs.readFileSync(file, 'utf8');
  window.document.head.appendChild(el);
  }
window.localStorage.setItem('kuro-profile-v1', JSON.stringify({ name: 'Kai Uchida' }));
(async () => {
  // Stand in for the Android account bridge so the real profile render runs offline.
  const accountState = { signedIn: false, connections: {} };
  window.KuroNative = window.KuroNative || {};
  window.KuroNative.account = (id) => setTimeout(() => window.__nativeResult && window.__nativeResult(id), 0);
  window.fetch = async () => ({ ok: true, status: 200, json: async () => accountState, text: async () => JSON.stringify(accountState) });
  window.view = 'profile';
  if (typeof window.nav === 'function') window.nav('profile');
  await new Promise(r => setTimeout(r, 120));
  await new Promise(r => setTimeout(r, 120));

  const body = window.document.body.innerHTML;
  const problems = [];
  for (const bad of ['profile-avatar547', 'profile-banner547', 'preset571-', 'profile-character549', 'profile-default571',
    'profile-banner-pick', 'profile-avatar-pick', 'profile-art571', 'profile-card-art548']) {
    if (body.includes(bad)) problems.push('markup still mentions ' + bad);
  }
  if (/<img[^>]+src="profile-(?:avatar|banner)/.test(body)) problems.push('profile pictures still rendered');
  const mono = window.document.querySelector('.profile-mono571');
  if (!mono) problems.push('monogram missing');
  else if (!/^[A-Z]{1,2}$/.test(mono.textContent.trim())) problems.push('monogram text is "' + mono.textContent + '"');

  if (window.__bootErrors) errors.push(...window.__bootErrors);
  // 5.81: the home hero deck must build slides, dots and one Watch pill per slide.
  window.nav('home');
  await new Promise(r => setTimeout(r, 80));
  window.renderSpotlight([
    { url: 'https://kuro.test/a', source: 'zoro', title: 'Frieren', meta: 'TV · 28 eps', img: 'https://kuro.test/a.jpg' },
    { url: 'https://kuro.test/b', source: 'nine', title: 'Dandadan', meta: 'TV · 12 eps', img: 'https://kuro.test/b.jpg' }
  ]);
  const slides = window.document.querySelectorAll('.hero-slide');
  const dots = window.document.querySelectorAll('.hero-dot581');
  const pills = window.document.querySelectorAll('[data-hero-open]');
  if (slides.length !== 2) problems.push('hero slides: ' + slides.length);
  if (dots.length !== 2) problems.push('hero dots: ' + dots.length);
  if (pills.length !== 2) problems.push('hero pills: ' + pills.length);
  if (dots[0] && dots[0].getAttribute('aria-current') !== 'true') problems.push('first dot not current');
  if (!window.document.querySelector('.hero-track581')) problems.push('no swipe track');
  if (dots[1]) { dots[1].dispatchEvent(new window.Event('click', { bubbles: true })); }
  if (dots[1] && dots[1].getAttribute('aria-current') !== 'true') problems.push('dot click did not move the deck');

  console.log('boot errors:', errors.length ? errors : 'none');
  console.log('profile problems:', problems.length ? problems : 'none');
  dom.window.close();
  process.exit(errors.length || problems.length ? 1 : 0);
})().catch(e => { console.error('harness failed:', e); process.exitCode = 2; });

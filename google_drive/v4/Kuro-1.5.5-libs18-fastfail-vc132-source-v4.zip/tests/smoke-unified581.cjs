'use strict';
// 5.81 offline check for the unified surfaces: the home hero deck (fed by the unified
// pager) and the browse filter chips. Runs the real scripts in jsdom.
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const root = path.join(__dirname, '..', 'assets');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const dom = new JSDOM(html.replace(/<script src="[^"]+"><\/script>/g, ''), {
  url: 'https://kuro.test/', runScripts: 'dangerously', pretendToBeVisual: true
});
const { window } = dom;
window.matchMedia = window.matchMedia || (() => ({ matches: false, addEventListener() {}, removeEventListener() {} }));
const accountState = { signedIn: false, connections: {} };
window.KuroNative = { account: (id) => setTimeout(() => window.__nativeResult && window.__nativeResult(id), 0) };
window.fetch = async () => ({ ok: true, status: 200, json: async () => accountState, text: async () => JSON.stringify(accountState) });

const errors = [];
window.addEventListener('error', e => errors.push(String(e.message)));
for (const tag of html.matchAll(/<script src="([^"]+)"><\/script>/g)) {
  const file = path.join(root, tag[1]);
  if (!fs.existsSync(file)) { errors.push('missing ' + tag[1]); continue; }
  const el = window.document.createElement('script');
  el.textContent = fs.readFileSync(file, 'utf8');
  window.document.head.appendChild(el);
}

const problems = [];
(async () => {
  await new Promise(r => setTimeout(r, 60));

  // --- hero deck through the unified entry point -------------------------------
  window.nav('home');
  await new Promise(r => setTimeout(r, 60));
  window.unifiedSpotlight([
    { url: 'https://kuro.test/a', source: 'zenkai', title: 'Frieren', meta: 'TV · 28 eps' },
    { url: 'https://kuro.test/b', source: 'wixi', title: 'Dandadan', meta: 'TV · 12 eps' }
  ]);
  if (window.document.querySelectorAll('.hero-slide').length !== 2) problems.push('unified hero has no deck');
  if (window.document.querySelectorAll('.hero-dot581').length !== 2) problems.push('unified hero has no dots');
  if (window.document.querySelectorAll('[data-hero-open]').length !== 2) problems.push('unified hero has no Watch pills');
  window.unifiedSpotlight({ url: 'https://kuro.test/a', source: 'zenkai', title: 'Frieren', meta: 'TV · 28 eps' });
  if (window.document.querySelectorAll('.hero-slide').length !== 2) problems.push('deck duplicated an existing title');

  // --- NEW chip on the freshly-added shelf ------------------------------------
  const shelf = window.document.getElementById('home-new');
  if (shelf) {
    window.unifiedCards([{ url: 'https://kuro.test/c', title: 'New Show', meta: 'TV' }], true);
    const html2 = window.unifiedCards([{ url: 'https://kuro.test/c', title: 'New Show', meta: 'TV' }], true);
    if (!html2.includes('poster-new581')) problems.push('NEW chip missing from the new shelf');
  }

  // --- filter chips over loaded browse results -------------------------------
  window.nav('search');
  await new Promise(r => setTimeout(r, 80));
  const chipsRoot = window.document.getElementById('filters581');
  if (!chipsRoot) {
    problems.push('no filter chip container on the browse page');
  } else {
    // A stand-in pager with mixed formats and years, exactly like the real state.
    const items = [
      { url: 'u1', title: 'Alpha', meta: 'TV · 24 eps · 2025' },
      { url: 'u2', title: 'Beta', meta: 'Movie · 2024' },
      { url: 'u3', title: 'Gamma', meta: 'TV · 2026' },
      { url: 'u4', title: 'Delta', meta: 'No metadata' }
    ];
    const grid = window.document.createElement('div');
    const fake = { state: { items }, grid, renderCard: (x, i) => `<button data-card="${i}">${x.title}</button>`, shown: items.length };
    window.attachFilters581(fake);
    if (!window.document.querySelector('[data-chip-format="TV"]')) problems.push('no TV format chip');
    if (!window.document.querySelector('[data-chip-format="MOVIE"]')) problems.push('no MOVIE format chip');
    if (!window.document.querySelector('[data-chip-year="2025"]')) problems.push('no 2025 year chip');

    window.eval('chips581.format="TV"');
    if (!window.chipMatch581({ title: 'x', meta: 'TV · 2025' })) problems.push('TV filter rejects a TV title');
    if (window.chipMatch581({ title: 'x', meta: 'Movie · 2024' })) problems.push('TV filter accepts a movie');
    window.eval('chips581.format="TV";chips581.year="2026"');
    if (!window.chipMatch581({ title: 'x', meta: 'TV · 2026' })) problems.push('combined filter rejects a match');
    if (window.chipMatch581({ title: 'x', meta: 'TV · 2025' })) problems.push('combined filter accepts a wrong year');
    window.eval('chips581.format="";chips581.year=""');

    // The pager renderer must respect the filter hook.
    const pager = { state: { items: items.map(x => ({ ...x, url: x.url })) }, grid: grid, shown: 0,
      renderCard: (x, i) => `<button data-card="${i}">${x.title}</button>`, skip: 0 };
    window.eval('chips581.format="TV";chips581.year=""');
    window.attachFilters581(pager);
    // renderPagerCards needs a live pager; drive the same predicate it uses.
    const kept = pager.state.items.filter(pager.itemFilter);
    if (kept.length !== 2) problems.push('filter hook kept ' + kept.length + ' of 2 TV titles');
  }

  if (window.__bootErrors) errors.push(...window.__bootErrors);
  console.log('boot errors:', errors.length ? errors : 'none');
  console.log('unified problems:', problems.length ? problems : 'none');
  dom.window.close();
  process.exit(errors.length || problems.length ? 1 : 0);
})().catch(e => { console.error('harness failed:', e); process.exit(2); });

'use strict';
// Frame script exercised against synthetic video/bridge fixtures. No live player.
const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path');
const code=fs.readFileSync(path.join(__dirname,'../assets/presence-frame565.js'),'utf8');
function fixture(){
 const sent=[],events={},windowEvents={},intervals=new Map(),timeouts=new Map();let next=1,queries=0;
 const video={duration:1200,currentTime:300,playbackRate:1,paused:false,ended:false,readyState:4,getBoundingClientRect(){return {width:320,height:180}}};
 const bridge={postMessage:x=>sent.push(x)},window={KuroPresenceFrame565:bridge,__kuroPresenceAttempt565:17,addEventListener:(n,f)=>windowEvents[n]=f};
 const document={readyState:'complete',videos:[video],querySelectorAll(q){assert.equal(q,'video');queries++;return this.videos},addEventListener(n,f){events[n]=f}};
 const context={window,document,Number,Array,JSON,getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'}),
  setInterval:f=>{let id=next++;intervals.set(id,f);return id},clearInterval:id=>intervals.delete(id),setTimeout:f=>{let id=next++;timeouts.set(id,f);return id},clearTimeout:id=>timeouts.delete(id)};
 vm.runInNewContext(code,context);return {video,bridge,window,document,sent,events,windowEvents,intervals,timeouts,get queries(){return queries},flush(){let work=[...timeouts.values()];timeouts.clear();for(let f of work)f()},tick(){for(const f of [...intervals.values()])f()},last(){return JSON.parse(sent.at(-1))}};
}
let x=fixture();assert.deepEqual(x.sent,['ready:17']);assert.equal(x.queries,0,'no video query while presence is off');
x.bridge.onmessage({data:'on'});assert.equal(x.queries,1);assert.deepEqual(x.last(),{kind:'sample',attempt:17,state:'playing',position:300000,duration:1200000,rate:1});
x.video.currentTime=480;x.video.playbackRate=1.5;x.events.seeked();x.events.ratechange();assert.equal(x.timeouts.size,1,'bursts coalesce');x.flush();assert.equal(x.last().position,480000);assert.equal(x.last().rate,1.5);
x.video.paused=true;x.events.pause();x.flush();assert.equal(x.last().state,'paused');
x.video.paused=false;x.video.readyState=4;x.events.waiting();x.flush();assert.equal(x.last().state,'buffering');x.events.playing();x.flush();assert.equal(x.last().state,'playing');
x.video.ended=true;x.events.ended();x.flush();assert.equal(x.last().state,'ended');
x.video.ended=false;x.video.readyState=4;x.video.duration=20;x.tick();assert.equal(x.last().state,'selected','short clips do not produce timestamps');
x.video.duration=1200;x.document.videos=[x.video,{...x.video}];x.tick();assert.equal(x.last().state,'selected','ambiguous players do not produce timestamps');
x.document.videos=[x.video];x.video.getBoundingClientRect=()=>({width:0,height:0});x.tick();assert.equal(x.last().state,'selected','hidden player ignored');
x.bridge.onmessage({data:'off'});let queries=x.queries,count=x.sent.length;x.events.playing();x.flush();x.tick();assert.equal(x.queries,queries,'no scanning while off');assert.equal(x.sent.length,count);assert.equal(x.intervals.size,0);
x.windowEvents.pagehide();assert.equal(x.sent.at(-1),'bye:17');
for(const raw of x.sent.filter(v=>v.startsWith('{'))){let p=JSON.parse(raw);assert(!('url' in p)&&!('cookie' in p)&&!('title' in p),'no raw URL, credential or media metadata');}
console.log('PASS frame-local opt-in, real progress, seek/rate/pause, ambiguity, hidden/short video, and off-state fixtures');

Kuro.tv 5.73 release build

This is the 5.79-test codebase with the public Android versionName changed to 5.73. Android versionCode is 80, higher than the previous test build's 79, to allow an in-place update with the same signing key. Future Android releases must use a versionCode greater than 80; public version names can continue from 5.73 independently.

Discord activity episode names use quotation marks. Anime Village and the other three newly requested video sources remain experimental episode fallbacks, not full catalogues; playback and subtitles have not been verified on an Android device. No physical device installation or Discord UI test was performed during this build. Offline presence tests and release signature checks were performed separately.

The app's GitHub updater compares visible version names and parses test suffixes differently from normal release tags. Automatic update behavior from test builds is not verified. Manually installing the signed 5.73 APK may be required. Never uninstall without backing up local data.

Signing materials and the separately supplied Discord SDK are not included in the source archives.

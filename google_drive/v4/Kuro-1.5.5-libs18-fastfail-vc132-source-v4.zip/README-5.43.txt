HISTORICAL NOTES: For current behavior and setup see README-5.46.txt.

KURO.TV 5.43 — DIRECT ANDROID GOOGLE SIGN-IN

What changed
- The Google button uses Android Credential Manager and Google Play services,
  not the old Supabase browser redirect. The public Google Web client ID from
  the owner's existing Kuro Cloud project is prefilled and can be edited in
  Account setup. No Google client secret is stored or requested in this app.
- The app verifies the ID token using Google's fixed HTTPS public signing-key
  endpoint, RSA signature, issuer, Web-client audience, expiration, issue time
  and a fresh single-use nonce. Only a locally verified identity is saved in
  Android Keystore-protected storage; the ID token is not retained.
- This is an on-device identity link, NOT a cloud account, sync, or a backend
  session. Local storage can be modified on a compromised device. Any future
  server must independently validate tokens on that server. Google account
  state is checked at sign-in, not continuously afterward.
- Email/password still uses the existing Supabase setup; Discord, MAL, AniList,
  local profile, Watch, news, bookmarks and one-way imports remain separate.
  The old Supabase Google callback is retained for an already pending flow.

Admin's one-time Google setup
- In the same Google Cloud project as the Web client, create an Android OAuth
  client for package app.lovelycrxshx.kuro with the release signing SHA-1
  E6:E9:D7:32:EB:52:E0:25:5B:88:05:68:D3:8D:53:FC:F5:9A:91:E8.
- If the Google audience is Testing, add the test Google account first. Google
  Play services and internet are needed. Existing Web redirect URIs can stay.
  Do not put Google client secrets in Kuro, the APK, source, or chat.
- Google controls the text shown in its consent UI; exact Kuro.tv branding is
  not guaranteed. Brand review can require a verified domain and public site.
  An app signed with a different key has a different fingerprint.

Build and tests
- JDK 17+, Android SDK platform 35/build tools 35.0.1, internet on first build.
  The Gradle wrapper resolves AGP, AndroidX and Google's official libraries.
  Set ANDROID_HOME, JAVA_HOME, KEYSTORE, KS_PASS and optional OUT. Run build.sh.
  Keep the update signing key and password private, outside this source tree.
- Run tests/native-panel/run.sh, npm ci / Playwright Chromium and the browser,
  shell/Java and Python scripts under tests. These are mock/synthetic tests,
  NOT actual phone login, playback, notifications, codecs or performance.
- A release APK was signed with the same certificate as the 5.42 Kuro build.
  Android may install it over the matching 5.42 package without uninstalling;
  real installation and account sign-in on a handset have not been verified.

Kuro.tv retains third-party attributions and previous 5.42 documentation.

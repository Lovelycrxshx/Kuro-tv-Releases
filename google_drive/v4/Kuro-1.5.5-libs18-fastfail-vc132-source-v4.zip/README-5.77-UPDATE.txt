Kuro 5.77-test — partial playback and notification improvements

A restricted fallback library no longer stops other fallback searches. A human-verification response is still remembered and no bypass is attempted. If no servers can be found and a fallback requested verification, the existing verification message is shown. This is a code-level change, not proof of playback on a device.

For a single new article, the notification adds a Read article action to an HTTPS URL from an existing publisher allowlist. It opens the external article via the Android handler. If a safe image URL is available, the app attempts to download at most 1.5 MB from an approved image host without redirects, using short network timeouts and downsampling before using it as the large icon; otherwise the bundled icon remains. This contacts the image host in the background. Grouped notifications keep their headline list and Open news action. Appearance varies with Android.

Anime Village is not integrated; its direct HLS media, headers and subtitles require safe player integration. AniWaves.tv, Anikoto.cz and Gogoanimes.cv remain experimental exact-episode fallback adapters, not full catalogues. Their playback has not been verified. No physical-device installation or notification test was performed.

Signing key/password and the separately supplied Discord SDK are excluded from source archives.

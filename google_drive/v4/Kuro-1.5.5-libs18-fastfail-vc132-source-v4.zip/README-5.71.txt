KURO.TV 5.71 — PROFILE ARTWORK AND LOCAL CONTROLS
Package app.lovelycrxshx.kuro, version 5.71 / versionCode 71, Android 8+.

Install only the original-key-signed APK over your existing Kuro installation.
Do not uninstall the app or clear its data. The signing certificate is checked
before release, but update installation and data retention still need a real
phone test. Consider exporting a local backup first; backup files are unencrypted.

PROFILE ARTWORK
The six supplied sheets were cropped into 160 profile-picture and 160 banner
choices. Choose PFP, Banner, Anime, or History independently. Tapping an image
changes the temporary preview only; Apply saves it and Cancel discards it. The
old image choices and gallery-upload controls are no longer presented. Gallery
files are not deleted. Previously selected Anime and History backgrounds are
retained until replaced. The currently saved profile PFP and banner are cleared
once during migration as requested; the name, other profile fields, lists,
accounts and unrelated data are retained. If no profile exists, the migration
does not create a blank one, so a backup profile can still be imported.
The choices remain limited by the quality of the user-supplied sheets.

LIBRARY AND PRIVACY
Search loaded episodes by number or name; at most 150 rows are initially built
and more can be shown without making a new search request. Add an identified
episode to the local watch queue, reorder or remove entries, and open it again.
Kuro stops if the saved source/series/episode cannot be verified uniquely. Queue
Play can start an available server; automatic queue advancement is not included.
For each series, choose detected audio preference and a preferred named server.
If unavailable, Kuro falls back; player-controlled audio, speed and subtitles can
differ. Queue and per-series choices are included in conservative local backups.

Settings includes a privacy/storage panel, a non-publishing illustrative Discord
Presence preview, and individually confirmed deletion of selected local values.
The displayed sizes estimate those WebView values only, not all app or device
storage. Clearing one selected value does not clear other values, gallery files,
backup files, accounts, cookies, downloads or remote tracker data. The preview
makes no network request and does not publish; Discord may render actual activity
differently. No Watch or Download buttons are sent in Discord Presence.

SUPPORTED NATIVE PLAYBACK ONLY
On Kuro's direct native player, a local subtitle appearance selector applies to
selectable native subtitles, not embedded sites, burned-in captions or protected
surfaces. This new native-only style preference is not included in local backups.
Native picture-in-picture provides a session-checked Play/Pause action; embedded
players may have no working PiP controls. Both features need real-device testing.

The diagnostics label now reports the correct release and describes available
device storage as approximate. Reduced-motion and keyboard focus handling are
provided for the new dialogs. These are targeted improvements, not a guarantee
of accessibility on every Android device or faster playback.

NOT INCLUDED / UNVERIFIED
Metadata-dependent episode reminders and automatic queue advancement are not
implemented in this release; no airing time is invented. Audio/server overrides
are limited to Kuro's detected server list, and do not force speed or tracks in
third-party players. Live provider availability, actual Discord display, physical
PiP/subtitle behavior, and in-place installation/data retention are unverified.
Continue to stop at third-party verification or rate limiting.

The existing anime-cover-only Discord Presence, accounts, provider setup,
Advanced video and best-effort enhancement remain subject to their previous
limitations. The signing key, password and separately licensed Discord SDK AAR
are not included in either source archive. See README-5.70.txt, README-5.69.txt
and README-5.63.txt for prior changes, SDK prerequisites and third-party notices.

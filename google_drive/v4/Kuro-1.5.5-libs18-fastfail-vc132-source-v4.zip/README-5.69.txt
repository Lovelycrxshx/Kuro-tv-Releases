KURO.TV 5.69 — DISCORD SHORTCUTS AND FULLSCREEN VIDEO
Package app.lovelycrxshx.kuro, version 5.69 / versionCode 69, Android 8+.

INSTALL AS AN UPDATE
Install the original-key-signed APK over the existing Kuro installation. Do not
uninstall Kuro or clear its storage. The update is designed to retain Kuro's
local profile, lists, watch history, provider IDs, preferences and encrypted
sessions; installation and data retention still need testing on a real phone.

DISCORD RICH PRESENCE
- Open the profile drawer and choose Discord Rich Presence or Presence
  customization directly. Both remain available in Settings, and all copies
  use the same settings. When signed out of Kuro, both shortcuts are also on
  the Log in sheet; a Kuro account is not needed to use them.
- The Discord action bridge now dispatches to the Android action rather than
  repeatedly posting itself. Clear turns sharing off and requests removal from
  both accounts. Reconnect current, reconnect linked, link and unlink provide
  their normal feedback or confirmation. Unlinking removes the local linked
  authorization; revoke it in Discord's Authorized Apps to revoke it online.
- To reconnect or send a test, first turn Share activity on. Enable the
  relevant account target in Presence customization. Link the other account
  before reconnecting it. Open Connection status for SDK feedback; an SDK
  acceptance does not guarantee the activity is visible in Discord.
- A linked-account flow also requires Discord's Public Client and registered
  mobile redirect to be correctly configured. The installed, signed-in Discord
  app supplies the current-account target. Live linking and simultaneous
  visibility were not verified on a physical phone.
- Kuro attempts updates every three seconds while eligible; Discord can delay,
  throttle or cache them. No Watch or Download activity buttons or video-frame
  artwork are sent. Neutral artwork lookup privacy remains as in 5.67.

VIDEO ENHANCEMENT AND FULLSCREEN
- Advanced remains on the Watch page, outside fullscreen. Adjust and enable the
  optional effects there. No Advanced settings panel or enhancement gear is
  displayed over fullscreen video. A temporary exit button appears; Android
  Back also returns to the Watch page.
- When enhancement is enabled and the video may be renderable, a player
  fullscreen request uses Kuro's enlarged existing WebView rather than the
  separate video-only Android view. This preserves the WebGL overlay and player
  session where the site's layout allows it. The existing Enhanced fullscreen
  button is also available. Site fullscreen and Android implementations vary;
  real provider/device behavior still needs testing.
- The overlay follows the actual accessible video on resize and when its site
  moves it to another container. It does not intercept input. Some controls may
  briefly show the original video so the player's own controls remain usable.
- Readable, unprotected video can use the real WebGL sharpening, color and
  optional on-device AI pipeline. For some cross-origin videos whose frames
  cannot be read, a browser CSS color-only fallback may work without reading
  pixels. This is explicitly labeled Color only; sharpening, denoising and AI
  are unavailable there. Comparison and disabling restore the site's filter.
- No approach can guarantee these pixel effects on every player: opaque embeds,
  protected/DRM video, unsupported GPUs, external Cast and separate native
  surfaces can remain unchanged. Known protected video is not sampled or
  styled. A player reporting unavailable falls back to its normal fullscreen.
  The native direct player still offers a switch to Web for these effects;
  Cast/remote output and volume boost have their own limitations. No DRM,
  access-control or verification bypass is included.

The owner-verified setup, public provider defaults, SDK licensing and original
signing instructions from 5.68 remain. See README-5.68.txt and earlier notes.
The signing key, password and separately licensed Discord SDK AAR are not in the
source backup; never package them or request user secrets.

KURO.TV 5.52 — ACCOUNT BUTTON ALIGNMENT

Package app.lovelycrxshx.kuro; version code 52; Android 8.0 or newer.
This is a visual update to 5.51: Discord, MyAnimeList and AniList sign-in
buttons now have three equal-width, centered columns, including narrow screens.
The provider login flows, local account, profile, lists and history are unchanged.
This release does not add automatic MAL/AniList progress synchronization.

Email/password remains local to this phone only. Email is not verified, no OTP
is sent, and there is no password reset or recovery. The local password does not
lock or encrypt the separate profile, lists or watch history. Google sign-in,
Drive backup and Supabase are not in the active app; existing online accounts,
projects and backups are not modified and cannot be accessed through this app.

To update, install the signed APK over the existing Kuro app; never uninstall
or clear data. The same package and original signing identity are used, but real
phone installation and live Discord, MAL and AniList login were not tested.
Discord login still requires the public-client setting and the exact redirect
app.lovelycrxshx.kuro://oauth/discord configured in the Discord developer portal.
The app asks for no Discord client secret. See README-5.51.txt for account and
security details. The 73-character gallery remains unchanged: Monster Musume and
the ambiguous magician title are still missing; artwork rights are unverified.

Build from matching source with JDK 17+, Android SDK platform 35 and build-tools
35.0.1. The original private signing key is separately held and not bundled.

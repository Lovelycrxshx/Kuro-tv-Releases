KURO.TV 5.70 — ANIME COVER IN DISCORD RICH PRESENCE
Package app.lovelycrxshx.kuro, version 5.70 / versionCode 70, Android 8+.

Install the original-key-signed APK over your existing Kuro installation.
Do not uninstall Kuro or clear its storage. Local data retention is intended,
but installation and data retention still need testing on a real phone.

Discord Rich Presence now uses an anime poster/cover, never an episode image.
The episode number, name, language and progress remain subject to your existing
Presence customization choices. Anime poster and App icon choices remain; if
the title is hidden, the identifying cover is hidden too.

When a safe anime cover is already available it is used immediately. Otherwise,
with Presence, title and artwork sharing enabled, Kuro may send the anime title
(but not the episode number, source address, cookies or credentials) to AniList
and, if needed, Kitsu to seek a unique exact title/alias match. Only recognized
anime-poster image paths on neutral metadata hosts can be sent to Discord.
Kuro no longer requests episode thumbnails for Rich Presence. If no safe unique
cover is available, Kuro sends no artwork and Discord may use the registered
app icon. Metadata availability, matching and Discord rendering can vary; a
real account and physical phone are still needed to verify the displayed image.

Both current and linked account targets use the same activity. No Discord Watch
or Download buttons are sent. The three-second update attempts, previous
fullscreen improvements, provider settings, saved preferences, and limitations
from 5.69 remain. See README-5.69.txt and earlier notes for details.

The signing key, password and separately licensed Discord SDK AAR are not in the
source backup. Never package signing credentials or ask users to disclose them.

KURO.TV 5.59 — STRONGER VIDEO ENHANCEMENT

WHAT CHANGED
The opt-in video renderer has been retuned so the six A/B/C combination modes
have distinct sharpening, smoothing and color/contrast settings. Darken Lines
darkens detectable dark outlines; Thin Lines lightens/reduces dark outlines;
Off does neither. Sharpen, denoise, edge preservation, saturation, contrast,
brightness, line strength and fine dither affect the actual processed frame.
Their effect depends on the content: e.g. denoising a perfectly flat image or a
line control when no lines are present will not create an artificial change.
The 8/16/32 detail buttons are performance presets using 5/9/13 image taps (including the center),
not literal 8x8/16x16/32x32 convolution kernels. Higher tiers use more GPU.

AI DETAIL
AI remains opt-in. When the pretrained small Anime4K CNN actually runs, its
learned residual is blended into the image. This version also applies a
conventional vivid-color/contrast and clarity finish, scaled by AI strength.
It is deliberately much stronger than before and can oversharpen or clip some
sources; lower AI strength if the look is excessive. The finish is NOT applied
as AI when the network is unavailable. At 0% strength AI is paused/neutral.
The model operates locally and is not Topaz or a full official Anime4K pipeline.
It uses up to 480x270 CNN input, adapting to lower inference resolutions on a
slow GPU before pausing AI to protect playback. It is not 4K AI reconstruction.
The original MIT license and source attribution are in assets and libs.

HOW TO SEE IT
1. Open a video in Watch, then Advanced > Video enhancement.
2. Enable enhancement and AI detail; try strength 100% and a mode such as A+A.
3. Tap Show original / Show enhanced to compare the same video without changing
   saved preferences. The status reports active, preparing, paused or unavailable.
4. For a larger picture with supported effects, use Enhanced fullscreen on the
   Watch page. It expands the existing WebView rather than replacing/reloading
   it. The fullscreen toolbar has Advanced and Exit controls; Android Back also
   exits. Rotate your phone as usual.

Normal fullscreen initiated by a third-party player can open Android's separate
video-only view, where WebView effects are paused. The app leaves that site
fullscreen behavior intact and tells you to use Enhanced fullscreen instead.
Some nested frames on known HTTPS player origins can now run the renderer in
that frame, if supported by AndroidX WebView. This does not change CORS, DRM,
verification or access: inaccessible, blocked or protected pixels stay original.
Browser-readable showing WebVTT text tracks are mirrored above the canvas;
site-drawn captions/controls keep their own stacking where possible. Some
protected, proprietary or inaccessible subtitle tracks may not be observable.
Tapping the original video temporarily reveals native player controls.

PERFORMANCE / LIMITATIONS
Effects may use more GPU, battery and heat; the adaptive safety fallback can
reduce AI resolution or pause it. Video and audio remain available when AI
cannot run. The synthetic tests cannot establish quality or speed on an actual
phone or live stream. Some streams, embeds, codecs, GPU drivers, page overlays,
subtitles and players can still be unsupported or change independently. A
more dramatic look is not proof of recovered detail and cannot guarantee visual
improvement on every scene. The footage remains local to the player's permitted
browser context; no frame upload, verification bypass or peer-to-peer was added.

DATA AND UPDATE
Package app.lovelycrxshx.kuro, version 5.59 / code 59; Android 8.0+. Install the
APK as an update over the existing app, using the original signer. Do not
uninstall, clear data, or reimport. If Android reports a signature/version
conflict, stop and keep the installed app and its data. Existing lists, imports,
accounts, history, providers and safety settings are not intentionally reset.
Google sign-in, Drive backup and Supabase remain removed; external backups are
untouched. The 5.56 base was reconstructed from 5.53, not a byte-identical
recovery of the lost 5.55 source or APK. Hayase handoffs remain removed; no
accessible direct Hayase source was verified or added, and no torrent is used.

BUILD / SOURCE BACKUP
Use JDK 17+, Android SDK platform 35 and build-tools 35.0.1. Dependencies can
require a first-run download. Set JAVA_HOME, ANDROID_HOME, KEYSTORE and KS_PASS
privately, then run ./build.sh. The original signing key is required for an
update-compatible APK; it and its password are stored separately, not in this
source or release. The text backup contains readable text and base64 binary
files with per-file SHA-256. Restore it to a NEW directory from the source ZIP:
  python3 scripts/restore-source-text.py /path/Kuro-tv-5.59-Source.txt NEW_DIR

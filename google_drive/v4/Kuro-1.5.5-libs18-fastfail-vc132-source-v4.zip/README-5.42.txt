HISTORICAL NOTES: For current behavior and setup see README-5.46.txt.

HISTORICAL 5.42 NOTES. For the current build see README-5.44.txt.
5.43 includes an editable, prefilled public Google Web client ID; it is not a secret.

Kuro.tv 5.42 — account/profile update
Package: app.lovelycrxshx.kuro. Version code 42. Android 8.0 or newer.

This update adds user-configured Supabase email/password and Google, Discord,
MyAnimeList and AniList sign-ins; local editable profile; and explicit read-only
MAL/AniList anime-list snapshots. Provider accounts are not created or configured
by this source. See Kuro-tv-5.42-Setup-Guide.txt in the release for phone steps.

Source layout:
  assets/accounts542.js and accounts542.css — local account/profile/import UI.
  src/app/lovelycrxshx/kuro/AccountOAuth.java — public client URL/PKCE rules.
  AccountVault.java — Android Keystore AES-GCM encrypted local sessions.
  AccountHttp.java and KuroAccounts.java — bounded provider requests/imports.
  MainActivity.java and AndroidManifest.xml — browser callbacks and image picker.
  tests/test-accounts542.cjs and tests/native-panel/.../Account*542Test.java —
  mocked browser and fake-provider tests; no real credentials or phone.

Build:
  Android platform 35 android.jar, build tools 35.0.1, Java 11+, unzip/zip.
  Set TOOLS, SDK and JAVA_HOME as needed; set KEYSTORE and KS_PASS securely to
  an authorized update-compatible signing identity, then run ./build.sh.
  No signing key, password, provider secret, account token or real provider IDs are in
  this source package. Signing with any other identity will not update 5.41.

The original 5.41 README and bundled notices are retained; this file takes
precedence for account behavior. Tests are synthetic and do not certify live
provider sign-in, Android Keystore hardware or phone playback.

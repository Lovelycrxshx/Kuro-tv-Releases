KURO.TV 5.46 — CONFIRMED GOOGLE-ACCOUNT BACKUP COPY

IMPORTANT: Tests use simulated accounts, Drive transport, Android shadows and
browser storage. No physical phone, live Google permission, Drive upload or
restore was tested. An existing 5.45 ownership setting does not prove that a
backup ever succeeded. The original owner's email may not be known.

What changed
- When the signed-in Google subject differs from this phone's backup owner,
  Account displays "Copy phone data to this account". Switching alone never
  copies data, authorizes Drive, merges or uploads. The user sees the verified
  target name/email when available and must explicitly confirm first.
- The confirmation is bound to a short-lived, one-use native ticket for the
  exact displayed subject and prior owner. After consent, the app verifies the
  Drive token's userinfo subject against that target before reading or writing.
  Credentials stay native; no Google access token is sent to the WebView.
- Kuro reads the NEW account's latest snapshot, if any; it doesn't use the old
  account's token or delete that account's backup. It then atomically sets the
  new owner and a pending mode in one encrypted vault commit, journal-merges,
  records the local revision, and only then enables automatic uploads. If the
  setup is interrupted after the pending commit, automatic upload remains off;
  sign in to the target account and choose Finish backup setup to resume.
- Matching local entries win. Explicitly empty local arrays stay empty; other
  cloud-only entries may reappear. Local and old-account data are not cleared.
  The app restores only the newest snapshot, not a selectable history. The
  confirmed action changes which account backs up THIS phone going forward.
- 5.45's global last-success time is migrated to its prior owner. Per-account
  status is now separate, and a copy target's success time is reset until a
  new upload succeeds on this phone. The old Drive files are unaffected.
- HTTP 403 messages distinguish account-verification refusal and some known
  Drive API/scope/quota reasons without exposing raw Google error bodies. A
  generic 403 still has several possible causes; the app cannot fix the Google
  Cloud project or guarantee that consent succeeds.

Backup scope and privacy
- Backed up: Kuro bookmarks/custom-status lists, recent titles, watched marks,
  last opened episode and episode history. Precise playback positions are not
  tracked. The private backup is stored in the selected Google account's hidden
  Drive appDataFolder, not a public folder; Kuro adds no end-to-end encryption.
- Excluded: local Kuro username/photo/banner, MAL/AniList import snapshots,
  provider sessions, passwords, Google credentials, stream URLs, APK and source.
- Uses openid + https://www.googleapis.com/auth/drive.appdata. Sign-in and
  Drive consent are separate. Drive permissions may be shown or reused by
  Google. There is no Kuro backend or embedded client secret.
- Upload/retry happens while Kuro is open and online; this is not live,
  conflict-free multi-device sync. The latest three confirmed snapshots from
  this installation are kept when possible; cleanup failure can leave more.
  Other installations' snapshots are not pruned. Turning off backup keeps
  existing cloud/local data; Google authorization revocation is separate.
- A fresh installation with no local Kuro data can restore a previously
  successful snapshot silently if Google already grants access. Otherwise the
  user must opt in. A successful old backup is required to restore after loss.

Implementation and tests
- KuroAccounts.java: legacy state migration, atomic encrypted owner/mode,
  verified native identity and protected session storage.
- BackupCoordinator545.java: opaque copy ticket, account/epoch guards,
  Drive authorization, pending activation and owner-specific status.
- DriveBackup545.java / BackupCodec545.java: bounded HTTPS, reason-safe 403,
  account subject check, immutable snapshots, payload whitelist and retention.
- assets/cloud545.js / accounts542.js: explicit confirmation, local-wins
  journaled merge, pending recovery, app-open scheduling and visible status.
- BackupCopy546Test and existing native/browser regressions use only fakes;
  there is no evidence of live Google, Android Keystore, or phone success.

Build: JDK 17+, Android SDK platform 35 and build-tools 35.0.1. Set
ANDROID_HOME, JAVA_HOME, KEYSTORE and KS_PASS, then run ./build.sh. A matching
original private signer is required for install-over updates. Signing material
is separate, private and not part of this source. Update over the existing app;
never uninstall or clear data. Stop and report the installer error if rejected.
No 5.46 release, source, log or signing material was uploaded by this build.

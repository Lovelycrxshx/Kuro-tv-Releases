KURO.TV 5.58 — COMPACT LIBRARY AND REMOVED APP HANDOFFS

WHAT CHANGED
The library's nine filters keep four per row in this order:
  All · Watching · Completed · On hold
  Dropped · Planned to watch · Imported · Bookmark
  History
All remains the default. Their purple/black visible surfaces are about 36 CSS
pixels tall, like compact server controls, while each touch area remains at
least 48 CSS pixels high. Long labels wrap within the surface on small screens.
The synthetic browser test covers widths 280–768 CSS px; an Android WebView on
a real phone or modified text-size setting may differ.

The links that opened or promoted the separate Hayase app were removed from
Browse, title details, the Watch page, and the Android JavaScript bridge. This
is not a Hayase video-source integration. Existing Kuro providers and the
current player/failover system are otherwise retained.

SOURCE FINDINGS AND SCOPE
The user selected direct streaming only, without torrent connections. Hayase's
own documentation says it is bring-your-own-content and ships without content
sources. Common Hayase extension catalogues return torrent metadata, not direct
playable HTTP video. Its HTTP/WebSeed API uses torrent hash/file information;
a personal or third-party source must actually supply the bytes.

We checked a third-party Japan-Paw community catalogue as a possible direct
WebSeed source. Its published manifest is torrent-based, its old HTTP extension
is no longer listed, and two representative episode URLs on the two catalogue
hosts each returned HTTP 403 in the build environment. We did not bypass those
restrictions, redistribute that extension code, or add it to Kuro. No accessible
and playable compatible Hayase HTTP source was verified. Consequently no new
Hayase source, P2P engine, peer-IP exposure, or seeding was added in 5.58.
A direct source would still need exact title/season/episode matching, acceptable
access and rights, a supported codec/container, and playback testing before use.

Research references (not content sources bundled in Kuro):
  https://wiki.hayase.watch/faq
  https://wiki.hayase.watch/extensions/overview
  https://wiki.hayase.watch/extensions/development/creating-extensions
  https://github.com/anh9000/anitorrent
  https://github.com/JuanPerezC893/ExtenJap

DATA AND UPDATE
Package app.lovelycrxshx.kuro, version 5.58 / code 58; Android 8.0+.
The APK must be signed with the existing Kuro key and installed as an Android
update over the existing installation. Do not uninstall or clear data; stop if
Android reports an installation/signature conflict. No list, import, account,
profile, artwork, history or adult-safety migration is included in this change.
Adult and unclassified imports remain hidden by default. Local email remains
unverified and device-only without OTP/recovery; it does not encrypt the lists.
Google sign-in, Drive backup and Supabase remain removed, and existing external
backups are not changed. Do not share passwords, tokens or secrets in chat.

The base was reconstructed in 5.56 from the 5.53 backup; it is not a byte-for-
byte recovery of the lost 5.55 source or APK. Tests use mock providers and
synthetic browser/Android environments. They do not establish real-phone
installation, live source playback, codecs, rotation, notifications, GPU
performance or battery use.

BUILD / SOURCE BACKUP
Use JDK 17+, Android SDK platform 35 and build-tools 35.0.1. Gradle dependencies
may require a first-run download. Set JAVA_HOME, ANDROID_HOME, KEYSTORE and
KS_PASS privately, then run ./build.sh. The original signing key is required
for an update-compatible APK; the key and password are stored separately and
are not included in the source or release bundle. The text backup contains
UTF-8 text and base64 binary files with per-file SHA-256. From the source ZIP,
restore it into a NEW directory:
  python3 scripts/restore-source-text.py /path/Kuro-tv-5.58-Source.txt NEW_DIR

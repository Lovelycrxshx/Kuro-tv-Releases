KURO.TV 5.68 — OWNER-VERIFIED PROVIDER SETUP
Package app.lovelycrxshx.kuro, version 5.68 / versionCode 68, Android 8+.

INSTALL AS AN UPDATE
Install the original-key-signed APK over your existing Kuro installation. Do
not uninstall Kuro or clear its storage. Existing accounts, saved provider IDs,
lists, watch history, preferences and encrypted provider sessions are retained.

OWNER-ONLY ACCOUNT SETUP
1. Open the Profile drawer and press and hold the Kuro.tv brand for about
   1.6 seconds. If signed out, open Log in and hold the Welcome back heading.
2. Choose Verify with GitHub. Copy the one-time code, open the official GitHub
   page, enter the code there, and approve the Kuro.tv Admin authorization
   while signed in as ImAuraxSiva. Check the site and only approve a request
   you personally started in Kuro. Return to the app.
3. GitHub's authenticated user ID must match the owner's immutable ID. Kuro
   opens provider setup for up to ten minutes. Back, closing the dialog, expiry
   or destruction of the Android activity invalidates that session. If Android
   destroys Kuro while the browser is open, start verification again.
4. Editing a provider's public ID disconnects that specific provider on this
   phone, because its existing session belongs to a different app ID. Leaving
   IDs unchanged preserves the sessions. Bookmarks, imports and history are not
   deleted. Existing nonempty saved IDs are not replaced by defaults.

The normal account screens contain no setup link. Hidden access is not itself
security: the Android configure bridge checks a fresh owner-verified session.
The verification uses the public OAuth application ID and no requested GitHub
repository scope or client secret. Access and refresh tokens stay in memory only
while confirming identity, are never written to storage, logged, or returned to
the WebView, and are discarded; the code is only copied if you press Copy.
GitHub, as the identity provider, sees the authorization. Never send a code,
GitHub password, authorization token or OAuth client secret to anyone. Revoke
an unfamiliar authorization in GitHub settings. The app does not provide the
assistant or Kuro with repository-management access.

This is an on-device gate, not a server-enforced security boundary: anyone who
modifies/re-signs the APK or controls the device could bypass a local lock. A
person who can approve requests in the owner's already signed-in GitHub browser
can also authorize it. Account setup is not a substitute for Android device or
GitHub account security. A real GitHub
owner authorization and installation on a physical Android phone remain to be
verified by the owner. A network outage, denial, rate limit, missing browser,
wrong account or rejected/broad GitHub authorization leaves setup locked.

RETAINED FEATURES
- Empty saved provider settings use public defaults Discord 1569077670074122250,
  MyAnimeList 37160cd5a180308c9009afb7faa4e341 and AniList 56440. These public
  identifiers are not credentials. Discord/MAL/AniList sign-ins remain optional.
- 5.67's Discord Rich Presence attempts a refresh at most every 3 seconds when
  enabled/visible. Discord can throttle or cache updates; live delivery is not
  guaranteed. No Watch/Download presence buttons or video-frame artwork are
  sent. Exact neutral episode/show artwork falls back safely; metadata lookups
  disclose title/episode to Kitsu or title to AniList as explained in settings.
- In-app watching, playback controls, local data and the purple/black settings
  choice sheets remain. See README-5.67.txt for full details and limitations.
  All earlier READMEs and TESTS files are historical, not descriptions of 5.68.

BUILD
The signing key/password and separately licensed Discord Social SDK AAR are not
in this source. See README-5.64.txt and build.sh for JDK, Android SDK 35,
build-tools 35.0.1, NDK r27c, Gradle and separately obtained Discord SDK setup.
Do not package signing material or OAuth client secrets into a build or archive.

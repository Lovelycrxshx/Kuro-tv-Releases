KURO.TV 5.64 — DISCORD RICH PRESENCE
===================================

CURRENT RELEASE / PHONE INSTALL

Install the signed Kuro-tv-5.64.apk as an update over your existing Kuro app.
Do not uninstall Kuro or clear its data. If Android reports a signature or
version conflict, stop and keep your installed app and data. Package:
app.lovelycrxshx.kuro; version 5.64/code 64; Android 8.0/API 26 or newer.
The APK is signed separately using the original Kuro release key. Source and
backup archives never contain the key or its password.

CURRENT DISCORD APP

Open the official Discord Android app and sign in. Turn on its activity
sharing. In Kuro open Settings → Discord Rich Presence → Share activity → On.
Sharing defaults to Off. Current account sharing controls the local Discord
app target. Kuro requests the activity type Watching and the name Kuro.tv;
Discord controls its final appearance and audience. Check your profile or ask
a friend to check: an SDK-success callback is not proof of visibility, and
Discord often does not show your own activity buttons to yourself.

CUSTOMIZATION AND PRIVACY

Presence customization includes anime-first/episode-first layout, dot/bar/dash
separator, title and episode visibility, poster or Discord app icon, Watch
button, available server, reported episode total, separate current/linked
sharing, pause progress or clearing after one/five minutes, buffering, optional
Download button and optional playback notification. Actions include clear,
reconnect each target, a local connection-event history, a 15-second test,
link/disconnect a second account and status with last accepted updates.

When title is hidden, Kuro also hides the anime poster and both buttons; when
episode is hidden, it hides both buttons. This conservative behavior reduces
accidental disclosure, but title, language, server, timing, public URLs and
Discord presentation may still reveal information depending on your choices.
When the poster is not sent, Discord normally uses the app icon registered for
the Discord application. Watch URLs and poster URLs are restricted to supported
hosts and reject credentials, queries, fragments, ports and escaped paths.
A Download URL is optional, user-supplied, off by default, and must be a public
HTTPS page with a simple path. Anything placed in its path can still reveal
information; never put a login, credential, token, private link or stream URL
there. Discord and its users receive whatever link you opt to publish.

Kuro samples accessible player state about every three seconds and coalesces
Discord updates at about fifteen-second intervals. Server names are taken from
Kuro's selected server chooser, and totals are shown only for supported sources
with a source-reported total; missing/derived list lengths are omitted. Native
Media3 or Kuro's validated direct-HLS player can report real playback/progress;
other cross-origin players show Selected without an invented timer. Pause
clearing and playback notification controls work only when Kuro can observe or
control the player. The notification is optional and requires Android
notification permission; play/pause is limited to supported players. It is not
a foreground playback service and cannot keep Kuro alive in the background.

LINK ANOTHER DISCORD ACCOUNT

This is separate from Kuro's Profile account connections. Open Settings → Discord
Rich Presence → Link another Discord account. A consent dialog opens Discord in
a browser. Sign in there as the desired second account, verify the account on
Discord's consent page, and approve only if you want to share. In Presence
customization enable Linked account sharing; Current account sharing can be on
or off independently. Do not enter an access token, password or client secret
into Kuro or chat. Discord's browser page handles its own sign-in.

Before linking can work, the owner of Discord application 1569077670074122250
must enable the Social SDK and Public Client in its Developer Portal and add
the exact OAuth2 redirect:
  discord-1569077670074122250:/authorize/callback
The mobile flow uses OAuth authorization code + PKCE with openid and
sdk.social_layer_presence. No client secret is embedded. A refresh credential is
encrypted using Android Keystore on this phone and is not included in Kuro's
local exports. Token refresh is serialized; stopping clears activity immediately
and can wait briefly for a rotation to finish. If secure storage or token
rotation fails, relinking may be required. Disconnect removes Kuro's local
linked credential but does not necessarily revoke it at Discord; use Discord's
Authorized Apps screen to revoke it. Current-app sharing is not deliberately
disconnected by that action. Kuro does not explicitly force Online, DND or
Invisible; Discord/SDK behavior and the user's settings control availability.

DUAL ACCOUNT LIMITATION: the implementation uses separate SDK clients, but the
Discord SDK and installed client have not been tested here on a real phone for
simultaneous publication to two different accounts. Neither two-account
visibility nor account identity switching is guaranteed. If linking or either
target fails, inspect the consent account, Public Client/redirect configuration,
Discord activity privacy and Kuro's status/history; do not share secrets.

LIFECYCLE

Closing the player returns to a browsing presence. Turning sharing off or using
Clear requests removal from both targets. Kuro requests removal approximately
12 seconds after going to the background, except while in picture-in-picture,
and reconnects on return. Android force-stop, process death, a closed Discord
client, an SDK/network failure or Discord caching can prevent timely clearing
or reconnection. This build has not been installed or tested with live Discord,
real playback, dual accounts, PiP or Android notification controls on a phone.

REBUILDING THE MATCHING SOURCE

The source ZIP and text backup contain Kuro code, resources, tests and notices.
They do not include Discord's SDK AAR, SDK header/vendor libraries, signing key
or password. The handwritten fake SDK used by host tests is a test double, not
Discord's SDK. Obtain Discord Social SDK 1.10.19337 from the Developer Portal
under the Discord SDK terms and extract its discord_partner_sdk.aar. The AAR
used for this build has SHA-256:
  b1b2491f1e1848c79fd6f1986d5aa1e0c8019e88a6e62c7be06b89e8e4870933
The original full SDK ZIP SHA-256:
  d784097504685953849cc2842561d8a8013326fe0b8df65a1de63ddefde62045

Required: Linux x86_64, JDK 17 or 21, Android SDK platform 35, build-tools
35.0.1, Android NDK r27c (27.2.12479018), Gradle 8.10.2, unzip and the
separately obtained SDK AAR. From the extracted source tree:

  export ANDROID_HOME=/path/to/android-sdk
  export ANDROID_NDK_HOME="$ANDROID_HOME/ndk/27.2.12479018"
  export KURO_DISCORD_SDK_AAR=/path/to/discord_partner_sdk.aar
  ./scripts/build-discord-jni.sh
  ./gradlew --no-daemon --max-workers=1 assembleRelease lintRelease

The bridge is built for arm64-v8a, armeabi-v7a, x86_64 and x86 with 16 KiB
ELF alignment. The unsigned APK is in build/outputs/apk/release/. To update the
installed app, sign with the original private Kuro key; never distribute it.
Source TXT can be restored to a new directory with scripts/restore-source-text.py.
Exact byte-for-byte output also depends on host tools and timestamps.

Discord's SDK notices are in Settings → Developer → Third-party notices and
assets/DISCORD-SOCIAL-SDK-NOTICES.txt. Official documentation:
https://docs.discord.com/developers/discord-social-sdk/development-guides/setting-rich-presence
https://docs.discord.com/developers/discord-social-sdk/development-guides/account-linking-on-mobile

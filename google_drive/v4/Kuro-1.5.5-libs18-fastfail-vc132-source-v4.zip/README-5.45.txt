HISTORICAL 5.45 BEHAVIOR: for the account-copy update see README-5.46.txt.

KURO.TV 5.45 — OPTIONAL GOOGLE DRIVE BACKUP

IMPORTANT: local simulations only. No actual Google login, Drive consent,
backup/restore, phone installation, or real multi-device test was performed.
Previous 5.44 account-picker cancellation on the user's phone remains unresolved;
the later-created OAuth client's type/package/fingerprint were not visible.

Behavior and privacy
- Opt-in backup of bookmarks, custom status lists, recent titles, watched marks,
  last opened episode and episode history. Not precise playback timestamps.
- Uses the authenticated user's hidden Drive appDataFolder with the narrow
  https://www.googleapis.com/auth/drive.appdata scope plus openid for subject
  verification. Google permission is separate from sign-in. No backend or
  embedded secret; Google access tokens remain in the Android native layer.
- Local profile/name/picture/banner, MAL/AniList imports, sessions, provider
  credentials and APK/source are not part of this backup. Kuro does not add
  end-to-end encryption; Drive backups contain potentially sensitive watch data.
- On first setup, the user confirms linking this phone's current Kuro data to
  the selected Google account. Native code verifies the Drive token's subject
  against the verified Google sign-in before any Drive read or write. Once the
  data has an owner, another Google account cannot silently adopt/upload it.
- A fresh installation with no Kuro data can silently restore the most recent
  snapshot after signing in if Google already granted access. Otherwise use
  Account > Turn on backup. If local Kuro data exists or was explicitly
  cleared, automatic ownership is not assumed; the user must confirm.
- The latest snapshot from all installations is restored. Matching local
  items/statuses and existing watched/last-episode records win. Cloud-only
  items can be added, so a previously removed item can reappear. This is not a
  live multi-device sync: another device's older snapshot remains in Drive but
  cannot currently be selected in the app. An interrupted restore is rolled
  back using a small local journal where storage permits.
- Uploads happen automatically while Kuro is open and online after changes;
  changes made offline are retried later. Confirmation on the Account page is
  required to know a backup succeeded. No background/scheduled upload is
  promised when the app is closed. The newest three confirmed snapshots from
  the same installation are retained; other installations are not pruned.
- Payloads over 2 MB, malformed data, unsafe URLs, mismatched accounts and
  incomplete authorization are rejected safely rather than silently uploaded.
  Stopping backup does not delete cloud or local data and does not itself
  revoke Google's authorization. Removing Kuro app data from Drive deletes its
  cloud backup. A previous successful backup is essential for later restoration.
- This version blocks account rebinding: sign in to the original Google
  account to resume this device's backup. There is no account-transfer UI.

Source files and tests
- DriveAuthorization545.java: official Play Services AuthorizationClient.
- DriveBackup545.java: bounded HTTPS/userinfo, immutable appData snapshots,
  account hash and per-installation retention. Never forwards redirects.
- BackupCoordinator545.java: account ownership, pending activation, lifecycle.
- BackupCodec545.java: strict watch-data allowlist and validation.
- assets/cloud545.js / accounts542.js: optional UI, merge, rollback, scheduling.
- Backup545Test and BackupCoordinator545Test use fake transports/accounts.
  tests/test-cloud545.cjs uses a simulated native bridge and browser storage.
  None proves a real Google token, appData access, or device behavior.

Build: JDK 17+, Android SDK platform 35 and build-tools 35.0.1. Set
ANDROID_HOME, JAVA_HOME, KEYSTORE and KS_PASS, then run ./build.sh. Only the
owner's existing authorized key can update the installed Kuro. Signing material
is separate and must never be included in source bundles. Install over Kuro;
never uninstall it or clear data to update. If installation fails, stop and
report the exact message. No 5.45 artifacts have been uploaded by this build.

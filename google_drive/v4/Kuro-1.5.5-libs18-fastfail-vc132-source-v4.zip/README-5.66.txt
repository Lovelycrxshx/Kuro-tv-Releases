KURO.TV 5.66 — DISCORD PRESENCE WITHOUT LINK BUTTONS
===================================================
Package app.lovelycrxshx.kuro, version 5.66 / versionCode 66, Android 8+.
This current release supersedes the 5.65 Watch-button description. Historical
readmes are preserved for context and do not describe current button behavior.

WHAT CHANGED
- Kuro does not create or send Discord Watch or Download buttons. Episode and
  show page identifiers are not passed from the player into the presence model.
  The Java/native boundary also sends no button URLs, and the native bridge
  ignores legacy URL arguments and creates no Discord ActivityButton.
- The old Watch control is removed from the Discord settings screen. Previously
  stored Watch and Download choices remain on-device, but cannot enable buttons.
  Kuro's in-app Watch/playback control and separate authorized-download feature
  are not removed.
- Presence can retain the real anime title, episode number/name, language,
  playback state and real progress, subject to the existing privacy options and
  observable-player limitations. The local and linked targets are unchanged.
- Discord artwork is restricted to simple HTTPS poster paths on AniList or
  MyAnimeList's known image hosts. Unsupported or provider-hosted posters are
  omitted so Discord can fall back to Kuro's registered application icon.
  Obvious source names, URL-shaped text and credentials are suppressed from
  public title/episode/server fields; this is a best-effort filter, not a proof
  that every untrusted title has no identifying text.

IMPORTANT LIMITS
This removes Kuro's Discord link buttons, not the underlying provider's network
requests. A device owner, network observer, provider, or anyone inspecting
traffic, app behavior, metadata or the source can still learn a provider's
identity. Discord can still see the anime/episode information you choose to
share. Third-party metadata services can see requests to their image hosts.
This is not source anonymization or a guarantee of confidentiality.

Discord controls rendering and may cache the old presence. A new Kuro activity
replaces the prior activity after Discord accepts it; a closed client, network
failure or cache can delay that. If another application published the visible
HiAnime activity, updating Kuro cannot modify that other application's button.
A friend can check the activity because Discord may hide buttons from the owner.

INSTALL AND CHECK
1. Install the original-key-signed 5.66 APK over the existing Kuro app. Do not
   uninstall it or clear app data; existing local lists and sign-in data stay.
2. Open Kuro, then Settings > Discord Rich Presence > Clear presence. Re-enable
   Share activity and play an episode; check the correct Discord account.
3. Have a friend confirm there are no buttons, after the new activity appears.
   Retry/reconnect if the old presence remains. Discord/SDK acceptance alone is
   not proof of visibility or timely removal.

The Discord Social SDK is not included in the matching source backup. For SDK,
Android tools, original signer, rebuild and OAuth details see README-5.64.txt;
its historical Watch/Download button descriptions are superseded by this file.
No real phone, live Discord account, player/provider or linked account was used
for verification in this environment. The automated tests use local test doubles.

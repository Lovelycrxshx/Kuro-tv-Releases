Kuro 5.75-test – experimental episode fallback sources

Three new best-effort video-server fallback adapters search AniWaves.tv, Anikoto.cz and Gogoanimes.cv for an exact title and episode already selected in Kuro. They do not add three separate catalogues; they contribute servers to the existing episode flow. Gogoanimes search is bounded to three category pages. A title, episode, source API or approved player host mismatch yields no server. These sites and players may change, block automated access or require interaction/verification. No verification bypass is implemented.

Live HTTP checks retrieved sample server URLs for all three; this is not a video-playback or Android-device test. Exact-title matching cannot guarantee a unique adaptation in every catalogue. Anime Village was investigated but not integrated: its sample stream is direct HLS from a different media host and needs a separately reviewed player/header/subtitle integration. It is not represented as a working source.

Signing materials and the separately supplied proprietary Discord SDK AAR are excluded from these source archives.

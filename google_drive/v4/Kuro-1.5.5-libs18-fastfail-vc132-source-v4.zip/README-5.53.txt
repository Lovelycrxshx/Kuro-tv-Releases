KURO.TV 5.53 — RELEASE NOTES

This update adds outbound automatic MyAnimeList and AniList status and watched
progress sync to the existing optional provider connections. The local library
now has all five requested statuses: Watching, Plan to watch, Completed, On hold
and Dropped. Connected-provider sync defaults to on and can be switched off per
provider in Profile > Tracker sync.

Safety and limits
- Initial conflicting provider statuses are preserved until the user chooses.
- Only verified catalogue IDs or an explicitly chosen exact match are used.
- Progress is based on consecutive local watched flags and the provider's current
  count; local removal and unmarking do not delete or lower provider data.
- Scores, notes and remote deletion are not sent. There is no atomic protection
  against changes made concurrently from another app.
- Changes queue locally when offline and retry while Kuro is open. A 429 retry
  delay is honored; 403/sign-in failures pause for user attention. Pending
  updates are bound to the provider account and are not sent to another account.
- Supported top-level single-video players can report a real end event; many
  third-party iframe/external players and videos shorter than three minutes
  cannot. Opening or timing an episode does not count as watched; use the
  episode list's Mark watched control when detection is unavailable.
- Initial sync includes local list entries and watched flags for titles with
  saved metadata. Imported provider lists remain separate and non-overwriting.

Kuro still has local-only, unverified email/password without OTP or recovery;
Google, Drive backup and Supabase remain removed from the app. Existing remote
backups and projects were not changed. Discord and the 73 artwork pairs remain;
Monster Musume and the ambiguous magician title are absent. Third-party artwork
rights have not been verified.

Package app.lovelycrxshx.kuro, version 5.53/code 53, Android 8+. Signed using
the original Kuro key so it is intended to install over the previous version;
do not uninstall or clear data. 52 Robolectric/fake tests and browser/static
regressions passed. No live MAL/AniList account, real phone installation,
player, battery or network test was performed. Provider setup and service
availability can still prevent a connection or update.

Phone setup: see Kuro-tv-5.53-Phone-Setup.txt in the release bundle.

KURO.TV 5.61 — PROFILE AND PLAYBACK

This is an update to the Kuro 5.60 source. It was designed independently using
the AniFam APK analysis as a feature reference; AniFam's original project,
server source and media were not available or copied.

PROFILE AND SETTINGS
The profile drawer uses the existing saved avatar, name and account details,
with a compact purple/black layout and the same Profile, Continue Watching,
Watch List, Import/Export, Settings and Logout actions. The configured accent,
edge gesture and handle controls remain. The entire visible “Player and alerts”
settings group is removed. The former settings keys and values are retained for
compatibility; lists, history, accounts and profile data are not cleared.

PLAYBACK
• Native Media3 playback is enabled only for the existing explicitly validated
  Zenkai direct HLS proxy. Other sources continue to use their WebView players.
  Native network requests and redirects are restricted to that HTTPS proxy.
  A non-verification native playback error first tries the existing web player.
  HTTP 401, 403 and 429 stop for access/verification; Kuro does not bypass them.
• Existing exact-match server fallback remains bounded and uses detected errors.
  Some embeds do not expose enough information for failure detection.
• Supported direct streams save a per-show/per-episode playback position about
  every five seconds and on pause (also on native-player close). The saved value is app-private; no
  timestamp can be obtained reliably from an inaccessible third-party embed.
  Existing Continue Watching still reopens the saved episode in those cases.
• Native skip buttons appear when the source supplies valid intro/outro ranges
  or the user saves an intro range for that episode. Auto skip uses these ranges
  when enabled. Web players retain their existing best-effort Skip button logic.
  No intro timings are invented or automatically identified from the video.
• Native HLS subtitles are selectable when supplied by the stream. A user may
  also choose a local .vtt or .srt subtitle file for the current native session.
• Picture-in-picture requires Android/device support; sites and codecs can limit
  it. The Watch page provides PiP for the supported direct player.
• Cast is user initiated and uses the Google Play services Cast SDK and Google's
  default receiver, not Google sign-in or a Kuro developer account. A warning
  explains that the TV receives the stream URL without the phone's cookies or
  headers. A compatible device and a source accessible to it are required.
• The Download button is shown for the supported direct source. The user must
  confirm they own the content or the provider permits offline storage; Kuro
  does not independently verify the license and does not bypass DRM or access
  checks. Downloads are stored privately by Media3 and shown under Settings →
  Manage downloads; only completed copies are played and playback is cache-only.
  A download may include multiple qualities and use substantial storage or data.
  A source may refuse, expire or fail. The private download database can contain
  source URLs; offline media is not included in Kuro's local JSON backup.

The native player cannot apply Kuro's existing Web video/AI effects or audio
boost. Advanced prompts the user to switch to the existing Web player; if those
effects were already enabled, that player is selected by default. Embedded,
protected or cross-origin videos may still limit effects. The local Anime4K
model is not Topaz. Device GPU performance and battery impact are not measured.

NO GOOGLE ACCOUNT OR CLOUD BACKUP WAS RE-ADDED
The Google Play services dependency was added for Cast; it is not Google sign-in
or a Drive backup. Kuro's
local email account, Discord/MAL/AniList connections and non-overwriting local
backup remain separate. Discord Rich Presence still needs the official SDK and
is not included. No Hayase handoff, torrent engine, Google sign-in, Google Drive
backup or Supabase was added.

SAFE UPDATE AND SOURCE
Package app.lovelycrxshx.kuro, version 5.61 / code 61, Android 8.0+. Install an
APK signed with the existing key as an update. Do not uninstall or clear app
data. If Android reports a signature or version conflict, stop and retain the
installed app and its data. The 5.56 base was reconstructed from the 5.53 backup,
not a byte-identical recovery of the lost 5.55 source/APK. The signing key and
password are stored separately and are never included in the source archives.

Build with JDK 17+, Android SDK platform 35 and build-tools 35.0.1; set JAVA_HOME,
ANDROID_HOME, KEYSTORE and KS_PASS privately, then run ./build.sh. First build
requires Gradle/Maven dependencies. The ZIP and text archives contain the same
source; restore the text archive into a NEW directory using:
  python3 scripts/restore-source-text.py /path/Kuro-tv-5.61-Source.txt NEW_DIR

Real phones, live providers, Cast devices, offline downloads, codecs, PiP and
battery/GPU behavior still need device testing. Automated tests use fixtures,
shadows and fakes and are not a substitute for those checks.

KURO.TV 5.56 — REBUILT RELEASE

This release was reconstructed from the available 5.53 source backup and the
reported 5.54/5.55 behavior. It is not the original 5.55 binary or a byte-for-
byte restoration of its source. Package app.lovelycrxshx.kuro, version code 56,
Android 8.0+ (API 26+). The release APK uses the original Kuro signing key.

WHAT CHANGED SINCE THE 5.53 BACKUP
- My Lists starts on Watching, which is the first tab. Imported provider
  snapshots appear beside local entries in the corresponding status and in All;
  Bookmarks, Imported and History also have explicit destinations.
- Profile status totals include stored imported entries. They can include
  hidden entries or separate entries referring to the same anime; no automatic
  season matching or migration is performed.
- Imported entries have a read-only detail sheet requested using the exact MAL
  or AniList ID. Finding a title in Kuro is manual; it never auto-plays or
  guesses which release/season is correct.
- Adult and unclassified imported entries are hidden by default. The optional
  imported-only show setting requires a second 18+ confirmation. An optional
  two-step classification check sends up to 250 imported anime IDs at a time
  to AniList without account credentials or watch progress. Only exact ID and
  matching title results classified non-adult are cached for up to 30 days;
  mismatched, unavailable, adult and unknown entries stay hidden unless the
  imported-only 18+ option is enabled. The global content flag remains off.
- Stored import snapshots stay separate and new imports skip existing provider
  IDs rather than overwrite their saved status or progress. Opening or filtering
  imported titles does not mutate local categories, bookmarks or history.

RETAINED FROM 5.53
- Local email/password is device-only, does not verify email or send OTP, has no
  recovery, and does not encrypt or lock the profile, bookmarks or history.
- Google sign-in, Drive backup and Supabase are not active in the app. Existing
  external accounts, projects and backups are not changed by this release.
- Discord/MAL/AniList account setup and the prior optional tracker sync remain.
  Tracker sync may send local status and watched-episode updates when enabled;
  provider restrictions, authentication and remote conflicts still apply. Many
  players cannot detect completion across third-party iframes; use existing
  manual watched controls when needed.
- Profile art and third-party notices are unchanged from the 5.53 backup.
  Artwork rights and official provenance were not verified. Monster Musume and
  the ambiguous magician entry remain absent.

UPDATE & PRIVACY
Install the signed 5.56 APK over the existing Kuro installation. Do not
uninstall the old app or clear its data. If Android reports a signing, version
or installation conflict, stop without removing anything. The original private
signing key and password are kept separately and are not included in this
release bundle. Do not disclose login tokens or client secrets in chat.

This reconstruction passed 74 Robolectric tests, 25 browser suites, eight
host/fake-Android scripts and static checks using synthetic data and fakes.
It has not been installed or tested on a real phone, or tested against a live
MAL/AniList account or live stream. Android WebView, notification, playback,
rotation, battery usage and service availability may differ. See TESTS-5.56.txt
and Kuro-tv-5.56-Phone-Setup.txt for details.

BUILD
Source is provided in ZIP and text backups. For a build use JDK 17+, Android
SDK platform 35 and build-tools 35.0.1. The Gradle wrapper downloads Gradle
8.10.2; libraries and test dependencies require network access on first use.
Set JAVA_HOME, ANDROID_HOME, KEYSTORE and KS_PASS privately, then run build.sh.
The original key is required to produce an update-compatible APK. Do not put
signing material in the source archive or share it publicly.

TEXT SOURCE BACKUP
The Source.txt archive includes UTF-8 source as readable text and binary assets
as base64, with a length and SHA-256 per file. To verify and restore it into a
new empty location, use the included source ZIP's utility:
  python3 scripts/restore-source-text.py /path/Kuro-tv-5.56-Source.txt NEW_DIR
The utility refuses to overwrite an existing output directory. The source ZIP
also contains all binary assets and is the simpler complete backup.

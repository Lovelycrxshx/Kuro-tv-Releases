KURO.TV 5.48 — MORE PROFILE PICTURES & CARD BACKGROUNDS

Adds six new original anime portraits, for 12 selectable profile-picture choices
including the earlier six. Existing user-chosen and custom photos are retained.
The Anime and History profile cards each have three independent artwork choices
(the prior background and two new illustrations). Use Profile > Change Anime &
History backgrounds to choose them. Images are bundled and work offline.

These appearance settings stay on this phone; they are not included in the
optional Drive watch-data backup. Existing local profile/image/banner, watch
lists, history, account links, imports and Drive confirmation are unchanged.
Generated illustrations are original; no actual provider data is implied.

Tests use a browser fake bridge and static APK checks, not a physical Android
phone or real Google/Drive account. Install over existing Kuro; never uninstall
or clear app data. The prior Google Drive 403 may still need Cloud configuration.

Build: JDK 17+, Android SDK 35/build-tools 35.0.1, and the original private
signing identity. Set ANDROID_HOME, JAVA_HOME, KEYSTORE and KS_PASS then run
./build.sh. The signing key is separate, never included. No releases uploaded.

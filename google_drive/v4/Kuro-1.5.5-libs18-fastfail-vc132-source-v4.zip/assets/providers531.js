'use strict';
// The 18+ switch is intentionally NOT exposed yet. Unknown classifications fail closed.
const KURO_ADULT_ENABLED=false;
const adultCache=new Map(),adultInflight=new Map();
const adultFlag=x=>!!(x&&(x.isAdult===true||x.adult===true||x.nsfw===true||x.hentai===true||x.adultSource===true||[...(Array.isArray(x.genres)?x.genres:[]),x.genre,x.rating].some(g=>/^(?:hentai|porn(?:ography)?|xxx|18\+|adult content)$/i.test(String(g||'').trim()))));
function contentMetadata(ids){
 return new Promise((resolve,reject)=>{
  if(!window.KuroNative||typeof KuroNative.adultMetadata!=='function')return reject(Error('18+ classification is temporarily unavailable.'));
  let id='adult-'+(++requestNo);pending[id]={resolve,reject};
  try{KuroNative.adultMetadata(id,JSON.stringify(ids))}catch(e){delete pending[id];reject(e)}
 });
}
async function classifyAdded(items){
 if(KURO_ADULT_ENABLED)return items;
 const ids={anilist:[],mal:[]};
 for(const x of items){let a=Number(x.anilistId),m=Number(x.malId);if(a>0&&!adultCache.has('a'+a)&&!ids.anilist.includes(a))ids.anilist.push(a);else if(!a&&m>0&&!adultCache.has('m'+m)&&!ids.mal.includes(m))ids.mal.push(m)}
 if(ids.anilist.length+ids.mal.length){
  const key=JSON.stringify({anilist:[...ids.anilist].sort((a,b)=>a-b),mal:[...ids.mal].sort((a,b)=>a-b)});
  let task=adultInflight.get(key);if(!task){task=contentMetadata(ids).finally(()=>adultInflight.delete(key));adultInflight.set(key,task)}
  const result=JSON.parse(await task);if(result.errors||!result.data)throw Error('18+ classification is temporarily unavailable.');
  for(const rec of [...(result.data.a?.media||[]),...(result.data.m?.media||[])]){
   // A missing or null isAdult value remains unknown and therefore hidden.
   if(typeof rec?.isAdult!=='boolean')continue;
   if(rec.id)adultCache.set('a'+Number(rec.id),rec);
   if(rec.idMal)adultCache.set('m'+Number(rec.idMal),rec);
  }
 }
 return items.filter(allowClassifiedItem);
}
function allowClassifiedItem(x){
 if(KURO_ADULT_ENABLED)return true;if(adultFlag(x))return false;
 const rec=adultCache.get('a'+Number(x.anilistId))||adultCache.get('m'+Number(x.malId));
 if(!rec||rec.isAdult!==false)return false;
 if(Number(x.anilistId)>0&&Number(rec.id)!==Number(x.anilistId))return false;
 if(Number(x.malId)>0&&Number(rec.idMal)!==Number(x.malId))return false;
 // The Library 13 cover ID is only a hint; verify the reported release year.
 if(x.source==='paradise'&&(!Number(x.sourceYear)||Number(rec.startDate?.year)!==Number(x.sourceYear)))return false;
 const titles=[rec.title?.english,rec.title?.romaji,rec.title?.native,...(rec.synonyms||[])].filter(Boolean).map(matchTitle);
 const originals=[x.title,...(x.titles||[])].filter(Boolean).map(matchTitle);
 if(!originals.some(n=>n&&titles.includes(n)))return false;
 x.anilistId=Number(rec.id);x.malId=Number(rec.idMal)||Number(x.malId)||0;x.adultVerified=true;
 return true;
}
function zenkaiItem(x){
 let t=x?.title,english=typeof t==='object'?t.english:x.englishTitle,romaji=typeof t==='object'?t.romaji:(x.romajiTitle||t);
 let title=String(english||romaji||'').trim(),aid=Number(x.anilistId||x.id),mid=Number(x.malId||x.idMal);
 if(!Number.isSafeInteger(aid)||aid<1)aid=0;if(!Number.isSafeInteger(mid)||mid<1)mid=0;
 let rawSlug=String(x.slug||x.siteUrl?.split('/media/')[1]?.split(/[/?#]/)[0]||(String(x.id||'').startsWith('animeav1-')?String(x.id).slice(9):''));
 let slug=/^[a-z0-9][a-z0-9-]{0,180}$/.test(rawSlug)?rawSlug:'';
 let img=validUrl(x.image||x.poster||x.coverImage?.extraLarge||x.coverImage?.large||'','image');
 let url=aid?base('zenkai')+'/api/anilist/media?id='+aid:mid?base('zenkai')+'/api/animeav1/search?id='+mid:'';
 if(!title||!url||(!aid&&!mid))return null;
 let sourceIds=Array.isArray(x.sourceEpisodeIds)?x.sourceEpisodeIds.map(Number).filter(n=>Number.isInteger(n)&&n>0&&n<=5000):[];
 return {title,titles:[english,romaji,typeof t==='object'?t.native:'',...(x.alternativeTitles||[])].filter(Boolean),url,img,source:'zenkai',meta:'Japanese audio · Spanish subtitles',anilistId:aid,malId:mid,zslug:slug,sourceIds,genres:x.genres||[],isAdult:x.isAdult,adult:x.adult,nsfw:x.nsfw,adultSource:x.adultSource,description:String(x.description||x.synopsis||'').replace(/<[^>]*>/g,' ').trim().slice(0,3000)};
}
async function addedCatalog(spec,page,raw){
 let j=JSON.parse(raw),out=[];
 if(spec.source==='zenkai'){
  let rows=spec.mode==='search'?(Array.isArray(j.results)&&j.results.length?j.results:j.media?[j.media]:[]):j.items;
  if(!Array.isArray(rows))throw Error('Unreadable library catalogue.');
  out=rows.map(zenkaiItem).filter(Boolean);
  out=await classifyAdded(out);
  let hasNext=spec.mode==='search'?false:spec.mode==='new'||spec.mode==='popularShelf'?false:!!j.hasMore;
  return {items:out,hasNext};
 }
 throw Error('Unknown catalogue');
}
async function addedDetails(item,raw){
 let safe=await classifyAdded([item]);if(!safe.length)throw Error('This title cannot be shown while 18+ is disabled, or its classification is unknown.');
 let slug=item.zslug;
 if(!slug){
  let j=JSON.parse(await get(base('zenkai')+'/api/animeav1/search?id='+Number(item.anilistId)));
  let candidates=[item.title,...(item.titles||[])].map(matchTitle);
  if(!j.ok||!candidates.includes(matchTitle(j.title))||!/^[a-z0-9][a-z0-9-]{0,180}$/.test(j.slug||''))throw Error('The exact playable title was not found.');
  slug=j.slug;item.zslug=slug;
 }
 const address='https://animeav1.com/media/'+slug,html=await get(address),d=parse(html);
 if(sourceNeedsVerification(d)||![item.title,...(item.titles||[])].map(matchTitle).includes(matchTitle(d.querySelector('h1')?.textContent)))throw Error('The exact title and season could not be verified.');
 // The source includes a bounded list of its episode IDs in its page state; no script is executed.
 let match=html.match(/episodes:\[((?:\{id:\d+,number:\d+\},?)+)\]/),numbers=[];
 if(match)numbers=[...match[1].matchAll(/number:(\d+)/g)].map(x=>Number(x[1]));
 if(!numbers.length)numbers=[...d.querySelectorAll('a[href]')].flatMap(a=>{let m=(a.getAttribute('href')||'').match(new RegExp('^/media/'+slug+'/(\\d+)$'));return m?[Number(m[1])]:[]});
 let eps=numbers.filter(n=>Number.isInteger(n)&&n>0&&n<=5000).map(n=>({number:String(n),name:'',url:base('zenkai')+'/api/animeav1/sources?slug='+encodeURIComponent(slug)+'&episode='+n+'&variant=SUB'}));
 return {episodes:uniqueEpisodes(eps),facts:[['Audio','Japanese'],['Subtitles','Spanish, as reported by the source']]};
}
function uniqueEpisodes(rows){const seen=new Set();return rows.filter(x=>!seen.has(x.number)&&seen.add(x.number)).sort((a,b)=>Number(a.number)-Number(b.number));}
// Only explicit seconds-based markers are passed through; missing or malformed
// provider data never produces guessed intro/outro timings.
function explicitSkipMarkers561(skip){
 if(!skip||typeof skip!=='object')return undefined;let out={};
 for(const name of ['intro','outro']){let r=skip[name];if(r&&Number.isFinite(r.start)&&Number.isFinite(r.end)&&r.start>=0&&r.end>r.start&&r.end<=86400)out[name]={start:r.start,end:r.end}}
 return Object.keys(out).length?out:undefined;
}
async function zenkaiServers(item,ep){
 if(!(await classifyAdded([item])).length)return [];
 let slug=item.zslug,n=Number(ep.number);if(!/^[a-z0-9][a-z0-9-]{0,180}$/.test(slug||'')||!Number.isInteger(n)||n<1)return [];
 let j=JSON.parse(await get(base('zenkai')+'/api/animeav1/sources?slug='+encodeURIComponent(slug)+'&episode='+n+'&variant=SUB'));
 if(!j.ok||j.slug!==slug||Number(j.episode)!==n||String(j.variant).toUpperCase()!=='SUB')return [];
 let out=[];for(let x of j.sources||[]){
  if(x.type!=='direct'||String(x.language).toLowerCase()!=='es')continue;
  let u=validUrl(abs(x.videoUrl||x.url,'zenkai'),'player');if(!u)continue;let p=new URL(u),inner;try{inner=new URL(p.searchParams.get('url'))}catch(_){continue}
  if(p.hostname!=='www.zenkaitv.com'||p.pathname!=='/api/source'||inner.protocol!=='https:'||inner.hostname!=='player.zilla-networks.com'||!inner.pathname.startsWith('/m3u8/'))continue;
  let option={name:'Library 8',lang:'sub',url:u,type:'hls',note:'Spanish subtitles',referer:'zenkai'},skip=explicitSkipMarkers561(x.skip);if(skip)option.skip=skip;out.push(option);
 }
 // The same Zenkai response advertises alternate iframe hosts. These remain
 // Spanish-sub sources and are tried only after the direct stream fails.
 const mirrorHosts=new Set(['animeav1.uns.bio','byselapuix.com','www.mp4upload.com']);
 for(let x of j.castSources||[]){
  if(x.type!=='iframe'||String(x.language).toLowerCase()!=='es')continue;
  let u=validUrl(x.externalUrl||x.url||'','player');if(!u||!mirrorHosts.has(new URL(u).hostname))continue;
  out.push({name:'Library 8',lang:'sub',url:u,note:'Spanish subtitles',referer:'zenkai-mirror'});if(out.length>=4)break;
 }return out;
}
async function flixDetail(item,raw){
 let d=parse(raw);if(sourceNeedsVerification(d))throw Error('The library requested human verification.');
 if(!new URL(item.url).pathname.startsWith('/anime/')){
  let h=d.querySelector('.anisc-detail .film-name a[href]');let u=validUrl(abs(h?.getAttribute('href')||'','flix'));
  if(!u||new URL(u).hostname!=='hianimeq.top'||!new URL(u).pathname.startsWith('/anime/')||matchTitle(h?.textContent)!==matchTitle(item.title))throw Error('The exact title could not be verified.');
  d=parse(await get(u));
 }
 if(sourceNeedsVerification(d)||matchTitle(d.querySelector('.anisc-detail .film-name')?.textContent)!==matchTitle(item.title))throw Error('The exact title and season could not be verified.');
 return d;
}
async function flixEpisodes(d){
 let first=validUrl(abs(d.querySelector('.btn-play[href]')?.getAttribute('href')||'','flix'));
 if(!first||new URL(first).hostname!=='hianimeq.top')throw Error('Episode list unavailable.');
 let watch=parse(await get(first));if(sourceNeedsVerification(watch))throw Error('The library requested human verification.');
 let id=watch.querySelector('#ani_detail')?.getAttribute('data-anime-id');if(!/^\d+$/.test(id||''))throw Error('Episode list unavailable.');
 let j=JSON.parse(await get(base('flix')+'/wp-json/v1/otakuthemes/episode/list/'+id));let doc=parse(j.html||'');
 return uniqueEpisodes([...doc.querySelectorAll('.ep-item[data-number][data-id][href]')].flatMap(a=>{let n=Number(a.getAttribute('data-number')),id=a.getAttribute('data-id'),url=validUrl(abs(a.getAttribute('href'),'flix'));return Number.isInteger(n)&&n>0&&n<=5000&&/^\d+$/.test(id)&&url&&new URL(url).hostname==='hianimeq.top'?[{number:String(n),name:a.getAttribute('title')||'',url,id}]:[]}));
}
async function flixServers(ep){
 let id=ep.id;if(!/^\d+$/.test(String(id||''))){let d=parse(await get(ep.url));if(sourceNeedsVerification(d))throw Error('The library requested human verification.');id=d.querySelector('#ani_detail')?.getAttribute('data-id')}
 if(!/^\d+$/.test(String(id||'')))return [];
 let j=JSON.parse(await get(base('flix')+'/wp-json/v1/otakuthemes/episode/servers?episodeId='+id));let d=parse(j.html||''),out=[];
 for(let x of d.querySelectorAll('.server-item[data-hash]')){let u='';try{u=validUrl(atob(x.getAttribute('data-hash')),'player')}catch(_){}let lang=(x.getAttribute('data-type')||'').toLowerCase();if(u&&(lang==='sub'||lang==='dub'))out.push({name:x.getAttribute('data-server-name')||'Server',lang,url:u,referer:'flix'})}return out;
}

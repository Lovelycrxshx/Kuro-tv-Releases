
'use strict';
/* One-time local recovery for an interrupted 5.45–5.49 restore. No network. */
(()=>{
 const journal='kuro-cloud-restore-journal-v1';
 const allowed=new Set(['kuro-library','kuro-recent','kuro-categories-v1','kuro-episode-history-v1','kuro-watched-v1','kuro-last-episode-v1']);
 try{
  const raw=localStorage.getItem(journal);if(!raw)return;
  const j=JSON.parse(raw);if(!j||j.v!==1||!j.before||typeof j.before!=='object'||Array.isArray(j.before))throw Error();
  const keys=Object.keys(j.before);if(keys.some(k=>!allowed.has(k)||!(j.before[k]===null||typeof j.before[k]==='string')))throw Error();
  for(const k of keys)localStorage.removeItem(k);
  for(const k of keys)if(j.before[k]!==null)localStorage.setItem(k,j.before[k]);
  localStorage.removeItem(journal);
 }catch(_){window.kuroLocalRestoreWarning='An older restore was interrupted and could not be rolled back automatically. Keep your app data; do not clear or uninstall.'}
})();

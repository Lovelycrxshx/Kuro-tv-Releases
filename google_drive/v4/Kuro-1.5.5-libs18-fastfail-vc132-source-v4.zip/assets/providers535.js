'use strict';
// Library 11 uses Miruro's publicly documented catalogue routes. No challenge
// solving, mirror switching or external backend is used. Responses can be
// JSON or XOR/gzip JSON decoded by the bounded Android network bridge.
const miruroCursors=new Map();
const miruroKey=spec=>JSON.stringify([spec.mode,String(spec.query||'').trim()]);
function miruroCatalogUrl(spec,page){
 if(!['all','search'].includes(spec.mode)||!Number.isInteger(page)||page<1)return '';
 let params=new URLSearchParams({limit:'15'}),query=String(spec.query||'').trim();
 if(spec.mode==='search'){if(!query)return '';params.set('q',query)}
 if(page>1){let cursor=miruroCursors.get(miruroKey(spec))?.get(page);if(!cursor)return '';params.set('cursor',cursor)}
 return base('miruro')+'/api/v1/anime?'+params.toString();
}
function miruroOneId(value){
 const values=(Array.isArray(value)?value:[value]).map(Number).filter(n=>Number.isSafeInteger(n)&&n>0);
 const unique=[...new Set(values)];return unique.length===1?unique[0]:0;
}
function miruroItem(value){
 if(!value||typeof value!=='object')return null;
 const id=String(value.id??'');if(!/^[A-Za-z0-9_-]{1,80}$/.test(id))return null;
 const t=value.title,names=(typeof t==='string'?[t]:[t?.english,t?.romaji,t?.native]).filter(x=>typeof x==='string'&&x.trim()).map(x=>x.trim());
 if(!names.length)return null;
 const title=names[0],external=value.external_ids||{},anilistId=miruroOneId(external.anilist||value.anilist_id||value.anilistId),malId=miruroOneId(external.mal||external.myanimelist||value.mal_id||value.malId);
 const format=String(value.format||'').slice(0,40),count=Number(value.episode_count);
 const item={title,titles:[...new Set(names)],source:'miruro',miruroId:id,url:base('miruro')+'/api/v1/anime/'+encodeURIComponent(id),img:validUrl(value.cover_url||'','image'),meta:format||'Anime',anilistId,malId};
 if(Number.isInteger(count)&&count>0&&count<=5000)item.counts={total:String(count)};
 if(typeof value.description==='string')item.description=parse(value.description).body.textContent.replace(/\s+/g,' ').trim().slice(0,3000);
 return item;
}
function miruroUnwrap(raw){
 const value=typeof raw==='string'?JSON.parse(raw):raw;if(value==null||typeof value!=='object')throw Error('Library 11 returned unreadable data.');return value;
}
function miruroRows(container){
 const data=container?.data??container;
 if(Array.isArray(data))return data;
 if(Array.isArray(data?.data))return data.data;
 if(Array.isArray(data?.media))return data.media;
 if(Array.isArray(data?.episodes))return data.episodes;
 throw Error('Library 11 returned an unexpected catalogue.');
}
function miruroCatalog(spec,page,raw){
 const body=miruroUnwrap(raw),rows=miruroRows(body),items=rows.map(miruroItem).filter(Boolean);
 const nested=body.data&&!Array.isArray(body.data)?body.data:{};
 const more=body.has_more??body.hasMore??nested.has_more??nested.hasMore;
 const next=body.next_cursor??body.nextCursor??nested.next_cursor??nested.nextCursor;
 let hasNext=!!more&&(typeof next==='string'||typeof next==='number')&&String(next).length>0&&String(next).length<=512;
 let key=miruroKey(spec),cursors=miruroCursors.get(key)||new Map();if(page===1)cursors=new Map();if(hasNext)cursors.set(page+1,String(next));else cursors.delete(page+1);miruroCursors.set(key,cursors);
 return {items,hasNext};
}
async function miruroDetails(item,raw){
 const data=miruroUnwrap(raw),record=data.data&&typeof data.data==='object'&&!Array.isArray(data.data)?data.data:data;
 const verified=miruroItem(record),id=String(item?.miruroId||'');
 if(!verified||verified.miruroId!==id||item.url!==verified.url||!verified.titles.some(t=>matchTitle(t)===matchTitle(item.title)))throw Error('The exact title could not be verified in Library 11.');
 for(const key of ['anilistId','malId'])if(Number(item[key])&&Number(verified[key])&&Number(item[key])!==Number(verified[key]))throw Error('Conflicting catalogue identifiers.');
 for(const key of ['anilistId','malId'])if(!Number(item[key])&&Number(verified[key]))item[key]=Number(verified[key]);
 item.description=verified.description||item.description||'';item.counts=verified.counts||item.counts;
 const response=miruroUnwrap(await get(base('miruro')+'/api/v1/anime/'+encodeURIComponent(id)+'/episodes?limit=10000'));
 const rows=miruroRows(response),groups=new Map();
 for(const row of rows){
  let n=Number(row?.episode_number??row?.number??row?.episode);if(!Number.isInteger(n)||n<1||n>5000)continue;
  let number=String(n),name=typeof row.title==='string'?row.title.trim().slice(0,160):'';
  let ep={number,name,miruroId:id,url:base('miruro')+'/api/v1/anime/'+encodeURIComponent(id)+'/episodes/'+number+'/play'};
  if(!groups.has(number))groups.set(number,[]);groups.get(number).push(ep);
 }
 const episodes=[...groups.values()].filter(x=>x.length===1).map(x=>x[0]).sort((a,b)=>Number(a.number)-Number(b.number));
 const facts=[['Format',String(record.format||'')],['Status',String(record.status||'')]].filter(x=>x[1]);return {episodes,facts};
}
async function miruroServers(item,ep){
 const id=String(item?.miruroId||''),number=String(ep?.number||'');
 if(!/^[A-Za-z0-9_-]{1,80}$/.test(id)||!/^\d{1,4}$/.test(number)||Number(number)<1||Number(number)>5000||ep.miruroId!==id)return [];
 const url=base('miruro')+'/api/v1/anime/'+encodeURIComponent(id)+'/episodes/'+Number(number)+'/play';if(ep.url!==url)return [];
 const body=miruroUnwrap(await get(url)),data=body.data&&typeof body.data==='object'&&!Array.isArray(body.data)?body.data:body;
 for(const value of [data.episode_number,data.episode])if(value!=null&&Number(value)!==Number(number))return [];
 if(data.anime_id!=null&&String(data.anime_id)!==id)return [];
 const tracks=Array.isArray(data.tracks)?data.tracks:[],out=[],seen=new Set();
 for(const track of tracks){
  const mode=String(track?.track||'').toLowerCase(),lang=mode==='dub'?'dub':mode==='sub'||mode==='ssub'?'sub':'';if(!lang)continue;
  for(const provider of Array.isArray(track.providers)?track.providers:[])for(const box of Array.isArray(provider.servers)?provider.servers:[]){
   // Do not forward arbitrary source-provided headers, cookies, or unknown
   // CDN URLs. Only already-supported embed hosts can be presented in-app.
   const headers=box?.headers&&typeof box.headers==='object'?box.headers:{},ref=String(headers.referer||headers.Referer||'');
   if(ref){let r;try{r=new URL(ref)}catch(_){continue}if(r.protocol!=='https:'||!['www.miruro.cx','miruro.cx'].includes(r.hostname))continue;}
   for(const stream of Array.isArray(box.streams)?box.streams:[]){
    const candidates=[];if(typeof stream?.embed_url==='string')candidates.push(stream.embed_url);if(typeof stream?.embedUrl==='string')candidates.push(stream.embedUrl);
    if(['embed','iframe'].includes(String(stream?.format||stream?.type||'').toLowerCase())||stream?.embed===true)candidates.push(stream.url||stream.file||'');
    for(const candidate of candidates){const safe=validUrl(candidate,'player');if(!safe)continue;const p=new URL(safe);if(/\.(?:m3u8|mp4)(?:$|\?)/i.test(p.pathname+p.search))continue;let key=safe+'|'+lang;if(seen.has(key))continue;seen.add(key);out.push({name:'Server',lang,url:safe,referer:'miruro',note:'Source-reported'});if(out.length>=40)return out;}
   }
  }
 }
 return out;
}
async function fallbackMiruro(title,number,expected={}){
 if(!validEpisodeNumber(number))return [];
 let found=[],spec={source:'miruro',mode:'search',query:title};for(let page=1;page<=3;page++){let result=await fetchCatalogPage(spec,page);found.push(...result.items.filter(x=>[x.title,...(x.titles||[])].some(t=>matchTitle(t)===matchTitle(title))));if(!result.hasNext)break;}
 const candidates=found.filter(x=>{if((expected.anilistId&&x.anilistId&&Number(expected.anilistId)!==Number(x.anilistId))||(expected.malId&&x.malId&&Number(expected.malId)!==Number(x.malId)))return false;if(expected.anilistId||expected.malId)return !!((expected.anilistId&&Number(expected.anilistId)===Number(x.anilistId))||(expected.malId&&Number(expected.malId)===Number(x.malId)));return true;});
 const unique=[...new Map(candidates.map(x=>[x.url,x])).values()];if(unique.length!==1)return [];
 const item=unique[0],detail=await miruroDetails(item,await get(item.url)),matches=detail.episodes.filter(ep=>ep.number===String(Number(number)));
 return matches.length===1?miruroServers(item,matches[0]):[];
}

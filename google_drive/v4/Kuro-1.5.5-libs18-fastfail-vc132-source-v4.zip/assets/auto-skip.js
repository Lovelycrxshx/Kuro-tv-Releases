/* Kuro's opt-in, best-effort Skip control detector.
   When the player's WebView supports document-start scripts, this code runs
   independently in each frame. It has no access to device files, accounts,
   or arbitrary native commands. It stops its timer when disabled. */
(function () {
  'use strict';
  if (window.__kuroSkipInitialized) return;
  window.__kuroSkipInitialized = true;

  var enabled = false;
  var timer = null;
  var lastClicks = new WeakMap();
  var cursors = new WeakMap();
  var nativeFrames = !!window.__kuroFrameMode && !!window.KuroSkipState;
  var INTERVAL_MS = 2000;
  var GROUP_BUDGET_MS = 6;
  var MAX_PER_GROUP = 400;
  var COOLDOWN_MS = 10000;
  var semanticSelector = 'button,[role="button"],a,input[type="button"],input[type="submit"]';
  var namedSelector = '[class*="skip" i],[id*="skip" i]';

  function timeNow() {
    return (window.performance && window.performance.now) ? window.performance.now() : Date.now();
  }

  function verificationPage(doc) {
    try {
      var href = String(doc.location && doc.location.href || '');
      var title = String(doc.title || '');
      if (/(?:captcha|turnstile|recaptcha|hcaptcha|\/challenge(?:\/|\?|$))/i.test(href)) return true;
      if (/(?:verify.{0,25}(?:human|browser)|checking your browser|security check|just a moment)/i.test(title)) return true;
      return !!doc.querySelector('iframe[src*="captcha" i],iframe[src*="challenge" i],.g-recaptcha,.h-captcha,.cf-turnstile,[data-sitekey],#challenge-form');
    } catch (_) { return true; }
  }

  function skipLabel(el) {
    var values = [el.getAttribute('aria-label'), el.getAttribute('title')];
    if (el.tagName === 'INPUT') values.push(el.value);
    values.push(el.textContent);
    for (var i = 0; i < values.length; i++) {
      var value = String(values[i] || '').trim().replace(/\s+/g, ' ');
      if (value.length && value.length <= 100 && /\bskip\b/i.test(value) &&
          !/\b(?:verify|verification|captcha|challenge|robot|human)\b/i.test(value)) return value.toLowerCase();
    }
    return '';
  }

  function visible(el, doc) {
    try {
      var win = doc.defaultView, r = el.getBoundingClientRect();
      if (!win || r.width < 1 || r.height < 1 || r.right <= 0 || r.bottom <= 0 ||
          r.left >= win.innerWidth || r.top >= win.innerHeight) return false;
      for (var n = el, depth = 0; n && n.nodeType === 1 && depth < 12; n = n.parentElement, depth++) {
        var style = win.getComputedStyle(n);
        if (style.display === 'none' || style.visibility === 'hidden' ||
            Number(style.opacity) === 0 || (n === el && style.pointerEvents === 'none')) return false;
      }
      if (doc.elementFromPoint) {
        var x = Math.max(0, Math.min(win.innerWidth - 1, (r.left + r.right) / 2));
        var y = Math.max(0, Math.min(win.innerHeight - 1, (r.top + r.bottom) / 2));
        var top = doc.elementFromPoint(x, y);
        if (top && top !== el && !el.contains(top) && !top.contains(el)) return false;
      }
      return true;
    } catch (_) { return false; }
  }

  // Some players fade their entire controls layer until the viewer touches the
  // screen. Only permit a specific intro/outro control in a known player that
  // contains exactly one actively playing video. A display:none control is
  // still inactive; generic Skip, ads, verification and disabled controls are
  // never acted on through this fallback. No synthetic touch is generated.
  function fadedPlayerControl(el, doc, label) {
    try {
      if (!el.matches(semanticSelector) || !/\b(?:intro|opening|outro|ending|credits)\b/i.test(label)) return false;
      if (/\b(?:ad|advert|trailer|preview|verify|verification|captcha|challenge|robot|human)\b/i.test(label)) return false;
      var box=el.closest('.jwplayer,.video-js,.plyr,[data-plyr],.player-container,.player-wrapper,.video-player');
      if (!box) return false;
      var videos=box.querySelectorAll('video');
      if (videos.length!==1 || videos[0].paused || videos[0].ended || videos[0].readyState<2) return false;
      var rect=el.getBoundingClientRect(),win=doc.defaultView;
      if (!win||rect.width<1||rect.height<1||rect.right<=0||rect.bottom<=0||rect.left>=win.innerWidth||rect.top>=win.innerHeight) return false;
      var faded=false;
      for(var n=el,depth=0;n&&n.nodeType===1&&depth<24;n=n.parentElement,depth++){
        if(n.hidden||n.getAttribute('aria-hidden')==='true')return false;
        var style=win.getComputedStyle(n);if(style.display==='none')return false;
        if(style.visibility==='hidden'||Number(style.opacity)===0||style.pointerEvents==='none')faded=true;
      }
      return faded;
    } catch (_) { return false; }
  }

  function consider(el, doc, group, clickedThisPass) {
    if (!el || el.nodeType !== 1) return;
    if (group === 2 && el.children.length) return; // Generic text fallback: leaf only.
    var label = skipLabel(el);
    if (!label) return;
    var control = el.closest(semanticSelector) || el.closest(namedSelector) || el;
    if (control.disabled || control.getAttribute('aria-disabled') === 'true') return;
    var context = [control.getAttribute('aria-label'), control.getAttribute('title'), control.textContent].join(' ');
    if (/\b(?:verify|verification|captcha|challenge|robot|human)\b/i.test(context)) return;
    label = skipLabel(control) || label;
    // Don't press a broad wrapper when it contains a more specific control.
    if (control === el && !el.matches(semanticSelector) && el.querySelector(semanticSelector)) return;
    if (control.closest('.g-recaptcha,.h-captcha,.cf-turnstile,[data-sitekey],#challenge-form')) return;
    if (!visible(control, doc) && !fadedPlayerControl(control, doc, label)) { lastClicks.delete(control); return; }
    for (var i = 0; i < clickedThisPass.length; i++) {
      var previous = clickedThisPass[i];
      if (previous === control || previous.contains(control) || control.contains(previous)) return;
    }
    var now = timeNow(), old = lastClicks.get(control);
    if (old && old.label === label && (now - old.time < COOLDOWN_MS || old.attempts >= 3)) return;
    lastClicks.set(control, {label: label, time: now, attempts: old && old.label === label ? old.attempts + 1 : 1});
    clickedThisPass.push(control);
    try { control.click(); } catch (_) {}
  }

  function inspectGroup(doc, selector, group, cursorState, clickedThisPass) {
    var list;
    try { list = doc.querySelectorAll(selector); } catch (_) { return; }
    var length = list.length;
    if (!length) { cursorState[group] = 0; return; }
    var index = cursorState[group] % length, checked = 0, until = timeNow() + GROUP_BUDGET_MS;
    while (checked < length && checked < MAX_PER_GROUP && timeNow() < until) {
      consider(list[index], doc, group, clickedThisPass);
      checked++;
      index = (index + 1) % length;
    }
    cursorState[group] = index;
  }

  function scanDocument(doc, depth) {
    if (!enabled || !doc || depth > 3 || verificationPage(doc)) return;
    try {
      var state = cursors.get(doc);
      if (!state) { state = [0, 0, 0]; cursors.set(doc, state); }
      var clickedThisPass = [];
      inspectGroup(doc, semanticSelector + ',[aria-label*="skip" i],[title*="skip" i]', 0, state, clickedThisPass);
      inspectGroup(doc, namedSelector, 1, state, clickedThisPass);
      inspectGroup(doc, 'span,div', 2, state, clickedThisPass);
      // Old WebViews can only inspect the main page and same-origin frames.
      // Modern WebViews inject this script separately into each frame instead.
      if (!nativeFrames) {
        var frames = doc.querySelectorAll('iframe');
        for (var i = 0; i < Math.min(frames.length, 12); i++) {
          try { if (frames[i].contentDocument) scanDocument(frames[i].contentDocument, depth + 1); } catch (_) {}
        }
      }
    } catch (_) {}
  }

  function tick() {
    timer = null;
    if (!enabled) return;
    scanDocument(document, 0);
    if (enabled) timer = window.setTimeout(tick, INTERVAL_MS);
  }

  function setEnabled(on) {
    on = !!on;
    if (on === enabled) return;
    enabled = on;
    if (timer !== null) { window.clearTimeout(timer); timer = null; }
    if (enabled) tick();
  }

  if (nativeFrames && typeof window.KuroSkipState.postMessage === 'function') {
    window.KuroSkipState.onmessage = function (event) { setEnabled(event && event.data === 'on'); };
    window.addEventListener('pagehide', function () {
      setEnabled(false);
      try { window.KuroSkipState.postMessage('bye'); } catch (_) {}
    });
    window.addEventListener('pageshow', function (event) {
      if (event && event.persisted) try { window.KuroSkipState.postMessage('ready'); } catch (_) {}
    });
    try { window.KuroSkipState.postMessage('ready'); } catch (_) {}
  } else {
    window.kuroSetAutoSkip = setEnabled;
    setEnabled(!!window.__kuroSkip);
  }
})();

/* Best-effort cosmetic styling and initial unmute for same-page video elements.
   Provider controls, media pipeline, permissions and DRM remain unchanged. */
(function () {
  'use strict';
  try {
    if (document.getElementById('kuro-video-skin')) return;
    var style = document.createElement('style');
    style.id = 'kuro-video-skin';
    style.textContent = `
      .jwplayer .jw-controlbar, .video-js .vjs-control-bar, .plyr--video .plyr__controls {
        background: linear-gradient(0deg,rgba(0,0,0,.88),rgba(0,0,0,.48) 65%,transparent) !important;
        border: 0 !important; box-shadow: none !important;
      }
      .jwplayer .jw-controlbar .jw-icon, .video-js .vjs-control-bar .vjs-control,
      .plyr--video .plyr__controls button { color: #ffffff !important; opacity: .96; }
      .jwplayer .jw-controlbar .jw-icon:hover, .video-js .vjs-control-bar .vjs-control:hover,
      .plyr--video .plyr__controls button:hover { color: #ba80f0 !important; }
      .jwplayer .jw-slider-time .jw-progress, .jwplayer .jw-slider-time .jw-timesegment-progress,
      .video-js .vjs-play-progress, .plyr--video .plyr__progress input { background: #ac6ee6 !important; }
      .jwplayer .jw-slider-time .jw-knob, .video-js .vjs-play-progress:before { color: #ac6ee6 !important; }
      .jwplayer .jw-slider-horizontal .jw-rail, .video-js .vjs-progress-holder { border-radius: 2px !important; }
      .jwplayer .jw-display-icon-container, .video-js .vjs-big-play-button,
      .plyr--video .plyr__control--overlaid { background: rgba(0,0,0,.68) !important; border-radius: 50% !important; }
    `;
    (document.head || document.documentElement).appendChild(style);
    // Once per video element; later user mute choices remain untouched.
    var seen = new WeakSet();
    function initialAudio(v) { if (!v || seen.has(v)) return; seen.add(v); try { v.muted = false; v.volume = 1; if (window.__kuroAutoplay) { var attempt=v.play(); if (attempt && attempt.catch) attempt.catch(function(){}); } } catch (_) {} }
    function scan() { document.querySelectorAll('video').forEach(initialAudio); }
    scan();
    // The optional Skip detector is implemented separately in auto-skip.js.
    new MutationObserver(scan).observe(document.documentElement, {childList: true, subtree: true});
  } catch (e) { /* Retain the provider's original player if styling fails. */ }
})();

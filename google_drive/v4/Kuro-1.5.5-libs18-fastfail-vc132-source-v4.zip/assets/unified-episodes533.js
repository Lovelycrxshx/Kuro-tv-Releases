'use strict';
// Only add episode numbers from a second listing when both listings expose the
// same catalogue ID and an exact title. Unknown identities remain separate.
function unifiedIdsFromDocument(item,doc){
 for(const [field,selector,re] of [
  ['anilistId','a[href^="https://anilist.co/anime/"]',/^https:\/\/anilist\.co\/anime\/(\d+)(?:[/?#]|$)/],
  ['malId','a[href^="https://myanimelist.net/anime/"]',/^https:\/\/myanimelist\.net\/anime\/(\d+)(?:[/?#]|$)/]
 ]){
  const ids=new Set([...doc.querySelectorAll(selector)].map(a=>(a.getAttribute('href')||'').match(re)?.[1]).filter(Boolean).map(Number));
  if(ids.size===1){const id=[...ids][0];if(!Number(item[field]))item[field]=id;else if(Number(item[field])!==id)throw Error('Conflicting catalogue identifiers.');}
 }
}
function unifiedEpisodeRows(rows){
 const byNumber=new Map();
 for(const ep of rows||[]){
  const n=Number(ep?.number);if(!Number.isInteger(n)||n<1||n>5000||!validUrl(ep.url))continue;
  const key=String(n),safe={...ep,number:key},identity=(ep.id||'')+'|'+ep.url;
  if(!byNumber.has(key))byNumber.set(key,new Map());byNumber.get(key).set(identity,safe);
 }
 return [...byNumber.values()].filter(m=>m.size===1).map(m=>[...m.values()][0]).sort((a,b)=>Number(a.number)-Number(b.number));
}
async function unifiedReadOtherEpisodes(candidate,expected){
 const item=unifiedCopy(candidate),s=item.source;if(!unifiedCompatible(item,expected)||matchTitle(item.title)!==matchTitle(expected.title))return null;
 const raw=await get(item.url);let doc;
 if(s==='miruro'){if(!unifiedKnownIdentity(expected,item))return null;const data=await miruroDetails(item,raw);return {item,episodes:unifiedEpisodeRows(data.episodes)};}
 if(s==='kitsune'){if(!unifiedKnownIdentity(expected,item))return null;const data=await kitsuneDetails(item,raw);return {item,episodes:unifiedEpisodeRows(data.episodes)};}
 if(s==='paradise'){if(!unifiedKnownIdentity(expected,item))return null;const data=await paradiseDetails(item,raw);return {item,episodes:unifiedEpisodeRows(data.episodes)};}
 if(['zenkai'].includes(s)){
  if(!unifiedKnownIdentity(expected,item))return null;const data=await addedDetails(item,raw);
  return {item,episodes:unifiedEpisodeRows(data.episodes)};
 }
 let aw=null;if(s==='aw'){aw=await awDetail(item,raw);doc=aw.doc}else if(s==='flix')doc=await flixDetail(item,raw);else doc=parse(raw);
 if(sourceNeedsVerification(doc))throw Error('The library requested human verification.');
 let heading=s==='ms'?doc.querySelector('h1')?.textContent:s==='dk'||s==='flix'||s==='aw'?doc.querySelector('.anisc-detail .film-name')?.textContent:doc.querySelector('h1,h2')?.textContent;
 if(!heading||matchTitle(heading)!==matchTitle(expected.title))return null;
 unifiedIdsFromDocument(item,doc);if(!unifiedKnownIdentity(expected,item))return null;
 let rows=[];
 if(s==='ms'){
  rows=[...doc.querySelectorAll('.hk-ep,.hk-wep')].map(x=>({number:x.getAttribute('data-ep')||x.getAttribute('data-episode')||x.textContent.trim(),name:(x.getAttribute('data-name')||'').trim(),url:validUrl(abs(x.getAttribute('href'),s))}));
 }else if(s==='dk'){
  const first=item.url.includes('/watch/')?item.url:validUrl(abs(doc.querySelector('.btn-play[href]')?.getAttribute('href')||'',s));
  if(!first||!new URL(first).pathname.startsWith('/watch/'))return null;
  const watch=parse(item.url===first?doc.documentElement.outerHTML:await get(first));if(sourceNeedsVerification(watch))throw Error('The library requested human verification.');
  const anime=watch.querySelector('#ani_detail')?.getAttribute('data-anime-id');if(!/^\d+$/.test(anime||''))return null;
  const data=JSON.parse(await get(base(s)+'/ajax/v2/episode/list/'+anime)),epdoc=parse(data.html||'');
  rows=[...epdoc.querySelectorAll('.ep-item[data-number][href]')].map(x=>({number:x.getAttribute('data-number'),name:(x.querySelector('.ep-name')?.getAttribute('title')||x.querySelector('.ep-name')?.textContent||x.getAttribute('title')||'').trim(),filler:x.classList.contains('ssl-item-filler')||x.getAttribute('data-filler')==='true',url:validUrl(abs(x.getAttribute('href'),s))}));
 }else if(s==='flix')rows=await flixEpisodes(doc);
 else if(s==='aw')rows=await awEpisodes(doc,aw.episodeDoc);
 else if(s==='nine'){
  const id=doc.querySelector('.block_area-episodes[data-series]')?.getAttribute('data-series');if(!/^\d+$/.test(id||''))return null;
  const data=JSON.parse(await get(base(s)+'/wp-json/9animetv/v1/episodes/'+id+'?active=0')),epdoc=parse(data.pages||'');
  rows=[...epdoc.querySelectorAll('.ep-item[data-number][href]')].map(x=>({number:x.getAttribute('data-number'),name:x.getAttribute('title')||'',url:validUrl(abs(x.getAttribute('href'),s))}));
 }else if(s==='zoro'){
  rows=[...doc.querySelectorAll('[class*=eplister] a[href]')].map(a=>({number:a.querySelector('.epl-num')?.textContent.trim()||'',name:a.querySelector('.epl-title')?.textContent.trim()||'',url:validUrl(abs(a.getAttribute('href'),s))}));
 }else if(s==='ani'){
  const id=doc.querySelector('#watch-main[data-id]')?.getAttribute('data-id');if(!/^\d+$/.test(id||''))return null;
  const data=JSON.parse(await get(base(s)+'/ajax/episode/list/'+id)),epdoc=parse(data.result||'');
  rows=[...epdoc.querySelectorAll('a[data-num][href]')].map(a=>({number:a.getAttribute('data-num'),name:a.querySelector('.d-title')?.textContent.trim()||'',url:validUrl(abs(a.getAttribute('href'),s))}));
 }else if(s==='salt'){
  rows=[...doc.querySelectorAll('a[href*="/episode/"]')].flatMap(a=>{let u=validUrl(abs(a.getAttribute('href'),s)),m=u&&new URL(u).pathname.match(/-1x(\d+)\/?$/);return m?[{number:m[1],name:'',url:u}]:[]});
 }
 return {item,episodes:unifiedEpisodeRows(rows)};
}
function unifiedBeginEpisodeScan(item,marker){
 if(!item?.unified)return;
 const status=$('#unified-episodes-status');if(!status)return;
 if(!Number(item.anilistId)&&!Number(item.malId)){status.textContent='Episode list from one source. Other sources are checked for matching playback when you open an episode.';return}
 const owner=item,targets=unifiedCodes.filter(s=>s!==owner.source),already=new Set(episodes.filter(e=>!e.missing).map(e=>String(Number(e.number))));
 let cursor=0,extra=0,stopped=false,blocked=false,finished=0;
 const alive=()=>!stopped&&marker===window.renderSeq&&view==='detail'&&selected===owner&&status.isConnected;
 const update=()=>{if(marker!==window.renderSeq||!status.isConnected)return;
  status.textContent=blocked?'A source requested verification; checking stopped.':stopped?'Checking ended. Some sources may not have been checked.':finished<targets.length?'Checking matching episode lists…':extra?`${extra} additional episode${extra===1?'':'s'} found in ID-matched listings.`:'No additional episode lists could be verified.';
 };
 status.textContent='Checking matching episode lists…';
 const timer=setTimeout(()=>{if(alive()){stopped=true;update()}},60000);
 async function worker(){
  while(alive()){
   const code=targets[cursor++];if(!code)return;
   if(unifiedVerificationBlocked.has(code)){blocked=true;stopped=true;update();return}
   try{
    let candidates=(owner.unifiedVariants||[]).filter(v=>v.source===code&&matchTitle(v.title)===matchTitle(owner.title)&&unifiedCompatible(v,owner));
    if(!candidates.length){
     const result=await unifiedSchedule(()=>{if(unifiedVerificationBlocked.has(code))throw Error('The library requested human verification.');return fetchCatalogPage({source:code,mode:'search',query:owner.title},1)},alive,3);if(!alive())return;
     candidates=result.items.filter(v=>matchTitle(v.title)===matchTitle(owner.title)&&unifiedCompatible(v,owner));
    }
    candidates=[...new Map(candidates.map(v=>[v.url,v])).values()];
    // Several different candidate URLs for the same title are ambiguous until
    // individually identified. Inspect no more than three, then require one ID match.
    if(candidates.length>3)candidates=[];
    const matches=[];
    for(const c of candidates){
     if(!alive())return;
     const data=await unifiedSchedule(()=>{if(unifiedVerificationBlocked.has(code))throw Error('The library requested human verification.');return unifiedReadOtherEpisodes(c,owner)},alive,3);if(!alive())return;if(data)matches.push(data);
    }
    const unique=[...new Map(matches.map(x=>[x.item.source+'|'+x.item.url,x])).values()];
    if(unique.length===1){
     const found=unique[0];let added=0;
     for(const ep of found.episodes){if(already.has(ep.number)){if(ep.filler){const ex154=episodes.find(z=>String(z.number)===String(ep.number));if(ex154)ex154.filler=true;}continue;}already.add(ep.number);episodes.push({...ep,unifiedOwner:unifiedCopy(found.item)});added++;extra++}
     if(added&&alive()){
      episodes=episodes.filter(e=>!e.missing).sort((a,b)=>Number(a.number)-Number(b.number));
      renderDetailEpisodes(owner,marker);
     }
    }
   }catch(e){if(!alive())return;if(unifiedProblem(e)){unifiedVerificationBlocked.add(code);blocked=true;stopped=true}}
   finished++;update();
  }
 }
 Promise.all([worker(),worker()]).finally(()=>{clearTimeout(timer);if(marker===window.renderSeq&&status.isConnected)update()});
}

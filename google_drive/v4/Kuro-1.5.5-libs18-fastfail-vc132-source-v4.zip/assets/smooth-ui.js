/* Kuro — smooth UI behaviour.
 *
 * Pairs with smooth-ui.css. Everything here is additive: if a selector or API is missing
 * the app keeps working exactly as before. Guarded for old WebViews (the app supports
 * Android 8, so every optional API is feature-detected).
 *
 * What it does:
 *   1. fades images in when decoded instead of popping them in half-loaded
 *   2. press feedback + a tiny haptic tick on touch devices
 *   3. shadow under the sticky header once content scrolls beneath it
 *   4. a subtle parallax on the profile banner (transform only)
 *   5. staggered reveal of the avatar grid when artwork changes
 *   6. window.kuroSmooth for the app: viewTransition(fn) and pill(text)
 */
(function () {
  "use strict";

  var reduce = false;
  try {
    reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  } catch (e) { }

  // ------------------------------------------------------------ 1. image fade-in

  function fadeImage(img) {
    if (!img || img.dataset.kuFaded === "1") return;
    img.dataset.kuFaded = "1";
    if (img.complete && img.naturalWidth > 0) {
      img.classList.remove("ku-loading");
      return;
    }
    img.classList.add("ku-loading");
    var show = function () { img.classList.remove("ku-loading"); };
    img.addEventListener("load", show, { once: true });
    img.addEventListener("error", show, { once: true });
  }

  function fadeImages(root) {
    var scope = root && root.querySelectorAll ? root : document;
    var list = scope.querySelectorAll("img:not([data-ku-faded])");
    for (var i = 0; i < list.length; i++) fadeImage(list[i]);
  }

  // ------------------------------------------------------------ 2. press feedback

  function tick() {
    if (reduce) return;
    try {
      if (navigator.vibrate) navigator.vibrate(6);
    } catch (e) { }
  }

  document.addEventListener("pointerdown", function (event) {
    var target = event.target;
    if (!target || !target.closest) return;
    if (target.closest("button, [role='button'], a.btn, .preset-choice571, .profile-card547")) tick();
  }, { passive: true });

  // ------------------------------------------------------------ 3. header shadow

  var header = null;
  var scrolled = false;

  function onScroll() {
    var y = window.scrollY || document.documentElement.scrollTop || 0;
    var now = y > 8;
    if (now !== scrolled) {
      scrolled = now;
      if (header) header.classList.toggle("ku-scrolled", now);
    }
  }

  // ------------------------------------------------------------ 4. banner parallax

  var parallaxEl = null;
  var parallaxFrame = 0;

  function findBanner() {
    return document.querySelector(".profile-banner > img");
  }

  function applyParallax() {
    parallaxFrame = 0;
    if (reduce || !parallaxEl) return;
    var rect = parallaxEl.getBoundingClientRect();
    if (rect.bottom < -80 || rect.top > window.innerHeight + 80) return;
    // 0 at the moment the banner is centred; ±6% of its height either side.
    var offset = (rect.top + rect.height / 2 - window.innerHeight / 2) / window.innerHeight;
    var shift = Math.max(-8, Math.min(8, offset * 8));
    parallaxEl.style.transform = "translate3d(0," + shift.toFixed(2) + "%,0) scale(1.06)";
  }

  function scheduleParallax() {
    if (parallaxFrame) return;
    parallaxFrame = window.requestAnimationFrame(applyParallax);
  }

  // ------------------------------------------------------------ 5. avatar grid sweep

  function sweepGrid(grid) {
    if (!grid || reduce) return;
    var items = grid.querySelectorAll(".preset-choice571");
    for (var i = 0; i < items.length; i++) {
      items[i].style.setProperty("--ku-i", String(i % 12));
    }
    grid.classList.remove("ku-sweep571");
    // force a reflow so the animation can restart when the same grid is re-rendered
    void grid.offsetWidth;
    grid.classList.add("ku-sweep571");
  }

  // ------------------------------------------------------------ 6. public helpers

  var pillTimer = 0;

  function pill(text, ms) {
    if (!text) return;
    var node = document.querySelector(".ku-pill");
    if (!node) {
      node = document.createElement("div");
      node.className = "ku-pill";
      node.setAttribute("role", "status");
      node.setAttribute("aria-live", "polite");
      document.body.appendChild(node);
    }
    node.textContent = text;
    // next frame so the transition runs even when the pill already exists
    window.requestAnimationFrame(function () { node.classList.add("is-on"); });
    if (pillTimer) window.clearTimeout(pillTimer);
    pillTimer = window.setTimeout(function () {
      node.classList.remove("is-on");
    }, ms || 1800);
  }

  function viewTransition(run) {
    if (typeof run !== "function") return;
    if (reduce || !document.startViewTransition) {
      try { run(); } catch (e) { }
      return;
    }
    try {
      var handle = document.startViewTransition(run);
      if (handle && handle.finished && handle.finished.catch) handle.finished.catch(function () { });
    } catch (e) {
      try { run(); } catch (ignore) { }
    }
  }

  // ------------------------------------------------------------ wiring

  function boot() {
    header = document.querySelector("header");
    parallaxEl = findBanner();

    fadeImages(document);
    onScroll();

    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("scroll", scheduleParallax, { passive: true });
    window.addEventListener("resize", scheduleParallax, { passive: true });

    // New nodes (profile rows, artwork grids, episode lists) get the same treatment.
    if (window.MutationObserver) {
      var observer = new MutationObserver(function (records) {
        for (var i = 0; i < records.length; i++) {
          var added = records[i].addedNodes;
          for (var j = 0; j < added.length; j++) {
            var node = added[j];
            if (node.nodeType !== 1) continue;
            if (node.tagName === "IMG") fadeImage(node);
            else fadeImages(node);
          }
        }
        if (!parallaxEl) parallaxEl = findBanner();
        scheduleParallax();
        // The profile hero animates itself through CSS; just make sure a freshly
        // mounted hero restarts its one-shot entrance instead of inheriting a
        // finished animation from a previous profile.
        var hero = document.querySelector(".profile-hero547");
        if (hero && !hero.dataset.kuReady) {
          hero.dataset.kuReady = "1";
          hero.classList.remove("ku-hero-in");
          void hero.offsetWidth;
          hero.classList.add("ku-hero-in");
        }
      });
      try {
        observer.observe(document.body, { childList: true, subtree: true });
      } catch (e) { }
    }

    // A profile/artwork picker that re-renders its grid sweeps it in once.
    document.addEventListener("click", function (event) {
      var target = event.target;
      if (!target || !target.closest) return;
      if (target.closest("[data-profile], [data-artwork], .preset-tabs571 button")) {
        window.setTimeout(function () {
          var grid = document.querySelector(".preset-grid571");
          if (grid) sweepGrid(grid);
        }, 40);
      }
    }, true);

    // Let the app opt in from anywhere: window.kuroSmooth.pill("Switched to Sakura")
    window.kuroSmooth = {
      pill: pill,
      viewTransition: viewTransition,
      sweep: function () { sweepGrid(document.querySelector(".preset-grid571")); },
      refresh: function () { fadeImages(document); scheduleParallax(); }
    };
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();

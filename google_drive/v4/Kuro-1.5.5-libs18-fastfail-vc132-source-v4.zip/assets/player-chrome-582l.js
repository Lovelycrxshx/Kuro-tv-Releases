
/* 5.82o: adopt the live app accent so the web player matches the native player.
   The theme layer stores the choice under 'kuro-accent-v1' and swaps a
   theme-<id>-1.1.css sheet that defines --cyan / --bg. */
(function accent582o(){
  try{
    var sw={violet:'#a65be4',teal:'#27d7c5',plum:'#d252e6',graphite:'#989898',sky:'#2e92d9',
            ice:'#25b4e0',royal:'#805be7',sapphire:'#4f7ce8',indigo:'#3f54dd',emerald:'#2ed984',
            mint:'#32e2ad',lime:'#8fe444',citron:'#e2e756',gold:'#e9c25a',amber:'#dc9b3b',
            sunset:'#de7548',coral:'#ed9183',rose:'#e968a9',crimson:'#de4866',magenta:'#e050c3'};
    var id=localStorage.getItem('kuro-accent-v1')||'violet';
    var hex=sw[id]||sw.violet;
    function hsl2hex(h,s,l){
      var c=(1-Math.abs(2*l-1))*s,x=c*(1-Math.abs(((h/60)%2)-1)),m=l-c/2,r=0,g=0,b=0;
      if(h<60){r=c;g=x}else if(h<120){r=x;g=c}else if(h<180){g=c;b=x}
      else if(h<240){g=x;b=c}else if(h<300){r=x;b=c}else{r=c;b=x}
      function p(v){return ('0'+Math.round((v+m)*255).toString(16)).slice(-2)}
      return '#'+p(r)+p(g)+p(b);
    }
    function hex2hue(hx){
      var r=parseInt(hx.slice(1,3),16)/255,g=parseInt(hx.slice(3,5),16)/255,b=parseInt(hx.slice(5,7),16)/255;
      var mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn,hue=0;
      if(d>0){if(mx===r)hue=((g-b)/d+(g<b?6:0))*60;else if(mx===g)hue=((b-r)/d+2)*60;else hue=((r-g)/d+4)*60}
      return hue;
    }
    var hue=hex2hue(hex);
    var floor=hsl2hex(hue,0.45,0.13);
    var root=document.documentElement;
    root.style.setProperty('--kuro-floor',floor);
    root.style.setProperty('--kuro-player-floor',floor);
    root.style.setProperty('--kuro-player-ring',hex);
    root.style.setProperty('--kuro-accent',hex);
  }catch(e){}
})();
/* 5.82l · Watch player chrome.
 *
 * Wraps the existing <video> in a rounded stage with padding, and adds a control
 * bar with: play/pause, seek rail, elapsed/total, SKIP -10/+10, VOLUME slider,
 * MUTE, LOOP (one episode on repeat), SPEED, PiP and FULLSCREEN.
 *
 * The <video> element itself is never replaced, so every existing hook keeps
 * working: video-effects537.js and ai-upscale540.js both select
 * `document.querySelectorAll('video')`, and stream-player.js binds by id.
 *
 * Loop:
 *   - default OFF; the choice is remembered in localStorage
 *   - when ON the video restarts itself on 'ended' instead of firing the app's
 *     ended/auto-next path
 *   - the app can force it with window.kuroLoop582l.set(true|false)
 */
(function () {
  'use strict';

  var LOOP_KEY = 'kuro-player-loop-582l';
  var SPEEDS = [0.75, 1, 1.25, 1.5, 2];

  var ICON = {
    play: '<svg viewBox="0 0 24 24"><path d="M7 4.5v15l13-7.5z" fill="currentColor" stroke="none"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><path d="M8 5v14M16 5v14" stroke-width="3"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path d="M4 5v14M20 12H9M13 7l-5 5 5 5"/></svg>',
    fwd: '<svg viewBox="0 0 24 24"><path d="M20 5v14M4 12h11M11 7l5 5-5 5"/></svg>',
    vol: '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor" stroke="none"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/></svg>',
    mute: '<svg viewBox="0 0 24 24"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor" stroke="none"/><path d="m16 9 5 6M21 9l-5 6"/></svg>',
    loop: '<svg viewBox="0 0 24 24"><path d="M17 2.5 20.5 6 17 9.5"/><path d="M3.5 12V9a3 3 0 0 1 3-3h14"/><path d="M7 21.5 3.5 18 7 14.5"/><path d="M20.5 12v3a3 3 0 0 1-3 3h-14"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1"/></svg>',
    pip: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2.5"/><rect x="12" y="12" width="7" height="5" rx="1.2" fill="currentColor" stroke="none"/></svg>',
    full: '<svg viewBox="0 0 24 24"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>'
  };

  var root = null, video = null, els = {}, hideTimer = 0, speedIdx = 1;

  function readLoop() {
    try { return localStorage.getItem(LOOP_KEY) === '1'; } catch (_) { return false; }
  }
  function writeLoop(v) {
    try { localStorage.setItem(LOOP_KEY, v ? '1' : '0'); } catch (_) {}
  }

  function fmt(t) {
    if (!isFinite(t) || t < 0) t = 0;
    var h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = Math.floor(t % 60);
    var mm = h ? (m < 10 ? '0' + m : m) : m;
    return (h ? h + ':' : '') + mm + ':' + (s < 10 ? '0' + s : s);
  }

  function build() {
    if (document.getElementById('kuro-player-host')) return;
    var host = document.createElement('div');
    host.id = 'kuro-player-host';
    host.innerHTML =
      '<div id="kuro-stage">' + '</div>' +
      '<div id="kuro-control" role="toolbar" aria-label="Player controls">' +
        '<div id="kuro-rail" role="progressbar" aria-label="Seek" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i></i></div>' +
        '<button type="button" class="k582l-btn" data-k="play" aria-label="Play">' + ICON.play + '</button>' +
        '<button type="button" class="k582l-btn k582l-opt" data-k="back" aria-label="Back 10 seconds">' + ICON.back + '</button>' +
        '<button type="button" class="k582l-btn k582l-opt" data-k="fwd" aria-label="Forward 10 seconds">' + ICON.fwd + '</button>' +
        '<span id="kuro-time"><b>0:00</b> / <span id="kuro-dur">0:00</span></span>' +
        '<span id="kuro-spacer"></span>' +
        '<button type="button" class="k582l-btn" data-k="loop" aria-label="Loop this episode" aria-pressed="false">' + ICON.loop + '</button>' +
        '<button type="button" class="k582l-btn k582l-opt" data-k="vol" aria-label="Volume">' + ICON.vol + '</button>' +
        '<button type="button" class="k582l-btn k582l-opt" data-k="mute" aria-label="Mute">' + ICON.mute + '</button>' +
        '<button type="button" class="k582l-btn k582l-chip" data-k="speed" aria-label="Playback speed">1x</button>' +
        '<button type="button" class="k582l-btn k582l-opt" data-k="pip" aria-label="Picture in picture">' + ICON.pip + '</button>' +
        '<button type="button" class="k582l-btn" data-k="full" aria-label="Fullscreen">' + ICON.full + '</button>' +
      '</div>';
    root = host;
    document.body.appendChild(host);

    els.stage = host.querySelector('#kuro-stage');
    // the bar must live INSIDE the rounded stage so it overlays the video
    // instead of anchoring to the viewport bottom
    els.stage.appendChild(host.querySelector('#kuro-control'));
    els.rail = host.querySelector('#kuro-rail');
    els.bar = host.querySelector('#kuro-rail > i');
    els.time = host.querySelector('#kuro-time b');
    els.dur = host.querySelector('#kuro-dur');

    // move the untouched <video> into the rounded stage
    video = document.getElementById('video') || document.querySelector('video');
    if (!video) return;
    video.removeAttribute('controls');
    video.setAttribute('playsinline', '');
    els.stage.appendChild(video);

    bind();
    syncLoop();
    updatePlay();
    setInterval(tick, 250);
  }

  function bind() {
    root.querySelector('[data-k="play"]').onclick = function () {
      if (video.paused) { var p = video.play(); if (p && p.catch) p.catch(function () {}); }
      else video.pause();
    };
    root.querySelector('[data-k="back"]').onclick = function () { video.currentTime = Math.max(0, video.currentTime - 10); };
    root.querySelector('[data-k="fwd"]').onclick = function () { video.currentTime = Math.min(video.duration || 1e9, video.currentTime + 10); };

    root.querySelector('[data-k="loop"]').onclick = function () {
      setLoop(!readLoop());
      writeLoop(readLoop());
    };

    root.querySelector('[data-k="mute"]').onclick = function () {
      video.muted = !video.muted;
      root.querySelector('[data-k="mute"]').classList.toggle('is-on', video.muted);
    };
    root.querySelector('[data-k="vol"]').onclick = function () {
      // simple 3-step volume, keeps the bar compact
      video.muted = false;
      video.volume = video.volume > 0.7 ? 0.4 : (video.volume > 0.2 ? 0 : 1);
    };

    root.querySelector('[data-k="speed"]').onclick = function (e) {
      speedIdx = (speedIdx + 1) % SPEEDS.length;
      video.playbackRate = SPEEDS[speedIdx];
      e.currentTarget.textContent = SPEEDS[speedIdx] + 'x';
      e.currentTarget.classList.toggle('is-on', SPEEDS[speedIdx] !== 1);
    };

    root.querySelector('[data-k="pip"]').onclick = function () {
      try {
        if (document.pictureInPictureElement) document.exitPictureInPicture();
        else if (video.requestPictureInPicture) video.requestPictureInPicture();
      } catch (_) {}
    };
    root.querySelector('[data-k="full"]').onclick = function () {
      try {
        if (document.fullscreenElement) document.exitFullscreen();
        else (root.requestFullscreen || video.requestFullscreen || function () {}).call(root);
      } catch (_) {}
    };

    // tap the rail to seek
    els.rail.addEventListener('click', function (ev) {
      var b = els.rail.getBoundingClientRect();
      var pct = Math.min(1, Math.max(0, (ev.clientX - b.left) / b.width));
      if (isFinite(video.duration)) video.currentTime = pct * video.duration;
    });

    video.addEventListener('play', updatePlay);
    video.addEventListener('pause', updatePlay);
    video.addEventListener('click', function () {
      if (video.paused) { var p = video.play(); if (p && p.catch) p.catch(function () {}); }
      else video.pause();
    });

    // auto-hide the bar while playing
    ['pointermove', 'pointerdown', 'touchstart'].forEach(function (t) {
      root.addEventListener(t, wake, { passive: true });
    });
    wake();
  }

  function setLoop(on) {
    writeLoop(on);
    syncLoop();
    var b = root && root.querySelector('[data-k="loop"]');
    if (b) {
      b.classList.toggle('is-on', !!on);
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
      b.setAttribute('aria-label', on ? 'Looping this episode (on)' : 'Loop this episode (off)');
    }
  }
  function syncLoop() {
    var on = readLoop();
    if (video) video.loop = on;
    var b = root && root.querySelector('[data-k="loop"]');
    if (b) {
      b.classList.toggle('is-on', on);
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    }
  }

  function updatePlay() {
    var b = root && root.querySelector('[data-k="play"]');
    if (!b) return;
    b.innerHTML = video.paused ? ICON.play : ICON.pause;
    b.setAttribute('aria-label', video.paused ? 'Play' : 'Pause');
  }

  function tick() {
    if (!video) return;
    var d = video.duration;
    if (isFinite(d) && d > 0) {
      var pct = (video.currentTime / d) * 100;
      els.bar.style.width = pct.toFixed(2) + '%';
      els.rail.setAttribute('aria-valuenow', Math.round(pct));
      els.dur.textContent = fmt(d);
    }
    els.time.textContent = fmt(video.currentTime);
    var muteBtn = root.querySelector('[data-k="mute"]');
    if (muteBtn) muteBtn.classList.toggle('is-on', video.muted || video.volume === 0);
  }

  function wake() {
    if (!root) return;
    root.classList.remove('is-idle');
    clearTimeout(hideTimer);
    if (video && !video.paused) {
      hideTimer = setTimeout(function () { root.classList.add('is-idle'); }, 2600);
    }
  }

  window.kuroLoop582l = {
    set: function (on) { setLoop(!!on); },
    get: readLoop,
    el: function () { return root; }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', build, { once: true });
  } else {
    build();
  }
})();

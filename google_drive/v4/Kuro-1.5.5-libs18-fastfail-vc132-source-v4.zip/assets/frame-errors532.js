/* Bounded error reporting for the known nested MegaPlay frame only.
   Two explicit checks, no continuous timer and no access to native data. */
(function () {
  'use strict';
  var attempt = Number(window.__kuroAttempt), bridge = window.KuroPlayerReport;
  if (!Number.isSafeInteger(attempt) || attempt < 1 || !bridge || typeof bridge.postMessage !== 'function') return;
  var done = false, timers = [];
  function stop() { done = true; for (var i=0;i<timers.length;i++) clearTimeout(timers[i]); timers = []; }
  function send(kind) { if (done) return; stop(); try { bridge.postMessage(kind + ':' + attempt); } catch (_) {} }
  function visible(el) {
    try { var s=getComputedStyle(el),r=el.getBoundingClientRect(); return !!el.getClientRects().length && r.width>0 && r.height>0 && s.display!=='none' && s.visibility!=='hidden' && Number(s.opacity)>0; } catch (_) { return false; }
  }
  function inspect() {
    if (done) return;
    try {
      var title=String(document.title||'').trim();
      if (/^(just a moment|attention required|verify you are human|access denied)/i.test(title)||document.querySelector('#challenge-form,#challenge-stage,.cf-challenge,.cf-turnstile,.g-recaptcha,.h-captcha')) { send('verification'); return; }
      var videos=document.querySelectorAll('video');
      if (videos.length===1 && videos[0].error && videos[0].error.code && visible(videos[0])) { send('error'); return; }
      var errors=document.querySelectorAll('.jw-error .jw-error-msg,.jw-error .jw-error-text,.vjs-error-display .vjs-modal-dialog-content,.player-error,.video-error');
      for(var i=0;i<errors.length;i++){
        var text=String(errors[i].textContent||'').trim();
        if(visible(errors[i]) && /file not found|video not found|error loading media|no playable sources|source not supported|cannot be played/i.test(text)){send('error');return;}
      }
    } catch (_) {}
  }
  timers.push(setTimeout(inspect,4000));timers.push(setTimeout(inspect,12000));
  window.addEventListener('pagehide',stop,{once:true});
})();

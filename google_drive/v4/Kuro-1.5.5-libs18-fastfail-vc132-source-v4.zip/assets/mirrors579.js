'use strict';
// HiAnime mirror rotation (5.79).
//
// Library 2 ('dk') is a HiAnime site. The same catalogue is served from several
// public domains, so instead of teaching every parser about three more source
// codes, the domain itself rotates: hianime.dk, then hianime.tw, hianime.fm,
// hianime.al and hianimes.es.
//
// hianime.tw was verified against the live site (5.82l): it serves the identical
// flw-item / film-name / film-poster DOM as hianime.dk, so the 'dk' parser reads
// it unchanged. Everything downstream keeps using the 'dk' code path and only the
// origin changes, which means the existing search, detail, episode, server and
// failover logic applies to the new domains unchanged.
//
// A mirror is only ever skipped after a real request to it failed. Nothing is
// probed at startup and no domain is marked dead on a guess.
const HI_MIRRORS = [
 'https://hianime.dk',
 'https://hianime.tw',
 'https://hianime.fm',
 'https://hianime.al',
 'https://hianimes.es'
];

/** Hostnames of every mirror, used by the URL allowlists. */
const HI_MIRROR_HOSTS = HI_MIRRORS.map(o => o.replace(/^https:\/\//, ''));

/** True for any mirror host, including a subdomain such as cdn.hianime.dk. */
function hiIsMirrorHost(hostname) {
 const h = String(hostname || '');
 return HI_MIRROR_HOSTS.some(x => h === x || h.endsWith('.' + x));
}

/** The origin currently preferred for 'dk'. */
let hiMirrorIndex = 0;
function hiCurrentOrigin() { return HI_MIRRORS[hiMirrorIndex] || HI_MIRRORS[0]; }

/**
 * Moves to the next mirror after a failure and returns it, or '' when every
 * mirror has already been tried for this request.
 */
function hiRotateMirror(failedOrigin) {
 const current = String(failedOrigin || '').replace(/\/$/, '');
 const at = HI_MIRRORS.indexOf(current);
 if (at === -1) return '';
 const next = (at + 1) % HI_MIRRORS.length;
 if (next === hiMirrorIndex) return '';
 hiMirrorIndex = next;
 return HI_MIRRORS[next];
}

/** Keeps a known-good mirror selected across page loads in the same session. */
function hiRememberMirror(origin) {
 const at = HI_MIRRORS.indexOf(String(origin || '').replace(/\/$/, ''));
 if (at !== -1) hiMirrorIndex = at;
}

/** Maps any mirror origin onto 'dk' so callers can reuse the existing code path. */
function hiSourceCodeFor(url) {
 try { return hiIsMirrorHost(new URL(url).hostname) ? 'dk' : ''; } catch (_) { return ''; }
}

/* 5.83: Domain health sweeper.
 * Periodically probes known streaming domains and prunes dead ones so the
 * failover pool stays current without a code update. Only domains already in
 * the allowlist are probed; nothing new is added blindly. A domain is marked
 * dead only after two consecutive failures, and revived after a success. */
const SWEEP_DOMAINS = [
  'hianime.dk','hianime.tw','hianime.fm','hianime.al','hianimes.es',
  'hianime.ms','9anime.or.at','zorotv.ba','animesalt.cx','aniwaves.ru',
  'hianimeq.top','www.zenkaitv.com','animeav1.com','aniwatch.co.at',
  'www.miruro.cx','kitsunee.moe','aniwaves.tv','anikoto.cz',
  'gogoanimes.cv','www.animevillage.org'
];
const SWEEP_INTERVAL = 10 * 60 * 1000; // 10 minutes
const SWEEP_STRIKES = 2;
const sweepHealth = {};
SWEEP_DOMAINS.forEach(d => sweepHealth[d] = { alive: true, strikes: 0, lastCheck: 0 });

async function sweepDomain(host) {
  const url = 'https://' + host + '/';
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(url, { signal: controller.signal, mode: 'no-cors', cache: 'no-store' });
    clearTimeout(timer);
    // no-cors responses are opaque; a successful fetch means the domain is alive
    sweepHealth[host].strikes = 0;
    sweepHealth[host].alive = true;
    return true;
  } catch (e) {
    sweepHealth[host].strikes++;
    if (sweepHealth[host].strikes >= SWEEP_STRIKES) {
      sweepHealth[host].alive = false;
    }
    return false;
  }
}

async function sweepAllDomains() {
  const now = Date.now();
  for (const host of SWEEP_DOMAINS) {
    if (now - sweepHealth[host].lastCheck < SWEEP_INTERVAL) continue;
    sweepHealth[host].lastCheck = now;
    await sweepDomain(host);
  }
}

/* Start the sweeper. Uses setInterval; safe to run in WebView. */
if (typeof setInterval === 'function') {
  setInterval(sweepAllDomains, SWEEP_INTERVAL);
  /* initial sweep after 30s to let the app boot first */
  setTimeout(sweepAllDomains, 30000);
}

/* Expose alive-domain list for failover adapters to consult. */
function sweepAliveDomains() {
  return SWEEP_DOMAINS.filter(d => sweepHealth[d] && sweepHealth[d].alive);
}

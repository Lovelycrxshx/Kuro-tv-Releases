/* Kuro.tv 5.59: frame-local, fixed-command FX bridge.
 * Installed only in known HTTPS player origins by AndroidX WebView. It neither
 * crosses frame boundaries nor grants access to protected/cross-origin pixels.
 * Only an ordinary video-effects configuration enters this frame; no account,
 * file, arbitrary-script, URL, or navigation commands are accepted.
 */
(function(){
 'use strict';
 if(window.__kuroFxFrame559)return;
 const bridge=window.KuroFx559,epoch=window.__kuroFxEpoch559;if(!bridge||typeof bridge.postMessage!=='function'||!Number.isSafeInteger(epoch)||epoch<1)return;
 window.__kuroFxFrame559=true;
 bridge.onmessage=function(event){
  try{
   if(typeof event.data!=='string'||event.data.length>4000)return;
   const command=JSON.parse(event.data);
   if(!command||command.version!==559||!command.settings||typeof command.settings!=='object'||Array.isArray(command.settings))return;
   if(window.__kuroFx537)window.__kuroFx537.configure(command.settings);
  }catch(_){}
 };
 function ready(){try{bridge.postMessage('ready:'+epoch)}catch(_){}}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready,{once:true});else ready();
 window.addEventListener('pagehide',()=>{try{bridge.postMessage('bye:'+epoch)}catch(_){}},{once:true});
})();

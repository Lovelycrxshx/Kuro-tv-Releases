/* Discord presence progress only. Installed in explicitly allowed HTTPS player
 * frames. No media URLs, bytes, cookies, account data or player commands cross
 * the bridge. The frame starts sampling only while Kuro asks it to. */
(function(){
 'use strict';
 const bridge=window.KuroPresenceFrame565,attempt=window.__kuroPresenceAttempt565;
 if(window.__kuroPresenceFrame565||!bridge||typeof bridge.postMessage!=='function'||!Number.isSafeInteger(attempt)||attempt<1)return;
 window.__kuroPresenceFrame565=true;
 let enabled=false,timer=0,queued=0,stalled=false;
 function send(value){try{bridge.postMessage(typeof value==='string'?value:JSON.stringify(value))}catch(_){}}
 function report(){
  queued=0;if(!enabled)return;
  let value={kind:'sample',attempt:attempt,state:'selected'};
  try{
   // Ignore tiny/hidden videos and short clips to reduce accidental ad reporting.
   // If a player exposes multiple candidates we do not guess which is the episode.
   let videos=Array.from(document.querySelectorAll('video')).filter(v=>{
    let b=v.getBoundingClientRect(),style=getComputedStyle(v);
    return b.width>=80&&b.height>=45&&style.display!=='none'&&style.visibility!=='hidden'&&Number(style.opacity)!==0;
   });
   if(videos.length===1){
    let v=videos[0],d=Number(v.duration),p=Number(v.currentTime),rate=Number(v.playbackRate);
    if(Number.isFinite(d)&&d>=60&&d<=86400&&Number.isFinite(p)&&p>=0&&p<=d&&Number.isFinite(rate)&&rate>=.25&&rate<=4){
     value={kind:'sample',attempt:attempt,state:v.ended?'ended':v.paused?'paused':stalled||v.seeking||v.readyState<3?'buffering':'playing',
      position:Math.round(p*1000),duration:Math.round(d*1000),rate:rate};
    }
   }
  }catch(_){}
  send(value);
 }
 function schedule(){if(enabled&&!queued)queued=setTimeout(report,0);}
 function setEnabled(on){
  enabled=on;
  if(timer){clearInterval(timer);timer=0;}
  if(!on){if(queued){clearTimeout(queued);queued=0;}return;}
  report();timer=setInterval(report,3000);
 }
 bridge.onmessage=function(event){if(event.data==='on')setEnabled(true);else if(event.data==='off')setEnabled(false);};
 for(const name of ['playing','play','pause','waiting','stalled','seeking','seeked','ratechange','ended','loadedmetadata'])
  document.addEventListener(name,()=>{if(name==='waiting'||name==='stalled'||name==='seeking')stalled=true;else if(name==='playing'||name==='seeked'||name==='ended')stalled=false;schedule()},true);
 function ready(){send('ready:'+attempt)}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready,{once:true});else ready();
 window.addEventListener('pagehide',()=>{setEnabled(false);send('bye:'+attempt)},{once:true});
})();

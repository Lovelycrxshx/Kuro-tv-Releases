'use strict';
// Library 13: a small independently written adapter for the public
// AnimeParadise catalogue and its ordinary website player. The API routes were
// documented by the MIT-declared anime-sdk project:
// https://github.com/hexxt-git/anime-sdk (package.json). No SDK code is bundled.
// Its page player is third-party; a SUB label is source-reported, not a promise.
// Off by default. A 403/429 is remembered across app restarts; only an explicit
// user retry after resolving any verification can clear it.
function paradiseEnabled(){try{return localStorage.getItem('kuro-paradise-enabled')==='1'}catch(_){return false}}
function paradiseBlocked(){try{return localStorage.getItem('kuro-paradise-blocked')==='1'}catch(_){return true}}
function paradiseMarkBlocked(){try{localStorage.setItem('kuro-paradise-blocked','1')}catch(_){}if(typeof syncParadiseControls==='function')syncParadiseControls()}
function paradiseCatalogUrl(spec,page){
 if(!paradiseEnabled()||paradiseBlocked()||spec.mode!=='search'||page!==1)return '';
 const q=String(spec.query||'').trim();if(!q||q.length>200)return '';
 return base('paradise')+'/search?q='+encodeURIComponent(q)+'&limit=20';
}
function paradiseAniListHint(poster){
 try{const p=new URL(poster);if(p.protocol!=='https:'||p.hostname!=='s4.anilist.co'||p.port||p.username||p.password)return 0;
  const m=p.pathname.match(/^\/file\/anilistcdn\/media\/anime\/cover\/(?:large|medium)\/b(?:x)?([1-9][0-9]{0,7})[-.]/);return m?Number(m[1]):0;
 }catch(_){return 0}
}
function paradiseItem(value){
 if(!value||typeof value!=='object'||adultFlag(value))return null;
 const id=String(value._id||''),year=Number(value.animeSeason?.year||String(value.startDate||'').slice(0,4));
 const names=[value.title,value.alternativeTitle?.english,value.alternativeTitle?.romaji,value.alternativeTitle?.native].filter(s=>typeof s==='string'&&s.trim()).map(s=>s.trim().slice(0,240));
 if(!/^[A-Za-z0-9_-]{1,80}$/.test(id)||!names.length||!Number.isInteger(year)||year<1900||year>2100)return null;
 const images=[value.posterImage?.large,value.posterImage?.medium].filter(x=>typeof x==='string');
 const hints=[...new Set(images.map(paradiseAniListHint).filter(Boolean))];if(hints.length!==1)return null;
 const img=images.find(x=>paradiseAniListHint(x)===hints[0])||'';
 return {source:'paradise',title:names[0],titles:[...new Set(names)],paradiseId:id,sourceYear:year,anilistId:hints[0],
  url:base('paradise')+'/anime/'+encodeURIComponent(id)+'/episode',img:validUrl(img,'image'),meta:'Anime · '+year,
  genres:Array.isArray(value.genres)?value.genres.filter(x=>typeof x==='string').slice(0,25):[]};
}
async function paradiseCatalog(spec,page,raw){
 const data=JSON.parse(raw);if(data?.success!==true||!Array.isArray(data.data))throw Error('Library 13 returned an unreadable catalogue.');
 // The AniList cover filename is only a hint, not a confirmed mapping. Require
 // AniList to confirm the exact title, release year, ID and non-adult flag.
 const candidates=data.data.slice(0,20).map(paradiseItem).filter(Boolean),items=await classifyAdded(candidates);
 return {items,hasNext:false}; // only the verified first search page is used
}
function paradiseWatchUrl(id,uid){
 if(!/^[A-Za-z0-9_-]{1,80}$/.test(String(id))||!/^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(String(uid)))return '';
 return 'https://www.animeparadise.moe/watch/'+uid+'?origin='+encodeURIComponent(id);
}
async function paradiseDetails(item,raw){
 const id=String(item?.paradiseId||'');
 if(item?.source!=='paradise'||!allowClassifiedItem(item)||item.url!==base('paradise')+'/anime/'+encodeURIComponent(id)+'/episode')throw Error('This Library 13 title could not be verified.');
 const body=JSON.parse(raw);if(body?.success!==true||!Array.isArray(body.data))throw Error('Library 13 episode list unavailable.');
 const groups=new Map();
 for(const row of body.data.slice(0,6000)){
  const n=Number(row?.number),uid=String(row?.uid||'');if(!validEpisodeNumber(row?.number)||String(row?.origin||'')!==id)continue;
  const url=paradiseWatchUrl(id,uid);if(!url||!validUrl(url))continue;
  const key=String(n),ep={number:key,name:String(row.title||'').slice(0,160),url,paradiseId:id,paradiseUid:uid};
  const group=groups.get(key)||new Map();group.set(uid,ep);groups.set(key,group);
 }
 const episodes=[...groups.values()].filter(g=>g.size===1).map(g=>[...g.values()][0]).sort((a,b)=>Number(a.number)-Number(b.number));
 item.counts={total:episodes.length?String(episodes.length):null};
 return {episodes,facts:[['Audio','Sub · source-reported'],['Player','Third-party website']]};
}
async function paradiseServers(item,ep){
 const id=String(item?.paradiseId||''),uid=String(ep?.paradiseUid||'');
 if(item?.source!=='paradise'||!allowClassifiedItem(item)||ep?.paradiseId!==id||!validEpisodeNumber(ep?.number))return [];
 const url=paradiseWatchUrl(id,uid);if(!url||ep.url!==url)return [];
 return [{name:'Site player',lang:'sub',url,referer:'paradise',note:'Source-reported'}];
}
async function fallbackParadise(title,number,expected={}){
 const id=Number(expected.anilistId);if(!validEpisodeNumber(number)||!Number.isSafeInteger(id)||id<1)return [];
 const result=await fetchCatalogPage({source:'paradise',mode:'search',query:title},1);
 const items=result.items.filter(x=>Number(x.anilistId)===id&&matchTitle(x.title)===matchTitle(title)&&(!expected.malId||!x.malId||Number(expected.malId)===Number(x.malId)));
 const unique=[...new Map(items.map(x=>[x.url,x])).values()];if(unique.length!==1)return [];
 const item=unique[0],details=await paradiseDetails(item,await get(item.url)),episodes=details.episodes.filter(e=>e.number===String(Number(number)));
 return episodes.length===1?paradiseServers(item,episodes[0]):[];
}

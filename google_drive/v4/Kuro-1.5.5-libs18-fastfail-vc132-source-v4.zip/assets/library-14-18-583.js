'use strict';
/*
 * Kuro 5.83 — Library 14–18: five additional source adapters.
 *
 * Internally we use short codes; the UI labels them by number, matching the
 * existing "Library N" convention. Each adapter was written against the live
 * sites on 2026-11-25 and verified to reach a real <player host>/stream URL.
 *
 * Deliberately excluded (and why):
 *   - miruro.bz      Cloudflare 403 from every datacenter IP. Same platform as
 *                    Library 11 (miruro.cx), which is already wired. Adding it
 *                    would just be a second copy of a source that returns 403.
 *   - anivault.tv    Cloudflare 403. Its streams come from a third-party
 *                    scraper API (SH0MIK/Anivault-API), not the site itself.
 *                    Depending on an unofficial middleman is not something this
 *                    app does — the existing adapters talk to sites directly.
 *   - animesuge.or.at  404 on every path. The domain is parked.
 *   - animerulz.co.in  Serves an empty document. Dead domain.
 *
 * Nothing here guesses: every function verifies the title and the episode
 * number, and only emits an https URL on a host we explicitly allow.
 */

/* ------------------------------------------------------------------ helpers */

// Titles are compared on letters+digits only, lowercased.
function l14Norm(s){return String(s==null?'':s).toLowerCase().replace(/[^a-z0-9]+/g,'');}

// True when e is exactly the episode we asked for (not 1 when we wanted 11).
function l14IsEp(fileName,num){
  let n=Number(num);if(!Number.isInteger(n)||n<1||n>5000)return false;
  return new RegExp('(?:^|[^0-9])0*'+n+'(?:[^0-9]|$)').test(String(fileName||''));
}

// Player hosts these adapters are allowed to hand back. Keep in sync with
// MainActivity.playerHost().
const L14_PLAYERS=['megaplay.buzz','player.videasy.net','player.abyssplayer.com','abyssplayer.com','ravok.buzz'];

function l14Player(url){
  try{
    let u=new URL(String(url||''));
    if(u.protocol!=='https:'||u.username||u.password||u.port)return '';
    let h=u.hostname.toLowerCase();
    if(!L14_PLAYERS.some(x=>h===x||h.endsWith('.'+x)))return '';
    return u.href;
  }catch(_){return '';}
}

// Pull the servers an episode page already embedded as JSON inside onclick=
// (animesalt.me shape: triggerEpisode([{"lang":"English","url":"https://..."}], ...))
function l14ExtractTriggered(html,pageUrl){
  let out=[],seen=new Set();
  // onclick may be single-quoted with \" escapes (X-Requested-With variant) or
  // double-quoted with &quot; entities. Normalise both before JSON.parse.
  let text=String(html||'').replace(/&quot;/g,'"').replace(/&#0?39;/g,"'").replace(/&amp;/g,'&');
  text=text.replace(/\\"/g,'"');       // \" -> "
  let re=/triggerEpisode\(\s*(\[[\s\S]*?\])\s*,/g,m;
  while((m=re.exec(text))){
    let raw=m[1];
    try{raw=JSON.parse(raw);}catch(_){continue;}
    if(!Array.isArray(raw))continue;
    for(const s of raw){
      if(!s||typeof s.url!=='string')continue;
      let url=l14Player(s.url);if(!url||seen.has(url))continue;
      let lang=/english|dub/i.test(String(s.lang||''))?'dub':'sub';
      seen.add(url);out.push({name:String(s.name||'Server').slice(0,40),lang,url,referer:pageUrl});
    }
  }
  return out;
}

// Pull <iframe src> / data-src / data-embed player URLs out of a page.
function l14ExtractIframes(html,pageUrl){
  let out=[],seen=new Set();
  let re=/<(?:iframe|div)[^>]*?(?:data-)?(?:src|embed)="([^"]+)"[^>]*>/gi,m;
  while((m=re.exec(html))){
    let raw=m[1].replace(/&amp;/g,'&');
    let url=l14Player(raw);if(!url||seen.has(url))continue;
    seen.add(url);out.push({name:'HD-1',lang:null,url,referer:pageUrl});
  }
  return out;
}

/* --------------------------------------------- Library 14 — animesuge.at ---
 * JSON API: /api/animesuge/anime/search?keyword=  → {result:{html,count}}
 *           /api/animesuge/anime/episodes?id=      → episode cards
 *           /api/animesuge/anime/server/list?id=   → base64 data-link attrs
 * Every server link decodes to megaplay.buzz.
 */
const L14_SUGE_API='https://animesuge.at/api/animesuge';

async function l14SugeSearch(title){
  let raw=await get(L14_SUGE_API+'/anime/search?keyword='+encodeURIComponent(title));
  let data;try{data=JSON.parse(raw);}catch(_){return [];}
  let html=data&&data.result&&data.result.html;if(typeof html!=='string')return [];
  let doc=parse(html),out=[];
  for(const a of doc.querySelectorAll('a.item[href]')){
    let href=String(a.getAttribute('href')||'');
    if(!/^https:\/\/animesuge\.at\/anime\/[a-z0-9-]+\/?$/i.test(href))continue;
    let name=a.querySelector('.name');let t=String(name?name.textContent:'').trim();
    let img=a.querySelector('img');let poster=img?String(img.getAttribute('src')||''):'';
    if(!t)continue;
    out.push({title:t,url:href,img:poster,source:'suge',meta:'AniSuge'});
  }
  return out;
}

// Returns the anime id (data-id) for the one exact-title match, or 0.
async function l14SugeAnimeId(title){
  let list=(await l14SugeSearch(title)).filter(x=>l14Norm(x.title)===l14Norm(title));
  if(list.length!==1)return 0;
  let page=await get(list[0].url);
  if(sourceNeedsVerification(parse(page)))throw Error('The library requested human verification.');
  let m=/data-id="(\d+)"/.exec(page);
  return m?Number(m[1]):0;
}

// Chain, verified live 2026-11-25:
//   anime id  → /episode/list?id=<animeId>  yields per-episode data-id + data-num
//   episode id → /server/list?id=<episodeId> yields data-link (base64) servers
async function sugeServers(title,number){
  let want=Number(number);if(!Number.isInteger(want)||want<1||want>5000)return [];
  let animeId=await l14SugeAnimeId(title);if(!animeId)return [];

  // 1. episode id for exactly this episode number
  let raw=await get(L14_SUGE_API+'/episode/list?id='+animeId);
  let data;try{data=JSON.parse(raw);}catch(_){return [];}
  let html=data&&data.result;if(typeof html!=='string')return [];
  let epId=0;
  let re=/<a[^>]*href="([^"]*)"[^>]*data-id="(\d+)"[^>]*data-num="(?:Episode\s*)?(\d+)"/g,m;
  while((m=re.exec(html))){
    if(Number(m[3])===want){epId=Number(m[2]);break;}
  }
  if(!epId)return [];

  // 2. servers for that episode id
  let raw2=await get(L14_SUGE_API+'/server/list?id='+epId);
  let d2;try{d2=JSON.parse(raw2);}catch(_){return [];}
  let h2=d2&&d2.result;if(typeof h2!=='string')return [];
  let out=[],seen=new Set();
  let re2=/data-type="(sub|dub)"[^>]*?data-link="([A-Za-z0-9+/=]+)"[^>]*?data-sv-id="([^"]+)"/g,m2;
  while((m2=re2.exec(h2))){
    let lang=m2[1]==='dub'?'dub':'sub',b64=m2[2],svId=m2[3];
    let url='';
    try{url=l14Player(atob(b64));}catch(_){url='';}
    if(!url||seen.has(url))continue;
    seen.add(url);out.push({name:String(svId||'Server').slice(0,40),lang,url,referer:'https://animesuge.at/'});
  }
  return out;
}

/* --------------------------------------------- Library 15 — animesuge.by ---
 * WordPress. Search: /?s=title  → cards carry data-url=".../slug-episode-N/"
 * Episode page carries <div class="server" data-embed="megaplay.buzz/...">
 */
async function l15BySearch(title){
  let raw=await get('https://animesuge.by/?s='+encodeURIComponent(title));
  let doc=parse(raw),out=[];
  for(const item of doc.querySelectorAll('[data-url]')){
    let u=String(item.getAttribute('data-url')||'');
    if(!/^https:\/\/animesuge\.by\/[a-z0-9-]+-episode-\d+\/?$/i.test(u))continue;
    let t=String(item.getAttribute('data-title')||'').trim();
    let a=item.querySelector('a.poster[href]');
    let poster=a?String(a.getAttribute('href')||''):''; // not a real poster; kept empty
    if(!t)continue;
    // Series slug = everything before the first -episode-N
    let slug=(u.match(/^https:\/\/animesuge\.by\/(.+?)-episode-\d+\/?$/i)||[])[1]||'';
    if(!slug)continue;
    out.push({title:t,slug,img:'',source:'sugeby',meta:'AniSuge'});
  }
  return out;
}

async function byServers(title,number){
  let want=Number(number);if(!Number.isInteger(want)||want<1)return [];
  let list=(await l15BySearch(title)).filter(x=>l14Norm(x.title)===l14Norm(title));
  // de-duplicate by slug (search returns one card per episode)
  let slugs=[...new Set(list.map(x=>x.slug))];
  if(slugs.length!==1)return [];
  let url='https://animesuge.by/'+slugs[0]+'-episode-'+want+'/';
  let html=await get(url);
  if(sourceNeedsVerification(parse(html)))throw Error('The library requested human verification.');
  let out=[],seen=new Set();
  let re=/<div class="server[^"]*"[^>]*data-embed="([^"]+)"[^>]*title="([^"]*)"/g,m;
  while((m=re.exec(html))){
    let u=l14Player(m[1].replace(/&amp;/g,'&'));
    if(!u||seen.has(u))continue;
    // Language lives on the enclosing server-type block; fall back to the path.
    let lang=/\/dub(?:[?/]|$)/i.test(u)?'dub':'sub';
    seen.add(u);out.push({name:String(m[2]||'Server').slice(0,40),lang,url:u,referer:url});
  }
  return out;
}

/* --------------------------------------------- Library 16 — animesalt.me ---
 * WordPress. Search /?s=  Episode tiles embed the stream JSON in onclick.
 * Player host is player.videasy.net.
 */
async function l16SaltMeSearch(title){
  let raw=await get('https://animesalt.me/?s='+encodeURIComponent(title));
  let doc=parse(raw),out=[];
  // Search results are standard WP posts: h2.entry-title > a[rel=bookmark]
  for(const h of doc.querySelectorAll('.entry-title')){
    let a=h.querySelector('a[href]');if(!a)continue;
    let u=String(a.getAttribute('href')||'');
    if(!/^https:\/\/animesalt\.me\/(tv|movie)\/[a-z0-9-]+\/?$/i.test(u))continue;
    let t=String(a.textContent||'').trim();
    if(!t)continue;
    out.push({title:t,url:u,img:'',source:'saltme',meta:'Anime Salt'});
  }
  return out;
}

async function saltMeServers(title,number){
  let want=Number(number);if(!Number.isInteger(want)||want<1)return [];
  let list=(await l16SaltMeSearch(title)).filter(x=>l14Norm(x.title)===l14Norm(title));
  let urls=[...new Set(list.map(x=>x.url))];
  if(urls.length!==1)return [];
  let html=await get(urls[0]);
  if(sourceNeedsVerification(parse(html)))throw Error('The library requested human verification.');
  let doc=parse(html);
  // Each .ep-tile has data-slug="ep-N" and an onclick carrying the JSON.
  for(const tile of doc.querySelectorAll('.ep-tile')){
    let slug=String(tile.getAttribute('data-slug')||'');
    let m=slug.match(/^ep-(\d+)$/i);
    if(!m||Number(m[1])!==want)continue;
    let onclick=String(tile.getAttribute('onclick')||'');
    let servers=l14ExtractTriggered(onclick,urls[0]);
    if(servers.length)return servers;
  }
  return [];
}

/* ------------------------------------------ Library 17 — animerulz.com.in ---
 * Series: /anime/slug/  Episodes: /slug-episode-N/
 * Episode page embeds /gogo-player.php?ep=<id>&type=sub which contains the
 * megaplay.buzz iframe. We fetch that hop so we hand back a real player URL.
 */
async function l17RulzSearch(title){
  let raw=await get('https://animerulz.com.in/?s='+encodeURIComponent(title));
  let doc=parse(raw),out=[];
  for(const a of doc.querySelectorAll('a[href]')){
    let u=String(a.getAttribute('href')||'');
    if(!/^https:\/\/animerulz\.com\.in\/anime\/[a-z0-9-]+\/?$/i.test(u))continue;
    let t=String(a.getAttribute('title')||'').trim()||String(a.textContent||'').trim();
    if(!t)continue;
    out.push({title:t,url:u,img:'',source:'rulz',meta:'Animerulz'});
  }
  return out;
}

async function rulzServers(title,number){
  let want=Number(number);if(!Number.isInteger(want)||want<1)return [];
  let list=(await l17RulzSearch(title)).filter(x=>l14Norm(x.title)===l14Norm(title));
  let urls=[...new Set(list.map(x=>x.url))];
  if(urls.length!==1)return [];
  let slug=urls[0].match(/\/anime\/([a-z0-9-]+)\/?$/i)[1];
  let epUrl='https://animerulz.com.in/'+slug+'-episode-'+want+'/';
  let html=await get(epUrl);
  if(sourceNeedsVerification(parse(html)))throw Error('The library requested human verification.');
  // Find the gogo-player hop(s) for this episode.
  let out=[],seen=new Set();
  let re=/src="(\/gogo-player\.php\?[^"]+)"/g,m;
  while((m=re.exec(html))){
    let hop='https://animerulz.com.in'+m[1].replace(/&amp;/g,'&');
    let inner;
    try{inner=await get(hop);}catch(_){continue;}
    for(const s of l14ExtractIframes(inner,epUrl)){
      if(seen.has(s.url))continue;
      let lang=/type=dub/i.test(hop)?'dub':'sub';
      seen.add(s.url);out.push({name:s.name,lang,url:s.url,referer:epUrl});
    }
  }
  return out;
}

/* --------------------------------------------- Library 18 — animesky.app ---
 * WordPress. Search /?keyword=   Series /series/slug/   Ep /episode/slug-1xN/
 * Episode page carries two things:
 *   iframe src="https://ravok.buzz/video/<hash>"
 *   iframe data-src="https://animesky.app/as-cdn/clone/multi-lang-plyr.php?data=<b64 JSON>"
 * The base64 payload lists per-language abyssplayer.com links.
 *
 * Abyssplayer is a JS-only player (no <video> in its HTML), so we do NOT add
 * those: the app can only play what it can detect as HLS/embed. Ravok is a
 * plain embed page, so that is the one we forward.
 */
async function l18SkySearch(title){
  let raw=await get('https://animesky.app/?keyword='+encodeURIComponent(title));
  // Result cards pair an empty <a class="chart-poster" href=...> with a following
  // <div class="chart-title">TITLE</div>. Scan in document order and pair them,
  // rather than relying on nested traversal.
  let re=/<a[^>]*class="chart-poster"[^>]*href="([^"]+)"[\s\S]*?<div[^>]*class="chart-title"[^>]*>([\s\S]*?)<\/div>/gi,m;
  let out=[],seen=new Set();
  while((m=re.exec(raw))){
    let u=m[1].replace(/&amp;/g,'&');
    if(!/^https:\/\/animesky\.app\/series\/[a-z0-9-]+\/?$/i.test(u))continue;
    let t=m[2].replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
    if(!t||seen.has(u))continue;
    seen.add(u);out.push({title:t,url:u,img:'',source:'sky',meta:'Anime Sky'});
  }
  // Fallback: some layouts put the href first and the title after in .tt
  if(!out.length){
    let re2=/<a[^>]*href="(https:\/\/animesky\.app\/series\/[a-z0-9-]+\/?)"[^>]*>[\s\S]{0,600}?<div[^>]*class="(?:chart-title|tt)"[^>]*>([\s\S]*?)<\/div>/gi,m2;
    while((m2=re2.exec(raw))){
      let u=m2[1];
      if(seen.has(u))continue;
      let t=m2[2].replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
      if(!t)continue;
      seen.add(u);out.push({title:t,url:u,img:'',source:'sky',meta:'Anime Sky'});
    }
  }
  return out;
}

async function skyServers(title,number){
  let want=Number(number);if(!Number.isInteger(want)||want<1)return [];
  let list=(await l18SkySearch(title)).filter(x=>l14Norm(x.title)===l14Norm(title));
  let urls=[...new Set(list.map(x=>x.url))];
  if(urls.length!==1)return [];
  let slug=urls[0].match(/\/series\/([a-z0-9-]+)\/?$/i)[1];
  let epUrl='https://animesky.app/episode/'+slug+'-1x'+want+'/';
  let html=await get(epUrl);
  if(sourceNeedsVerification(parse(html)))throw Error('The library requested human verification.');
  let out=[],seen=new Set();
  let re=/<iframe[^>]*?(?:data-)?src="([^"]+)"[^>]*>/gi,m;
  while((m=re.exec(html))){
    let raw=m[1].replace(/&amp;/g,'&');
    let u=l14Player(raw);
    if(!u||seen.has(u))continue;
    if(/multilang-plyr/i.test(u))continue; // abyssplayer payload: JS-only, unplayable
    seen.add(u);out.push({name:'HD-1',lang:'sub',url:u,referer:epUrl});
  }
  // Fall back to a bare ravok.buzz/video/<hash> reference if no <iframe> matched.
  if(!out.length){
    let r=/https?:\/\/ravok\.buzz\/video\/[a-f0-9]{16,}/i.exec(html);
    if(r){let u=l14Player(r[0]);if(u)out.push({name:'HD-1',lang:'sub',url:u,referer:epUrl});}
  }
  return out;
}

/* ------------------------------------------------- register the adapters --- */

window.KuroLibrary14to18={
  sugeServers,byServers,saltMeServers,rulzServers,skyServers,
  search:{
    suge:l14SugeSearch, sugeby:l15BySearch, saltme:l16SaltMeSearch,
    rulz:l17RulzSearch, sky:l18SkySearch
  }
};

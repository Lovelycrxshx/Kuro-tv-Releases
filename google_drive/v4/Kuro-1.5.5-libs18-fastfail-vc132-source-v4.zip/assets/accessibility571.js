'use strict';
/* Keep keyboard focus inside the new local dialogs; no background polling. */
(()=>{
 document.addEventListener('keydown',e=>{
  if(e.key!=='Tab')return;
  // Catalogue and status dialogs manage or require their own topmost focus scope.
  const top=document.querySelector('#catalog-modal573, #status-modal');
  if(top){if(top.id==='catalog-modal573')return;const buttons=[...top.querySelectorAll('button:not([disabled])')].filter(x=>x.getClientRects().length);if(!buttons.length){e.preventDefault();return}const i=buttons.indexOf(document.activeElement);if(e.shiftKey&&i<=0){e.preventDefault();buttons[buttons.length-1].focus()}else if(!e.shiftKey&&(i<0||i===buttons.length-1)){e.preventDefault();buttons[0].focus()}return}
  const modal=document.querySelector('#anime-prefs571 .dialog-panel571, #privacy-overlay571 .dialog-panel571, #queue-overlay571 .dialog-panel571')||document.querySelector('#account-overlay.artwork-picker571 .account-dialog');
  if(!modal)return;
  const focusable=Array.from(modal.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),a[href],[tabindex]:not([tabindex="-1"])')).filter(x=>x.getClientRects().length&&!x.hidden);
  if(!focusable.length){e.preventDefault();return}
  const first=focusable[0],last=focusable[focusable.length-1],active=document.activeElement;
  if(e.shiftKey&&(active===first||!modal.contains(active))){e.preventDefault();last.focus()}
  else if(!e.shiftKey&&(active===last||!modal.contains(active))){e.preventDefault();first.focus()}
 },true);
})();

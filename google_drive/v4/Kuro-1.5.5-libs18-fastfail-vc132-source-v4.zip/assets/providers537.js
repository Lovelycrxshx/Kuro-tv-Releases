'use strict';
// Library 12: independently written adapter to the publicly documented routes
// of Kitsune (MIT; https://github.com/Dovakiin0/Kitsune). Its catalog is
// AniList-based; its AniKoto episode mapping and SUB/DUB tags are source reports.
// Only existing MegaPlay embeds are opened. HLS URLs, arbitrary referers,
// unknown hosts and challenge bypasses are intentionally not forwarded.
function kitsuneCatalogUrl(spec,page){
 if(!Number.isInteger(page)||page<1||page>250)return '';
 const q=String(spec.query||'').trim(),p=new URLSearchParams({page:String(page),perPage:'20'}),root=base('kitsune');
 if(spec.mode==='search'){if(!q)return '';p.set('query',q);return root+'/api/search?'+p}
 if(spec.mode==='all'||spec.mode==='popularShelf')return root+'/api/popular?'+p;
 if(spec.mode==='genre'||spec.mode==='music'){let g=sourceGenre('kitsune',spec.genre||'music');if(!g)return '';p.set('genre',g);return root+'/api/filter?'+p}
 return '';
}
function kitsuneItem(value){
 if(!value||typeof value!=='object'||value.isAdult!==false)return null;
 const id=Number(value.id);if(!Number.isSafeInteger(id)||id<1||id>99999999)return null;
 let t=value.title||{},names=[t.english,t.romaji,t.native].filter(x=>typeof x==='string'&&x.trim()).map(x=>x.trim().slice(0,240));
 if(!names.length)return null;
 let format=String(value.format||'Anime').slice(0,40),year=Number(value.seasonYear)||0;
 return {title:names[0],titles:[...new Set(names)],source:'kitsune',anilistId:id,malId:Number(value.idMal)||0,
  url:base('kitsune')+'/api/info/'+id,img:validUrl(value.coverImage?.large||'','image'),meta:format+(year?' · '+year:'')};
}
function kitsuneCatalog(spec,page,raw){
 const data=JSON.parse(raw);if(!Array.isArray(data?.results))throw Error('Library 12 returned an unreadable catalogue.');
 return {items:data.results.map(kitsuneItem).filter(Boolean),hasNext:!!data.hasNextPage&&page<250};
}
async function kitsuneDetails(item,raw){
 const data=JSON.parse(raw),verified=kitsuneItem(data),id=Number(item?.anilistId);
 if(!verified||verified.anilistId!==id||item.url!==verified.url||!verified.titles.some(x=>matchTitle(x)===matchTitle(item.title)))throw Error('The exact title could not be verified in Library 12.');
 let malId=Number(data.idMal)||0;if(Number(item.malId)&&malId&&Number(item.malId)!==malId)throw Error('Conflicting catalogue identifiers.');
 if(malId)item.malId=malId;
 item.description=typeof data.description==='string'?parse(data.description).body.textContent.replace(/\s+/g,' ').trim().slice(0,3000):'';
 const body=JSON.parse(await get(base('kitsune')+'/api/episodes/anikoto/'+id+'?map=false'));
 const provider=body?.providers?.anikoto,meta=provider?.meta,lists=provider?.episodes;
 if(!meta||!lists||!malId||Number(meta.malId)!==malId)throw Error('This Library 12 episode mapping could not be verified by its catalogue ID.');
 const groups=new Map(),seen=new Set(),ambiguous=new Set();
 for(const lang of ['sub','dub'])for(const row of Array.isArray(lists[lang])?lists[lang]:[]){
  let n=Number(row?.number);if(!Number.isInteger(n)||n<1||n>5000)continue;
  if(row.id!==`watch/anikoto/${id}/${lang}/anikoto-${n}`||row.audio!==lang)continue;
  let key=String(n),pair=lang+'|'+key,old=groups.get(key)||{number:key,name:String(row.title||'').slice(0,160),kitsuneId:id,modes:[],url:base('kitsune')+`/api/watch/anikoto/${id}/sub/anikoto-${n}`};
  if(seen.has(pair)){ambiguous.add(pair);old.modes=old.modes.filter(x=>x!==lang)}else if(!ambiguous.has(pair)){seen.add(pair);old.modes.push(lang)}
  if(!old.name&&row.title)old.name=String(row.title).slice(0,160);groups.set(key,old);
 }
 const episodes=[...groups.values()].filter(x=>x.modes.length).sort((a,b)=>Number(a.number)-Number(b.number));
 const sub=episodes.filter(x=>x.modes.includes('sub')).length,dub=episodes.filter(x=>x.modes.includes('dub')).length;
 item.counts={sub:sub?String(sub):null,dub:dub?String(dub):null,total:episodes.length?String(episodes.length):null};
 const facts=[['Format',String(data.format||'')],['Status',String(data.status||'')]].filter(x=>x[1]);
 return {episodes,facts};
}
async function kitsuneServers(item,ep){
 const id=Number(item?.anilistId),number=Number(ep?.number);
 if(!Number.isSafeInteger(id)||id<1||ep?.kitsuneId!==id||!Number.isInteger(number)||number<1||number>5000||!Array.isArray(ep.modes))return [];
 const modes=['dub','sub'].filter(x=>ep.modes.includes(x)),out=[],seen=new Set();
 // Prefer English dub, but make these sequential so a 403/429 immediately
 // stops the source rather than launching another language request.
 for(const lang of modes){
  let body;try{body=JSON.parse(await get(base('kitsune')+`/api/watch/anikoto/${id}/${lang}/anikoto-${number}`))}catch(error){if(unifiedProblem(error))throw error;continue}
  if(Number(body?.anilistId)!==id||Number(body?.episode)!==number||String(body?.audio||'').toLowerCase()!==lang)continue;
  if(Number(item.malId)&&Number(body.malId)&&Number(item.malId)!==Number(body.malId))continue;
  for(const stream of Array.isArray(body.streams)?body.streams:[]){
   let url=validUrl(stream?.embedUrl||(stream?.type==='embed'?stream.url:'')||'','player');if(!url)continue;let u=new URL(url),ref=String(stream.referer||'');
   if([...u.searchParams.keys()].some(k=>k!=='s')||(u.searchParams.has('s')&&u.searchParams.get('s')!=='tcdn'))continue;
   if(u.hostname!=='megaplay.buzz'||u.username||u.password||u.port||!/^\/(?:videojs\/)?stream\/[A-Za-z0-9_-]+\/[0-9]+\/(?:sub|dub)$/.test(u.pathname)||!u.pathname.endsWith('/'+lang))continue;
   if(ref){try{let r=new URL(ref);if(r.protocol!=='https:'||r.hostname!=='megaplay.buzz'||r.port||r.username||r.password)continue}catch(_){continue}}
   const key=url+'|'+lang;if(seen.has(key))continue;seen.add(key);out.push({name:'Server',lang,url,referer:'kitsune',note:'Source-reported'});if(out.length>=12)return out;
  }
 }
 return out;
}
async function fallbackKitsune(title,number,expected={}){
 if(!validEpisodeNumber(number))return [];
 const id=Number(expected.anilistId);if(!Number.isSafeInteger(id)||id<1)return [];
 const url=base('kitsune')+'/api/info/'+id,raw=await get(url),item=kitsuneItem(JSON.parse(raw));
 if(!item||![item.title,...item.titles].some(x=>matchTitle(x)===matchTitle(title)))return [];
 if(expected.malId&&item.malId&&Number(expected.malId)!==item.malId)return [];
 const detail=await kitsuneDetails(item,raw),matches=detail.episodes.filter(x=>x.number===String(Number(number)));
 return matches.length===1?kitsuneServers(item,matches[0]):[];
}

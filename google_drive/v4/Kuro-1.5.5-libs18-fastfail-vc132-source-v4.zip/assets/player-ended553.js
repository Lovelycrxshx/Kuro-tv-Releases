'use strict';
(()=>{
 if(window.__kuroEnded553)return;
 window.__kuroEnded553=true;
 let sent85=false,sentEnd=false,lastCheck154=0;
 const maxTimeMap=new WeakMap();
 function trackMax(v){
  const prev=maxTimeMap.get(v)||0;
  if(Number.isFinite(v.currentTime)&&v.currentTime>prev){
   maxTimeMap.set(v,v.currentTime);
   return v.currentTime;
  }
  return prev;
 }
 function checkVideo154(v,fromEndedEvent){
  if(!(v instanceof HTMLVideoElement))return;
  const dur=v.duration;
  if(!Number.isFinite(dur)||dur<45)return;
  const cur=Number.isFinite(v.currentTime)?v.currentTime:0;
  const peak=Math.max(cur,trackMax(v));
  if(!sent85&&(cur>=dur*0.85||peak>=dur*0.85)){
   sent85=true;
   try{window.KuroFinished553?.postMessage('progress85')}catch(_){}
  }
  if(!sentEnd){
   const genuinelyEnded=(fromEndedEvent||v.ended)&&(cur>=dur*0.80||peak>=dur*0.85);
   const atTailEnd=!v.seeking&&v.paused&&dur>=45&&cur>=dur-1.0&&peak>=dur*0.92;
   if(genuinelyEnded||atTailEnd){
    sentEnd=true;
    try{window.KuroFinished553?.postMessage('ended')}catch(_){}
   }
  }
 }
 document.addEventListener('ended',e=>checkVideo154(e.target,true),true);
 document.addEventListener('pause',e=>checkVideo154(e.target,false),true);
 document.addEventListener('timeupdate',e=>{
  if(e.target instanceof HTMLVideoElement)trackMax(e.target);
  const now=Date.now();
  if(now-lastCheck154<1500)return;
  lastCheck154=now;
  checkVideo154(e.target,false);
 },true);
})();

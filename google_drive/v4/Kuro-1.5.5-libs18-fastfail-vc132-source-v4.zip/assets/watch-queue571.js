'use strict';
/* Private, manual episode queue. One key is changed atomically per edit. */
(()=>{
 const KEY='kuro-watch-queue571-v1',MAX=200;
 const escape=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function identity(row){
  try{const item=row?.item,ep=row?.ep;if(!item||!unifiedCodes.includes(item.source)||typeof item.title!=='string'||!item.title.trim()||item.title.length>500||typeof item.url!=='string'||item.url.length>2048||!validUrl(item.url)||!validEpisodeNumber(ep?.number))return '';
   const show=new URL(item.url),origin=new URL(base(item.source));if(show.port||show.username||show.password||!(show.hostname===origin.hostname||show.hostname.endsWith('.'+origin.hostname)))return '';
   if(ep.url&&(!validUrl(ep.url)||String(ep.url).length>2048))return '';
   return item.source+'|'+show.href+'|'+String(Number(ep.number));
  }catch(_){return ''}
 }
 function read(){let raw=localStorage.getItem(KEY);if(raw===null)return [];try{const a=JSON.parse(raw);if(!Array.isArray(a)||a.length>MAX||a.some(x=>!identity(x)))throw Error();return a}catch(_){throw Error('Your saved queue cannot be read. Nothing was changed.')}}
 function write(a){if(!Array.isArray(a)||a.length>MAX||a.some(x=>!identity(x)))throw Error('This episode cannot be saved safely.');try{localStorage.setItem(KEY,JSON.stringify(a))}catch(_){throw Error('The queue could not be saved. Your existing queue was kept.')}}
 function add(item,ep){if(!item||!ep||ep.missing||!validEpisodeNumber(ep.number))throw Error('Only an identified episode can be added.');
  if(ep.unifiedOwner&&!unifiedKnownIdentity(item,ep.unifiedOwner))throw Error('This episode’s series could not be verified.');
  const owner=ep.unifiedOwner||item,row={item:compactItem(owner),ep:{number:String(Number(ep.number)),name:String(ep.name||'').slice(0,160),url:String(ep.url||'').slice(0,2048)}};
  if(!identity(row)||JSON.stringify(row).length>12000)throw Error('This episode cannot be saved safely.');const list=read();if(list.some(x=>identity(x)===identity(row)))return false;if(list.length>=MAX)throw Error('The queue is full. Remove an item first.');list.push(row);write(list);return true;
 }
 let root=null,returnFocus=null;
 function close(){if(!root)return;root.remove();root=null;if(returnFocus?.isConnected)returnFocus.focus();returnFocus=null}
 function render(){if(!root)return;let rows;try{rows=read()}catch(e){root.querySelector('.queue-body571').innerHTML=`<p class="notice error">${escape(e.message)}</p>`;return}
  const body=root.querySelector('.queue-body571');body.innerHTML=`<p class="queue-intro571">Only on this device and in your local backups. Play opens the exact saved episode and may start an available server. Automatic queue advancement is not included.</p><p class="queue-status571" role="status" aria-live="polite">${rows.length} of ${MAX} episodes</p><div class="queue-list571">${rows.map((r,i)=>`<article class="queue-row571"><div><strong>${escape(r.item.title)}</strong><small>Episode ${escape(r.ep.number)}${r.ep.name?' · '+escape(r.ep.name):''} · ${escape(r.item.source.toUpperCase())}</small></div><div class="queue-controls571"><button type="button" data-up="${i}" aria-label="Move ${escape(r.item.title)} episode ${escape(r.ep.number)} up" ${i===0?'disabled':''}>↑</button><button type="button" data-down="${i}" aria-label="Move ${escape(r.item.title)} episode ${escape(r.ep.number)} down" ${i===rows.length-1?'disabled':''}>↓</button><button type="button" data-play="${i}">Play</button><button type="button" data-remove="${i}" aria-label="Remove ${escape(r.item.title)} episode ${escape(r.ep.number)}">Remove</button></div></article>`).join('')||'<p class="queue-empty571">Add an episode from its anime’s episode list.</p>'}</div>`;
  const status=body.querySelector('.queue-status571');
  function change(i,kind){try{const list=read();if(i<0||i>=list.length)return;if(kind==='remove')list.splice(i,1);else{let j=i+(kind==='up'?-1:1);if(j<0||j>=list.length)return;[list[i],list[j]]=[list[j],list[i]]}write(list);render()}catch(e){status.textContent=e.message}}
  body.querySelectorAll('[data-up]').forEach(b=>b.onclick=()=>change(Number(b.dataset.up),'up'));
  body.querySelectorAll('[data-down]').forEach(b=>b.onclick=()=>change(Number(b.dataset.down),'down'));
  body.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>change(Number(b.dataset.remove),'remove'));
  body.querySelectorAll('[data-play]').forEach(b=>b.onclick=async()=>{let row;try{row=read()[Number(b.dataset.play)];if(!row)return}catch(e){status.textContent=e.message;return}close();if(typeof window.kuroQueueOpen571==='function')await window.kuroQueueOpen571(row)});
 }
 function open(){if(root)return;returnFocus=document.activeElement;root=document.createElement('div');root.id='queue-overlay571';root.className='dialog-overlay571';root.innerHTML=`<section class="dialog-panel571" role="dialog" aria-modal="true" aria-labelledby="queue-title571"><header><div><small>KURO.TV · ON THIS DEVICE</small><h2 id="queue-title571">Watch queue</h2></div><button type="button" data-close aria-label="Close watch queue">×</button></header><div class="queue-body571"></div></section>`;document.body.append(root);root.querySelector('[data-close]').onclick=close;root.onclick=e=>{if(e.target===root)close()};root.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();close()}};render();root.querySelector('[data-close]').focus()}
 window.kuroQueue571=Object.freeze({add,read,identity,open,close});
 const previous=window.kuroBack;window.kuroBack=()=>{if(root){close();return}previous?.()};
})();

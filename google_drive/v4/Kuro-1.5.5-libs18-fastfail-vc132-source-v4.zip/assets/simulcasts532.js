'use strict';
// A dedicated editorial airing directory, separate from Browse.
let airPagerState=null;
const airLibraryCodes=['ms','dk','nine','zoro','ani','salt','flix','zenkai','aw','suge','sugeby','saltme','rulz','sky'];
function closeAirPicker(restore=true){
 const sheet=document.getElementById('air-source-modal');if(!sheet)return;
 sheet.remove();const trigger=document.getElementById('air-source-trigger');if(trigger){trigger.setAttribute('aria-expanded','false');if(restore)trigger.focus()}
}
function openAirPicker(){
 if(document.getElementById('air-source-modal'))return;
 const trigger=document.getElementById('air-source-trigger');if(trigger)trigger.setAttribute('aria-expanded','true');
 const overlay=document.createElement('div');overlay.id='air-source-modal';overlay.className='air-source-overlay';
 overlay.innerHTML=`<section class="air-source-sheet" role="dialog" aria-modal="true" aria-labelledby="air-picker-title"><div class="air-sheet-handle"></div><div class="air-sheet-head"><div><span class="air-sheet-kicker">YOUR AIRING DIRECTORY</span><h2 id="air-picker-title">Choose a library</h2><p>Lists are supplied by each library.</p></div><button class="air-sheet-close" type="button" aria-label="Close library picker">×</button></div><div class="air-source-choices" role="radiogroup" aria-label="Library">${airLibraryCodes.map((s,i)=>`<button type="button" class="air-source-choice ${source===s?'chosen':''}" role="radio" aria-checked="${source===s}" data-air-source="${s}"><span class="air-choice-index">${String(i+1).padStart(2,'0')}</span><span>${label(s)}</span><i aria-hidden="true">${source===s?'✓':'›'}</i></button>`).join('')}</div><p class="air-sheet-note">Some libraries do not publish an airing list. Availability can change.</p></section>`;
 document.body.appendChild(overlay);overlay.onclick=e=>{if(e.target===overlay)closeAirPicker()};overlay.querySelector('.air-sheet-close').onclick=()=>closeAirPicker();
 overlay.querySelectorAll('[data-air-source]').forEach(b=>b.onclick=()=>{const next=b.dataset.airSource;closeAirPicker(false);if(next===source){document.getElementById('air-source-trigger')?.focus();return}source=next;airPagerState=null;window.scrollTo(0,0);renderSimulcasts();document.getElementById('air-source-trigger')?.focus()});
 overlay.onkeydown=e=>{if(e.key==='Escape'){e.preventDefault();closeAirPicker()}else if(e.key==='Tab'){let f=[...overlay.querySelectorAll('button')].filter(x=>!x.disabled),i=f.indexOf(document.activeElement);if(e.shiftKey&&i===0){e.preventDefault();f[f.length-1].focus()}else if(!e.shiftKey&&i===f.length-1){e.preventDefault();f[0].focus()}}};
 overlay.querySelector('[aria-checked="true"]')?.focus();
}
function airBadges(counts){
 const n=v=>typeof v==='string'&&/^\d+$/.test(v)?v:'';let sub=n(counts?.sub),dub=n(counts?.dub),total=n(counts?.total);
 return `${sub?`<span class="air-badge" aria-label="${sub} subtitled episodes reported">CC <b>${sub}</b></span>`:''}${dub?`<span class="air-badge" aria-label="${dub} dubbed episodes reported">DUB <b>${dub}</b></span>`:''}${!sub&&!dub&&total?`<span class="air-badge" aria-label="${total} episodes reported">EP <b>${total}</b></span>`:''}`;
}
function airRowMarkup(item,index){
 return `<button type="button" class="air-row" data-card="${index}" aria-label="${escapeHTML(item.title)}: view episodes"><span class="air-row-number">${String(index+1).padStart(2,'0')}</span><span class="air-poster poster">${item.img?`<img src="${escapeHTML(item.img)}" loading="lazy" decoding="async" alt="">`:'<span class="poster-fallback" aria-hidden="true">K</span>'}</span><span class="air-row-info"><span class="air-row-kicker"><i></i> AIRING LIST</span><strong>${escapeHTML(item.title)}</strong><small>${escapeHTML(item.meta||'Anime')} · ${escapeHTML(label(item.source))}</small><span class="air-badges">${airBadges(item.counts)}</span></span><span class="air-row-arrow" aria-hidden="true">↗</span></button>`;
}
function renderAirFeature(item){
 const root=document.getElementById('air-feature');if(!root||!item)return;
 const key=item.url+'|'+(item.img||'');if(root.dataset.key===key)return;root.dataset.key=key;
 root.innerHTML=`<article class="air-feature-card"><div class="air-feature-art">${item.img?`<img src="${escapeHTML(item.img)}" alt="">`:'<span class="air-art-fallback">K</span>'}</div><div class="air-feature-shade"></div><div class="air-feature-copy"><span class="air-feature-label"><i></i> FEATURED FROM THE LIST</span><h2>${escapeHTML(item.title)}</h2><p>${escapeHTML(item.meta||'Anime')} · ${escapeHTML(label(item.source))}</p><div class="air-feature-badges">${airBadges(item.counts)}</div><button type="button" id="air-feature-open">View episodes <span aria-hidden="true">↗</span></button></div><span class="air-feature-number" aria-hidden="true">01</span></article>`;
 document.getElementById('air-feature-open').onclick=()=>openShow(item);
}
function renderAirStatus(state){
 const root=document.getElementById('air-feature');if(!root||state.items.length)return;
 root.removeAttribute('data-key');
 let title=state.error?'No list to spotlight':state.done?'No titles to spotlight':'Finding something to watch';
 let message=state.error?'Choose another library or see the message below.':state.done?'This library returned no airing titles.':'Loading the selected library’s airing list…';
 root.innerHTML=`<div class="air-feature-empty"><span class="air-empty-symbol">K</span><div><strong>${title}</strong><small>${message}</small></div></div>`;
}
function renderSimulcasts(){
 const marker=++window.renderSeq,s=source;
 main.innerHTML=`<section class="air-masthead" aria-labelledby="air-title"><div class="air-orbits" aria-hidden="true"><span></span><span></span><span></span><b>✳</b></div><div class="air-kicker"><span class="air-signal"><i></i><i></i><i></i></span> KURO / AIRING GUIDE</div><h1 id="air-title">Simulcasts<span>.</span></h1><p>Stories in motion.<br><b>Find your next episode.</b></p><div class="air-source-line"><button id="air-source-trigger" class="air-source-trigger" type="button" aria-haspopup="dialog" aria-expanded="false"><span class="air-source-icon" aria-hidden="true">◈</span><span><small>SHOWING FROM</small><strong>${escapeHTML(label(s))}</strong></span><b aria-hidden="true">⌄</b></button><span class="air-source-caption"><i></i> Source-reported<br>airing list</span></div></section><button type="button" class="btn seasonal-open573">Seasonal dashboard</button><button type="button" class="btn calendar-open573">Release calendar</button><div class="air-information"><span aria-hidden="true">i</span><p>Listed as airing by the selected library. Titles and availability may be outdated; this is not a live schedule.</p></div><section class="air-directory" aria-labelledby="air-spotlight-label"><div class="air-heading"><div><span class="air-section-kicker">THE AIRING EDIT</span><h2 id="air-spotlight-label">On your radar <span>✳</span></h2></div><span class="air-heading-number">CURATED BY THE LIBRARY</span></div><div id="air-feature" aria-live="polite"></div><div class="air-list-heading"><div><span class="air-section-kicker">KEEP EXPLORING</span><h2>More on the list</h2></div><span id="air-count">${escapeHTML(label(s))}</span></div><div id="results"></div></section>`;
 document.querySelector('.seasonal-open573').onclick=()=>window.kuroSeason573?.();document.querySelector('.calendar-open573').onclick=()=>window.kuroCalendar573?.();
 document.getElementById('air-source-trigger').onclick=openAirPicker;
 const spec={source:s,mode:'airing'};if(!sameSpec(airPagerState,spec))airPagerState=makePager(spec);
 mountPager(airPagerState,{layout:'air',renderCard:airRowMarkup,skip:1,onData:renderAirFeature,onStatus:renderAirStatus,count:document.getElementById('air-count')});
}

/* 5.82k · Image polish layer — no markup changes needed by the callers.
 *
 *  1. BROKEN IMAGES: poster sources 404 constantly (20+ scraper hosts). Any
 *     <img> that fails to load is swapped for the app's existing .poster-fallback
 *     gradient instead of leaving an empty dark box.
 *  2. FADE-IN: an image appears only once it has decoded, so rails fill
 *     smoothly instead of popping in as a grey hole and then flashing.
 *  3. REDUCED MOTION: the fade is skipped when the user asks for less motion.
 *  4. MEMORY: broken URLs are remembered so a re-render does not retry a dead
 *     host on every page change.
 *  5. FALLBACK FOR EMPTY ART: posters with no img at all already render the
 *     fallback in markup; nothing to do here.
 *
 * Deliberately CSS-class driven (no inline styles) to stay inside the app's
 * strict CSP: style-src 'self'.
 */
(function () {
  'use strict';

  var DEAD = {};                       // host+path -> true, culled to 200 entries
  var DEAD_MAX = 200;
  var reduced = false;
  try {
    reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  } catch (_) {}

  function remember(src) {
    try {
      var k = String(src).slice(0, 220);
      if (DEAD[k]) return;
      var keys = Object.keys(DEAD);
      if (keys.length >= DEAD_MAX) delete DEAD[keys[0]];
      DEAD[k] = 1;
    } catch (_) {}
  }
  function isDead(src) {
    try { return !!DEAD[String(src).slice(0, 220)]; } catch (_) { return false; }
  }

  /* swap a broken <img> for the fallback gradient the app already styles */
  function swapToFallback(img) {
    var parent = img.parentNode;
    if (!parent) return;
    if (parent.querySelector(':scope > .poster-fallback')) { img.remove(); return; }
    var fb = document.createElement('span');
    fb.className = 'poster-fallback';
    fb.setAttribute('aria-hidden', 'true');
    // a banner-ish frame gets the same gradient, just no letter
    var wide = parent.classList.contains('pa155-banner-frame') ||
               parent.classList.contains('pa155-pair-art') ||
               parent.classList.contains('pa155-stage-banner') ||
               parent.classList.contains('k154-detail-banner') ||
               parent.classList.contains('history-image');
    if (!wide) fb.textContent = 'K';
    parent.insertBefore(fb, img);
    img.remove();
  }

  function markLoaded(img) {
    if (img.dataset.k582k === '1') return;
    img.dataset.k582k = '1';
    img.classList.add('k582k-in');
  }

  function prep(img) {
    if (!img || img.tagName !== 'IMG' || img.dataset.k582k === '2') return;
    img.dataset.k582k = '2';
    if (!reduced) img.classList.add('k582k-fade');

    if (isDead(img.getAttribute('src'))) {
      remember(img.getAttribute('src'));
      swapToFallback(img);
      return;
    }

    img.addEventListener('error', function () {
      remember(img.getAttribute('src') || '');
      swapToFallback(img);
    }, { once: true });
    img.addEventListener('load', function () { markLoaded(img); }, { once: true });

    // already in cache / already decoded before we attached
    if (img.complete) {
      if (img.naturalWidth > 0) markLoaded(img);
      else if (img.getAttribute('src')) swapToFallback(img);
    }
  }

  function scan(root) {
    if (!root || root.nodeType !== 1 && root.nodeType !== 9) return;
    if (root.tagName === 'IMG') { prep(root); return; }
    var list = root.querySelectorAll ? root.querySelectorAll('img:not([data-k582k])') : [];
    for (var i = 0; i < list.length; i++) prep(list[i]);
  }

  window.k582k = { scan: scan, deadCount: function () { return Object.keys(DEAD).length; } };

  function boot() {
    scan(document);
    if (!window.MutationObserver) return;
    var mo = new MutationObserver(function (records) {
      for (var i = 0; i < records.length; i++) {
        var added = records[i].addedNodes;
        for (var j = 0; j < added.length; j++) {
          var n = added[j];
          if (n.nodeType !== 1) continue;
          if (n.tagName === 'IMG') prep(n);
          else if (n.querySelector && n.querySelector('img:not([data-k582k])')) scan(n);
        }
      }
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();

/* Kuro.tv 5.59: opt-in WebGL2 video enhancement and Web Audio gain.
 * The classic filter is independent and NOT AI. Optional AI uses an adapted
 * small Anime4K CNN with its pretrained weights (MIT); it is not the full suite.
 * No pixels are accessed unless the browser permits canvas access. No DRM or
 * verification bypass. Only accessible frames can be processed; protected or
 * blocked video remains unchanged. The optional AI look combines a real CNN
 * residual with a separately disclosed vivid color/clarity finish.
 */
(function(){
 'use strict';
 if(window.__kuroFx537)return;
 const defaults={enabled:false,ai:false,aiStrength:100,preset:'A',line:'off',detail:8,sharpen:100,denoise:100,lineStrength:100,edge:100,saturation:100,contrast:100,brightness:100,deband:0,gain:100,visible:true,compare:false};
 let settings={...defaults},video=null,canvas=null,gl=null,program=null,texture=null,frameId=0,frameKind='',revealTimer=0,revealed=false,resizeObserver=null,oldPosition='',parent=null;
 let aiEngine=null,aiFence=null,aiFailed='',aiSlow=0,aiSubmitted=0,aiRetryTimer=0,aiDeferred=false,aiTier=0;
 let captions=null,captionList=null,captionTracks=[],captionUpdate=null;
 let colorVideo569=null,colorBefore569='',colorPriority569='',colorApplied569='';
 let audioVideo=null,audioContext=null,audioGain=null,audioSource=null,audioPending=false;
 let status={video:'off',audio:'off',reason:'',width:0,height:0,taps:5,ai:'off',aiReason:'',aiWidth:0,aiHeight:0,aiTier:0};
 // Sharpness, noise reduction, saturation and contrast are independently
 // tuned. These are Kuro's own modes, not the official Anime4K pipelines.
 const presets={A:[1,.65,1.04,1.04],B:[.50,1.05,.99,.98],C:[.25,1.50,1.00,.96],'A+A':[1.80,.55,1.11,1.09],'B+B':[.15,1.90,.94,.90],'C+A':[1.35,1.45,1.12,1.10]};
 const aiCaps=[270,135,90];
 function emit(){try{const data=JSON.stringify(status);if(window.KuroFx559&&typeof window.KuroFx559.postMessage==='function'&&Number.isSafeInteger(window.__kuroFxEpoch559))window.KuroFx559.postMessage('status:'+window.__kuroFxEpoch559+':'+data);else if(window.KuroFxStatus&&typeof window.KuroFxStatus.postMessage==='function')window.KuroFxStatus.postMessage(data)}catch(_){}}
 function clamp(x,lo,hi,def){x=Number(x);return Number.isFinite(x)?Math.min(hi,Math.max(lo,x)):def}
 function normalize(x){return {enabled:x.enabled===true,ai:x.ai===true,aiStrength:clamp(x.aiStrength,0,100,100),preset:Object.prototype.hasOwnProperty.call(presets,x.preset)?x.preset:'A',line:['off','dark','thin'].includes(x.line)?x.line:'off',detail:[8,16,32].includes(Number(x.detail))?Number(x.detail):8,
  sharpen:clamp(x.sharpen,0,200,100),denoise:clamp(x.denoise,0,200,100),lineStrength:clamp(x.lineStrength,0,200,100),edge:clamp(x.edge,0,200,100),saturation:clamp(x.saturation,0,200,100),contrast:clamp(x.contrast,0,200,100),brightness:clamp(x.brightness,0,150,100),deband:clamp(x.deband,0,100,0),gain:clamp(x.gain,100,300,100),visible:x.visible!==false,compare:x.compare===true}}
 function directVideo(){
  const list=[...document.querySelectorAll('video')].filter(v=>{let r=v.getBoundingClientRect();return r.width>=50&&r.height>=35&&getComputedStyle(v).display!=='none'&&getComputedStyle(v).visibility!=='hidden'});
  return list.length===1?list[0]:null;
 }
 function readable(v){
  if(!v||v.readyState<2||!v.videoWidth||!v.videoHeight)return 'waiting';
  if(v.mediaKeys)return 'protected';
  try{const test=document.createElement('canvas');test.width=test.height=1;const c=test.getContext('2d',{willReadFrequently:true});if(!c)return 'unsupported';c.drawImage(v,0,0,1,1);c.getImageData(0,0,1,1);return 'yes'}catch(_){return 'restricted'}
 }
 function compile(type,source){const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){let msg=gl.getShaderInfoLog(s)||'shader';gl.deleteShader(s);throw Error(msg)}return s}
 const vertex=`#version 300 es
 out vec2 uv;
 void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));uv=p;gl_Position=vec4(p*2.0-1.0,0.0,1.0);}`;
 const fragment=`#version 300 es
 precision highp float;
 uniform sampler2D image;uniform sampler2D aiDetail;uniform float aiMix;uniform vec2 sourceSize;uniform vec2 outputSize;uniform vec2 cssSize;uniform vec2 fitAnchor;uniform int fitMode;
 uniform float sharp;uniform float noise;uniform float lineStrength;uniform float edgePreserve;uniform float sat;uniform float contrast;uniform float brightness;uniform float dither;
 uniform float presetSharp;uniform float presetNoise;uniform float presetSat;uniform float presetContrast;uniform int detail;uniform int lineMode;
 in vec2 uv;out vec4 color;
 float lum(vec3 x){return dot(x,vec3(0.2126,0.7152,0.0722));}
 vec3 at(vec2 p){p=clamp(p,vec2(0.0),vec2(1.0));vec3 c=texture(image,p).rgb;if(aiMix>0.0)c+=texture(aiDetail,p).rrr*aiMix*1.25;return clamp(c,0.0,1.0);}
 void main(){
  float screenRatio=outputSize.x/outputSize.y,sourceRatio=sourceSize.x/sourceSize.y;vec2 extent=vec2(1.0);
  // Mirror the video's actual object-fit rather than always letterboxing it.
  if(fitMode==1){if(screenRatio>sourceRatio)extent.x=sourceRatio/screenRatio;else extent.y=screenRatio/sourceRatio;}
  else if(fitMode==2){if(screenRatio>sourceRatio)extent.y=screenRatio/sourceRatio;else extent.x=sourceRatio/screenRatio;}
  else if(fitMode==3)extent=sourceSize/max(cssSize,vec2(1.0));
  vec2 p=(uv-(vec2(1.0)-extent)*fitAnchor)/extent;
  if(any(lessThan(p,vec2(0.0)))||any(greaterThan(p,vec2(1.0)))){color=vec4(0,0,0,1);return;}
  vec2 d=1.0/sourceSize;vec3 c=at(p);vec3 sum=at(p+vec2(d.x,0))+at(p-vec2(d.x,0))+at(p+vec2(0,d.y))+at(p-vec2(0,d.y));float count=4.0;
  if(detail>=16){sum+=at(p+d)+at(p-d)+at(p+vec2(d.x,-d.y))+at(p+vec2(-d.x,d.y));count+=4.0;}
  if(detail>=32){sum+=at(p+vec2(2.0*d.x,0))+at(p-vec2(2.0*d.x,0))+at(p+vec2(0,2.0*d.y))+at(p-vec2(0,2.0*d.y));count+=4.0;}
  vec3 avg=sum/count;float e=length(c-avg);float preserve=clamp(1.0-e*edgePreserve*1.8,0.0,1.0);
  // B and C deliberately smooth more than A; the quality tier controls the
  // actual neighbour samples. Sharpen 0 and denoise 0 disable those stages.
  vec3 result=mix(c,avg,clamp(noise*presetNoise*0.34*preserve,0.0,0.75));
  result+=(c-avg)*sharp*presetSharp*0.66;
  float outline=clamp((lum(avg)-lum(c))*3.8,0.0,0.8)*lineStrength;
  if(lineMode==1)result*=1.0-clamp(outline*0.80,0.0,0.75);
  else if(lineMode==2)result=mix(result,avg,clamp(outline*0.90,0.0,0.75));
  // AI strength controls both the learned residual and a disclosed, conventional
  // vivid/clarity finish. These are zero if the real CNN did not produce a frame.
  result+=(c-avg)*aiMix*0.72;
  float y=lum(result);result=mix(vec3(y),result,sat*presetSat*(1.0+0.32*aiMix));
  result=(result-0.5)*contrast*presetContrast*(1.0+0.17*aiMix)+0.5;result*=brightness;
  // Fine dither is intentionally subtle; it is not invented recovered detail.
  float hash=fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233)))*43758.5453)-.5;result+=hash*dither*3.0/255.0;
  color=vec4(clamp(result,0.0,1.0),1.0);
 }`;
 function cancelFrame(){if(!frameId)return;try{if(frameKind==='video'&&video?.cancelVideoFrameCallback)video.cancelVideoFrameCallback(frameId);else cancelAnimationFrame(frameId)}catch(_){}frameId=0;frameKind=''}
 function disposeAI(clearFailure=true){
  clearTimeout(aiRetryTimer);aiRetryTimer=0;if(gl&&aiFence){try{gl.deleteSync(aiFence)}catch(_){}aiFence=null}
  if(aiEngine){try{aiEngine.destroy()}catch(_){}aiEngine=null}aiSlow=0;aiSubmitted=0;aiDeferred=false;status.aiWidth=0;status.aiHeight=0;if(clearFailure)aiFailed='';
 }
 function failAI(reason){disposeAI(false);aiFailed=reason;status.ai='unavailable';status.aiReason=reason;status.aiTier=aiTier;emit()}
 function lowerAIBudget(){
  if(aiTier>=aiCaps.length-1){failAI('AI paused to protect playback speed');return}
  aiTier++;disposeAI(false);aiDeferred=true;status.ai='waiting';status.aiTier=aiTier;status.aiReason='Reducing AI resolution to protect playback speed';emit();
 }
 function aiReady(){
  if(!aiFence)return true;let result;try{result=gl.clientWaitSync(aiFence,0,0)}catch(_){failAI('GPU synchronization unavailable');return true}
  const elapsed=performance.now()-aiSubmitted;
  if(result===gl.TIMEOUT_EXPIRED){
   if(elapsed>300){lowerAIBudget();return true}
   return false;
  }
  if(result===gl.WAIT_FAILED){failAI('GPU synchronization failed');return true}
  gl.deleteSync(aiFence);aiFence=null;
  if(video&&!video.paused){aiSlow=elapsed>110?aiSlow+1:Math.max(0,aiSlow-1);if(aiSlow>=3)lowerAIBudget()}
  return true;
 }
 // Poll asynchronously even if playback stops producing frame callbacks. No
 // busy wait: a stalled GPU falls back to the classic filter within ~300 ms.
 function checkAI(){
  aiRetryTimer=0;if(!aiFence||!gl||!settings.visible||document.hidden)return;
  const ready=aiReady();if(!ready){aiRetryTimer=setTimeout(checkAI,60);return}
  if(aiDeferred||aiFailed){aiDeferred=false;drawOnce();emit()}
 }
 // Canvas would otherwise cover the browser's built-in text-track captions.
 // Mirror only currently showing, browser-readable cues, as safe WebVTT DOM.
 // Do not change track selection or fetch subtitles. Site-owned overlays remain
 // later siblings above our canvas where the site's stacking allows it.
 function detachCaptions(){
  if(captionList)for(const type of ['addtrack','removetrack','change'])try{captionList.removeEventListener(type,bindCaptionTracks)}catch(_){}
  for(const track of captionTracks)try{track.removeEventListener('cuechange',captionUpdate)}catch(_){}
  if(video&&captionUpdate)try{video.removeEventListener('timeupdate',captionUpdate);video.removeEventListener('seeked',captionUpdate)}catch(_){}
  captionTracks=[];captionList=null;captionUpdate=null;if(captions){captions.remove();captions=null}
 }
 function bindCaptionTracks(){
  for(const track of captionTracks)try{track.removeEventListener('cuechange',captionUpdate)}catch(_){}
  captionTracks=[];if(!captionList||!captionUpdate)return;
  try{for(const track of Array.from(captionList)){captionTracks.push(track);track.addEventListener('cuechange',captionUpdate)}}catch(_){}
  captionUpdate();
 }
 function attachCaptions(v){
  captions=document.createElement('div');captions.dataset.kuroCaptions='true';captions.setAttribute('aria-hidden','true');
  Object.assign(captions.style,{all:'initial',position:'absolute',zIndex:canvas.style.zIndex,pointerEvents:'none',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'flex-end',boxSizing:'border-box',padding:'0 5% 4%',overflow:'hidden',color:'white',fontFamily:'sans-serif',fontWeight:'600',textAlign:'center',lineHeight:'1.3',textShadow:'0 1px 3px #000, 1px 1px 2px #000'});
  parent.insertBefore(captions,canvas.nextSibling);
  captionUpdate=()=>{
   if(!captions)return;captions.replaceChildren();let count=0;
   for(const track of captionTracks){if(track.mode!=='showing')continue;let cues;try{cues=track.activeCues}catch(_){continue}if(!cues)continue;
    for(const cue of Array.from(cues)){if(count++>=12)break;const row=document.createElement('span');Object.assign(row.style,{all:'unset',display:'block',whiteSpace:'pre-line',backgroundColor:'rgba(0,0,0,.72)',padding:'0.08em 0.3em',borderRadius:'0.15em',color:'white',font:'inherit',textAlign:'center',textShadow:'inherit'});
     try{if(typeof cue.getCueAsHTML==='function'&&String(cue.text||'').length<=3000)row.appendChild(cue.getCueAsHTML());else row.textContent=String(cue.text||'').slice(0,3000)}catch(_){row.textContent=String(cue.text||'').slice(0,3000)}captions.appendChild(row);
    }
   }
  };
  try{captionList=v.textTracks;for(const type of ['addtrack','removetrack','change'])captionList.addEventListener(type,bindCaptionTracks);v.addEventListener('timeupdate',captionUpdate);v.addEventListener('seeked',captionUpdate);bindCaptionTracks()}catch(_){}
 }
 function overlayVisible(show){if(canvas)canvas.style.visibility=show?'visible':'hidden';if(captions)captions.style.visibility=show?'visible':'hidden'}
 function restoreOverlayParent569(){
  if(parent&&parent.dataset.kuroFxPosition==='true'){
   // Do not overwrite a position the site changed while the overlay was active.
   if(parent.style.position==='relative')parent.style.position=oldPosition;
   delete parent.dataset.kuroFxPosition;
  }
  parent=null;oldPosition='';
 }
 function adoptOverlayParent569(){
  if(!video||!canvas||!video.parentElement)return false;
  const next=video.parentElement;
  if(next===parent&&canvas.parentElement===next)return true;
  restoreOverlayParent569();parent=next;
  if(getComputedStyle(parent).position==='static'){oldPosition=parent.style.position;parent.style.position='relative';parent.dataset.kuroFxPosition='true'}
  // The filtered canvas follows the actual video without intercepting input.
  parent.insertBefore(canvas,video.nextSibling);if(captions)parent.insertBefore(captions,canvas.nextSibling);
  return true;
 }
 function cleanVideo(){
  disposeAI();cancelFrame();clearTimeout(revealTimer);revealTimer=0;revealed=false;detachCaptions();
  if(resizeObserver){resizeObserver.disconnect();resizeObserver=null}
  if(canvas){canvas.remove();canvas=null}restoreOverlayParent569();
  if(gl){try{gl.deleteTexture(texture);gl.deleteProgram(program)}catch(_){}}gl=null;program=null;texture=null;video=null;status.width=0;status.height=0;status.ai=settings.ai?'waiting':'off';status.aiReason='';
 }
 function sizeCanvas(){
  if(!canvas||!video||!gl||!adoptOverlayParent569())return;
  const v=video.getBoundingClientRect(),p=parent.getBoundingClientRect(),dpr=Math.max(1,Math.min(devicePixelRatio||1,4));
  canvas.style.left=(v.left-p.left+parent.scrollLeft)+'px';canvas.style.top=(v.top-p.top+parent.scrollTop)+'px';canvas.style.width=v.width+'px';canvas.style.height=v.height+'px';
  if(captions){captions.style.left=canvas.style.left;captions.style.top=canvas.style.top;captions.style.width=canvas.style.width;captions.style.height=canvas.style.height;captions.style.fontSize=Math.max(12,Math.min(36,v.height*.05))+'px'}
  const maxH=settings.detail===8?720:settings.detail===16?1080:2160,maxW=maxH*16/9;
  let w=Math.max(1,Math.round(v.width*dpr)),h=Math.max(1,Math.round(v.height*dpr)),maxTex=gl.getParameter(gl.MAX_TEXTURE_SIZE),vp=gl.getParameter(gl.MAX_VIEWPORT_DIMS);
  let factor=Math.min(1,maxW/w,maxH/h,maxTex/w,maxTex/h,vp[0]/w,vp[1]/h);w=Math.max(1,Math.floor(w*factor));h=Math.max(1,Math.floor(h*factor));
  if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;status.width=w;status.height=h;emit()}
 }
 function createRenderer(v){
  cleanVideo();video=v;if(!v.parentElement)throw Error('No video container');
  canvas=document.createElement('canvas');canvas.setAttribute('aria-hidden','true');canvas.dataset.kuroFx='true';const videoZ=getComputedStyle(v).zIndex;Object.assign(canvas.style,{position:'absolute',zIndex:/^-?\d+$/.test(videoZ)?videoZ:'auto',pointerEvents:'none',display:'block'});
  if(!adoptOverlayParent569())throw Error('No video container');attachCaptions(v);
  gl=canvas.getContext('webgl2',{alpha:false,antialias:false,depth:false,stencil:false,preserveDrawingBuffer:false});if(!gl)throw Error('WebGL2 unavailable');
  const vs=compile(gl.VERTEX_SHADER,vertex),fs=compile(gl.FRAGMENT_SHADER,fragment);program=gl.createProgram();gl.attachShader(program,vs);gl.attachShader(program,fs);gl.linkProgram(program);gl.deleteShader(vs);gl.deleteShader(fs);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('GPU shader unavailable');
  texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
  canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();cleanVideo();status.video='unavailable';status.reason='GPU context lost';status.ai=settings.ai?'unavailable':'off';status.aiReason=settings.ai?status.reason:'';emit()},{once:true});
  if(window.ResizeObserver){resizeObserver=new ResizeObserver(()=>{if(canvas){sizeCanvas();drawOnce()}});resizeObserver.observe(v)}
  sizeCanvas();
 }
 function uniform(name,value){gl.uniform1f(gl.getUniformLocation(program,name),value)}
 function drawOnce(){
  if(!canvas||!gl||!video||!settings.enabled||!settings.visible||settings.compare||document.hidden||revealed||video.readyState<2)return;
  try{
   // Never submit a second neural frame while the first is still on the GPU.
   if(settings.ai&&settings.aiStrength>0&&aiFence&&!aiReady()){aiDeferred=true;return}
   sizeCanvas();gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,video);
   let aiResult=null;
   if(settings.ai&&settings.aiStrength>0&&!aiFailed){
    try{
     if(!aiEngine){status.ai='waiting';status.aiReason='Preparing on-device AI';emit();if(!window.__kuroAI540)throw Error('AI engine unavailable');aiEngine=window.__kuroAI540.create(gl)}
     aiResult=aiEngine.render(texture,video.videoWidth,video.videoHeight,aiCaps[aiTier]);aiDeferred=false;
     aiFence=gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE,0);if(!aiFence)throw Error('GPU synchronization unavailable');aiSubmitted=performance.now();gl.flush();clearTimeout(aiRetryTimer);aiRetryTimer=setTimeout(checkAI,60);
     status.ai='active';status.aiReason=aiTier?'AI using a lighter resolution to protect playback speed':'';status.aiTier=aiTier;status.aiWidth=aiResult.width;status.aiHeight=aiResult.height;
    }catch(e){failAI('On-device AI unavailable for this player or GPU');aiResult=null}
   }else if(!settings.ai||settings.aiStrength<=0){if(aiEngine||aiFence||aiFailed)disposeAI();status.ai=settings.ai?'paused':'off';status.aiReason=settings.ai?'AI strength is 0%':''}
   else if(aiFailed){status.ai='unavailable';status.aiReason=aiFailed}
   gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,canvas.width,canvas.height);gl.useProgram(program);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
   gl.uniform1i(gl.getUniformLocation(program,'image'),0);gl.uniform1i(gl.getUniformLocation(program,'aiDetail'),1);gl.uniform1f(gl.getUniformLocation(program,'aiMix'),aiResult?settings.aiStrength/100:0);
   gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,aiResult?aiResult.texture:texture);gl.activeTexture(gl.TEXTURE0);
   gl.uniform2f(gl.getUniformLocation(program,'sourceSize'),video.videoWidth,video.videoHeight);gl.uniform2f(gl.getUniformLocation(program,'outputSize'),canvas.width,canvas.height);
   const vr=video.getBoundingClientRect(),style=getComputedStyle(video),pos=style.objectPosition.trim().split(/\s+/),percent=(s)=>/%$/.test(s)?clamp(parseFloat(s)/100,0,1,.5):.5;
   let fit=style.objectFit,mode=fit==='contain'?1:fit==='cover'?2:fit==='none'?3:fit==='scale-down'?(video.videoWidth<=vr.width&&video.videoHeight<=vr.height?3:1):0;
   gl.uniform2f(gl.getUniformLocation(program,'cssSize'),vr.width,vr.height);gl.uniform2f(gl.getUniformLocation(program,'fitAnchor'),percent(pos[0]),1-percent(pos[1]||pos[0]));gl.uniform1i(gl.getUniformLocation(program,'fitMode'),mode);
   for(const [k,v] of Object.entries({sharp:settings.sharpen/100,noise:settings.denoise/100,lineStrength:settings.lineStrength/100,edgePreserve:settings.edge/100,sat:settings.saturation/100,contrast:settings.contrast/100,brightness:settings.brightness/100,dither:settings.deband/100,presetSharp:presets[settings.preset][0],presetNoise:presets[settings.preset][1],presetSat:presets[settings.preset][2],presetContrast:presets[settings.preset][3]}))uniform(k,v);
   gl.uniform1i(gl.getUniformLocation(program,'detail'),settings.detail);gl.uniform1i(gl.getUniformLocation(program,'lineMode'),settings.line==='dark'?1:settings.line==='thin'?2:0);gl.drawArrays(gl.TRIANGLES,0,3);
   if(gl.getError()!==gl.NO_ERROR)throw Error('GPU render failed');status.video='active';status.reason='';status.taps=settings.detail===8?5:settings.detail===16?9:13;
  }catch(e){cleanVideo();status.video='unavailable';status.reason='Video frames or GPU are not available';status.ai=settings.ai?'unavailable':'off';status.aiReason=settings.ai?status.reason:'';emit()}
 }
 function schedule(){
  cancelFrame();if(!canvas||!video||!settings.enabled||!settings.visible||settings.compare||document.hidden||revealed||video.paused||video.ended)return;
  const loop=()=>{frameId=0;drawOnce();if(canvas&&video&&!video.paused&&!document.hidden&&settings.enabled&&settings.visible&&!settings.compare&&!revealed){if(video.requestVideoFrameCallback){frameKind='video';frameId=video.requestVideoFrameCallback(loop)}else{frameKind='raf';frameId=requestAnimationFrame(loop)}}};
  if(video.requestVideoFrameCallback){frameKind='video';frameId=video.requestVideoFrameCallback(loop)}else{frameKind='raf';frameId=requestAnimationFrame(loop)}
 }
 // A visual-only browser color filter needs no script-readable frames and can
 // help some cross-origin videos. It is NOT sharpening, denoising or AI. It
 // never samples or exports pixels and never touches a known protected video.
 function restoreColor569(){
  if(colorVideo569&&colorVideo569.style.getPropertyValue('filter')===colorApplied569){
   if(colorBefore569)colorVideo569.style.setProperty('filter',colorBefore569,colorPriority569);else colorVideo569.style.removeProperty('filter');
  }
  colorVideo569=null;colorBefore569=colorPriority569=colorApplied569='';
 }
 function applyColor569(v){
  if(!v||v.mediaKeys||!window.CSS?.supports?.('filter','saturate(1)'))return false;
  if(colorVideo569!==v){restoreColor569();colorVideo569=v;colorBefore569=v.style.getPropertyValue('filter');colorPriority569=v.style.getPropertyPriority('filter')}
  else if(v.style.getPropertyValue('filter')!==colorApplied569){colorBefore569=v.style.getPropertyValue('filter');colorPriority569=v.style.getPropertyPriority('filter')}
  const base=colorBefore569&&colorBefore569!=='none'?colorBefore569+' ':'';
  const preset=presets[settings.preset];
  colorApplied569=base+'saturate('+(settings.saturation/100*preset[2])+') contrast('+(settings.contrast/100*preset[3])+') brightness('+(settings.brightness/100)+')';
  try{v.style.setProperty('filter',colorApplied569,colorPriority569);const computed=getComputedStyle(v).filter;if(!computed||computed==='none'||!computed.includes('saturate(')){restoreColor569();return false}return true}catch(_){restoreColor569();return false}
 }
 function applyVideo(){
  if(!settings.enabled){restoreColor569();cleanVideo();status.video='off';status.reason='';status.ai='off';return}
  if(!settings.visible||document.hidden){cancelFrame();disposeAI(false);status.video='paused';status.ai=settings.ai?'paused':'off';status.aiReason=settings.ai?'AI paused while video is hidden':'';return}
  if(settings.compare){restoreColor569();cancelFrame();clearTimeout(revealTimer);revealTimer=0;revealed=false;disposeAI();overlayVisible(false);status.video='compare';status.reason='Showing original';status.ai=settings.ai?'paused':'off';status.aiReason=settings.ai?'Showing original':'';return}
  if(canvas&&!revealed)overlayVisible(true);
  let v=directVideo();if(!v){restoreColor569();cleanVideo();status.video='waiting';status.reason='No accessible direct video';status.ai=settings.ai?'waiting':'off';status.aiReason=settings.ai?status.reason:'';return}
  let access=readable(v);if(access!=='yes'){
   cleanVideo();
   if(access==='restricted'&&applyColor569(v)){status.video='color';status.reason='Color only; frame access is restricted';status.ai=settings.ai?'unavailable':'off';status.aiReason=settings.ai?'AI and pixel filters need readable frames':'';return}
   restoreColor569();status.video=access==='waiting'?'waiting':'unavailable';status.reason=access==='protected'?'Protected video':access==='restricted'?'Video access restricted':access==='unsupported'?'Canvas unavailable':'Waiting for video';status.ai=settings.ai?(access==='waiting'?'waiting':'unavailable'):'off';status.aiReason=settings.ai?status.reason:'';return
  }
  restoreColor569();try{if(v!==video||!canvas){aiTier=0;status.aiTier=0;createRenderer(v)}status.taps=settings.detail===8?5:settings.detail===16?9:13;drawOnce();schedule()}catch(e){cleanVideo();status.video='unavailable';status.reason='GPU enhancement unavailable';status.ai=settings.ai?'unavailable':'off';status.aiReason=settings.ai?status.reason:''}
 }
 function audioAllowed(v){
  // Web Audio can permanently reroute an element and mute cross-origin media.
  // Limit it to Kuro's own stable direct HLS element; never touch third-party embeds.
  return location.protocol==='https:'&&location.hostname==='kuro.local'&&location.pathname==='/stream-player.html'&&v&&v.id==='video'&&readable(v)==='yes';
 }
 function applyAudio(userGesture){
  if(audioGain&&audioVideo){
   audioGain.gain.setTargetAtTime(settings.gain/100,audioContext.currentTime,.035);
   if(audioContext.state!=='running'){
    status.audio='tap';if(userGesture&&!audioPending){audioPending=true;Promise.resolve(audioContext.resume()).then(()=>{audioPending=false;applyAudio(false);emit()}).catch(()=>{audioPending=false;status.audio='unavailable';emit()})}return;
   }
   status.audio=settings.gain>100?'active':'off';return
  }
  if(settings.gain<=100){status.audio='off';return}
  let v=directVideo();if(!v){status.audio='waiting';return}
  if(!audioAllowed(v)){status.audio='unavailable';return}
  try{
   const C=window.AudioContext||window.webkitAudioContext;if(!C){status.audio='unavailable';return}
   if(!audioContext)audioContext=new C();
   if(audioContext.state!=='running'){
    status.audio='tap';if(userGesture&&!audioPending){audioPending=true;Promise.resolve(audioContext.resume()).then(()=>{audioPending=false;if(audioContext.state==='running'){applyAudio(false);emit()}}).catch(()=>{audioPending=false;status.audio='unavailable';emit()})}return;
   }
   // Prepare the destination before rerouting the element. If connection
   // fails after rerouting, attempt a unity-gain pass-through immediately.
   const gain=audioContext.createGain();gain.gain.value=settings.gain/100;gain.connect(audioContext.destination);
   const source=audioContext.createMediaElementSource(v);try{source.connect(gain)}catch(e){try{source.connect(audioContext.destination)}catch(_){}throw e}
   audioSource=source;audioGain=gain;audioVideo=v;status.audio='active';
  }catch(_){status.audio='unavailable'}
 }
 function reveal(){
  if(!canvas||!settings.enabled||settings.compare)return;revealed=true;overlayVisible(false);cancelFrame();clearTimeout(revealTimer);
  revealTimer=setTimeout(()=>{revealed=false;if(canvas&&!settings.compare){overlayVisible(true);drawOnce();schedule()}},2400);
 }
 document.addEventListener('pointerdown',e=>{
  const active=video||audioVideo||directVideo();
  if(active&&(e.target===active||active.contains(e.target))){if(active===video)reveal();applyAudio(true);emit()}
 },true);
 for(const type of ['loadeddata','play','playing','pause','ended'])document.addEventListener(type,e=>{if(!(e.target instanceof HTMLVideoElement))return;if(settings.enabled){applyVideo();if(type==='pause'||type==='ended')cancelFrame()}if(settings.gain>100)applyAudio(false);emit()},true);
 document.addEventListener('visibilitychange',()=>{if(settings.enabled)applyVideo();else if(document.hidden)cancelFrame();emit()});
 const refreshOverlay569=()=>{if(canvas){sizeCanvas();drawOnce();schedule()}};
 window.addEventListener('resize',refreshOverlay569);
 if(window.visualViewport)window.visualViewport.addEventListener('resize',refreshOverlay569);
 for(const type of ['fullscreenchange','webkitfullscreenchange'])document.addEventListener(type,refreshOverlay569);
 window.addEventListener('pagehide',()=>{restoreColor569();cleanVideo();if(audioContext)try{audioContext.close()}catch(_){}});
 window.__kuroFx537={
  configure(x){const prior=settings;settings=normalize(x||{});if(prior.ai!==settings.ai||prior.aiStrength!==settings.aiStrength&&(!prior.aiStrength||!settings.aiStrength)){disposeAI();aiTier=0;status.aiTier=0;status.ai=settings.ai?'waiting':'off';status.aiReason=''}applyVideo();applyAudio(false);emit();return JSON.stringify(status)},
  status(){return JSON.stringify(status)}
 };
})();

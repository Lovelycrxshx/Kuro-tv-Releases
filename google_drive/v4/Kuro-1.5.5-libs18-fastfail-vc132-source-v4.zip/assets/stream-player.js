'use strict';
(function(){
 const video=document.getElementById('video');let reported=false;
 // Exact position is sent only to Kuro's origin-scoped Android listener.
 const params=new URLSearchParams(location.search),attempt=Number(params.get('attempt')),startMs=Number(params.get('startMs'));
 let lastProgress=0,resumeApplied=false;
 function progress(force,ended){if((!resumeApplied&&!ended)||!Number.isSafeInteger(attempt)||attempt<0||!window.KuroProgress561)return;const now=Date.now();if(!force&&now-lastProgress<5000)return;const position=Math.round(video.currentTime*1000),duration=Number.isFinite(video.duration)?Math.round(video.duration*1000):-1;if(!Number.isFinite(position)||position<0)return;lastProgress=now;try{window.KuroProgress561.postMessage(JSON.stringify({attempt,position,duration,ended:!!ended}));}catch(_){}}
 video.addEventListener('loadedmetadata',()=>{if(resumeApplied)return;resumeApplied=true;if(Number.isFinite(startMs)&&startMs>=5000&&startMs<=86400000&&(!Number.isFinite(video.duration)||startMs<video.duration*1000-1000)){try{video.currentTime=startMs/1000;}catch(_){}}});
 // Only explicit, validated episode ranges are used; never infer an intro from timing.
 let skipConfig={on:false,ranges:[]};
 window.__kuroSetMarkers574=config=>{skipConfig={on:config?.on===true,ranges:Array.isArray(config?.ranges)?config.ranges.filter(r=>Array.isArray(r)&&r.length===2&&r.every(Number.isFinite)&&r[0]>=0&&r[1]>r[0]&&r[1]<=86400&&r[1]-r[0]<=1800):[]}};
 video.addEventListener('timeupdate',()=>{if(!skipConfig.on||video.paused||video.seeking||!Number.isFinite(video.duration))return;for(const r of skipConfig.ranges){if(r[1]<=video.duration&&video.currentTime>=r[0]&&video.currentTime<r[1]){try{video.currentTime=r[1]}catch(_){}break}}});
 video.addEventListener('timeupdate',()=>progress(false,false));video.addEventListener('pause',()=>progress(true,video.ended));video.addEventListener('ended',()=>progress(true,true));window.addEventListener('pagehide',()=>progress(true,video.ended));
 function signal(type){if(reported)return;reported=true;location.href='kuro-player://event?type='+encodeURIComponent(type);}
 let source;try{
  source=new URL(new URLSearchParams(location.search).get('src')||'');const inner=new URL(source.searchParams.get('url')||'');
  if(source.protocol!=='https:'||source.hostname!=='www.zenkaitv.com'||source.pathname!=='/api/source'||source.port||source.username||source.password||source.hash||source.searchParams.getAll('url').length!==1||inner.protocol!=='https:'||inner.hostname!=='player.zilla-networks.com'||inner.port||inner.username||inner.password||inner.hash||!inner.pathname.startsWith('/m3u8/'))throw Error('Invalid stream');
 }catch(_){signal('fatal');return}
 let autoplay=params.get('autoplay')!=='0';window.__kuroSetAutoplay561=on=>{autoplay=!!on;video.autoplay=autoplay};video.muted=false;video.volume=1;video.autoplay=autoplay;video.addEventListener('error',()=>signal('fatal'),{once:true});
 if(window.Hls&&Hls.isSupported()){
  const hls=new Hls({enableWorker:false});hls.on(Hls.Events.ERROR,(_event,data)=>{if(!data.fatal)return;const status=Number(data.response?.code||data.networkDetails?.status||0);signal(status===401||status===403||status===429?'verification':'fatal')});
  hls.on(Hls.Events.MEDIA_ATTACHED,()=>hls.loadSource(source.href));hls.on(Hls.Events.MANIFEST_PARSED,()=>{if(autoplay)video.play().catch(()=>{})});hls.attachMedia(video);
 }else if(video.canPlayType('application/vnd.apple.mpegurl')){video.src=source.href;if(autoplay)video.play().catch(()=>{})}
 else signal('fatal');
})();

/* 5.84: Brute-force quality render for all players.
 * Tries the highest available quality first, then falls back through
 * lower renditions if the top one fails to load. Works for both HLS
 * streams (native level selection) and direct video URLs. */
(function quality584() {
  'use strict';
  const QUALITY_ORDER = [
    { label: 'Auto', value: 'auto' },
    { label: '1080p', value: '1080' },
    { label: '720p', value: '720' },
    { label: '480p', value: '480' },
    { label: '360p', value: '360' }
  ];
  const QUALITY_KEY = 'kuro-quality-v1';

  function getQuality() {
    try { return localStorage.getItem(QUALITY_KEY) || 'auto'; } catch (_) { return 'auto'; }
  }
  function setQuality(q) {
    try { localStorage.setItem(QUALITY_KEY, q); } catch (_) {}
    window.dispatchEvent(new CustomEvent('kuro:quality', { detail: { value: q } }));
  }

  function applyToHls(hls, video) {
    if (!hls || !video) return;
    const q = getQuality();
    if (q === 'auto') {
      hls.currentLevel = -1;
      return;
    }
    const target = Number(q);
    const levels = hls.levels || [];
    if (!levels.length) return;
    /* find the closest level to target height */
    let best = levels[0];
    for (const lvl of levels) {
      if (lvl.height <= target && lvl.height > (best.height || 0)) best = lvl;
    }
    /* if no level <= target, use the lowest */
    const lower = levels.filter(l => l.height <= target);
    if (lower.length) best = lower.sort((a, b) => b.height - a.height)[0];
    else best = levels.sort((a, b) => a.height - b.height)[0];
    hls.currentLevel = levels.indexOf(best);
  }

  function bruteForceQuality(hls, video, url) {
    if (hls && hls.levels && hls.levels.length) {
      applyToHls(hls, video);
      return;
    }
    /* Non-HLS: try direct URL variants with quality in path.
     * Sources often serve quality-suffixed paths like /720p.m3u8.
     * Try highest first, then fall back. */
    const q = getQuality();
    if (q === 'auto') return;
    const candidates = [1080, 720, 480, 360].filter(h => h <= Number(q));
    if (!candidates.length) candidates.push(720, 480, 360);
    /* the base URL is already the best available; brute-force means
     * if the current stream errors, try lower quality renditions */
    video.addEventListener('error', function onErr() {
      video.removeEventListener('error', onErr);
      const base = url.replace(/\/(\d{3,4})p?[^/]*$/i, '/').replace(/\.(m3u8|mp4)$/i, '');
      const lower = candidates.filter(h => h < 720).sort((a, b) => b - a);
      for (const h of lower) {
        const testUrl = base + h + '.' + (url.match(/\.(m3u8|mp4)$/i) || ['.m3u8'])[1];
        if (testUrl !== url) {
          try { video.src = testUrl; return; } catch (_) {}
        }
      }
    }, { once: true });
  }

  window.kuroQuality584 = {
    get: getQuality,
    set: setQuality,
    options: QUALITY_ORDER,
    apply: function (hls, video, url) { bruteForceQuality(hls, video, url); }
  };
})();

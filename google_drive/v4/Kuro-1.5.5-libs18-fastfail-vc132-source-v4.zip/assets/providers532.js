'use strict';
// Library 10: the public Aniwatch WordPress catalogue and episode endpoints.
// Search cards can be episode pages, so always resolve and verify the series first.
async function awDetail(item,raw){
 const original=parse(raw);if(sourceNeedsVerification(original))throw Error('The library requested human verification.');
 const src=new URL(item.url);if(src.hostname!=='aniwatch.co.at')throw Error('Invalid Library 10 title.');
 let episodeDoc=null,doc=original,canonical=item.url;
 if(!src.pathname.startsWith('/anime/')){
  const link=original.querySelector('.anisc-detail .film-name a[href]');
  canonical=validUrl(abs(link?.getAttribute('href')||'','aw'));
  if(!canonical||new URL(canonical).hostname!=='aniwatch.co.at'||!new URL(canonical).pathname.startsWith('/anime/')||matchTitle(link?.textContent)!==matchTitle(item.title))throw Error('This exact title and season could not be verified.');
  episodeDoc=original;doc=parse(await get(canonical));
 }
 if(sourceNeedsVerification(doc))throw Error('The library requested human verification.');
 const heading=doc.querySelector('.anisc-detail .film-name')?.textContent;
 if(!heading||matchTitle(heading)!==matchTitle(item.title))throw Error('This exact title and season could not be verified.');
 const seriesId=doc.querySelector('.wl-item[data-animeid]')?.getAttribute('data-animeid')||doc.querySelector('[data-anime-id]')?.getAttribute('data-anime-id');
 if(!/^\d+$/.test(seriesId||''))throw Error('The library did not provide a series identifier.');
 if(episodeDoc){const id=episodeDoc.querySelector('#ani_detail')?.getAttribute('data-anime-id');if(id!==seriesId)throw Error('This exact title and season could not be verified.');}
 item.url=canonical;item.awId=seriesId;
 return {doc,episodeDoc,seriesId};
}
function awEpisodeRows(doc){
 const groups=new Map();
 for(const a of doc.querySelectorAll('.ep-item[data-number][data-id][href]')){
  let number=Number(a.getAttribute('data-number')),id=a.getAttribute('data-id'),url=validUrl(abs(a.getAttribute('href')||'','aw'));
  if(!Number.isInteger(number)||number<1||number>5000||!/^\d+$/.test(id||'')||!url||new URL(url).hostname!=='aniwatch.co.at')continue;
  const key=String(number),row={number:key,id,url,name:(a.querySelector('.ep-name')?.getAttribute('title')||a.getAttribute('title')||'').trim()};
  if(!groups.has(key))groups.set(key,new Map());groups.get(key).set(id+'|'+url,row);
 }
 // A duplicated number referring to distinct episodes is ambiguous: skip it.
 return [...groups.values()].filter(g=>g.size===1).map(g=>[...g.values()][0]).sort((a,b)=>Number(a.number)-Number(b.number));
}
async function awEpisodes(doc,episodeDoc){
 const seriesId=doc.querySelector('.wl-item[data-animeid]')?.getAttribute('data-animeid')||doc.querySelector('[data-anime-id]')?.getAttribute('data-anime-id');
 if(!/^\d+$/.test(seriesId||''))throw Error('Episode list unavailable.');
 if(episodeDoc){if(episodeDoc.querySelector('#ani_detail')?.getAttribute('data-anime-id')!==seriesId)throw Error('The exact series could not be verified.');let rows=awEpisodeRows(episodeDoc);if(rows.length)return rows;}
 const j=JSON.parse(await get(base('aw')+'/wp-json/hianime/v1/episode/list/'+seriesId));
 if(j.status!==true||typeof j.html!=='string')throw Error('Episode list unavailable.');
 return awEpisodeRows(parse(j.html));
}
async function awServers(ep){
 let number=Number(ep?.number),id=String(ep?.id||'');
 if(!Number.isInteger(number)||number<1||number>5000||!/^\d+$/.test(id))return [];
 let j=JSON.parse(await get(base('aw')+'/wp-json/hianime/v1/episode/servers/'+id));
 if(j.status!==true||typeof j.html!=='string')return [];
 let doc=parse(j.html),notice=doc.querySelector('.server-notice b')?.textContent?.trim()||'',found=notice.match(/^Episode\s+(\d+)$/i);
 if(!found||Number(found[1])!==number)return [];
 let out=[];
 for(const b of doc.querySelectorAll('.server-item[data-hash][data-type]')){
  let lang=(b.getAttribute('data-type')||'').toLowerCase(),url='';try{url=validUrl(atob(b.getAttribute('data-hash')||''),'player')}catch(_){}
  if(!url||!['sub','dub'].includes(lang))continue;let host=new URL(url).hostname;
  if(host!=='1anime.site'&&!host.endsWith('.1anime.site')&&host!=='megaplay.buzz')continue;
  out.push({name:b.getAttribute('data-server-name')||'Server',lang,url,referer:'aw'});
 }
 return out;
}
async function fallbackAw(title,number,expected={}){
 if(!validEpisodeNumber(number))return [];
 let candidates=[];
 for(let page=1;page<=3;page++){
  let result=await fetchCatalogPage({source:'aw',mode:'search',query:title},page);
  candidates.push(...result.items.filter(x=>matchTitle(x.title)===matchTitle(title)));
  if(!result.hasNext)break;
 }
 const unique=[...new Map(candidates.map(x=>[x.url,x])).values()];if(!unique.length||unique.length>4)return [];
 let series=new Map();
 for(let item of unique){
  const resolved=await awDetail(item,await get(item.url));
  const al=resolved.doc.querySelector('a[href^="https://anilist.co/anime/"]')?.getAttribute('href')?.match(/\/anime\/(\d+)/);
  const mal=resolved.doc.querySelector('a[href^="https://myanimelist.net/anime/"]')?.getAttribute('href')?.match(/\/anime\/(\d+)/);
  if(expected.anilistId&&al&&Number(al[1])!==Number(expected.anilistId))continue;
  if(expected.malId&&mal&&Number(mal[1])!==Number(expected.malId))continue;
  series.set(item.url,resolved);
 }
 if(series.size!==1)return [];
 const resolved=[...series.values()][0],eps=await awEpisodes(resolved.doc,resolved.episodeDoc),matches=eps.filter(x=>x.number===String(Number(number)));
 return matches.length===1?awServers(matches[0]):[];
}

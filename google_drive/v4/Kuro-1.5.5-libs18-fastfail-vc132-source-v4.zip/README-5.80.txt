KURO.TV 5.80 — RELEASE NOTES
================================================================================
Version name   5.80
Version code   83   (5.75 was 82)
Package        app.lovelycrxshx.kuro
Build signer   CN=Kuro Anime (unchanged key)


--------------------------------------------------------------------------------
1. WHAT THIS RELEASE IS
--------------------------------------------------------------------------------
5.80 is 5.75 plus one change: Library 2 (HiAnime) is no longer tied to a single
domain. It now rotates through four, in this order:

    1. https://hianime.dk        (the domain 5.75 shipped with)
    2. https://hianime.fm
    3. https://hianime.al
    4. https://hianimes.es

Nothing else about how Kuro works changed. There is no new library, no new
permission, no new network host beyond those three domains.


--------------------------------------------------------------------------------
2. WHY IT IS DONE THIS WAY
--------------------------------------------------------------------------------
Kuro already had a 'dk' code path that knows how to read a HiAnime site: search,
detail pages, episode lists, the ajax/v2 endpoints, the server list and the
Referer each player needs. The three new domains serve the same catalogue, so
teaching the parsers about them would have meant four near-identical copies of
that logic drifting apart.

Instead only the origin moves. `base('dk')` returns the currently selected
mirror, and every existing parser, server extractor, playback guard and
pip/offline path keeps working untouched.

The mirror list lives in one file, assets/mirrors579.js:

    const HI_MIRRORS = [
      'https://hianime.dk', 'https://hianime.fm',
      'https://hianime.al', 'https://hianimes.es'
    ];

The same four hosts are declared once in MainActivity.java (HI_MIRROR_HOSTS) and
the browser allowlists read HI_MIRROR_HOSTS, so the source allowlist, the player
allowlist and the Referer map cannot drift from the app's host policy.


--------------------------------------------------------------------------------
3. FALLBACK BEHAVIOUR
--------------------------------------------------------------------------------
- A mirror is only skipped after a real request to it failed. Nothing is probed
  on startup and no domain is marked dead on a guess.
- The interactive path (opening a show, loading episodes) remembers the mirror
  that actually answered and keeps using it for that session.
- The fallback path walks the list in searchFallbacks before giving up on the
  library, so a dead domain costs one request instead of the whole source.
- A human-verification challenge is never rotated around: if a mirror answers
  with a challenge, that is reported, not bypassed.

Sequential rather than parallel on purpose: Kuro is used on metered mobile data,
and four simultaneous requests to the same catalogue is not a fair trade for a
few hundred milliseconds.


--------------------------------------------------------------------------------
4. WHAT DID NOT CHANGE
--------------------------------------------------------------------------------
- Package name, signing key, minSdk 26 / targetSdk 35, every permission.
- Libraries 1 and 3-13 and the whole failover order.
- No new host is allowed to serve player frames; the player allowlist only gained
  the HiAnime domains that the source allowlist already accepts.

Testing: tests/test-hianime-mirrors579.cjs covers the list, host matching
(subdomains in, look-alikes out), rotation and wrap-around, mirror memory, and
checks the browser and native allowlists still agree. The existing browser test
suite was run before and after this change; the pass/fail set is identical apart
from the new test.

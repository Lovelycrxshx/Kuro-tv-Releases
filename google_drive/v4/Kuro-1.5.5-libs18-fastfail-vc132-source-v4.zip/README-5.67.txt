KURO.TV 5.67 — LIVE NEUTRAL ARTWORK AND THEMED OPTIONS
Package app.lovelycrxshx.kuro, version 5.67 / versionCode 67, Android 8+.

Install the original-key-signed update over your existing Kuro installation.
Do not uninstall Kuro or clear its storage. Existing accounts, client IDs,
lists, watch history, preferences, and encrypted saved credentials are kept.

DISCORD RICH PRESENCE
- When presence is enabled and Kuro is visible or in picture-in-picture, it
  samples playback and asks the Social SDK to refresh at most every 3 seconds.
  SDK errors cause a bounded exponential retry delay. Discord can throttle,
  queue, cache or delay these requests; 3-second visibility is not guaranteed.
- When poster and title sharing are on, Kuro first accepts a safe neutral image
  provided for the selected episode, then tries an exact, unique Kitsu match
  for an episode thumbnail. Without one, it uses a supported anime cover or
  an exact, unique AniList cover; otherwise it uses Kuro's registered app icon.
  It never captures video frames. Artwork can be missing or delayed and an
  unmatched, ambiguous or unnumbered episode will not be guessed.
- A metadata lookup discloses the anime title to AniList and/or the title and
  episode number to Kitsu. Episode lookup is skipped when episode sharing is
  hidden. Lookup is limited, cached and skipped when presence, title or artwork
  is off. No source URL, user token, cookie or stream is sent to these lookups.
- Provider-hosted artwork and all Watch/Download activity buttons are rejected;
  source text is filtered best-effort. In-app watching is unaffected. This is
  not a guarantee of anonymity from the network or a modified client.
- Current and linked Discord target choices, history, reconnect, pause and status
  remain. SDK acceptance does not prove that a profile is visible to others.

ACCOUNTS AND ADMIN SETUP
- Empty per-device settings use these approved public IDs: Discord application
  1569077670074122250, MyAnimeList client 37160cd5a180308c9009afb7faa4e341,
  AniList client 56440. Existing nonempty IDs and account sessions are not
  replaced. These identifiers are public, not credentials. Provider-side app
  configuration and real sign-in behavior have not been verified.
- Provider setup is hidden from the normal account screens and its native
  configure bridge is blocked while GitHub verification is unfinished. This
  release does NOT implement owner GitHub verification; even the owner cannot
  change these IDs in this version. A future implementation needs the owner's
  public GitHub identity and a public OAuth application client ID. Never place
  an OAuth client secret in an APK. A modified APK can bypass local-only locks.

OPTIONS
- Settings select controls use purple/black (or light-theme) in-app choice
  sheets with touch targets, keyboard support, and the original saved values.

BUILD
- The signing key/password and Discord Social SDK AAR are NOT in the source.
  Retain the existing private key and use a separately obtained, licensed SDK.
- See README-5.64.txt and build.sh for Android SDK 35, build-tools 35.0.1,
  NDK r27c and Gradle 8.10.2. Do not embed a client secret or signing key.
- The APK and supplied source were built/tested in a sandbox. No physical
  Android device, live Discord account, Kitsu user, or provider login was used.

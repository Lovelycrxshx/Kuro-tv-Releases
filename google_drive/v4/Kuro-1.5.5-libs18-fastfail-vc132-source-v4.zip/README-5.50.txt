KURO.TV 5.50 — EMAIL/PASSWORD AND LOCAL DATA

This file describes 5.50 and takes precedence over the older historical README
files. Package app.lovelycrxshx.kuro; version code 50; Android 8.0 or newer.

- Google account sign-in, its native Credential Manager integration, Google
  Drive authorization/backup UI, background scheduler, native Drive bridge and
  Google/Drive source modules have been removed from this build. No old Google
  Drive files are deleted or revoked. A previously connected Google identity is
  no longer used or displayed. Prior local watch data is not intentionally
  cleared; local profile editing is available without a signed-in account.
- Email/password signup and login still use the configured Supabase project.
  Signup uses the real /signup endpoint, not a fake local login. Before sending
  signup, Kuro asks that project's public Auth settings to confirm that email
  confirmation is disabled. It does not send a signup if that cannot be shown,
  and it only shows connected after the server returns an actual session. No
  signup/login email OTP, link or confirmation is implemented in this build.
- The app cannot change Supabase's settings. The project administrator must
  enable Email and turn OFF Confirm email under Authentication > Sign In /
  Providers > Email. Server policies, CAPTCHA, rate limits or connectivity can
  still block a real request. Old unconfirmed accounts may need separate admin
  attention. A project URL and a publishable/legacy anon key are required in
  Account setup; no admin secret or service-role key belongs in the client.
- Disabling email confirmation means users may register email addresses they do
  not own; email address ownership is not established. Do not use that address
  alone as proof of identity. Passwords are still validated by the server.
- Optional Forgot password is preserved for security and requires a recovery
  email link, separately from ordinary signup/sign-in. It needs a working
  Supabase email sender and redirect; default SMTP has restrictions. There is
  no unsafe unverified password-reset shortcut.
- There is no cloud backup or sync in 5.50. Email sign-in does NOT back up the
  local profile, bookmarks, history, progress, or imports. Existing Drive
  snapshots, if any, are not touched but cannot be accessed by this version.
- Discord/MAL/AniList account options and one-way imports remain independent;
  their providers may have their own authorization steps. Source-site human
  verification is unchanged and is not bypassed.
- local-restore-safety550.js is a local-only compatibility recovery for a
  journal from an interrupted 5.45–5.49 restore. It makes no network request.

Build: JDK 17+, Android SDK platform 35/build tools 35.0.1; set ANDROID_HOME,
JAVA_HOME, KEYSTORE and KS_PASS privately and run ./build.sh. The original
signing key and password are separate and NOT included. A matching signing
identity is required to install over earlier Kuro versions. Do not uninstall or
clear app data. If Android rejects the update, stop and report the exact error.

The supplied tests use fake providers and browser/native shadows. They do not
prove real-device installation, email signup, password reset, provider behavior,
playback, Android Keystore, or an existing cloud backup. 5.49 character artwork
and its attribution file are unchanged; third-party rights remain unverified.
Gallery coverage remains as in 5.49: Monster Musume is not included, the
ambiguous magician title was not resolved, and "Chillin' in Another World" is
interpreted as Level 2 Super Cheat Powers.

KURO.TV 5.75 — TEST RELEASE FOR THE UPDATE SYSTEM
================================================================
Version name   5.75
Version code   82   (5.74 was 81)
Package        app.lovelycrxshx.kuro
Purpose        To be published on GitHub so an installed 5.74 can find it,
               prove the update check works end to end, and download it.


----------------------------------------------------------------
WHY THIS BUILD EXISTS
----------------------------------------------------------------
5.74 could not prove its own update system, because GitHub's newest
release was the version already installed. A correct "up to date" and
a broken check look identical from the outside.

5.75 exists to be the newer release. Publish it, then let a phone
running 5.74 look for it.


----------------------------------------------------------------
CHANGES SINCE 5.74
----------------------------------------------------------------
Code changes are deliberately small; this is a test target, not a
feature release.

 1. Version 5.75, versionCode 82, in both build.gradle defaultConfig
    and AndroidManifest.xml.

 2. New diagnostic — "GitHub offers". Every completed check now stores
    the version and tag that GitHub returned, and Settings > Kuro
    updates prints them:

        GitHub offers: 5.75  (tag v5.75)
        Release source: https://api.github.com/repos/Lovelycrxshx/...

    This is the line that ends the guessing. After any check the
    dialog states what the server actually said, whether or not an
    update was offered.

Everything else is unchanged from 5.74: all 5.74-5.79 features,
the canonical repository, the releases-list fallback, tolerant tag
parsing and the visible error text.


----------------------------------------------------------------
HOW TO PUBLISH THIS ON GITHUB (so 5.74 can find it)
----------------------------------------------------------------
 1. Open https://github.com/Lovelycrxshx/Kuro-tv-Releases/releases
 2. Draft a new release.
 3. Tag: v5.75   (v5.75 and 5.75 both parse; keep the v for consistency)
 4. Target: main
 5. Title: Kuro.tv 5.75
 6. Attach the APK: Kuro-tv-5.75.apk
 7. IMPORTANT: leave "Set as the latest release" ticked, and do not
    tick "pre-release". Kuro ignores drafts and pre-releases by design.
 8. Publish.

Then, on the phone running 5.74:
 Settings > Kuro updates > Check now
 Expected: "Kuro 5.75 is available", then the reminder flow, then an
 automatic download, then Android's install prompt.

If instead it shows "GitHub offers: 5.73", the release did not become
the latest one. If it shows "GitHub offers: 5.75" but no notification
appears, Android notifications are blocked for Kuro.


----------------------------------------------------------------
VERIFICATION
----------------------------------------------------------------
Built with JDK 17, Android SDK platform 35, build-tools 35.0.0, NDK
r27c and the owner-supplied Discord Social SDK 1.10.19337 AAR
(release variant). Signed with the original release identity so it
installs over 5.73 and 5.74. Signature schemes v2 and v3, zipalign
16 KB page size.

Not verified on hardware: notification display, background download,
installer handoff. Those are exactly what this release is meant to
test on your phone.

Signing material and the Discord SDK AAR are not in the source archive.
===

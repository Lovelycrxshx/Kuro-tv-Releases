Kuro 5.78-test — experimental Anime Village episode fallback

Adds Anime Village as a fallback to the existing selected-title/episode flow. It searches the site's API for a unique exact title, checks the requested episode number and any available AniList identity, then offers only the site's returned MegaPlay embed when its HTTPS host, episode ID and audio mode match. Sub and dub are requested separately. It is not an independent Anime Village catalogue or browsing integration.

The embedded third-party player handles playback and any subtitles; Kuro does not consume the API's direct HLS or subtitle URLs, and does not provide native subtitle selection for this fallback. The player or source may change or require user interaction. No verification bypass is implemented. A live sample returned sub and dub embeds and the sub embed URL returned HTTP 200; that is not playback validation. Mocked API safety and matching tests passed. Android installation, video playback and subtitle behavior require physical-device testing.

Existing AniWaves.tv, Anikoto.cz and Gogoanimes.cv fallback integrations remain experimental and are not full catalogues. The 5.77 notification and fallback reliability changes remain included.

Signing key/password and the separately supplied Discord SDK are excluded from source archives.

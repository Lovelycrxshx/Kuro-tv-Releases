KURO.TV 5.51 — LOCAL EMAIL/PASSWORD, NO ACCOUNT SERVER

This file describes the current release and supersedes earlier historical notes.
Package app.lovelycrxshx.kuro; version code 51; Android 8.0 or newer.

- Google sign-in, Drive backup and the Supabase account integration are not in
  the active app. This build does not modify/delete any prior server account,
  project, Drive snapshot or user data. Legacy encrypted credentials may remain
  inactive in device storage; no old provider is contacted by the local login.
- Email/password is now ONE local convenience account per app installation.
  Create a new one on this phone. The entered email is an identifier only: its
  ownership is not verified, no email or OTP is sent, and this is NOT a real
  cross-device account. It does not migrate or authenticate an old server login.
- Passwords are not stored in plaintext: a random salt and PBKDF2-HMAC-SHA256
  verifier (310,000 rounds) are saved in the existing Android Keystore-backed
  encrypted vault. Local sign-in checks the password; repeated wrong attempts
  cause a brief local delay. These measures do not make an offline app tamperproof.
- The local account is a convenience, not an app lock: the separate local
  profile, bookmarks, lists and history remain usable without sign-in and are
  not encrypted or protected by this password. There is no cloud backup/sync.
- Password reset and recovery are not provided. Remember the password;
  if forgotten, local profile and watch data remain usable signed out, but the
  local account cannot be recovered by email. Do not clear data or uninstall.
- The editable local profile, character gallery, MAL/AniList imports and
  separate Discord/MAL/AniList provider options remain. Those providers may
  require their own authorization; the local account needs no provider setup.
  Existing data is not intentionally replaced. Source-site verification is not
  bypassed. Existing interrupted-restore journal handling remains local only.
- The 5.49 character gallery is unchanged: Monster Musume is absent, the
  ambiguous magician title remains unresolved and Chillin' in Another World is
  interpreted as Level 2 Super Cheat Powers. Fan/third-party artwork rights were
  not verified; credits are included.

Build using JDK 17+, Android platform 35 and build-tools 35.0.1. Set ANDROID_HOME,
JAVA_HOME, KEYSTORE and KS_PASS privately and run ./build.sh. The original
private signer is not bundled and is required to update the installed Kuro app.
Android preserves app data during a compatible in-place update; real phone
installation was not tested. Never uninstall or clear data to update.

Tests use simulated providers / browser / Android shadows, not a phone. They do
not establish real playback, provider login, device keystore, performance or a
cloud backup. No APK/source upload or cloud deletion is performed by this update.

KURO.TV 5.57 — FOUR-COLUMN MY LISTS

My Lists opens on All. Its filters are arranged in this order, four per row:
  All, Watching, Completed, On hold
  Dropped, Planned to watch, Imported, Bookmark
  History
The layout does not require horizontal scrolling. On small phones, long labels
wrap within their own buttons. Buttons expose their selected state to assistive
technology. The grid was measured in a simulated browser at 280–768 CSS pixels,
not on a physical phone.

All displays a non-destructive union of local bookmarks and categorized titles,
with duplicate local entries removed only from the display when both source and
URL match. Visible imported entries are shown separately; imported entries and
local titles are not guessed or merged across providers. Bookmark, Imported and
History remain separate routes, as do each status. Your existing stored data is
not rewritten by changing the layout or switching filters.

The imported-content safety gate, read-only exact-ID details and non-overwriting
snapshots remain from 5.56. Adult and unclassified imports are hidden unless
explicitly opted in; the optional AniList ID classification remains separate and
requires confirmation. Local email remains device-only and unverified, with no
OTP or recovery and no encryption of lists. Google sign-in, Drive backup and
Supabase remain absent. Optional Discord/MAL/AniList connections and tracker
sync retain their prior behavior.

Version 5.57 / code 57; package app.lovelycrxshx.kuro; Android 8.0+.
Install over the existing Kuro app. Do not uninstall or clear data. If Android
reports an installation conflict, stop and preserve the existing app and data.
The original private signing key is stored separately and is not bundled here.

Tests use fake provider data and synthetic browser/Android environments. They do
not establish real-phone installation, live provider access, playback, codecs,
rotation, notifications, GPU performance or battery use. The 5.56 base was a
reconstruction from the 5.53 backup, not the original 5.55 binary.

BUILD / SOURCE BACKUP
The ZIP and text source archives include the source, tests, assets and build
scripts. Use JDK 17+, Android SDK platform 35 and build-tools 35.0.1; Gradle and
dependencies require a first-run download. Set JAVA_HOME, ANDROID_HOME, KEYSTORE
and KS_PASS privately, then run build.sh. The original key is required for an
update-compatible APK. Never put signing material in the source or a public link.
The text backup contains readable UTF-8 and base64 binary files with per-file
SHA-256. From the source ZIP, restore it into a NEW directory with:
  python3 scripts/restore-source-text.py /path/Kuro-tv-5.57-Source.txt NEW_DIR

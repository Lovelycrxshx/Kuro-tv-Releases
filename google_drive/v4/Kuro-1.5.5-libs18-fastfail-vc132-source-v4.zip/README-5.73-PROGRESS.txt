Kuro 5.73-test - development build

This source matches the application code and assets in the accompanying APK.
It is a work-in-progress, not a statement that all proposed feature extensions are complete.

This update includes: AniList seasonal catalogue, release calendar and opt-in recommendations; bounded prequel/sequel traversal; local library search, audio/source filters and sorting; a catalogue light palette; accessibility focus improvements; playback diagnostics and recovery work; native saved intro/outro markers and the same saved or supplied markers for Kuro's own direct Web stream player. The auto-skip detector can also attempt visible skip controls on supported embedded pages.

Limitations: embedded players do not expose reliable seeking or arbitrary marker edits to Kuro; marker-based Web skipping only works on Kuro's direct stream page. Some providers, WebViews or playback situations may not report enough information. Imported items have their own search. Title exclusions are not global. Watch-order exploration is bounded and not definitive. Theme, layouts, accessibility and actionable errors do not cover every surface. No physical-device testing was performed. No cloud sync was added.

The APK was signed with the same certificate as Kuro 5.72. The private key and Discord Social SDK AAR are not included in this archive. The Discord AAR must be obtained separately as documented in README-5.64.txt. The source text archive can be restored with scripts/restore-source-text.py.

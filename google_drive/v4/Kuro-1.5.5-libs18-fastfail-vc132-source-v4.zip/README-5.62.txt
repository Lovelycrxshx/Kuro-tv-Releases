KURO.TV 5.62 — ANILIST SIGN-IN CORRECTION

This is a focused update to 5.61. Kuro's AniList implicit OAuth authorization
request no longer sends an extra redirect_uri parameter. It now sends only the
public client_id and response_type=token, as shown in AniList's documentation:
https://docs.anilist.co/guide/auth/implicit
The AniList developer application's registered redirect must still be:
https://anilist.co/api/v2/oauth/pin

AniList tokens grant broad account access. Kuro reads the account identity and
anime list and can update list status/progress when tracker sync is enabled.
Paste the token only into the Kuro dialog on your own device. Never share it,
the client secret or a post-authorization URL in a chat. Public numeric client
IDs are not secrets. The app's token vault remains encrypted on the device.

The prior 5.61 playback, drawer, profile, locally stored lists, accounts,
preferences, backups, logos and feature limitations remain; see README-5.61.txt.
No app storage, cookies, accounts or lists are intentionally cleared by this
update. Package app.lovelycrxshx.kuro, version 5.62 / code 62, Android 8+.
Install the signed APK over the existing app. Do not uninstall or clear data.
If Android reports a signature or version conflict, stop and keep the app/data.

The developer page must be configured by the user with their own client ID and
PIN redirect. No credentials, user accounts or device were available during
this repair. The URL shape was tested locally, but a real AniList approval and
phone sign-in have not been verified; the user's screenshot did not display its
full request and the reported cause remains likely rather than proven.

Build with JDK 17+, Android SDK platform 35 and build-tools 35.0.1. Keep the
original signer outside the source archive. Set JAVA_HOME, ANDROID_HOME,
KEYSTORE and KS_PASS privately and run ./build.sh. Source ZIP and TXT contain
the same files and can be restored using scripts/restore-source-text.py.

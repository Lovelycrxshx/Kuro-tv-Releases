KURO.TV 5.74 — UPDATE CHECK HARDENED AND MADE VISIBLE, ALL 5.74–5.79 FEATURES

WHAT WAS ACTUALLY WRONG (measured, not assumed)
The update checker was suspected of being dead because the release repository had been
renamed from ImAuraxSiva/Kuro-tv-Releases to Lovelycrxshx/Kuro-tv-Releases, and the old
path now answers HTTP 301 with a small JSON error body instead of release data.

That suspicion was tested and is NOT the fault. The 5.73 updater already disabled
HttpURLConnection's automatic redirects and followed the Location header itself, so it
coped with the rename. Running the unmodified 5.73 code against GitHub returns:

    fetch: PASS  460 ms  8437 B
    parse: version=5.73  asset=Kuro-tv-5.73.apk  54492725 B
    tag -> version   : 5.73  (tag was v5.73)
    isNewer(5.73,5.73): false

The real reason nothing appeared on the phone is the last line: GitHub's latest release
was v5.73 and 5.73 was installed, so there was no newer version to report. A silent,
correct "up to date" is indistinguishable from a broken check, which is the defect this
release fixes.

WHAT 5.74 CHANGES
 1. Canonical repository. Requests go to Lovelycrxshx/Kuro-tv-Releases directly, so the
    301 hop is gone. The old renamed path is kept only as a second attempt.
 2. Third fallback. If /releases/latest is refused or returns nothing usable, Kuro reads
    /releases?per_page=5 and selects the highest non-draft, non-prerelease version.
 3. Tolerant tag parsing. Tags are reduced to their dotted number wherever it appears, so
    v5.74, 5.74-test and Kuro-tv-5.74 all read as 5.74. Previously only a bare 5.74 did.
 4. Visible diagnostics. Settings → Kuro updates now prints the exact release URL that
    produced the answer, or the error text when none did. Checking can no longer fail
    silently.

VERIFICATION PERFORMED (live GitHub, app code, desktop JVM)
Compiled the shipped KuroUpdater572 against android-35 and executed its own getText() and
parsers against the real API. All three paths answered and parsed identically:

    canonical /releases/latest   542 ms   8437 B  -> version 5.73  Kuro-tv-5.73.apk 54492725 B
    legacy renamed repo (301)    299 ms   8437 B  -> version 5.73  Kuro-tv-5.73.apk 54492725 B
    releases list fallback       157 ms  16804 B  -> version 5.73  Kuro-tv-5.73.apk 54492725 B

Decision logic: isNewer("5.73","5.74") false and isNewer("5.75","5.74") true.
Not verified: the notification actually appearing, the background download, and Android's
installer. Those need a device and, for the notification, a genuinely newer release
published on GitHub (for example v5.75).

EVERYTHING THROUGH 5.79 IS INCLUDED — 5.73 already carried the 5.79-test codebase:
 · 5.74  home discovery/recommendation section removed (local data untouched); auto-skip
         stays opt-in and acts only on explicit visible intro/outro controls.
 · 5.75  experimental exact-episode fallbacks: AniWaves.tv, Anikoto.cz, Gogoanimes.cv.
 · 5.76  home surfaces suppress accidental text selection and touch callouts; monochrome
         news status icon, branded image, purple accent, Open news action.
 · 5.77  a restricted fallback library no longer stops the other fallback searches; news
         notifications gain Read article plus an optional 1.5 MB-capped large icon.
 · 5.78  Anime Village experimental episode fallback through its MegaPlay embed.
 · 5.79  Discord activity episode names use quotation marks: Episode 1 - "Title" · DUB.

VERSIONING
Android versionCode 81 (5.73 was 80) and versionName 5.74. The version exists in TWO
places and both are set: build.gradle defaultConfig, which wins during a Gradle build, and
AndroidManifest.xml. Setting only the manifest would ship 80/5.73 and be refused by
Android as an install over an equal version. Any future build must use a versionCode
above 81.

BUILD NOTES
buildToolsVersion is 35.0.0 here. Google does not publish build-tools 35.0.1 for Linux
(both known download paths return 404), so 35.0.0 was used; this affects only which tool
binaries run, not the output. Windows and macOS builds may keep 35.0.1.
The release was built with the owner-supplied Discord Social SDK 1.10.19337 AAR
(discord_partner_sdk.aar, 29,875,932 bytes, release variant) and Android NDK r27c, which
compiled build/kuro-discord-jni for arm64-v8a, armeabi-v7a, x86_64 and x86. Signed with
the original release identity, certificate CN=Kuro Anime, SHA-256
1d37c3ca28ed80cc484601a7a7907d5c43970a5d57d51aa4e91475a60703e93e, schemes v2 and v3,
zipalign 16 KB page size verified. The APK is 54,492,725 bytes, MD5
177ef547c09f5d17b4f26ee1d393e873 — the same size as 5.73 by coincidence of alignment
padding; versionCode 81 is what distinguishes it.

Signing material and the Discord SDK AAR are never included in source archives. Nothing
was installed on a device, and no playback, subtitle, notification or Discord appearance
test was performed on hardware. Never uninstall Kuro or clear its data.

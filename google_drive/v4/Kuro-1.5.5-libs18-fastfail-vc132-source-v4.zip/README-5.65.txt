KURO.TV 5.65 — DISCORD EPISODE DETAILS AND PLAYBACK PROGRESS
==============================================================

This file describes the current 5.65 update and supersedes the 5.64 presence
instructions. Existing source documentation for older releases is kept for
history. Package app.lovelycrxshx.kuro, version 5.65/code 65, Android 8+.

EXAMPLE ACTIVITY
  Watching Kuro.tv
  Jujutsu Kaisen
  Episode 12 - (The Shibuya Incident) · DUB
  [Discord's progress/timer, when playback and duration are observable]
  [Watch]

The anime and episode are examples, not values baked into the app. The number,
name, audio and public page come from Kuro's actual selected episode and source
metadata. If an episode name is not supplied, only its number is shown. No
name is invented. The anime/episode-first layout, separators, server and total
choices still apply; an episode name is suppressed if anime title or episode
visibility is off. Watch is hidden when either visibility choice is off or a
safe public page is unavailable. A numeric HiAnime.dk episode query is allowed;
other queries, URL credentials, fragments, stream/API/embed URLs and unknown
hosts are not published. A safe show page may be used when the exact episode
page is unavailable. A path alone cannot guarantee that a provider never put
sensitive text there; do not use private or secret URLs as source pages.

The user selected Watch only for now. There is no Discord Download button in
5.65, even if 5.64 had saved a Download choice. The old preference is not
deleted. This does not remove the app's separate authorized media-download
feature. No APK, source, Drive folder or signing material has been made public.

REAL PROGRESS, NOT AN ASSUMED TIMER

For a playing video with a valid position and finite duration, Kuro supplies
Discord with both real Unix-millisecond start and end timestamps, adjusted for
actual playback speed. Discord controls whether and how a progress bar or timer
is displayed. On pause, buffering or end, timestamps are removed so they cannot
keep falsely advancing. The optional paused-position text remains controlled by
existing settings. Seeking and rate changes are re-sampled. Latest changes are
coalesced; SDK/Discord delivery may delay updates and no live rendering is
promised. When playing normally the timestamp lets Discord advance the display
between publications without per-second network sends.

Native Media3 and Kuro's direct HLS player remain supported. For WebView players,
Kuro can now observe a single visible HTML video in the top-level permitted
player or in a frame on the existing explicit HTTPS player-origin allowlist,
when the Android WebView supports its document-start and message features.
The fixed-command frame bridge reports only attempt number, state, position,
duration and rate; it does not expose account data, cookies, media URLs, stream
bytes or playback commands. It samples only while Discord sharing is on and Kuro
is visible/PiP. Frames from another attempt or origin and stale data are ignored.
A unique visible candidate of at least 60 seconds is required to reduce the risk
of treating an advertisement as an episode; multiple candidates, short clips,
protected/opaque frames, unsupported origins, stale observations and other
unreadable states fall back to Selected without invented timing. These checks
reduce ambiguity but cannot establish the identity of every third-party video.
There is no bypass of DRM, verification, cross-origin protection or access
controls. Every provider and WebView version is different and may stop working.

SETUP AND SECURITY

Install the signed APK over existing Kuro; never uninstall or clear app data. In
Discord enable activity sharing and sign in; in Kuro Settings → Discord Rich
Presence turn Share activity on. Share current/linked accounts separately.
Discord often hides the owner's own buttons: a friend may need to check. An SDK
success is not proof that Discord showed the activity. For a linked account,
Discord application 1569077670074122250 needs Social SDK enabled, Public Client
on and this exact registered redirect:
  discord-1569077670074122250:/authorize/callback
Do not enter/send access tokens, passwords or client secrets. Linked credentials
use Android Keystore and are excluded from local backups. See README-5.64.txt
for the unchanged OAuth, lifecycle, third-party notices, rebuild instructions,
SDK version and checksum. It is an older release document where details differ.

LIMITATIONS
No Android phone, live Discord, linked account, profile progress rendering or
real third-party player was available for testing. Kuro cannot promise delivery,
visibility, simultaneous accounts or exact timing on all devices. The included
host/browser and Robolectric tests are simulations. Kuro samples progress about
every three seconds and coalesces updates at roughly 15-second intervals; the
actual Discord update can take longer. Background clearing is best-effort.

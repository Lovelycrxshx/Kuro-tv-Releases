HISTORICAL NOTES: For current behavior and setup see README-5.46.txt.

KURO.TV 5.44 — GOOGLE BUTTON CRASH FIX

What was fixed
- The 5.43 APK packaged AndroidX Core 1.1.0 even though its Activity 1.5.1
  dependency requires Core 1.8.0 or newer. Six interfaces implemented by
  ComponentActivity, plus other runtime classes, were missing from the DEX.
  The Play Services metadata also excluded AndroidX Loader. A normal build
  did not detect these runtime omissions.
- Explicit AndroidX Core 1.13.1, Activity 1.5.1, and Loader 1.1.0 dependencies
  now provide the required runtime classes. The Gradle dependency report and
  actual release APK DEX should be checked before distributing another build.
- Kuro catches native Google provider runtime/linkage failures where it can and
  shows a safe error without displaying exception text or tokens. Errors inside
  Android/Google activities outside Kuro's callbacks cannot all be intercepted.

Diagnosis and tests
- Under Robolectric, the actual AndroidX Play Services provider launched its
  HiddenActivity. Recreating the 5.43 Core 1.1.0 / no-Loader dependency set
  reproduced NoClassDefFoundError for OnConfigurationChangedProvider in that
  activity. The same provider/activity test passed using the new dependencies.
  This matches the reported symptom, but a real phone stack was not collected.
  To reproduce the expected failure, use this diagnostic (never for release):
  ./gradlew --no-daemon --init-script tests/force-543-core.gradle testDebugUnitTest --tests '*GoogleNative544Test.realPlayServicesProviderCreatesAndStartsItsHiddenActivity'
- The APK regression test checks class definitions, including ComponentActivity
  interfaces and Loader, not merely strings. It must fail on the old 5.43 APK
  and pass on the new signed APK. Run it after building:
  python3 tests/test-google-apk-classes.py /path/to/Kuro-tv-5.44.apk
- Run the Gradle/Robolectric suite with tests/native-panel/run.sh. Its Google
  tests cover the real local provider/hidden-activity path on Android 8 and 13
  shadows, plus simulated provider errors, cancellation and token forwarding.
  Android 14 Credential Manager factory handling is also checked in a shadow.
  Neither a physical handset nor real Google Play services, a real account,
  or successful live Google login was tested.

Privacy and update
- The package, signing certificate, storage, profile, bookmarks, imports and
  other account providers are preserved. Install this APK over the existing
  signed Kuro app. Never uninstall Kuro or clear its data to install the update.
  If Android refuses the update, stop and report the exact installer message.
- Google still requires internet, up-to-date Google Play services, the public
  Web client ID, a correctly registered Android OAuth client, and test-user
  access when the Cloud app is in Testing. No Google client secret is needed
  in Kuro. Kuro's verified Google identity remains local to the phone; it is
  not a backend/cloud account or a cross-device sync feature.
- No new APK, source, log, key or other artifact was uploaded by this fix.

Build
- JDK 17+, Android SDK platform 35 and build-tools 35.0.1 are required.
  Set ANDROID_HOME, JAVA_HOME, KEYSTORE, KS_PASS and optional OUT; run build.sh.
  The private signing key/password must remain outside the source tree.
  Official Maven dependencies and Gradle are downloaded on a first build.
- libs/core-1.1.0.aar is a historical source-bundle artifact, not the Core
  version in the 5.44 runtime APK. See build.gradle and third-party notices.
- All earlier 5.43/5.42 features and their historical notes remain included.

package app.lovelycrxshx.kuro;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.*;

/** Public catalogue metadata only; fixed query and endpoint, no account tokens. */
public final class KuroCatalog573 {
 static JSONObject request(String action,String input) throws Exception {
  if(input==null||input.length()>("metaBatch154".equals(action)||"watchFeed154".equals(action)?2400:300))throw new IOException("Invalid request");
  JSONObject p=new JSONObject(input),v=new JSONObject();String query;
  if("season".equals(action)){
   int year=p.optInt("year",0),page=p.optInt("page",0);String season=p.optString("season","");
   if(year<1940||year>2100||page<1||page>50||!java.util.Arrays.asList("WINTER","SPRING","SUMMER","FALL").contains(season))throw new IOException("Invalid season");
   v.put("year",year).put("season",season).put("page",page);
   query="query($year:Int,$season:MediaSeason,$page:Int){Page(page:$page,perPage:20){pageInfo{hasNextPage} media(type:ANIME,seasonYear:$year,season:$season,isAdult:false,sort:POPULARITY_DESC){id isAdult title{romaji english} format status episodes startDate{year month day} nextAiringEpisode{airingAt episode}}}}";
  }else if("calendar".equals(action)){
   long start=p.optLong("start",0),end=p.optLong("end",0);int page=p.optInt("page",0);
   if(start<1||end<=start||end-start>8*86400L||end>2147483647L||page<1||page>50)throw new IOException("Invalid calendar range");
   v.put("start",start).put("end",end).put("page",page);
   query="query($start:Int,$end:Int,$page:Int){Page(page:$page,perPage:50){pageInfo{hasNextPage} airingSchedules(airingAt_greater:$start,airingAt_lesser:$end,sort:TIME){airingAt episode media{id type isAdult title{romaji english}}}}}";
  }else if("recommend".equals(action)){
   long id=p.optLong("id",0);String provider=p.optString("provider","");if(id<1||id>999999999||!(provider.equals("anilist")||provider.equals("mal")))throw new IOException("Invalid catalogue ID");v.put("id",id);
   String field=provider.equals("mal")?"idMal":"id";
   query="query($id:Int){Media("+field+":$id,type:ANIME){id isAdult recommendations(page:1,perPage:20,sort:RATING_DESC){nodes{rating mediaRecommendation{id type isAdult title{romaji english} format}}}}}";
  }else if("related".equals(action)){
   long id=p.optLong("id",0);String provider=p.optString("provider","");if(id<1||id>999999999||!(provider.equals("anilist")||provider.equals("mal")))throw new IOException("Invalid catalogue ID");v.put("id",id);
   String field=provider.equals("mal")?"idMal":"id";
   query="query($id:Int){Media("+field+":$id,type:ANIME){id isAdult title{romaji english} relations{edges{relationType node{id type isAdult title{romaji english} format startDate{year month day}}}}}}";
  }else if("detail154".equals(action)){
   long id=p.optLong("id",0);String provider=p.optString("provider",""),search=p.optString("search","").trim();
   String fields="{id idMal isAdult title{romaji english} bannerImage coverImage{extraLarge large} averageScore duration episodes status format season seasonYear genres studios(isMain:true){nodes{name}} nextAiringEpisode{airingAt episode} streamingEpisodes{title thumbnail} relations{edges{relationType node{id idMal type isAdult title{romaji english} format status episodes startDate{year month day}}}}}";
   if(id>=1&&id<=999999999&&(provider.equals("anilist")||provider.equals("mal"))){v.put("id",id);String field=provider.equals("mal")?"idMal":"id";query="query($id:Int){Media("+field+":$id,type:ANIME,isAdult:false)"+fields+"}";}
   else if(search.length()>=1&&search.length()<=140){v.put("search",search);query="query($search:String){Media(search:$search,type:ANIME,isAdult:false,sort:SEARCH_MATCH)"+fields+"}";}
   else throw new IOException("Invalid detail lookup");
  }else if("metaBatch154".equals(action)){
   if(p.optBoolean("random",false)){
    int page=Math.max(1,Math.min(12,p.optInt("page",1)));v.put("page",page);
    query="query($page:Int){Page(page:$page,perPage:24){media(type:ANIME,isAdult:false,sort:POPULARITY_DESC,averageScore_greater:74){id idMal isAdult title{romaji english} coverImage{large} bannerImage averageScore format status episodes season seasonYear genres}}}";
   }else if(p.optJSONArray("ids")!=null){
    JSONArray rawIds=p.optJSONArray("ids"),cleanIds=new JSONArray();
    for(int i=0;i<rawIds.length()&&cleanIds.length()<36;i++){long x=rawIds.optLong(i,0);if(x>=1&&x<=999999999)cleanIds.put(x);}
    if(cleanIds.length()==0)throw new IOException("Empty IDs");v.put("ids",cleanIds);
    query="query($ids:[Int]){Page(page:1,perPage:36){media(id_in:$ids,type:ANIME,isAdult:false){id idMal isAdult title{romaji english} averageScore format status episodes season seasonYear genres}}}";
   }else if(p.optJSONArray("titles")!=null){
    JSONArray names=p.optJSONArray("titles");if(names.length()==0||names.length()>8)throw new IOException("Invalid title batch");
    StringBuilder params=new StringBuilder("query("),body=new StringBuilder("{");int count=0;
    for(int i=0;i<names.length();i++){String name=names.optString(i,"").trim();if(name.length()<2||name.length()>140)continue;if(count>0)params.append(",");params.append("$q").append(count).append(":String");body.append("m").append(count).append(":Media(search:$q").append(count).append(",type:ANIME,isAdult:false,sort:SEARCH_MATCH){id idMal isAdult title{romaji english} averageScore format status episodes season seasonYear genres} ");v.put("q"+count,name);count++;}
    if(count==0)throw new IOException("Empty title batch");
    query=params.append(")").append(body).append("}").toString();
   }else throw new IOException("Invalid batch lookup");
  }else if("watchFeed154".equals(action)){
   long id=p.optLong("id",0);String search=p.optString("search","").trim();
   String recFields="{id idMal isAdult title{romaji english} bannerImage coverImage{extraLarge large} averageScore episodes format seasonYear genres studios(isMain:true){nodes{name}}}";
   String mediaFields="{id bannerImage coverImage{extraLarge large} averageScore duration seasonYear genres streamingEpisodes{title thumbnail} recommendations(page:1,perPage:14,sort:RATING_DESC){nodes{mediaRecommendation"+recFields+"}}}";
   String fb="fallback:Page(page:1,perPage:16){media(type:ANIME,isAdult:false,sort:POPULARITY_DESC)"+recFields+"}";
   if(id>=1&&id<=999999999){v.put("id",id);query="query($id:Int){Media(id:$id,type:ANIME,isAdult:false)"+mediaFields+" "+fb+"}";}
   else if(search.length()>=1&&search.length()<=140){v.put("search",search);query="query($search:String){Media(search:$search,type:ANIME,isAdult:false,sort:SEARCH_MATCH)"+mediaFields+" "+fb+"}";}
   else{query="query{"+fb+"}";}
  }else throw new IOException("Invalid action");
  return new JSONObject().put("query",query).put("variables",v);
 }
 public static String lookup(String action,String input) throws Exception {
  JSONObject data=request(action,input);
  return KuroFastNet154.postAnilistCatalog(data.toString(),700000);
 }
}

package app.lovelycrxshx.kuro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.view.View;

/**
 * 5.82s · Rounds the video by PAINTING THE CORNERS AWAY.
 *
 * Four clipping attempts failed on device: clipToOutline on a SurfaceView, then on a
 * TextureView, then on a wrapping FrameLayout with an outline, then with an added
 * canvas.clipPath. Each was measured square. The common factor is that all of them
 * ASK a compositor to clip, and a video that is composited in its own layer can
 * sidestep the request.
 *
 * This does not ask. It sits on top of the video and draws four concave corner patches
 * in the surround colour with a CLEAR xfermode, so whatever the GPU composited
 * underneath is erased at the corners. If the frame is drawn at all, this works.
 */
final class KuroCornerMask582s extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private float radiusPx = 0f;
    private int color = 0xff000000;

    KuroCornerMask582s(Context c, int radiusPx, int surroundColor) {
        super(c);
        this.radiusPx = radiusPx;
        this.color = surroundColor;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(surroundColor);
        setTag("kuro-mask-582s");
        setClickable(false);
        setFocusable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    void setRadius(float px) { radiusPx = Math.max(0f, px); invalidate(); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (radiusPx <= 0f) return;
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;

        // Clear the four corner squares, then refill everything outside the arcs.
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        canvas.drawRect(0, 0, radiusPx, radiusPx, paint);
        canvas.drawRect(w - radiusPx, 0, w, radiusPx, paint);
        canvas.drawRect(0, h - radiusPx, radiusPx, h, paint);
        canvas.drawRect(w - radiusPx, h - radiusPx, w, h, paint);

        // Paint the surround colour back outside each arc, leaving the rounded corner.
        paint.setXfermode(null);
        paint.setColor(color);
        drawCorner(canvas, 0, 0, 0, 0);
        drawCorner(canvas, w, 0, 1, 0);
        drawCorner(canvas, 0, h, 0, 1);
        drawCorner(canvas, w, h, 1, 1);
    }

    /** Fills the region of a radius x radius square that lies OUTSIDE the corner arc. */
    private void drawCorner(Canvas canvas, float cx, float cy, int dx, int dy) {
        path.reset();
        float r = radiusPx;
        float ax = cx + (dx == 0 ? r : -r);
        float ay = cy + (dy == 0 ? r : -r);
        // square minus circle
        path.addRect(Math.min(cx, cx + (dx == 0 ? r : -r)), Math.min(cy, cy + (dy == 0 ? r : -r)),
                Math.max(cx, cx + (dx == 0 ? r : -r)), Math.max(cy, cy + (dy == 0 ? r : -r)),
                Path.Direction.CW);
        path.addCircle(ax, ay, r, Path.Direction.CCW);
        canvas.drawPath(path, paint);
    }
}

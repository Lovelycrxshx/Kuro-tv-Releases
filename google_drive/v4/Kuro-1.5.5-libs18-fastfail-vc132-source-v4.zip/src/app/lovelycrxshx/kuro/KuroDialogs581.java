package app.lovelycrxshx.kuro;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Kuro 5.81 — themed dialogs.
 *
 * The settings screens had two visual languages: the app itself is dark violet with
 * rounded cards (see PlayerOptionsDialog), while every settings dialog was a stock
 * Material alert: grey panel, teal system accent, flat list rows. This class renders
 * those dialogs with the app's own palette, rounded panel, focus states and motion so
 * the same screen stops looking like two different apps.
 *
 * Everything here is built from framework views only, so it also works on the
 * android:style/Theme.Material.NoActionBar base theme the app uses (no AppCompat,
 * no Material Components dependency).
 *
 * Remote-first rules baked in:
 *  - every action and every choice row is focusable and takes a visible focus ring
 *    through a StateListDrawable, so DPAD navigation never loses the cursor;
 *  - initial focus is placed on the first action or the selected choice, never on
 *    the panel itself;
 *  - a focused-but-not-selected choice still shows a ring, distinct from "selected".
 */
public final class KuroDialogs581 {

    // Palette taken from the app's own CSS and PlayerOptionsDialog so the native
    // layer cannot drift from the WebView layer again.
    static int INK, MUTED, PURPLE, PURPLE_SOFT, PANEL, CARD, BORDER, SELECTED, DIVIDER;
    static {
        KuroTheme12.register(KuroDialogs581::retint);
    }

    static void retint() {
        INK = KuroTheme12.col(0xfff3eef7);
        MUTED = KuroTheme12.col(0xffb7a4c7);
        PURPLE = KuroTheme12.col(0xffa65be4);
        PURPLE_SOFT = KuroTheme12.col(0xffc088f4);
        PANEL = KuroTheme12.col(0xff100c18);
        CARD = KuroTheme12.col(0xff211229);
        BORDER = KuroTheme12.col(0xff665078);
        SELECTED = KuroTheme12.col(0xff2b1a3a);
        DIVIDER = KuroTheme12.col(0xff3a2c4a);
    }

    private KuroDialogs581() {
    }

    static Activity findActivity155(Context c) {
        Context cur = c;
        for (int i = 0; i < 12 && cur != null; i++) {
            if (cur instanceof Activity) return (Activity) cur;
            if (cur instanceof android.content.ContextWrapper) cur = ((android.content.ContextWrapper) cur).getBaseContext();
            else break;
        }
        return null;
    }

    static boolean canShow155(Context c) {
        Activity a = findActivity155(c);
        return a != null && !a.isFinishing() && !a.isDestroyed();
    }

    static boolean safeShow155(Dialog d, Context c) {
        if (d == null || !canShow155(c)) return false;
        try {
            d.show();
            return true;
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    static android.app.AlertDialog safeShowBuilder155(android.app.AlertDialog.Builder b, Context c) {
        if (b == null || !canShow155(c)) return null;
        try {
            android.app.AlertDialog d = b.create();
            d.show();
            return d;
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    /** Context for stock alert dialogs: keeps Activity IBinder token intact while enforcing App DPI. */
    public static Context themed(Context context) {
        KuroDisplay155.enforce500Dpi(context);
        return new ContextThemeWrapper(context, KuroTheme12.dialogTheme());
    }

    public static Builder build(Activity activity, String title) {
        return new Builder(activity, title);
    }

    public interface ChoiceListener {
        void onChoice(int index);
    }

    private interface Block {
        void render(LinearLayout host);
    }

    private static final class Action {
        final String label;
        final boolean primary;
        final Runnable run;

        Action(String label, boolean primary, Runnable run) {
            this.label = label;
            this.primary = primary;
            this.run = run;
        }
    }

    public static final class Builder {
        private final Activity activity;
        private final String title;
        private String subtitle = "";
        private boolean cancelable = true;
        private final List<Block> blocks = new ArrayList<>();
        private final List<Action> actions = new ArrayList<>();
        private final Dialog[] owner = new Dialog[1];

        Builder(Activity activity, String title) {
            this.activity = activity;
            this.title = title;
        }

        private int dp(int n) {
            return Math.round(n * activity.getResources().getDisplayMetrics().density);
        }

        public Builder subtitle(String text) {
            this.subtitle = text == null ? "" : text;
            return this;
        }

        /** A label/value line: "Installed" / "Kuro 5.80". */
        public Builder row(String label, String value) {
            final String l = label == null ? "" : label;
            final String v = value == null ? "" : value;
            blocks.add(host -> {
                LinearLayout line = new LinearLayout(activity);
                line.setOrientation(LinearLayout.HORIZONTAL);
                line.setGravity(Gravity.CENTER_VERTICAL);
                line.setPadding(0, dp(5), 0, dp(5));
                TextView name = body(l, 13, MUTED);
                name.setMaxLines(2);
                TextView val = body(v, 13, INK);
                val.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                val.setGravity(Gravity.END);
                val.setMaxLines(3);
                line.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                vp.setMarginStart(dp(12));
                line.addView(val, vp);
                host.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            });
            return this;
        }

        /** A muted paragraph. */
        public Builder note(String text) {
            final String t = text == null ? "" : text;
            if (t.isEmpty()) return this;
            blocks.add(host -> {
                TextView tv = body(t, 12, MUTED);
                tv.setLineSpacing(dp(3), 1f);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                p.topMargin = dp(6);
                host.addView(tv, p);
            });
            return this;
        }

        /** Small uppercase group label. */
        public Builder section(String text) {
            final String t = text == null ? "" : text;
            if (t.isEmpty()) return this;
            blocks.add(host -> {
                TextView tv = body(t.toUpperCase(java.util.Locale.US), 11, MUTED);
                tv.setLetterSpacing(0.12f);
                tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                p.topMargin = dp(12);
                p.bottomMargin = dp(6);
                host.addView(tv, p);
            });
            return this;
        }

        /**
         * Parses a "Label: value" report (the updater's describe() output) into rows,
         * keeping anything that is not a label/value pair as a paragraph. Formatting
         * stays owned by the caller; only presentation changes here.
         */
        public Builder body(String report) {
            if (report == null) return this;
            for (String raw : report.split("\n")) {
                String line = raw == null ? "" : raw.trim();
                if (line.isEmpty()) continue;
                int colon = line.indexOf(": ");
                if (colon > 1 && colon <= 40) {
                    row(line.substring(0, colon), line.substring(colon + 2));
                } else {
                    note(line);
                }
            }
            return this;
        }

        /** Radio list. Picking a row dismisses the dialog and reports the index. */
        public Builder choice(String[] labels, String[] hints, int selected, ChoiceListener listener) {
            final String[] texts = labels == null ? new String[0] : labels;
            final String[] subs = hints == null ? new String[texts.length] : hints;
            final int current = selected;
            final ChoiceListener onChoice = listener;
            blocks.add(host -> {
                for (int i = 0; i < texts.length; i++) {
                    final int index = i;
                    boolean isSelected = index == current;
                    LinearLayout rowView = new LinearLayout(activity);
                    rowView.setOrientation(LinearLayout.HORIZONTAL);
                    rowView.setGravity(Gravity.CENTER_VERTICAL);
                    rowView.setFocusable(true);
                    rowView.setClickable(true);
                    rowView.setContentDescription(texts[index] + (isSelected ? ", selected" : ""));
                    rowView.setBackground(rowBackground(isSelected, dp(12)));
                    rowView.setPadding(dp(12), dp(10), dp(12), dp(10));

                    // radio dot
                    LinearLayout dot = new LinearLayout(activity);
                    dot.setGravity(Gravity.CENTER);
                    GradientDrawable ring = new GradientDrawable();
                    ring.setShape(GradientDrawable.OVAL);
                    ring.setColor(Color.TRANSPARENT);
                    ring.setStroke(dp(2), isSelected ? PURPLE : BORDER);
                    dot.setBackground(ring);
                    if (isSelected) {
                        View core = new View(activity);
                        GradientDrawable fill = new GradientDrawable();
                        fill.setShape(GradientDrawable.OVAL);
                        fill.setColor(PURPLE);
                        core.setBackground(fill);
                        LinearLayout.LayoutParams coreParams = new LinearLayout.LayoutParams(dp(10), dp(10));
                        dot.addView(core, coreParams);
                    }
                    rowView.addView(dot, new LinearLayout.LayoutParams(dp(22), dp(22)));

                    LinearLayout column = new LinearLayout(activity);
                    column.setOrientation(LinearLayout.VERTICAL);
                    TextView label = body(texts[index], 14, INK);
                    label.setTypeface(Typeface.DEFAULT, isSelected ? Typeface.BOLD : Typeface.NORMAL);
                    column.addView(label);
                    String hint = index < subs.length ? subs[index] : null;
                    if (hint != null && !hint.isEmpty()) {
                        TextView h = body(hint, 11, MUTED);
                        h.setLineSpacing(dp(2), 1f);
                        column.addView(h);
                    }
                    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                    cp.setMarginStart(dp(12));
                    rowView.addView(column, cp);

                    if (isSelected) {
                        TextView mark = body("✓", 15, PURPLE_SOFT);
                        rowView.addView(mark);
                    }

                    rowView.setOnClickListener(v -> {
                        if (owner[0] != null) owner[0].dismiss();
                        if (onChoice != null) onChoice.onChoice(index);
                    });
                    rowView.setOnKeyListener((v, keyCode, event) -> {
                        if (event.getAction() == android.view.KeyEvent.ACTION_DOWN
                                && (keyCode == android.view.KeyEvent.KEYCODE_DPAD_CENTER
                                || keyCode == android.view.KeyEvent.KEYCODE_ENTER
                                || keyCode == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER)) {
                            v.performClick();
                            return true;
                        }
                        return false;
                    });

                    LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    if (i > 0) rp.topMargin = dp(8);
                    host.addView(rowView, rp);
                }
            });
            return this;
        }

        public Builder action(String label, boolean primary, Runnable run) {
            actions.add(new Action(label, primary, run));
            return this;
        }

        public Builder cancelable(boolean value) {
            this.cancelable = value;
            return this;
        }

        public Dialog show() {
            Dialog dialog = new Dialog(activity);
            owner[0] = dialog;
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setCanceledOnTouchOutside(cancelable);
            dialog.setCancelable(cancelable);

            LinearLayout root = new LinearLayout(activity);
            root.setOrientation(LinearLayout.VERTICAL);
            GradientDrawable panel = new GradientDrawable();
            panel.setColor(PANEL);
            panel.setCornerRadius(dp(20));
            panel.setStroke(dp(1), BORDER);
            root.setBackground(panel);
            root.setPadding(dp(20), dp(16), dp(20), dp(14));

            // accent strip: the app's violet, faded out to the right
            View accent = new View(activity);
            GradientDrawable accentShape = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{PURPLE, KuroTheme12.col(0x00a65be4)});
            accentShape.setCornerRadius(dp(2));
            accent.setBackground(accentShape);
            LinearLayout.LayoutParams accentParams = new LinearLayout.LayoutParams(dp(56), dp(3));
            accentParams.bottomMargin = dp(10);
            root.addView(accent, accentParams);

            TextView heading = body(title, 20, INK);
            heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            root.addView(heading, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            if (!subtitle.isEmpty()) {
                TextView sub = body(subtitle, 12, MUTED);
                LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                sp.topMargin = dp(4);
                root.addView(sub, sp);
            }

            if (!blocks.isEmpty()) {
                View line = new View(activity);
                line.setBackgroundColor(DIVIDER);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
                lp.topMargin = dp(12);
                lp.bottomMargin = dp(4);
                root.addView(line, lp);

                LinearLayout bodyColumn = new LinearLayout(activity);
                bodyColumn.setOrientation(LinearLayout.VERTICAL);
                for (Block block : blocks) block.render(bodyColumn);

                ScrollView scroll = new ScrollView(activity);
                scroll.setFillViewport(false);
                scroll.addView(bodyColumn);
                int maxHeight = Math.min(dp(460), Math.round(activity.getResources().getDisplayMetrics().heightPixels * 0.52f));
                LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                root.addView(scroll, sp);
                scroll.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        scroll.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        int content = bodyColumn.getMeasuredHeight();
                        ViewGroup.LayoutParams params = scroll.getLayoutParams();
                        params.height = Math.min(content, maxHeight);
                        scroll.setLayoutParams(params);
                    }
                });
            }

            final View[] firstFocus = new View[1];
            if (!actions.isEmpty()) {
                LinearLayout footer = new LinearLayout(activity);
                footer.setOrientation(LinearLayout.HORIZONTAL);
                footer.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                fp.topMargin = dp(14);
                root.addView(footer, fp);
                for (Action action : actions) {
                    TextView button = actionView(action.label, action.primary, dp(12));
                    button.setOnClickListener(v -> {
                        try { dialog.dismiss(); } catch (RuntimeException ignored) {}
                        if (action.run != null) action.run.run();
                    });
                    LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    bp.setMarginStart(dp(8));
                    footer.addView(button, bp);
                    if (firstFocus[0] == null && action.primary) firstFocus[0] = button;
                    if (firstFocus[0] == null) firstFocus[0] = button;
                }
            }

            dialog.setContentView(root);

            dialog.setOnShowListener(d -> {
                Window window = dialog.getWindow();
                if (window == null) return;
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                WindowManager.LayoutParams attributes = window.getAttributes();
                attributes.dimAmount = 0.78f;
                int screenWidth = activity.getResources().getDisplayMetrics().widthPixels;
                attributes.width = Math.min(dp(520), Math.round(screenWidth * 0.92f));
                attributes.height = WindowManager.LayoutParams.WRAP_CONTENT;
                window.setAttributes(attributes);
                root.setAlpha(0f);
                root.setTranslationY(dp(14));
                root.animate().alpha(1f).translationY(0f).setDuration(220)
                        .setInterpolator(new DecelerateInterpolator()).start();
                if (firstFocus[0] != null) firstFocus[0].requestFocus();
            });

            safeShow155(dialog, activity);
            return dialog;
        }

        private TextView body(String text, int sp, int color) {
            TextView view = new TextView(activity);
            view.setText(text);
            view.setTextColor(color);
            view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
            view.setLineSpacing(dp(2), 1f);
            return view;
        }

        private StateListDrawable rowBackground(boolean selected, int radius) {
            StateListDrawable states = new StateListDrawable();
            states.addState(new int[]{android.R.attr.state_focused}, shape(SELECTED, PURPLE_SOFT, radius));
            states.addState(new int[]{android.R.attr.state_pressed}, shape(SELECTED, PURPLE_SOFT, radius));
            states.addState(new int[]{}, shape(selected ? SELECTED : CARD, selected ? PURPLE : BORDER, radius));
            return states;
        }

        private GradientDrawable shape(int fill, int stroke, int radiusDp) {
            GradientDrawable drawable = new GradientDrawable();
            drawable.setColor(fill);
            drawable.setCornerRadius(dp(radiusDp));
            drawable.setStroke(dp(1), stroke);
            return drawable;
        }

        private TextView actionView(String label, boolean primary, int radiusDp) {
            TextView button = new TextView(activity);
            button.setText(label);
            button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            button.setGravity(Gravity.CENTER);
            button.setMinHeight(dp(46));
            button.setMinWidth(dp(96));
            button.setPadding(dp(18), dp(10), dp(18), dp(10));
            button.setFocusable(true);
            button.setClickable(true);
            button.setTextColor(primary ? KuroTheme12.col(0xff140b1a) : INK);
            StateListDrawable states = new StateListDrawable();
            states.addState(new int[]{android.R.attr.state_focused}, shape(primary ? PURPLE_SOFT : SELECTED, PURPLE_SOFT, radiusDp));
            states.addState(new int[]{android.R.attr.state_pressed}, shape(primary ? PURPLE_SOFT : SELECTED, PURPLE_SOFT, radiusDp));
            states.addState(new int[]{}, shape(primary ? PURPLE : CARD, primary ? PURPLE : BORDER, radiusDp));
            button.setBackground(states);
            return button;
        }
    }

    public interface DisplayHost155 {
        boolean isAutoNextEnabled();
        void setAutoNextEnabled(boolean on);
        void onDisplayApplied(boolean recreateNow);
        void onPreviewUpNext();
    }

    public static final class AutoNextHandle155 {
        public final Dialog dialog;
        public final android.widget.ImageView posterView;
        private final TextView timerBadge;
        private final TextView statusLine;
        private final View progressFill;
        private int trackWidthPx = 0;
        public boolean paused = false;

        AutoNextHandle155(Dialog d, android.widget.ImageView pv, TextView tb, TextView sl, View pf) {
            dialog = d;
            posterView = pv;
            timerBadge = tb;
            statusLine = sl;
            progressFill = pf;
        }

        public void updateProgress(long remainingMs, long totalMs, String epTag) {
            if (paused) return;
            int sec = (int) Math.max(1L, (remainingMs + 999L) / 1000L);
            timerBadge.setText("\u23f8 " + sec + "s");
            statusLine.setText("Playing " + epTag + " in " + sec + (sec == 1 ? " second" : " seconds") + " \u00b7 Tap timer to hold");
            float frac = totalMs > 0 ? Math.max(0f, Math.min(1f, 1f - (remainingMs / (float) totalMs))) : 1f;
            View parent = (View) progressFill.getParent();
            int w = parent != null ? parent.getWidth() : trackWidthPx;
            if (w > 0) {
                trackWidthPx = w;
                ViewGroup.LayoutParams lp = progressFill.getLayoutParams();
                int targetW = Math.max(1, Math.round(w * frac));
                if (lp.width != targetW) {
                    lp.width = targetW;
                    progressFill.setLayoutParams(lp);
                }
            }
        }
    }

    private static int sdp155(Context c, float dpVal, float scale) {
        return Math.max(1, Math.round(dpVal * scale * c.getResources().getDisplayMetrics().density));
    }

    private static GradientDrawable box155(int fill, int stroke, int strokePx, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (strokePx > 0) g.setStroke(strokePx, stroke);
        return g;
    }

    private static StateListDrawable pillStates155(boolean primary, int strokePx, float radiusPx) {
        StateListDrawable s = new StateListDrawable();
        int focusFill = primary ? PURPLE_SOFT : SELECTED;
        int idleFill = primary ? PURPLE : CARD;
        int idleStroke = primary ? PURPLE : BORDER;
        s.addState(new int[]{android.R.attr.state_focused}, box155(focusFill, PURPLE_SOFT, strokePx, radiusPx));
        s.addState(new int[]{android.R.attr.state_pressed}, box155(focusFill, PURPLE_SOFT, strokePx, radiusPx));
        s.addState(new int[]{}, box155(idleFill, idleStroke, strokePx, radiusPx));
        return s;
    }

    private static void attachBounce155(View v) {
        v.setOnTouchListener((view, ev) -> {
            int a = ev.getActionMasked();
            if (a == android.view.MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
            } else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(130).start();
            }
            return false;
        });
    }

    public static AutoNextHandle155 createAutoNext155(
            Activity activity,
            String showTitle,
            String epBadgeText,
            String epHeadline,
            String epMetaLine,
            int totalSeconds,
            Runnable onCancel,
            Runnable onPlayNow,
            Runnable onOpenTuning
    ) {
        KuroDisplay155.enforce500Dpi(activity);
        retint();
        final float sc = KuroDisplay155.upNextScaleFactor(activity);
        final int stroke1 = Math.max(1, Math.round(activity.getResources().getDisplayMetrics().density));

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCanceledOnTouchOutside(true);

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setTag("kuro-autonext-card-155");
        int padH = sdp155(activity, 18, sc);
        int padV = sdp155(activity, 16, sc);
        root.setPadding(padH, padV, padH, padV);
        root.setBackground(box155(PANEL, BORDER, stroke1, sdp155(activity, 22, sc)));

        // Top accent glow bar matching KuroDialogs581 & KuroUpdateDialog582
        View accentBar = new View(activity);
        GradientDrawable glow = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{PURPLE, PURPLE_SOFT, KuroTheme12.col(0x00a65be4)}
        );
        glow.setCornerRadius(sdp155(activity, 99, sc));
        accentBar.setBackground(glow);
        LinearLayout.LayoutParams glowLp = new LinearLayout.LayoutParams(sdp155(activity, 68, sc), Math.max(sdp155(activity, 3, sc), 3));
        glowLp.bottomMargin = sdp155(activity, 12, sc);
        root.addView(accentBar, glowLp);

        // Header Row: [▶ UP NEXT] ............ [⏸ 8s] [⚙]
        LinearLayout headRow = new LinearLayout(activity);
        headRow.setOrientation(LinearLayout.HORIZONTAL);
        headRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView upNextPill = new TextView(activity);
        upNextPill.setText("\u25b6  UP NEXT");
        upNextPill.setTextColor(PURPLE_SOFT);
        upNextPill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f * sc);
        upNextPill.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        upNextPill.setLetterSpacing(0.08f);
        upNextPill.setPadding(sdp155(activity, 10, sc), sdp155(activity, 4, sc), sdp155(activity, 10, sc), sdp155(activity, 4, sc));
        upNextPill.setBackground(box155(SELECTED, PURPLE, stroke1, sdp155(activity, 999, sc)));
        headRow.addView(upNextPill, new LinearLayout.LayoutParams(-2, -2));

        View headSpacer = new View(activity);
        headRow.addView(headSpacer, new LinearLayout.LayoutParams(0, 1, 1f));

        final TextView timerChip = new TextView(activity);
        timerChip.setText("\u23f8 " + totalSeconds + "s");
        timerChip.setTextColor(INK);
        timerChip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f * sc);
        timerChip.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        timerChip.setGravity(Gravity.CENTER);
        timerChip.setFocusable(true);
        timerChip.setClickable(true);
        timerChip.setPadding(sdp155(activity, 10, sc), sdp155(activity, 4, sc), sdp155(activity, 10, sc), sdp155(activity, 4, sc));
        timerChip.setBackground(pillStates155(false, stroke1, sdp155(activity, 999, sc)));
        headRow.addView(timerChip, new LinearLayout.LayoutParams(-2, -2));

        if (onOpenTuning != null) {
            TextView tuneBtn = new TextView(activity);
            tuneBtn.setText("\u2699");
            tuneBtn.setContentDescription("Display, DPI and Auto-Next settings");
            tuneBtn.setTextColor(MUTED);
            tuneBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f * sc);
            tuneBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            tuneBtn.setGravity(Gravity.CENTER);
            tuneBtn.setFocusable(true);
            tuneBtn.setClickable(true);
            tuneBtn.setBackground(pillStates155(false, stroke1, sdp155(activity, 999, sc)));
            int gearSz = sdp155(activity, 28, sc);
            LinearLayout.LayoutParams gearLp = new LinearLayout.LayoutParams(gearSz, gearSz);
            gearLp.leftMargin = sdp155(activity, 6, sc);
            tuneBtn.setOnClickListener(v -> {
                try { dialog.dismiss(); } catch (RuntimeException ignored) {}
                onOpenTuning.run();
            });
            headRow.addView(tuneBtn, gearLp);
        }

        root.addView(headRow, new LinearLayout.LayoutParams(-1, -2));

        // Episode Media Card: [Poster + EP Badge] + [Series Title / Episode Headline / Meta]
        LinearLayout mediaCard = new LinearLayout(activity);
        mediaCard.setOrientation(LinearLayout.HORIZONTAL);
        mediaCard.setGravity(Gravity.CENTER_VERTICAL);
        int mcPad = sdp155(activity, 11, sc);
        mediaCard.setPadding(mcPad, mcPad, mcPad, mcPad);
        mediaCard.setBackground(box155(CARD, DIVIDER, stroke1, sdp155(activity, 15, sc)));
        LinearLayout.LayoutParams mcLp = new LinearLayout.LayoutParams(-1, -2);
        mcLp.topMargin = sdp155(activity, 12, sc);
        root.addView(mediaCard, mcLp);

        int posterW = sdp155(activity, 54, sc);
        int posterH = sdp155(activity, 74, sc);
        final int posterRad = sdp155(activity, 10, sc);
        android.widget.FrameLayout posterWrap = new android.widget.FrameLayout(activity);
        posterWrap.setBackground(box155(SELECTED, BORDER, stroke1, posterRad));
        posterWrap.setClipToOutline(true);
        posterWrap.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View view, android.graphics.Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), posterRad);
            }
        });

        TextView posterFallback = new TextView(activity);
        posterFallback.setText("\u25b6");
        posterFallback.setTextColor(PURPLE_SOFT);
        posterFallback.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f * sc);
        posterFallback.setGravity(Gravity.CENTER);
        posterWrap.addView(posterFallback, new android.widget.FrameLayout.LayoutParams(-1, -1));

        android.widget.ImageView posterImg = new android.widget.ImageView(activity);
        posterImg.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        posterWrap.addView(posterImg, new android.widget.FrameLayout.LayoutParams(-1, -1));

        if (epBadgeText != null && !epBadgeText.isEmpty()) {
            TextView epCorner = new TextView(activity);
            epCorner.setText(epBadgeText);
            epCorner.setTextColor(Color.WHITE);
            epCorner.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f * sc);
            epCorner.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            epCorner.setPadding(sdp155(activity, 5, sc), sdp155(activity, 2, sc), sdp155(activity, 5, sc), sdp155(activity, 2, sc));
            epCorner.setBackground(box155(KuroTheme12.col(0x99000000), PURPLE, stroke1, sdp155(activity, 6, sc)));
            android.widget.FrameLayout.LayoutParams badgeLp = new android.widget.FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
            int bm = sdp155(activity, 4, sc);
            badgeLp.setMargins(bm, bm, bm, bm);
            posterWrap.addView(epCorner, badgeLp);
        }

        mediaCard.addView(posterWrap, new LinearLayout.LayoutParams(posterW, posterH));

        LinearLayout metaCol = new LinearLayout(activity);
        metaCol.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(0, -2, 1f);
        metaLp.leftMargin = sdp155(activity, 12, sc);
        mediaCard.addView(metaCol, metaLp);

        if (showTitle != null && !showTitle.isEmpty()) {
            TextView showTv = new TextView(activity);
            showTv.setText(showTitle);
            showTv.setTextColor(MUTED);
            showTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f * sc);
            showTv.setSingleLine(true);
            showTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
            metaCol.addView(showTv, new LinearLayout.LayoutParams(-1, -2));
        }

        TextView epHeadTv = new TextView(activity);
        epHeadTv.setText(epHeadline);
        epHeadTv.setTextColor(INK);
        epHeadTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f * sc);
        epHeadTv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        epHeadTv.setMaxLines(2);
        epHeadTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams ehLp = new LinearLayout.LayoutParams(-1, -2);
        ehLp.topMargin = sdp155(activity, 2, sc);
        metaCol.addView(epHeadTv, ehLp);

        if (epMetaLine != null && !epMetaLine.isEmpty()) {
            TextView metaTv = new TextView(activity);
            metaTv.setText(epMetaLine);
            metaTv.setTextColor(PURPLE_SOFT);
            metaTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f * sc);
            metaTv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            metaTv.setSingleLine(true);
            metaTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams mtLp = new LinearLayout.LayoutParams(-1, -2);
            mtLp.topMargin = sdp155(activity, 4, sc);
            metaCol.addView(metaTv, mtLp);
        }

        // Smooth Animated Countdown Bar
        int barH = Math.max(4, sdp155(activity, 6, sc));
        int barRad = sdp155(activity, 99, sc);
        android.widget.FrameLayout barTrack = new android.widget.FrameLayout(activity);
        barTrack.setBackground(box155(DIVIDER, 0, 0, barRad));
        LinearLayout.LayoutParams btLp = new LinearLayout.LayoutParams(-1, barH);
        btLp.topMargin = sdp155(activity, 13, sc);
        root.addView(barTrack, btLp);

        View barFill = new View(activity);
        GradientDrawable fillGrad = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{PURPLE, PURPLE_SOFT}
        );
        fillGrad.setCornerRadius(barRad);
        barFill.setBackground(fillGrad);
        barTrack.addView(barFill, new android.widget.FrameLayout.LayoutParams(1, -1));

        final TextView statusTv = new TextView(activity);
        String cleanEpTag = (epBadgeText != null && !epBadgeText.isEmpty()) ? epBadgeText : "next episode";
        statusTv.setText("Playing " + cleanEpTag + " in " + totalSeconds + " seconds \u00b7 Tap timer to hold");
        statusTv.setTextColor(MUTED);
        statusTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f * sc);
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(-1, -2);
        stLp.topMargin = sdp155(activity, 7, sc);
        root.addView(statusTv, stLp);

        // Action Row: [Cancel]   [▶ Play Ep X]
        LinearLayout actions = new LinearLayout(activity);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams actLp = new LinearLayout.LayoutParams(-1, -2);
        actLp.topMargin = sdp155(activity, 14, sc);
        root.addView(actions, actLp);

        int btnH = sdp155(activity, 44, sc);
        int btnRad = sdp155(activity, 13, sc);

        TextView cancelBtn = new TextView(activity);
        cancelBtn.setText("Cancel");
        cancelBtn.setTextColor(INK);
        cancelBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f * sc);
        cancelBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        cancelBtn.setGravity(Gravity.CENTER);
        cancelBtn.setMinHeight(btnH);
        cancelBtn.setFocusable(true);
        cancelBtn.setClickable(true);
        cancelBtn.setBackground(pillStates155(false, stroke1, btnRad));
        attachBounce155(cancelBtn);
        cancelBtn.setOnClickListener(v -> {
            if (onCancel != null) onCancel.run();
        });
        actions.addView(cancelBtn, new LinearLayout.LayoutParams(0, btnH, 1f));

        TextView playBtn = new TextView(activity);
        String playLabel = (epBadgeText != null && !epBadgeText.isEmpty()) ? ("\u25b6  Play " + epBadgeText) : "\u25b6  Play now";
        playBtn.setText(playLabel);
        playBtn.setTextColor(KuroTheme12.col(0xff140b1a));
        playBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f * sc);
        playBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        playBtn.setGravity(Gravity.CENTER);
        playBtn.setMinHeight(btnH);
        playBtn.setFocusable(true);
        playBtn.setClickable(true);
        playBtn.setBackground(pillStates155(true, stroke1, btnRad));
        attachBounce155(playBtn);
        playBtn.setOnClickListener(v -> {
            if (onPlayNow != null) onPlayNow.run();
        });
        LinearLayout.LayoutParams playLp = new LinearLayout.LayoutParams(0, btnH, 1.38f);
        playLp.leftMargin = sdp155(activity, 9, sc);
        actions.addView(playBtn, playLp);

        final AutoNextHandle155 handle = new AutoNextHandle155(dialog, posterImg, timerChip, statusTv, barFill);
        timerChip.setOnClickListener(v -> {
            handle.paused = !handle.paused;
            if (handle.paused) {
                timerChip.setText("\u25b6 Hold");
                statusTv.setText("Countdown paused \u00b7 Tap Play when ready");
            } else {
                timerChip.setText("\u23f8 Resumed");
            }
        });

        dialog.setContentView(root);
        dialog.setOnShowListener(ignored -> {
            Window window = dialog.getWindow();
            if (window == null) return;
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams attr = window.getAttributes();
            attr.dimAmount = 0.62f;
            android.util.DisplayMetrics dm = activity.getResources().getDisplayMetrics();
            int maxW = sdp155(activity, 396, sc);
            attr.width = Math.max(sdp155(activity, 260, 1f), Math.min(maxW, Math.round(dm.widthPixels * 0.90f)));
            attr.height = WindowManager.LayoutParams.WRAP_CONTENT;
            window.setAttributes(attr);
            root.setAlpha(0f);
            root.setScaleX(0.97f);
            root.setScaleY(0.97f);
            root.setTranslationY(sdp155(activity, 14, 1f));
            root.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(200).setInterpolator(new DecelerateInterpolator()).start();
            playBtn.requestFocus();
        });

        return handle;
    }

    public static Dialog openDisplayController155(Activity activity, DisplayHost155 host) {
        if (!canShow155(activity)) return null;
        KuroDisplay155.enforce500Dpi(activity);
        retint();
        final int stroke1 = Math.max(1, Math.round(activity.getResources().getDisplayMetrics().density));

        final int sysDpi = KuroDisplay155.systemDpi();
        final int[] draftDpi = {KuroDisplay155.configuredDpi(activity)};
        final int[] draftScale = {KuroDisplay155.uiScale(activity)};
        final int[] draftSec = {KuroDisplay155.autoNextSeconds(activity)};
        final int[] draftCard = {KuroDisplay155.upNextScale(activity)};
        final boolean[] draftAutoNext = {host == null || host.isAutoNextEnabled()};

        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCanceledOnTouchOutside(true);

        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(false);
        scroll.setBackground(box155(PANEL, BORDER, stroke1, sdp155(activity, 22, 1f)));

        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = sdp155(activity, 18, 1f);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root, new ViewGroup.LayoutParams(-1, -2));

        View accentBar = new View(activity);
        GradientDrawable glow = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{PURPLE, PURPLE_SOFT, KuroTheme12.col(0x00a65be4)}
        );
        glow.setCornerRadius(sdp155(activity, 99, 1f));
        accentBar.setBackground(glow);
        LinearLayout.LayoutParams glowLp = new LinearLayout.LayoutParams(sdp155(activity, 64, 1f), Math.max(3, sdp155(activity, 3, 1f)));
        glowLp.bottomMargin = sdp155(activity, 10, 1f);
        root.addView(accentBar, glowLp);

        TextView titleTv = new TextView(activity);
        titleTv.setText("Display, App DPI & Auto-Next");
        titleTv.setTextColor(INK);
        titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        titleTv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(titleTv, new LinearLayout.LayoutParams(-1, -2));

        final TextView subTv = new TextView(activity);
        subTv.setTextColor(MUTED);
        subTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = sdp155(activity, 3, 1f);
        subLp.bottomMargin = sdp155(activity, 12, 1f);
        root.addView(subTv, subLp);

        // Section 1: App DPI
        LinearLayout dpiBox = new LinearLayout(activity);
        dpiBox.setOrientation(LinearLayout.VERTICAL);
        int boxPad = sdp155(activity, 12, 1f);
        dpiBox.setPadding(boxPad, boxPad, boxPad, boxPad);
        dpiBox.setBackground(box155(CARD, DIVIDER, stroke1, sdp155(activity, 14, 1f)));
        root.addView(dpiBox, new LinearLayout.LayoutParams(-1, -2));

        final TextView dpiReadout = new TextView(activity);
        dpiReadout.setTextColor(INK);
        dpiReadout.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        dpiReadout.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        dpiBox.addView(dpiReadout, new LinearLayout.LayoutParams(-1, -2));

        final android.widget.SeekBar dpiSeek = new android.widget.SeekBar(activity);
        dpiSeek.setMax(36); // 280 + i*10 -> 280..640
        LinearLayout.LayoutParams skLp = new LinearLayout.LayoutParams(-1, -2);
        skLp.topMargin = sdp155(activity, 6, 1f);
        dpiBox.addView(dpiSeek, skLp);

        android.widget.HorizontalScrollView dpiHScroll = new android.widget.HorizontalScrollView(activity);
        dpiHScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout dpiChipRow = new LinearLayout(activity);
        dpiChipRow.setOrientation(LinearLayout.HORIZONTAL);
        dpiHScroll.addView(dpiChipRow, new ViewGroup.LayoutParams(-2, -2));
        LinearLayout.LayoutParams dchLp = new LinearLayout.LayoutParams(-1, -2);
        dchLp.topMargin = sdp155(activity, 6, 1f);
        dpiBox.addView(dpiHScroll, dchLp);

        final int[] dpiPresetVals = {0, 360, 400, 440, 480, 500, 540, 600};
        final List<TextView> dpiPresetViews = new ArrayList<>();

        // Section 2: App UI Size
        LinearLayout scaleBox = new LinearLayout(activity);
        scaleBox.setOrientation(LinearLayout.VERTICAL);
        scaleBox.setPadding(boxPad, boxPad, boxPad, boxPad);
        scaleBox.setBackground(box155(CARD, DIVIDER, stroke1, sdp155(activity, 14, 1f)));
        LinearLayout.LayoutParams scBoxLp = new LinearLayout.LayoutParams(-1, -2);
        scBoxLp.topMargin = sdp155(activity, 10, 1f);
        root.addView(scaleBox, scBoxLp);

        final TextView scaleReadout = new TextView(activity);
        scaleReadout.setTextColor(INK);
        scaleReadout.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        scaleReadout.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        scaleBox.addView(scaleReadout, new LinearLayout.LayoutParams(-1, -2));

        final android.widget.SeekBar scaleSeek = new android.widget.SeekBar(activity);
        scaleSeek.setMax(12); // 75 + i*5 -> 75..135
        LinearLayout.LayoutParams sskLp = new LinearLayout.LayoutParams(-1, -2);
        sskLp.topMargin = sdp155(activity, 6, 1f);
        scaleBox.addView(scaleSeek, sskLp);

        android.widget.HorizontalScrollView scaleHScroll = new android.widget.HorizontalScrollView(activity);
        scaleHScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout scaleChipRow = new LinearLayout(activity);
        scaleChipRow.setOrientation(LinearLayout.HORIZONTAL);
        scaleHScroll.addView(scaleChipRow, new ViewGroup.LayoutParams(-2, -2));
        LinearLayout.LayoutParams schLp = new LinearLayout.LayoutParams(-1, -2);
        schLp.topMargin = sdp155(activity, 6, 1f);
        scaleBox.addView(scaleHScroll, schLp);

        final int[] scalePresetVals = {80, 90, 95, 100, 105, 110, 120};
        final List<TextView> scalePresetViews = new ArrayList<>();

        // Section 3: Auto-Next Countdown & Card Size
        LinearLayout anBox = new LinearLayout(activity);
        anBox.setOrientation(LinearLayout.VERTICAL);
        anBox.setPadding(boxPad, boxPad, boxPad, boxPad);
        anBox.setBackground(box155(CARD, DIVIDER, stroke1, sdp155(activity, 14, 1f)));
        LinearLayout.LayoutParams anBoxLp = new LinearLayout.LayoutParams(-1, -2);
        anBoxLp.topMargin = sdp155(activity, 10, 1f);
        root.addView(anBox, anBoxLp);

        LinearLayout anHead = new LinearLayout(activity);
        anHead.setOrientation(LinearLayout.HORIZONTAL);
        anHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView anTitle = new TextView(activity);
        anTitle.setText("Auto-Play Next & Card Size");
        anTitle.setTextColor(INK);
        anTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        anTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        anHead.addView(anTitle, new LinearLayout.LayoutParams(0, -2, 1f));

        final TextView anToggle = new TextView(activity);
        anToggle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        anToggle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        anToggle.setPadding(sdp155(activity, 11, 1f), sdp155(activity, 5, 1f), sdp155(activity, 11, 1f), sdp155(activity, 5, 1f));
        anToggle.setFocusable(true);
        anToggle.setClickable(true);
        anHead.addView(anToggle, new LinearLayout.LayoutParams(-2, -2));
        anBox.addView(anHead, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout secRow = new LinearLayout(activity);
        secRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams secRowLp = new LinearLayout.LayoutParams(-1, -2);
        secRowLp.topMargin = sdp155(activity, 8, 1f);
        anBox.addView(secRow, secRowLp);
        final int[] secVals = {5, 8, 10, 15};
        final List<TextView> secViews = new ArrayList<>();

        LinearLayout cardRow = new LinearLayout(activity);
        cardRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams cardRowLp = new LinearLayout.LayoutParams(-1, -2);
        cardRowLp.topMargin = sdp155(activity, 7, 1f);
        anBox.addView(cardRow, cardRowLp);
        final int[] cardVals = {85, 100, 115};
        final String[] cardNames = {"Compact", "Default", "Large"};
        final List<TextView> cardViews = new ArrayList<>();

        final boolean[] syncingSeek = {false};
        final Runnable refreshUi = () -> {
            int base = draftDpi[0] <= 0 ? sysDpi : draftDpi[0];
            int eff = Math.max(220, Math.min(760, Math.round(base * (draftScale[0] / 100f))));
            String dLbl = draftDpi[0] <= 0 ? ("System (" + sysDpi + " DPI)") : (draftDpi[0] + " DPI");
            subTv.setText(dLbl + " \u00b7 UI Size " + draftScale[0] + "% \u00b7 Effective " + eff + " DPI");
            dpiReadout.setText("App DPI: " + dLbl);
            scaleReadout.setText("App UI Size: " + draftScale[0] + "% (" + eff + " eff DPI)");

            syncingSeek[0] = true;
            dpiSeek.setProgress(Math.max(0, Math.min(36, Math.round((base - 280) / 10f))));
            scaleSeek.setProgress(Math.max(0, Math.min(12, Math.round((draftScale[0] - 75) / 5f))));
            syncingSeek[0] = false;

            for (int i = 0; i < dpiPresetViews.size(); i++) {
                boolean on = draftDpi[0] == dpiPresetVals[i];
                TextView tv = dpiPresetViews.get(i);
                tv.setTextColor(on ? KuroTheme12.col(0xff140b1a) : INK);
                tv.setBackground(pillStates155(on, stroke1, sdp155(activity, 999, 1f)));
            }
            for (int i = 0; i < scalePresetViews.size(); i++) {
                boolean on = draftScale[0] == scalePresetVals[i];
                TextView tv = scalePresetViews.get(i);
                tv.setTextColor(on ? KuroTheme12.col(0xff140b1a) : INK);
                tv.setBackground(pillStates155(on, stroke1, sdp155(activity, 999, 1f)));
            }
            anToggle.setText(draftAutoNext[0] ? "Auto-Next ON" : "Auto-Next OFF");
            anToggle.setTextColor(draftAutoNext[0] ? KuroTheme12.col(0xff140b1a) : INK);
            anToggle.setBackground(pillStates155(draftAutoNext[0], stroke1, sdp155(activity, 999, 1f)));

            for (int i = 0; i < secViews.size(); i++) {
                boolean on = draftSec[0] == secVals[i];
                TextView tv = secViews.get(i);
                tv.setTextColor(on ? KuroTheme12.col(0xff140b1a) : INK);
                tv.setBackground(pillStates155(on, stroke1, sdp155(activity, 999, 1f)));
            }
            for (int i = 0; i < cardViews.size(); i++) {
                boolean on = Math.abs(draftCard[0] - cardVals[i]) <= 4;
                TextView tv = cardViews.get(i);
                tv.setTextColor(on ? KuroTheme12.col(0xff140b1a) : INK);
                tv.setBackground(pillStates155(on, stroke1, sdp155(activity, 999, 1f)));
            }
        };

        for (int i = 0; i < dpiPresetVals.length; i++) {
            final int val = dpiPresetVals[i];
            TextView chip = new TextView(activity);
            chip.setText(val == 0 ? ("System (" + sysDpi + ")") : String.valueOf(val));
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
            chip.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            chip.setGravity(Gravity.CENTER);
            chip.setFocusable(true);
            chip.setClickable(true);
            chip.setPadding(sdp155(activity, 11, 1f), sdp155(activity, 6, 1f), sdp155(activity, 11, 1f), sdp155(activity, 6, 1f));
            chip.setOnClickListener(v -> { draftDpi[0] = val; refreshUi.run(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            if (i > 0) lp.leftMargin = sdp155(activity, 6, 1f);
            dpiChipRow.addView(chip, lp);
            dpiPresetViews.add(chip);
        }

        for (int i = 0; i < scalePresetVals.length; i++) {
            final int val = scalePresetVals[i];
            TextView chip = new TextView(activity);
            chip.setText(val + "%");
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
            chip.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            chip.setGravity(Gravity.CENTER);
            chip.setFocusable(true);
            chip.setClickable(true);
            chip.setPadding(sdp155(activity, 11, 1f), sdp155(activity, 6, 1f), sdp155(activity, 11, 1f), sdp155(activity, 6, 1f));
            chip.setOnClickListener(v -> { draftScale[0] = val; refreshUi.run(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            if (i > 0) lp.leftMargin = sdp155(activity, 6, 1f);
            scaleChipRow.addView(chip, lp);
            scalePresetViews.add(chip);
        }

        for (int i = 0; i < secVals.length; i++) {
            final int val = secVals[i];
            TextView chip = new TextView(activity);
            chip.setText(val + "s");
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
            chip.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            chip.setGravity(Gravity.CENTER);
            chip.setFocusable(true);
            chip.setClickable(true);
            chip.setPadding(0, sdp155(activity, 6, 1f), 0, sdp155(activity, 6, 1f));
            chip.setOnClickListener(v -> { draftSec[0] = val; refreshUi.run(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.leftMargin = sdp155(activity, 6, 1f);
            secRow.addView(chip, lp);
            secViews.add(chip);
        }

        for (int i = 0; i < cardVals.length; i++) {
            final int val = cardVals[i];
            TextView chip = new TextView(activity);
            chip.setText("Card: " + cardNames[i]);
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
            chip.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            chip.setGravity(Gravity.CENTER);
            chip.setFocusable(true);
            chip.setClickable(true);
            chip.setPadding(0, sdp155(activity, 6, 1f), 0, sdp155(activity, 6, 1f));
            chip.setOnClickListener(v -> { draftCard[0] = val; refreshUi.run(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) lp.leftMargin = sdp155(activity, 6, 1f);
            cardRow.addView(chip, lp);
            cardViews.add(chip);
        }

        dpiSeek.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                if (!fromUser || syncingSeek[0]) return;
                draftDpi[0] = 280 + progress * 10;
                refreshUi.run();
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar sb) {}
            @Override public void onStopTrackingTouch(android.widget.SeekBar sb) {}
        });

        scaleSeek.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                if (!fromUser || syncingSeek[0]) return;
                draftScale[0] = 75 + progress * 5;
                refreshUi.run();
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar sb) {}
            @Override public void onStopTrackingTouch(android.widget.SeekBar sb) {}
        });

        anToggle.setOnClickListener(v -> { draftAutoNext[0] = !draftAutoNext[0]; refreshUi.run(); });

        // Footer Buttons: [Reset] [▶ Preview] [✓ Apply]
        LinearLayout actions = new LinearLayout(activity);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams actLp = new LinearLayout.LayoutParams(-1, -2);
        actLp.topMargin = sdp155(activity, 14, 1f);
        root.addView(actions, actLp);

        int btnH = sdp155(activity, 42, 1f);
        int btnRad = sdp155(activity, 12, 1f);

        TextView resetBtn = new TextView(activity);
        resetBtn.setText("Reset");
        resetBtn.setTextColor(INK);
        resetBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        resetBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        resetBtn.setGravity(Gravity.CENTER);
        resetBtn.setFocusable(true);
        resetBtn.setClickable(true);
        resetBtn.setBackground(pillStates155(false, stroke1, btnRad));
        resetBtn.setOnClickListener(v -> {
            draftDpi[0] = 500;
            draftScale[0] = 100;
            draftSec[0] = 8;
            draftCard[0] = 100;
            draftAutoNext[0] = true;
            refreshUi.run();
        });
        actions.addView(resetBtn, new LinearLayout.LayoutParams(0, btnH, 0.85f));

        TextView prevBtn = new TextView(activity);
        prevBtn.setText("\u25b6 Preview");
        prevBtn.setTextColor(INK);
        prevBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        prevBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        prevBtn.setGravity(Gravity.CENTER);
        prevBtn.setFocusable(true);
        prevBtn.setClickable(true);
        prevBtn.setBackground(pillStates155(false, stroke1, btnRad));
        prevBtn.setOnClickListener(v -> {
            KuroDisplay155.saveConfig(activity, draftDpi[0], draftScale[0], draftSec[0], draftCard[0]);
            if (host != null) host.setAutoNextEnabled(draftAutoNext[0]);
            try { dialog.dismiss(); } catch (RuntimeException ignored) {}
            if (host != null) host.onPreviewUpNext();
        });
        LinearLayout.LayoutParams pvLp = new LinearLayout.LayoutParams(0, btnH, 1.05f);
        pvLp.leftMargin = sdp155(activity, 7, 1f);
        actions.addView(prevBtn, pvLp);

        TextView applyBtn = new TextView(activity);
        applyBtn.setText("\u2713 Apply");
        applyBtn.setTextColor(KuroTheme12.col(0xff140b1a));
        applyBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        applyBtn.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        applyBtn.setGravity(Gravity.CENTER);
        applyBtn.setFocusable(true);
        applyBtn.setClickable(true);
        applyBtn.setBackground(pillStates155(true, stroke1, btnRad));
        applyBtn.setOnClickListener(v -> {
            boolean densityChanged = draftDpi[0] != KuroDisplay155.configuredDpi(activity)
                || draftScale[0] != KuroDisplay155.uiScale(activity);
            KuroDisplay155.saveConfig(activity, draftDpi[0], draftScale[0], draftSec[0], draftCard[0]);
            if (host != null) host.setAutoNextEnabled(draftAutoNext[0]);
            try { dialog.dismiss(); } catch (RuntimeException ignored) {}
            if (host != null) host.onDisplayApplied(densityChanged);
        });
        LinearLayout.LayoutParams apLp = new LinearLayout.LayoutParams(0, btnH, 1.15f);
        apLp.leftMargin = sdp155(activity, 7, 1f);
        actions.addView(applyBtn, apLp);

        refreshUi.run();
        dialog.setContentView(scroll);
        dialog.setOnShowListener(ignored -> {
            Window window = dialog.getWindow();
            if (window == null) return;
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            WindowManager.LayoutParams attr = window.getAttributes();
            attr.dimAmount = 0.72f;
            android.util.DisplayMetrics dm = activity.getResources().getDisplayMetrics();
            attr.width = Math.min(sdp155(activity, 430, 1f), Math.round(dm.widthPixels * 0.92f));
            attr.height = WindowManager.LayoutParams.WRAP_CONTENT;
            window.setAttributes(attr);
            applyBtn.requestFocus();
        });

        safeShow155(dialog, activity);
        return dialog;
    }
}

package app.lovelycrxshx.kuro;

import org.json.JSONObject;
import java.net.URI;
import java.util.Map;

interface AccountTransport {
 JSONObject request(String method,String url,Map<String,String> headers,String body) throws Exception;
}

/** Authenticated requests never follow redirects and never leave known HTTPS hosts. */
final class AccountHttp implements AccountTransport {
 public JSONObject request(String method,String address,Map<String,String> headers,String body) throws Exception {
  URI u=new URI(address);
  return KuroFastNet154.accountRequest(method,u,headers,body);
 }
}

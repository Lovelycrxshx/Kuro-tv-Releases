package app.lovelycrxshx.kuro;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.DefaultTimeBar;

import java.util.Locale;

/**
 * 5.82p · The watch-player control bar, drawn by us instead of by PlayerView.
 *
 * The reference screenshot's row, left to right:
 *   play · volume · 00:03 / 21:00 · [spacer] · -10 · +10 · CC · gear · PiP · fullscreen
 * with a scrubber rail above it.
 *
 * Why not Media3's own controller: relying on controller_layout_id made the whole
 * bar depend on one successful inflation, and when it failed we got neither the bar
 * nor the rounding. This row is plain Android views, so it always renders, and every
 * colour comes from the accent.
 */
final class KuroPlayerBar582p {

    interface Host {
        void onToggleFullscreen582p();
        void onTogglePip582p();
    }

    static final class Bar {
        final FrameLayout root;
        final DefaultTimeBar rail;
        final ImageButton play, rew, ffwd, vol, cc, gear, loop, pip, full;
        final TextView position, duration;
        boolean visible = true;

        Bar(FrameLayout root, DefaultTimeBar rail, ImageButton play, ImageButton rew, ImageButton ffwd,
            ImageButton vol, ImageButton cc, ImageButton gear, ImageButton loop, ImageButton pip,
            ImageButton full, TextView position, TextView duration) {
            this.root = root; this.rail = rail; this.play = play; this.rew = rew; this.ffwd = ffwd;
            this.vol = vol; this.cc = cc; this.gear = gear; this.loop = loop; this.pip = pip;
            this.full = full; this.position = position; this.duration = duration;
        }

        void setVisible(boolean show, boolean animate) {
            visible = show;
            float target = show ? 1f : 0f;
            if (animate) root.animate().alpha(target).setDuration(200).start();
            else root.setAlpha(target);
            root.setVisibility(show ? View.VISIBLE : View.GONE);
        }

        void toggle() { setVisible(!visible, true); }

        /** Drives the rail and clock from outside; DefaultTimeBar has no setPlayer in 1.7.1. */
        void poll(androidx.media3.common.Player ex) {
            long pos = ex.getCurrentPosition(), dur = ex.getDuration();
            if (dur > 0) { rail.setDuration(dur); rail.setPosition(Math.min(pos, dur)); }
        }
    }

    private KuroPlayerBar582p() {}

    static String clock(long ms) {
        if (ms < 0) ms = 0;
        long total = ms / 1000;
        long h = total / 3600, m = (total % 3600) / 60, s = total % 60;
        if (h > 0) return String.format(Locale.US, "%d:%02d:%02d", h, m, s);
        return String.format(Locale.US, "%02d:%02d", m, s);
    }

    static Bar attach(final Activity act, final ExoPlayer ex, final FrameLayout surface,
                      final int radiusDp, final Host host, final Runnable onToggleLoop) {
        Context c = act;
        int dp = KuroPlayerTheme582n.dp(c, 1);

        FrameLayout bar = new FrameLayout(c);
        bar.setTag("kuro-bar-582p");
        bar.setBackground(KuroPlayerTheme582n.scrim(c));

        // --- scrubber rail ---
        DefaultTimeBar rail = new DefaultTimeBar(c, null);
        rail.setId(View.generateViewId());
        KuroPlayerTheme582n.timeBar(rail);
        FrameLayout.LayoutParams railLp = new FrameLayout.LayoutParams(-1, KuroPlayerTheme582n.dp(c, 14));
        railLp.gravity = Gravity.TOP;
        railLp.leftMargin = KuroPlayerTheme582n.dp(c, 10);
        railLp.rightMargin = KuroPlayerTheme582n.dp(c, 10);
        railLp.topMargin = KuroPlayerTheme582n.dp(c, 2);
        bar.addView(rail, railLp);

        // --- button row ---
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        ImageButton play = icon(c, R.drawable.kuro_ic_play_563, "Play or pause");
        ImageButton rew = icon(c, R.drawable.kuro_ic_rew_563, "Rewind 10 seconds");
        ImageButton ffwd = icon(c, R.drawable.kuro_ic_ffwd_563, "Forward 10 seconds");
        ImageButton vol = icon(c, R.drawable.kuro_ic_vol_on_563, "Mute or unmute");

        TextView position = time(c);
        TextView duration = time(c);
        TextView slash = time(c);
        slash.setText(" / ");

        ImageButton cc = icon(c, R.drawable.kuro_ic_cc_563, "Subtitles");
        cc.setBackgroundColor(Color.TRANSPARENT);
        ImageButton gear = icon(c, R.drawable.kuro_ic_gear_563, "Playback settings");
        ImageButton loop = icon(c, R.drawable.kuro_ic_loop_563, "Repeat this episode");
        ImageButton pip = icon(c, R.drawable.kuro_ic_pip_563, "Picture in picture");
        ImageButton full = icon(c, R.drawable.kuro_ic_full_563, "Fullscreen");

        row.addView(play); row.addView(vol);
        row.addView(position); row.addView(slash); row.addView(duration);
        // spacer pushes the right-hand cluster to the edge, like the reference
        View spacer = new View(c);
        row.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
        row.addView(rew); row.addView(ffwd);
        row.addView(cc); row.addView(gear); row.addView(loop); row.addView(pip); row.addView(full);

        FrameLayout.LayoutParams rowLp = new FrameLayout.LayoutParams(-1, -2);
        rowLp.gravity = Gravity.BOTTOM;
        rowLp.topMargin = KuroPlayerTheme582n.dp(c, 14);
        bar.addView(row, rowLp);

        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(-1, -2);
        barLp.gravity = Gravity.BOTTOM;
        surface.addView(bar, barLp);

        Bar b = new Bar(bar, rail, play, rew, ffwd, vol, cc, gear, loop, pip, full, position, duration);

        rail.addListener(new androidx.media3.ui.TimeBar.OnScrubListener() {
            @Override public void onScrubStart(androidx.media3.ui.TimeBar bar, long position) {}
            @Override public void onScrubMove(androidx.media3.ui.TimeBar bar, long position) {}
            @Override public void onScrubStop(androidx.media3.ui.TimeBar bar, long position, boolean canceled) {
                if (!canceled) ex.seekTo(position);
            }
        });

        // --- behaviour ---
        play.setOnClickListener(v -> {
            if (ex.isPlaying()) ex.pause(); else ex.play();
            syncPlayIcon(ex, play);
        });
        rew.setOnClickListener(v -> ex.seekBack());
        ffwd.setOnClickListener(v -> ex.seekForward());

        final boolean[] muted = {act.getPreferences(Context.MODE_PRIVATE).getBoolean("nativeMuted582o", false)};
        ex.setVolume(muted[0] ? 0f : 1f);
        vol.setImageResource(muted[0] ? R.drawable.kuro_ic_vol_off_563 : R.drawable.kuro_ic_vol_on_563);
        vol.setOnClickListener(v -> {
            muted[0] = !muted[0];
            ex.setVolume(muted[0] ? 0f : 1f);
            vol.setImageResource(muted[0] ? R.drawable.kuro_ic_vol_off_563 : R.drawable.kuro_ic_vol_on_563);
            act.getPreferences(Context.MODE_PRIVATE).edit().putBoolean("nativeMuted582o", muted[0]).apply();
        });

        cc.setOnClickListener(v -> {
            // cycles captions off -> on, using the engine's own track selector
            android.util.TypedValue tv = new android.util.TypedValue();
            boolean captionsOn = ex.getTrackSelectionParameters().disabledTrackTypes
                    .contains(androidx.media3.common.C.TRACK_TYPE_TEXT) == false;
            androidx.media3.common.TrackSelectionParameters.Builder tb =
                    ex.getTrackSelectionParameters().buildUpon();
            tb.setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, captionsOn);
            ex.setTrackSelectionParameters(tb.build());
            cc.setColorFilter(captionsOn ? 0x66ffffff : KuroTheme582pAccent());
        });

        gear.setOnClickListener(v -> KuroPlayerSheet582p.open(act, ex));

        loop.setOnClickListener(v -> {
            if (onToggleLoop != null) onToggleLoop.run();
            loop.setColorFilter(ex.getRepeatMode() == Player.REPEAT_MODE_ONE
                    ? KuroTheme582pAccent() : 0xffffffff);
        });
        loop.setColorFilter(ex.getRepeatMode() == Player.REPEAT_MODE_ONE
                ? KuroTheme582pAccent() : 0xffffffff);

        pip.setOnClickListener(v -> host.onTogglePip582p());
        full.setOnClickListener(v -> host.onToggleFullscreen582p());

        ex.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean playing) { syncPlayIcon(ex, play); }
            @Override public void onPlaybackStateChanged(int state) {
                syncPlayIcon(ex, play);
                if (state == Player.STATE_READY) {
                    duration.setText(clock(ex.getDuration()));
                    position.setText(clock(ex.getCurrentPosition()));
                }
            }
        });

        KuroPlayerTheme582n.roundOutline(bar, KuroPlayerTheme582n.dp(c, radiusDp));
        return b;
    }

    private static int KuroTheme582pAccent() {
        return KuroPlayerTheme582n.accent();
    }

    private static void syncPlayIcon(Player ex, ImageButton play) {
        boolean playing = ex.isPlaying();
        play.setImageResource(playing ? R.drawable.kuro_ic_pause_563 : R.drawable.kuro_ic_play_563);
    }

    private static ImageButton icon(Context c, int res, String desc) {
        ImageButton b = new ImageButton(c);
        int s = KuroPlayerTheme582n.dp(c, 40);
        b.setLayoutParams(new LinearLayout.LayoutParams(s, s));
        b.setImageResource(res);
        b.setColorFilter(0xffffffff);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        int p = KuroPlayerTheme582n.dp(c, 8);
        b.setPadding(p, p, p, p);
        b.setContentDescription(desc);
        return b;
    }

    /** The "10" badge used by the reference's rewind/forward buttons. */
    private static TextView rew10(Context c) {
        TextView t = time(c);
        t.setText("10\u2039");
        t.setTextSize(13);
        int w = KuroPlayerTheme582n.dp(c, 34);
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(w, KuroPlayerTheme582n.dp(c, 34)));
        return t;
    }

    private static TextView ffwd10(Context c) {
        TextView t = time(c);
        t.setText("\u203a10");
        t.setTextSize(13);
        int w = KuroPlayerTheme582n.dp(c, 34);
        t.setGravity(Gravity.CENTER);
        t.setLayoutParams(new LinearLayout.LayoutParams(w, KuroPlayerTheme582n.dp(c, 34)));
        return t;
    }

    private static TextView time(Context c) {
        TextView t = new TextView(c);
        t.setTextSize(12);
        t.setTextColor(0xffffffff);
        t.setIncludeFontPadding(false);
        return t;
    }
}

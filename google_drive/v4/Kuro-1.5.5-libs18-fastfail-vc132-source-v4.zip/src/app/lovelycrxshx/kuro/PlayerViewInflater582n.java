package app.lovelycrxshx.kuro;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;

import androidx.media3.common.Player;
import androidx.media3.ui.PlayerView;

/**
 * 5.82p · Inflates res/layout/kuro_player_561.xml.
 *
 * Media3 1.7.1 has NO setSurfaceType() (verified with javap on media3-ui-1.7.1),
 * so the `surface_type` attribute was silently ignored and the video stayed a
 * SurfaceView — which ignores outline clipping. That is why the corners were square.
 * On API 16+ `surface_type="texture_view"` in the layout is honoured by the inflater,
 * so the rounding can finally apply to the video itself.
 */
final class PlayerViewInflater582n {
    private PlayerViewInflater582n() {}

    static android.widget.ImageButton button(PlayerView view, int id) {
        return view == null ? null : view.findViewById(id);
    }

    static PlayerView inflate(Activity activity, Player engine) {
        View root = LayoutInflater.from(activity).inflate(R.layout.kuro_player_561, null, false);
        root.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        PlayerView view = root.findViewById(R.id.kuro_player_view_561);
        if (view == null) throw new IllegalStateException("player view missing");
        view.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        view.setShutterBackgroundColor(KuroPlayerTheme582n.floor());
        view.setPlayer(engine);
        view.setUseController(true);
        return view;
    }
}

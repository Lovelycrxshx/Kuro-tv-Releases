package app.lovelycrxshx.kuro;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import org.json.JSONObject;

/**
 * Kuro 1.5.5-beta8 — Controllable App DPI, Global UI Size & Auto-Next Timing Engine.
 * Preserves native hardware system resolution while letting users choose System DPI or
 * any custom App DPI (280..640, default 500), global App UI Size (75%..135%, default 100%),
 * Auto-Play Next countdown seconds (3..20s, default 8s), and Up Next card scale (80%..125%).
 */
public final class KuroDisplay155 {
    public static final String PREFS = "kuro-display-155";
    public static final int FORCE_DPI = 0;      // 5.82c - 0 = follow System DPI (was hard-coded 500)
    public static final float FORCE_DENSITY = 500f / 160f;
    private static final int SYSTEM_DPI = detectHardwareSystemDpi();

    private static volatile boolean loaded = false;
    private static volatile int cfgDpi = FORCE_DPI;       // 0 = System DPI, else 280..640
    private static volatile int cfgUiScale = 100;         // 75..135 (%)
    private static volatile int cfgAutoNextSec = 8;       // 3..20 (s)
    private static volatile int cfgUpNextScale = 100;     // 80..125 (%)

    private KuroDisplay155() {}

    private static int detectHardwareSystemDpi() {
        try {
            Resources sys = Resources.getSystem();
            if (sys != null) {
                DisplayMetrics dm = sys.getDisplayMetrics();
                if (dm != null && dm.densityDpi >= 120 && dm.densityDpi <= 960) {
                    return dm.densityDpi;
                }
            }
        } catch (Throwable ignored) {}
        return 420;
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    public static void ensureLoaded(Context context) {
        if (loaded || context == null) return;
        synchronized (KuroDisplay155.class) {
            if (loaded) return;
            try {
                SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                int d = sp.getInt("dpi", FORCE_DPI);
                cfgDpi = d <= 0 ? 0 : clamp(d, 280, 640);
                cfgUiScale = clamp(sp.getInt("uiScale", 100), 75, 135);
                cfgAutoNextSec = clamp(sp.getInt("autoNextSec", 8), 3, 20);
                cfgUpNextScale = clamp(sp.getInt("upNextScale", 100), 80, 125);
                if (!sp.getBoolean("dpiSystem112", false)) {
                    cfgDpi = 0;
                    sp.edit().putInt("dpi", 0).putBoolean("dpiSystem112", true).apply();
                }
                loaded = true;
            } catch (Throwable ignored) {}
        }
    }

    public static void saveConfig(Context context, int dpi, int uiScale, int autoNextSec, int upNextScale) {
        int cleanDpi = dpi <= 0 ? 0 : clamp(dpi, 280, 640);
        int cleanScale = clamp(uiScale, 75, 135);
        int cleanSec = clamp(autoNextSec, 3, 20);
        int cleanCard = clamp(upNextScale, 80, 125);
        synchronized (KuroDisplay155.class) {
            cfgDpi = cleanDpi;
            cfgUiScale = cleanScale;
            cfgAutoNextSec = cleanSec;
            cfgUpNextScale = cleanCard;
            loaded = true;
            if (context != null) {
                try {
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit()
                        .putInt("dpi", cleanDpi)
                        .putInt("uiScale", cleanScale)
                        .putInt("autoNextSec", cleanSec)
                        .putInt("upNextScale", cleanCard)
                        .commit();
                } catch (Throwable ignored) {}
            }
        }
        if (context != null) {
            enforce500Dpi(context);
        }
    }

    public static int systemDpi() {
        return SYSTEM_DPI;
    }

    public static int configuredDpi(Context context) {
        ensureLoaded(context);
        return cfgDpi;
    }

    public static int baseDpi(Context context) {
        ensureLoaded(context);
        return cfgDpi <= 0 ? SYSTEM_DPI : cfgDpi;
    }

    public static int uiScale(Context context) {
        ensureLoaded(context);
        return cfgUiScale;
    }

    public static int effectiveDpi(Context context) {
        ensureLoaded(context);
        int base = cfgDpi <= 0 ? SYSTEM_DPI : cfgDpi;
        return clamp(Math.round(base * (cfgUiScale / 100f)), 220, 760);
    }

    public static float effectiveDensity(Context context) {
        return effectiveDpi(context) / 160f;
    }

    public static int autoNextSeconds(Context context) {
        ensureLoaded(context);
        return cfgAutoNextSec;
    }

    public static int upNextScale(Context context) {
        ensureLoaded(context);
        return cfgUpNextScale;
    }

    public static float upNextScaleFactor(Context context) {
        return upNextScale(context) / 100f;
    }

    public static Context wrapContext(Context base) {
        if (base == null) return null;
        try {
            ensureLoaded(base);
            int effDpi = effectiveDpi(base);
            float effDensity = effDpi / 160f;
            Resources res = base.getResources();
            if (res == null) return base;
            DisplayMetrics rawDm = res.getDisplayMetrics();
            Configuration cfg = new Configuration(res.getConfiguration());
            cfg.densityDpi = effDpi;
            if (rawDm != null && rawDm.widthPixels > 0 && rawDm.heightPixels > 0) {
                int wDp = Math.max(260, Math.round(rawDm.widthPixels / effDensity));
                int hDp = Math.max(260, Math.round(rawDm.heightPixels / effDensity));
                cfg.screenWidthDp = wDp;
                cfg.screenHeightDp = hDp;
                cfg.smallestScreenWidthDp = Math.min(wDp, hDp);
            }
            Context wrapped = base.createConfigurationContext(cfg);
            applyMetricsToResources(wrapped.getResources(), effDpi, effDensity);
            return wrapped;
        } catch (RuntimeException ignored) {
            return base;
        }
    }

    public static void enforce500Dpi(Context context) {
        if (context == null) return;
        try {
            ensureLoaded(context);
            int effDpi = effectiveDpi(context);
            float effDensity = effDpi / 160f;
            applyMetricsToResources(context.getResources(), effDpi, effDensity);
            Context app = context.getApplicationContext();
            if (app != null && app != context) {
                applyMetricsToResources(app.getResources(), effDpi, effDensity);
            }
        } catch (RuntimeException ignored) {}
    }

    private static void applyMetricsToResources(Resources res, int effDpi, float effDensity) {
        if (res == null) return;
        Configuration cfg = res.getConfiguration();
        float fontScale = (cfg != null && cfg.fontScale > 0f) ? cfg.fontScale : 1f;
        if (cfg != null) {
            cfg.densityDpi = effDpi;
        }
        DisplayMetrics dm = res.getDisplayMetrics();
        if (dm != null) {
            dm.density = effDensity;
            dm.densityDpi = effDpi;
            dm.xdpi = effDpi;
            dm.ydpi = effDpi;
            dm.scaledDensity = effDensity * fontScale;
            if (cfg != null && dm.widthPixels > 0 && dm.heightPixels > 0) {
                int wDp = Math.max(260, Math.round(dm.widthPixels / effDensity));
                int hDp = Math.max(260, Math.round(dm.heightPixels / effDensity));
                cfg.screenWidthDp = wDp;
                cfg.screenHeightDp = hDp;
                cfg.smallestScreenWidthDp = Math.min(wDp, hDp);
            }
        }
    }

    public static void applyActivity500Dpi(Activity activity) {
        if (activity == null) return;
        enforce500Dpi(activity);
    }

    public static String infoJson(Context context) {
        return infoJson(context, true);
    }

    public static String infoJson(Context context, boolean autoNextEnabled) {
        try {
            enforce500Dpi(context);
            DisplayMetrics dm = context != null && context.getResources() != null
                ? context.getResources().getDisplayMetrics() : null;
            int pw = dm != null ? dm.widthPixels : 0;
            int ph = dm != null ? dm.heightPixels : 0;
            int effDpi = effectiveDpi(context);
            float effDensity = effDpi / 160f;
            int wDp = pw > 0 ? Math.round(pw / effDensity) : 360;
            int hDp = ph > 0 ? Math.round(ph / effDensity) : 780;
            int rawCfg = configuredDpi(context);
            return new JSONObject()
                .put("dpi", rawCfg)
                .put("dpiMode", rawCfg <= 0 ? "system" : "custom")
                .put("systemDpi", SYSTEM_DPI)
                .put("baseDpi", baseDpi(context))
                .put("uiScale", uiScale(context))
                .put("effectiveDpi", effDpi)
                .put("density", (double) effDensity)
                .put("widthDp", wDp)
                .put("heightDp", hDp)
                .put("autoNextEnabled", autoNextEnabled)
                .put("autoNextSec", autoNextSeconds(context))
                .put("upNextScale", upNextScale(context))
                .put("resolutionMode", "system-default")
                .put("physicalWidth", pw)
                .put("physicalHeight", ph)
                .toString();
        } catch (Exception e) {
            return "{\"dpi\":500,\"baseDpi\":500,\"uiScale\":100,\"effectiveDpi\":500,\"density\":3.125,\"resolutionMode\":\"system-default\"}";
        }
    }

    public static String diagnosticsSummary(Context context) {
        enforce500Dpi(context);
        DisplayMetrics dm = context != null && context.getResources() != null
            ? context.getResources().getDisplayMetrics() : null;
        int pw = dm != null ? dm.widthPixels : 0;
        int ph = dm != null ? dm.heightPixels : 0;
        int rawCfg = configuredDpi(context);
        int base = baseDpi(context);
        int scale = uiScale(context);
        int eff = effectiveDpi(context);
        return "System Resolution (" + pw + "x" + ph + ") \u00b7 "
            + (rawCfg <= 0 ? ("System " + base) : ("App " + base))
            + " DPI \u00b7 UI " + scale + "% (" + eff + " eff DPI)";
    }
}

package app.lovelycrxshx.kuro;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.view.Gravity;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;

import androidx.media3.common.Player;
import androidx.media3.common.VideoSize;
import androidx.media3.exoplayer.ExoPlayer;

/**
 * 5.82q · The video surface, with NO PlayerView involved.
 *
 * Two failures led here, both measured on the user's screenshots:
 *   1. corners stayed square — media3-ui 1.7.1 has no setSurfaceType(), so the
 *      video stayed a SurfaceView, and a SurfaceView ignores clipToOutline;
 *   2. the control bar vanished — the custom controller_layout_id never inflated.
 *
 * So the video is now a bare TextureView bound with Player.setVideoTextureView(),
 * and everything around it is ours. A TextureView draws like an ordinary View,
 * which means a rounded outline genuinely clips the video pixels.
 */
final class KuroVideoSurface582q extends TextureView {

    interface Fit582q { int FIT = 0, FILL = 1, ZOOM = 2; }

    private int videoW = 0, videoH = 0;
    private int fit = Fit582q.FIT;

    KuroVideoSurface582q(Activity act) {
        super(act);
        setTag("kuro-texture-582q");
        setOpaque(false);
        setBackgroundColor(Color.TRANSPARENT);
    }

    /** Bind the engine and keep the aspect ratio ourselves. */
    void bind(final ExoPlayer ex) {
        setSurfaceTextureListener(new SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
                ex.setVideoTextureView(KuroVideoSurface582q.this);
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { applyFit(w, h); }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                ex.clearVideoTextureView(KuroVideoSurface582q.this);
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) {}
        });
        ex.addListener(new Player.Listener() {
            @Override public void onVideoSizeChanged(VideoSize size) {
                videoW = size.width;
                videoH = size.height;
                applyFit(getWidth(), getHeight());
            }
        });
    }

    void setFit(int mode) {
        fit = mode;
        applyFit(getWidth(), getHeight());
    }

    int getFit() { return fit; }

    /** Letterbox (FIT), crop (ZOOM) or stretch, laid out with a Matrix on the TextureView. */
    void applyFit(int viewW, int viewH) {
        if (viewW <= 0 || viewH <= 0 || videoW <= 0 || videoH <= 0) return;
        float scaleX = (float) viewW / videoW;
        float scaleY = (float) viewH / videoH;
        float scale;
        if (fit == Fit582q.FILL) {
            /* Fill STRETCHES to the view: independent axis scales, no crop. */
            Matrix stretch = new Matrix();
            stretch.setScale(scaleX, scaleY);
            setTransform(stretch);
            return;
        }
        if (fit == Fit582q.ZOOM) scale = Math.max(scaleX, scaleY);
        else scale = Math.min(scaleX, scaleY);
        float dx = (viewW - videoW * scale) / 2f;
        float dy = (viewH - videoH * scale) / 2f;
        Matrix m = new Matrix();
        m.setScale(scale, scale);
        m.postTranslate(dx, dy);
        setTransform(m);
    }

    /** Round the video itself. Works because this is a TextureView, not a SurfaceView. */
    void round(int radiusPx) {
        KuroPlayerTheme582n.roundOutline(this, radiusPx);
    }
}

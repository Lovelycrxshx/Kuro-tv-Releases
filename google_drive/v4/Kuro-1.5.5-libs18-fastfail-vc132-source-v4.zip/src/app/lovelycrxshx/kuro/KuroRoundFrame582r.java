package app.lovelycrxshx.kuro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

/**
 * 5.82r · A FrameLayout that genuinely clips its children to rounded corners.
 *
 * Setting clipToOutline on a TextureView did not round the picture on the user's
 * device (measured: first bright pixel at the same x on every row, i.e. a square
 * corner). A TextureView composites its video in a separate layer, so clipping the
 * view itself is unreliable across GPUs.
 *
 * This container clips two ways at once:
 *   1. a rounded ViewOutlineProvider + clipToOutline (cheap, hardware path);
 *   2. an explicit canvas clip in draw() using a Path, which the GPU cannot skip.
 * Belt and braces, because guessing has cost enough rounds already.
 */
final class KuroRoundFrame582r extends FrameLayout {

    private final Path path = new Path();
    private final RectF bounds = new RectF();
    private float radiusPx = 0f;

    KuroRoundFrame582r(Context c) {
        super(c);
        setWillNotDraw(false);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
    }

    void setRadius(float px) {
        radiusPx = Math.max(0f, px);
        setClipToOutline(true);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radiusPx);
            }
        });
        invalidateOutline();
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        bounds.set(0, 0, w, h);
        rebuild();
        invalidateOutline();
    }

    private void rebuild() {
        path.reset();
        path.addRoundRect(bounds, radiusPx, radiusPx, Path.Direction.CW);
    }

    @Override protected void dispatchDraw(Canvas canvas) {
        int save = canvas.save();
        if (radiusPx > 0f) {
            if (bounds.width() == 0 || bounds.height() == 0) bounds.set(0, 0, getWidth(), getHeight());
            rebuild();
            canvas.clipPath(path);
        }
        super.dispatchDraw(canvas);
        canvas.restoreToCount(save);
    }
}

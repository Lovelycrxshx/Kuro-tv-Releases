package app.lovelycrxshx.kuro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.media3.exoplayer.ExoPlayer;

/** 5.82p · The gear sheet: playback speed, matching the reference's settings button. */
final class KuroPlayerSheet582p {
    private KuroPlayerSheet582p() {}

    static void open(final Activity act, final ExoPlayer ex) {
        final float before = ex.getPlaybackParameters().speed;
        float[] speeds = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};
        CharSequence[] labels = {"0.5\u00d7", "0.75\u00d7", "Normal", "1.25\u00d7", "1.5\u00d7", "2\u00d7"};
        int checked = 2;
        for (int i = 0; i < speeds.length; i++) if (Math.abs(speeds[i] - before) < 0.01f) checked = i;

        new AlertDialog.Builder(act, KuroTheme12.dialogTheme())
                .setTitle("Playback speed")
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    ex.setPlaybackSpeed(speeds[which]);
                    act.getPreferences(Context.MODE_PRIVATE).edit()
                            .putFloat("nativeSpeed582p", speeds[which]).apply();
                    d.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    static float savedSpeed(Context c) {
        float s = 1f;
        if (c instanceof Activity) s = ((Activity) c).getPreferences(Context.MODE_PRIVATE).getFloat("nativeSpeed582p", 1f);
        return (s < 0.25f || s > 4f) ? 1f : s;
    }
}

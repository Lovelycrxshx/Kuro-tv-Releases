package app.lovelycrxshx.kuro;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.TextView;

import androidx.media3.ui.DefaultTimeBar;

/**
 * 5.82p · Watch-player palette.
 *
 * The user asked for the reference player look with an OLED-black surround.
 * So the frame is true #000000 by default (OLED test: 0,0,0 — pixels off), and the
 * user's existing AMOLED toggle in KuroTheme12 decides whether that black is pure.
 * When AMOLED is off we keep a near-black sheet that carries a trace of the accent
 * so the player still belongs to the theme.
 */
final class KuroPlayerTheme582n {
    private KuroPlayerTheme582n() {}

    /** The surround. Pure black for OLED; faintly accent-tinted otherwise. */
    static int floor() {
        return KuroTheme12.amoled() ? 0xff000000 : 0xff0b0b0d;
    }

    static int accent() {
        int a = KuroTheme12.accentColor();
        return Color.argb(255, Color.red(a), Color.green(a), Color.blue(a));
    }

    static int accentAlpha(float alpha) {
        int a = accent();
        return Color.argb(Math.round(Math.max(0f, Math.min(1f, alpha)) * 255),
                Color.red(a), Color.green(a), Color.blue(a));
    }

    static int blend(int base, int over, float amount) {
        float f = Math.max(0f, Math.min(1f, amount));
        return Color.argb(255,
                Math.round(Color.red(base) * (1 - f) + Color.red(over) * f),
                Math.round(Color.green(base) * (1 - f) + Color.green(over) * f),
                Math.round(Color.blue(base) * (1 - f) + Color.blue(over) * f));
    }

    static int hsl(float h, float s, float l) {
        float c = (1f - Math.abs(2f * l - 1f)) * s;
        float x = c * (1f - Math.abs(((h / 60f) % 2f) - 1f));
        float m = l - c / 2f;
        float r, g, b;
        int seg = (int) Math.floor(((h % 360f) + 360f) % 360f / 60f);
        switch (seg) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x; break;
        }
        return Color.argb(255, Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255));
    }

    /** Round a view's outline. Only honoured by content drawn as a View (TextureView). */
    static void roundOutline(View v, final int radiusPx) {
        v.setClipToOutline(true);
        v.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View view, android.graphics.Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
            }
        });
    }

    static GradientDrawable chip(Context c, boolean on, float radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(radiusPx);
        d.setColor(on ? accentAlpha(0.9f) : 0x66000000);
        d.setStroke(dp(c, 1), on ? accent() : 0x55ffffff);
        return d;
    }

    static GradientDrawable pill(Context c, float radiusPx) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(radiusPx);
        d.setColor(0xffffffff);
        return d;
    }

    static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable scrim(Context c) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xff000000, 0xcc000000, 0x00000000});
        float r = dp(c, 14);
        d.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        return d;
    }

    /** Tint a DefaultTimeBar to the accent. */
    static void timeBar(DefaultTimeBar bar) {
        if (bar == null) return;
        int acc = accent();
        bar.setPlayedColor(acc);
        bar.setScrubberColor(acc);
        bar.setBufferedColor(0x77ffffff);
        bar.setUnplayedColor(0x44ffffff);
    }

    static void times(TextView position, TextView duration) {
        if (position != null) position.setTextColor(0xffffffff);
        if (duration != null) duration.setTextColor(0xb3ffffff);
    }
}

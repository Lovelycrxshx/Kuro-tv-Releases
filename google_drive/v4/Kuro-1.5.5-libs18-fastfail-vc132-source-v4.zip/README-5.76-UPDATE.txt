Kuro 5.76 test – home selection and news notifications

Home browse surfaces suppress accidental text selection and touch callouts when scrolling or holding cards. Inputs, editable content and explicitly selectable elements remain selectable. Other application screens are not intentionally changed.

News alerts have a Kuro monochrome status icon, a bundled brand image, a purple accent, a labelled Open news action, and an expandable single-story summary or multiple headlines. Actual appearance, color and available actions vary by Android version and device. The brand image is bundled; article artwork is not downloaded in the background. RSS summaries are shown only when the feed supplies them. The action opens Kuro's news feed, not necessarily an individual article.

The existing alert settings, source checking, player and fallback adapters are unchanged. Browser tests and host-side simulated Android tests passed; physical device operation, notification appearance and long-press behavior need device testing.

Build uses the separately supplied Discord SDK AAR and original signing key, neither included in source archives. Source text can be restored with scripts/restore-source-text.py.

KURO.TV 5.72 — EXACT RESUME, CARD BACKGROUND CONTROLS, NATIVE FIT/CROP AND UPDATES
Package app.lovelycrxshx.kuro, version 5.72 / versionCode 72, Android 8+.

Install only the original-key-signed APK over your existing Kuro installation.
Do not uninstall the app and do not clear its data. The signing certificate is
checked before release, and 5.72 is signed with the same key as 5.71, but update
installation, permissions and data retention still need a real phone test.
Consider exporting a local backup first; backup files are unencrypted.

1. EXACT EPISODE RESUME AND RESTART
Kuro already stored the exact playback position per episode. Restart now uses it,
but only where the player proves it has a real position and can seek:
 * Native player: the ExoPlayer position and duration, with a real seek to zero.
 * Kuro's own stream page: exactly one video element reporting finite position
   and duration. The seek is applied and then confirmed.
 * Any other embedded player: Restart is not offered. Kuro keeps the previous
   last-episode behaviour instead of pretending, because it cannot trust a
   third-party timeline.
The new Restart chip sits in the player tools below PiP, Cast and Download.
A saved checkpoint is cleared only after the restart seek is applied.

2. ANIME AND HISTORY BACKGROUND DIM AND SOFTEN
Open Profile, then "Customize PFP, Banner, Anime & History". On the Anime or
History tab, two sliders appear: Dim (0-80%) and Soften (0-20 px blur). Each
card keeps its own values; changing Anime never changes History.
Sliders change the preview only. Apply saves, Cancel discards, exactly like the
5.71 artwork flow. Adjusting a background you already chose never forces you to
pick a new picture, and one card's values never overwrite another's.
Existing 5.71 selections, older 5.48 card artwork, gallery files and backups are
kept. The values travel inside the existing local card-art record, so local
backups already include them.

3. FIT AND CROP FOR KURO'S NATIVE PLAYER
The Fit/Crop chip appears on Kuro's own native player while a direct stream is
playing. Crop fills the screen and trims the edges; Fit shows the whole frame.
This changes only the picture inside Kuro's player view. Fullscreen, display
cutout, rotation, PiP and the enhanced fullscreen toolbar are untouched. The
choice is remembered for the next native episode. WebView-based and embedded
players are not affected, because Kuro does not control their surface.

4. UPDATE CHECKS AND APK PREFLIGHT
Settings has a new "Kuro updates" section showing the installed version, the last
check, how many reminders were shown, whether a file is ready, and the last error.
It also offers Check now, Install when a file is ready, and turning the automatic
checks off.

Preflight (feature 48) inspects an APK before Kuro hands it to Android:
package must be app.lovelycrxshx.kuro, the versionCode must be higher than the
installed one, and the signing certificate set must match this installation
exactly. A file that fails any check is deleted and never offered to the
installer. Android's installer remains the final authority and re-verifies the
package and signature itself.

UPDATE FLOW AS REQUESTED
Kuro reads the public GitHub latest-release metadata for
https://github.com/ImAuraxSiva/Kuro-tv-Releases and finds a .apk asset hosted on
GitHub over HTTPS. When a newer release appears:
 * Three notifications are shown, about one day apart.
 * After the third notification Kuro downloads the APK itself, in the app, over
   either Wi-Fi or mobile data.
 * There is no download prompt, no GitHub page, no "remind me later" button and
   no fourth reminder.
 * The downloaded file is checksummed when the release publishes a digest, then
   preflight-checked, then a single "ready to install" notice appears. Tapping it
   re-runs the preflight and opens Android's installer.

WHAT ANDROID STILL DECIDES
 * Kuro cannot install silently. Android always shows its own install
   confirmation, and may require "Allow from this source" for Kuro once.
 * Android decides when background jobs run. Notifications and downloads can be
   delayed, and the spacing is approximate, not to the minute.
 * If notifications are blocked for Kuro, reminders are not silently skipped and
   nothing is downloaded; the Settings panel reports this instead.
 * The unauthenticated GitHub API is rate-limited, so a check can fail and be
   retried on a later pass. Failures are recorded, not hidden.
 * Download retries stop after three failures.
 * The first updater-enabled APK (this one) must be installed normally over 5.71.
   Automatic preparation only takes effect for releases after it.

CARRIED OVER FROM 5.71 AND EARLIER
All six supplied sheets still provide 160 profile-picture and banner pairs, with
independent PFP, Banner, Anime and History choices and the reversible preview.
Advanced video effects, free on-device AI and the honestly labelled sharp/colour
enhancement are unchanged. Discord Rich Presence keeps the anime-cover-only
artwork, linked/current accounts, history, test and status controls, and three-
second updates while visible. Providers, imports, trackers, local email and the
purple/black interface are unchanged. No Google sign-in, no Drive backup and no
Supabase.

STILL NOT DEVICE-TESTED
Actual resume and Restart against a live stream, the dim/soften appearance on a
real screen, native fit/crop on a device with a display cutout, the three-day
notification schedule, the in-app download, Android's install confirmation and
data retention across the update have not been exercised on a phone. Those need
your device.

FILES
Kuro-tv-5.72.apk — signed release, install this.
Kuro-tv-5.72-Source.zip — matching complete source tree.
Kuro-tv-5.72-Source.txt — the same tree as a restorable text archive
(scripts/restore-source-text.py restores it into a new directory).
No signing key, password, token, generated SDK/tool cache or separately licensed
standalone binary is included in either source archive.

PUBLISHING ON GITHUB (you must press Publish yourself)
1. Open https://github.com/ImAuraxSiva/Kuro-tv-Releases/releases/new
2. Tag: v5.72 (lowercase v, as before). Target: main.
3. Title: Kuro 5.72
4. Attach Kuro-tv-5.72.apk as the release asset. Do not attach the ZIP or TXT as
   the APK; they are source backups. Each release asset must be under 2 GiB.
5. Leave "Set as pre-release" off.
6. Describe the release with the sections above, then Publish release.

The updater in this release looks for the latest published, non-draft,
non-prerelease release with a .apk asset, so publishing anything else first would
send the wrong file to 5.72 users.

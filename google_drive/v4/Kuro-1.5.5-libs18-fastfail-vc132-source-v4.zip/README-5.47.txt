KURO.TV 5.47 — SCREENSHOT-INSPIRED PROFILE PAGE

The Account/Profile page now uses a purple/black anime banner, editable local
profile image/name/banner, six optional offline avatar variants, a local-only
privacy card, real library/history counts, and grouped lists/account rows.
The artwork is original generated art. No public profile or privacy toggle was
added; the local Kuro profile remains on this phone. There is no manga or
comment-reply system: the second card is the actual Kuro History, and the
notification row opens existing anime news/alerts. Counts are from local Kuro
status lists, not MAL/AniList statistics.

Existing Google/email/Discord/MAL/AniList connections, manual one-way imports,
optional Drive backup, copy-confirmation and profile-image picker are retained.
The old backup restrictions and exclusions still apply; profile/images and
imported snapshots are not included in Drive backup. See README-5.46.txt for
backup behavior and limitations. Kuro data stays intact when updating.

The previous signed package ID and signer are retained. Install over the app;
do NOT uninstall it or clear data. Tested with simulated browser flows and APK
packaging checks only; no real device, Google login, upload, restore or provider
interaction was verified. No release artifact was uploaded online.

Build: JDK 17+, Android SDK platform 35/build-tools 35.0.1; set ANDROID_HOME,
JAVA_HOME, KEYSTORE and KS_PASS and run ./build.sh. Signing key is separate.

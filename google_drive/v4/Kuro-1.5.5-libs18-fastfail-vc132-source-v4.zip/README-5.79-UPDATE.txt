Kuro 5.79-test — Discord activity episode title formatting

Episode names in Discord activity use double quotation marks rather than parentheses, for example: Episode 1 - "Smoke Signal" · DUB · Paused 0:00. The same privacy controls, title safety filtering and UTF-8 length budget remain in effect. Empty or generic episode names remain omitted. Offline presence model tests passed; appearance in Discord on an Android device has not been tested.

5.78 Anime Village remains an experimental exact-episode fallback using a third-party embedded player, not a full catalogue. Playback and subtitle behavior have not been verified on a device. Signing key/password and the separately supplied Discord SDK are excluded from source archives.

Kuro 5.74-test: home discovery removal and skip-control update

The home discovery/history recommendation section, including its content preference controls, is removed from unified and individual-library home screens. Saved local data is not deleted.

Auto-skip remains opt-in. Web player detection can act on explicit intro/outro controls in known player containers while the controls are faded, provided the container has exactly one playing video. It does not synthesize a touch, click hidden-by-display controls, or bypass verification. Other providers may hide their controls differently or require trusted gestures, so skipping cannot be guaranteed on every server. The native player and Kuro's direct web stream player continue to use source/saved timing markers when available.

APK signed using the original release certificate. Android device testing is still needed. Source archives omit signing materials and the externally supplied Discord Social SDK AAR.

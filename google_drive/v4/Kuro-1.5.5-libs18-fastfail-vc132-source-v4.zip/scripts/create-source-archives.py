#!/usr/bin/env python3
"""Create matching ZIP and KURO-SOURCE-TEXT-1 archives of a source tree.

Usage: python3 scripts/create-source-archives.py SOURCE_DIR OUT.zip OUT.txt
Generated build/cache folders and local signing material are not archived.
The text archive can be restored with scripts/restore-source-text.py.
"""
import base64
import hashlib
import json
import pathlib
import stat
import sys
import zipfile

SKIP_DIRS = {'.git', '.gradle', '.cache', 'node_modules', 'build', 'target', '__pycache__', '.venv'}
SKIP_NAMES = {'local.properties'}
SKIP_SUFFIXES = {'.apk', '.idsig', '.jks', '.keystore', '.p12', '.pfx', '.pem', '.key'}


def collect(root):
    result = []
    for p in sorted(root.rglob('*')):
        rel = p.relative_to(root)
        if any(part in SKIP_DIRS for part in rel.parts):
            continue
        if p.is_symlink():
            raise ValueError('symlink in source tree: ' + str(rel))
        if not p.is_file() or p.name in SKIP_NAMES or p.suffix.lower() in SKIP_SUFFIXES:
            continue
        if p.name.lower().startswith(('signing-password', 'signing-key', 'signer-pass', 'signer-key')):
            raise ValueError('possible signing material in source tree: ' + str(rel))
        result.append((rel.as_posix(), p.read_bytes(), bool(p.stat().st_mode & stat.S_IXUSR)))
    return result


def make(root, zip_path, text_path):
    files = collect(root)
    if not files:
        raise ValueError('source tree is empty')
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, content, executable in files:
            info = zipfile.ZipInfo(root.name.replace('kuro-anime-', 'Kuro-tv-') + '-Source/' + name)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = ((0o100755 if executable else 0o100644) << 16)
            archive.writestr(info, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with text_path.open('wb') as out:
        out.write(b'KURO-SOURCE-TEXT-1\n')
        for name, content, executable in files:
            try:
                content.decode('utf-8')
                if b'\x00' in content:
                    raise UnicodeError('binary NUL')
                encoding, payload = 'utf-8', content
            except UnicodeError:
                encoding, payload = 'base64', base64.b64encode(content)
            meta = {'path': name, 'encoding': encoding, 'size': len(content),
                    'payload_size': len(payload), 'sha256': hashlib.sha256(content).hexdigest(),
                    'executable': executable}
            out.write(b'@@KURO-FILE ' + json.dumps(meta, ensure_ascii=False, separators=(',', ':')).encode('utf-8') + b'\n')
            out.write(payload)
            out.write(b'\n@@END-KURO-FILE\n')
        out.write(b'@@END-ARCHIVE\n')
    print(f'Archived {len(files)} files into {zip_path} and {text_path}')


def main():
    if len(sys.argv) != 4:
        raise SystemExit(__doc__)
    root = pathlib.Path(sys.argv[1]).resolve()
    zip_path, text_path = (pathlib.Path(arg).resolve() for arg in sys.argv[2:])
    if not root.is_dir() or root in (zip_path, text_path) or root in zip_path.parents or root in text_path.parents:
        raise SystemExit('Use a source directory and output paths outside that directory.')
    if zip_path.exists() or text_path.exists():
        raise SystemExit('Output already exists; refusing to overwrite it.')
    make(root, zip_path, text_path)


if __name__ == '__main__':
    main()

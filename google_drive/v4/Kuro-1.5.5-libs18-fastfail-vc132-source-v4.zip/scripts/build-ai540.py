from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]
source=(root/'libs/Anime4K_Upscale_CNN_x2_S.glsl').read_text()
parts=source.split('//!DESC ')[1:]
assert len(parts)==5 and all('Conv-' in x for x in parts[:4]) and 'Depth-to-Space' in parts[4]
conv=[]
for part in parts[:4]:
    start=part.index('#define go_0');end=part.index('\n}',start)+2
    conv.append(part[start:end])
assert all('vec4 hook()' in p for p in conv)
header='''/* Kuro.tv experimental on-device AI detail enhancement.
 * Convolution stages and pretrained CNN weights are adapted from
 * Anime4K_Upscale_CNN_x2_S.glsl, copyright (c) 2019-2021 bloc97, MIT License.
 * Source: https://github.com/bloc97/Anime4K, commit 7684e9586f8dcc738af08a1cdceb024cc184f426.
 * This WebGL2 port caps the CNN input and blends its learned residual over the
 * original frame; it is not the complete official Anime4K processing pipeline.
 * It accesses only frames the WebView is already allowed to draw. No network,
 * verification, cross-origin, or protected-media bypass is used.
 * See libs/anime4k-LICENSE.txt in the source distribution.
 */
(function(){
'use strict';
if(window.__kuroAI540)return;
'''
body=r'''
const vs=`#version 300 es
out vec2 uv;
void main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));uv=p;gl_Position=vec4(p*2.0-1.0,0.0,1.0);}`;
const residual=`#version 300 es
precision highp float;
in vec2 uv;uniform sampler2D u_in;uniform vec2 u_size;out vec4 outColor;
void main(){
 vec2 point=clamp(uv,vec2(0.0),vec2(0.999999))*u_size;
 ivec2 pixel=clamp(ivec2(floor(point)),ivec2(0),ivec2(u_size)-1);
 ivec2 part=ivec2(floor(fract(point)*2.0));
 float learned=texelFetch(u_in,pixel,0)[part.y*2+part.x];
 outColor=vec4(learned,learned,learned,1.0);
}`;
const macros=['MAIN','conv2d_tf','conv2d_1_tf','conv2d_2_tf'];
function shader(gl,type,src){const s=gl.createShader(type);if(!s)throw Error('GPU shader unavailable');gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){let message=gl.getShaderInfoLog(s)||'AI shader unavailable';gl.deleteShader(s);throw Error(message)}return s}
function program(gl,fragment){let v=null,f=null,p=null;try{v=shader(gl,gl.VERTEX_SHADER,vs);f=shader(gl,gl.FRAGMENT_SHADER,fragment);p=gl.createProgram();if(!p)throw Error('AI program unavailable');gl.attachShader(p,v);gl.attachShader(p,f);gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p)||'AI program unavailable');return p}catch(e){if(p)gl.deleteProgram(p);throw e}finally{if(v)gl.deleteShader(v);if(f)gl.deleteShader(f)}}
function convShader(i){return `#version 300 es
precision highp float;
in vec2 uv;uniform sampler2D u_in;uniform vec2 u_texel;out vec4 outColor;
#define ${macros[i]}_texOff(offset) texture(u_in, clamp(uv+(offset)*u_texel,vec2(0.0),vec2(1.0)))
${conv[i]}
void main(){outColor=hook();}`}
function create(gl){
 if(!gl||!gl.getExtension('EXT_color_buffer_float'))throw Error('AI requires WebGL2 floating-point buffers');
 const programs=[],targets=[];let w=0,h=0;
 function destroyTargets(){for(const t of targets){gl.deleteFramebuffer(t.fb);gl.deleteTexture(t.tex)}targets.length=0;w=h=0;gl.bindFramebuffer(gl.FRAMEBUFFER,null)}
 function destroy(){destroyTargets();for(const p of programs)gl.deleteProgram(p);programs.length=0}
 function target(width,height,linear){
  const tex=gl.createTexture(),fb=gl.createFramebuffer();if(!tex||!fb){if(tex)gl.deleteTexture(tex);if(fb)gl.deleteFramebuffer(fb);throw Error('AI GPU memory unavailable')}
  gl.bindTexture(gl.TEXTURE_2D,tex);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,linear?gl.LINEAR:gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,linear?gl.LINEAR:gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA16F,width,height,0,gl.RGBA,gl.HALF_FLOAT,null);gl.bindFramebuffer(gl.FRAMEBUFFER,fb);gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,tex,0);
  if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE){gl.deleteFramebuffer(fb);gl.deleteTexture(tex);throw Error('AI floating-point render target unavailable')}
  return {fb,tex};
 }
 try{for(let i=0;i<4;i++)programs.push(program(gl,convShader(i)));programs.push(program(gl,residual))}catch(e){destroy();throw e}
 function render(source,width,height){
  if(!Number.isFinite(width)||!Number.isFinite(height)||width<1||height<1)throw Error('AI is waiting for a video frame');
  // Bounded inference, not a 4K claim: high-resolution input remains the base.
  const scale=Math.min(1,480/width,270/height),nw=Math.max(1,Math.floor(width*scale)),nh=Math.max(1,Math.floor(height*scale));
  if(nw!==w||nh!==h){destroyTargets();try{targets.push(target(nw,nh,false));targets.push(target(nw,nh,false));targets.push(target(nw*2,nh*2,true));w=nw;h=nh}catch(e){destroyTargets();throw e}}
  let input=source;
  for(let i=0;i<5;i++){
   const out=i===4?targets[2]:targets[i%2];gl.bindFramebuffer(gl.FRAMEBUFFER,out.fb);gl.viewport(0,0,i===4?w*2:w,i===4?h*2:h);gl.useProgram(programs[i]);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,input);
   gl.uniform1i(gl.getUniformLocation(programs[i],'u_in'),0);
   if(i===4)gl.uniform2f(gl.getUniformLocation(programs[i],'u_size'),w,h);else gl.uniform2f(gl.getUniformLocation(programs[i],'u_texel'),1/w,1/h);
   gl.drawArrays(gl.TRIANGLES,0,3);input=out.tex;
  }
  gl.bindFramebuffer(gl.FRAMEBUFFER,null);
  if(gl.getError()!==gl.NO_ERROR)throw Error('AI GPU render failed');
  return {texture:targets[2].tex,width:w,height:h};
 }
 return {render,destroy};
}
window.__kuroAI540={create};
})();
'''
output=header+'const conv='+json.dumps(conv,ensure_ascii=False,separators=(',',':'))+';\n'+body
p=root/'assets/ai-upscale540.js';p.write_text(output)
print('generated',len(output),'bytes from',len(source),'byte MIT licensed Anime4K shader')

#!/usr/bin/env python3
"""Restore a Kuro text source archive into a NEW directory.

Usage: python3 scripts/restore-source-text.py Kuro-tv-5.68-Source.txt NEW_DIR
The tool refuses existing output directories, validates every SHA-256 before
writing anything, and rejects absolute/traversing file paths.
"""
import base64,hashlib,json,pathlib,sys

MAGIC=b'KURO-SOURCE-TEXT-1\n'
END=b'\n@@END-KURO-FILE\n'
def read_archive(path):
    data=pathlib.Path(path).read_bytes()
    if not data.startswith(MAGIC):raise ValueError('not a Kuro source text archive')
    pos=len(MAGIC);files={}
    while pos<len(data):
        e=data.find(b'\n',pos)
        if e<0:raise ValueError('truncated header')
        line=data[pos:e];pos=e+1
        if line==b'@@END-ARCHIVE':
            if pos!=len(data):raise ValueError('extra data after archive')
            return files
        prefix=b'@@KURO-FILE '
        if not line.startswith(prefix):raise ValueError('invalid file header')
        meta=json.loads(line[len(prefix):].decode('utf-8'))
        name=meta['path'];p=pathlib.PurePosixPath(name)
        if not name or p.is_absolute() or '..' in p.parts or str(p)!=name or '\\' in name or name in files:raise ValueError('unsafe or duplicate path')
        length=meta['payload_size']
        if not isinstance(length,int) or length<0 or length>100_000_000:raise ValueError('invalid length')
        body=data[pos:pos+length];pos+=length
        if len(body)!=length or data[pos:pos+len(END)]!=END:raise ValueError('truncated file')
        pos+=len(END)
        if meta['encoding']=='utf-8':body.decode('utf-8')
        elif meta['encoding']=='base64':body=base64.b64decode(body,validate=True)
        else:raise ValueError('unknown encoding')
        if len(body)!=meta['size'] or hashlib.sha256(body).hexdigest()!=meta['sha256']:raise ValueError('file checksum mismatch: '+name)
        files[name]=(body,bool(meta.get('executable',False)))
    raise ValueError('archive end missing')

def main():
    if len(sys.argv)!=3:raise SystemExit(__doc__)
    files=read_archive(sys.argv[1]);root=pathlib.Path(sys.argv[2])
    if root.exists():raise SystemExit('Output directory already exists; refusing to overwrite it.')
    root.mkdir(parents=True)
    for name,(data,executable) in files.items():
        out=root.joinpath(*pathlib.PurePosixPath(name).parts);out.parent.mkdir(parents=True,exist_ok=True)
        with out.open('xb') as f:f.write(data)
        if executable:out.chmod(0o755)
    print('Restored',len(files),'checksum-verified files to',root)
if __name__=='__main__':main()

#!/usr/bin/env python3
"""Extract Kuro's supplied profile presets from the six user-provided sheets.

This script is reproducible when the six original PNG sheets are supplied in
--input-dir. The extracted JPEGs and manifest are already included in the
source backup, so the original sheets are not required for a normal build.
No internet or external artwork is used.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from PIL import Image, ImageOps

# Each box is relative to the top of a row: avatar first, banner second.
# User screenshots have different grid dimensions; keep the banner's own
# built-in dark gradient rather than extending or inventing image content.
SHEETS = [
    ("1794252121278.png", 12, 200.0, [((190, 26, 382, 218), (420, 28, 1764, 212))]),
    ("1794251072981.png", 15, 160.0, [((10, 8, 150, 148), (180, 6, 892, 154)), ((920, 8, 1060, 148), (1080, 6, 1786, 154))]),
    ("1794251353451.png", 16, 158.0, [((12, 4, 148, 140), (164, 4, 561, 152)), ((578, 4, 714, 140), (730, 4, 1128, 152)), ((1140, 4, 1276, 140), (1296, 4, 1692, 152))]),
    ("1794251342010.png", 11, 2304 / 11, [((12, 8, 204, 200), (226, 8, 920, 200)), ((1000, 8, 1192, 200), (1228, 8, 1848, 200))]),
    ("1794251543771.png", 12, 200.0, [((8, 8, 200, 200), (214, 8, 892, 192)), ((906, 8, 1098, 200), (1110, 8, 1786, 192))]),
    ("1794251320574.png", 12, 200.0, [((8, 8, 196, 196), (214, 8, 892, 193)), ((910, 8, 1098, 196), (1110, 8, 1786, 193))]),
]

def crop(source: Image.Image, box: tuple[int, int, int, int], top: int) -> Image.Image:
    x0, y0, x1, y1 = box
    # PIL pads the few pixels outside an edge with black, preserving aspect.
    return source.crop((x0, y0 + top, x1, y1 + top)).convert("RGB")

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--input-dir', type=Path, required=True)
    ap.add_argument('--output-dir', type=Path, required=True)
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    entries, sources = [], []
    for group, (filename, rows, height, columns) in enumerate(SHEETS, 1):
        path = args.input_dir / filename
        raw = path.read_bytes()
        sources.append({'file': filename, 'sha256': hashlib.sha256(raw).hexdigest()})
        image = Image.open(path).convert('RGB')
        # Row order first, then column; this follows the supplied sheet layout.
        for row in range(rows):
            top = round(row * height)
            for column, (avatar, banner) in enumerate(columns, 1):
                n = len(entries) + 1
                af, bf = f'preset571-a-{n:03}.jpg', f'preset571-b-{n:03}.jpg'
                av = crop(image, avatar, top)
                av = ImageOps.fit(av, (176, 176), method=Image.Resampling.LANCZOS)
                bn = crop(image, banner, top)
                # Never upscale the provided art. Cap exceptionally wide rows for
                # a smaller APK while retaining their original aspect ratio.
                if bn.width > 1200:
                    bn.thumbnail((1200, 1200), Image.Resampling.LANCZOS)
                av.save(args.output_dir / af, 'JPEG', quality=87, optimize=True, progressive=True)
                bn.save(args.output_dir / bf, 'JPEG', quality=87, optimize=True, progressive=True)
                entries.append({'id': n, 'avatar': af, 'banner': bf,
                                'label': f'Sheet {group}, row {row + 1}, choice {column}'})
    assert len(entries) == 160, len(entries)
    manifest = {'version': 1, 'source': 'User-provided artwork sheets', 'sources': sources, 'entries': entries}
    (args.output_dir / 'preset-manifest571.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    # The browser consumes this static local script. No fetch or third-party URL.
    (args.output_dir / 'preset-manifest571.js').write_text('window.KURO_PRESETS571=Object.freeze(' + json.dumps(entries, ensure_ascii=False, separators=(',', ':')) + ');\n', encoding='utf-8')
    print(f'Extracted {len(entries)} avatars and {len(entries)} banners from {len(SHEETS)} supplied sheets.')

if __name__ == '__main__':
    main()

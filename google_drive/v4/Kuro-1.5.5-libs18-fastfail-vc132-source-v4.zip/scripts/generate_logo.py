#!/usr/bin/env python3
"""Recreate the user's raster logo as smooth Bezier paths and make Android assets.

Requires Python Pillow, NumPy, OpenCV, CairoSVG, and the potrace binary.
The included SVG and PNG assets are already generated; this script is optional.
Use --master PATH to additionally write a 15,360-pixel-wide black-backed PNG.
The new geometry is an approximation of the provided source, not recovered 16K detail.
"""
from pathlib import Path
import argparse, re, subprocess, tempfile
import cv2
import numpy as np
from PIL import Image
import cairosvg

ROOT=Path(__file__).resolve().parents[1]
original=ROOT/'art/original-kuro-tv.png'
img=cv2.imread(str(original),cv2.IMREAD_COLOR)
if img is None: raise SystemExit('Missing original logo image')
rgb=cv2.cvtColor(img,cv2.COLOR_BGR2RGB);bright=rgb.max(2)
# A high threshold retains the dark flower/stamen cut-outs and produces clean,
# scale-independent edges. The original gradients are approximated per shape.
mask=(bright>130).astype(np.uint8)
count,labels,stats,_=cv2.connectedComponentsWithStats(mask,8)
components=sorted([(int(i),[int(x) for x in s]) for i,s in enumerate(stats) if i and s[4]>100],key=lambda a:(a[1][0],a[1][1]))
defs=[];layers=[];emblem=[]
with tempfile.TemporaryDirectory(prefix='kuro-logo-') as tmp:
 tmp=Path(tmp)
 for number,(label,(x,y,w,h,area)) in enumerate(components):
  pad=4;x0=max(0,x-pad);y0=max(0,y-pad);x1=min(img.shape[1],x+w+pad);y1=min(img.shape[0],y+h+pad)
  shape=np.where(labels[y0:y1,x0:x1]==label,0,255).astype(np.uint8)
  Image.fromarray(shape).convert('1').save(tmp/'shape.pbm')
  subprocess.run(['potrace','-s','--turdsize','4','--alphamax','0.7','--opttolerance','0.35','-o',str(tmp/'shape.svg'),str(tmp/'shape.pbm')],check=True)
  traced=(tmp/'shape.svg').read_text(encoding='utf-8');match=re.search(r'<g transform="([^"]+)"[^>]*>(.*?)</g>',traced,re.S)
  if not match:raise RuntimeError('Unexpected potrace output')
  data=rgb[y:y+h,x:x+w];core=(labels[y:y+h,x:x+w]==label)&(bright[y:y+h,x:x+w]>100); colors=[]
  for band in range(7):
   lo=int(h*band/7);hi=max(lo+1,int(h*(band+1)/7));pixels=data[lo:hi][core[lo:hi]]
   if len(pixels)<10:pixels=data[core]
   col=np.median(pixels,axis=0).astype(int);colors.append('#%02x%02x%02x'%tuple(col))
  stops=''.join(f'<stop offset="{i/6:.3f}" stop-color="{c}"/>' for i,c in enumerate(colors))
  # Potrace flips the y axis, so y=1 to 0 follows the original top to bottom.
  defs.append(f'<linearGradient id="g{number}" x1="0" y1="1" x2="0" y2="0">{stops}</linearGradient>')
  layer=f'<g transform="translate({x0},{y0})"><g transform="{match.group(1)}" fill="url(#g{number})" stroke="none">{match.group(2)}</g></g>'
  layers.append(layer)
  # Crop the K-and-blossom emblem for small launcher icons. The separate
  # streak above the wordmark and all text remain in the full logo only.
  if x<1250 and not (y<380 and x>=1180):emblem.append(layer)

def make_svg(box,parts):
 return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{box}" role="img" aria-label="Kuro.tv logo"><defs>'+''.join(defs)+'</defs>'+''.join(parts)+'</svg>'
full=make_svg('110 180 2740 950',layers);mark=make_svg('110 180 1150 950',emblem)
(ROOT/'art/kuro-tv-logo.svg').write_text(full,encoding='utf-8')
(ROOT/'art/kuro-tv-emblem.svg').write_text(mark,encoding='utf-8')
(ROOT/'assets/kuro-logo.svg').write_text(full,encoding='utf-8')

def raster(svg,path,width,height):cairosvg.svg2png(bytestring=svg.encode(),write_to=str(path),output_width=width,output_height=height)
raster(full,ROOT/'assets/kuro-logo.png',2192,760)
raster(full,ROOT/'res/drawable-nodpi/splash_logo.png',2740,950)
with tempfile.TemporaryDirectory(prefix='kuro-icon-') as tmp:
 tmp=Path(tmp)
 # Safe zone within a 108 x 108 adaptive-icon canvas; Android masks its outer edges.
 for size,artwidth,name in [(1080,630,'icon_foreground.png'),(1024,820,'icon.png')]:
  artheight=round(artwidth*950/1150);target=tmp/'mark.png';raster(mark,target,artwidth,artheight)
  layer=Image.open(target).convert('RGBA');canvas=Image.new('RGBA',(size,size),(0,0,0,0));canvas.alpha_composite(layer,((size-artwidth)//2,(size-artheight)//2));canvas.save(ROOT/'res/drawable-nodpi'/name,optimize=True)

parser=argparse.ArgumentParser();parser.add_argument('--master',type=Path);args=parser.parse_args()
if args.master:
 # 15,360 px wide keeps the logo's actual aspect ratio; do not stretch to 16:9.
 height=round(15360*950/2740)
 cairosvg.svg2png(bytestring=full.encode(),write_to=str(args.master),output_width=15360,output_height=height,background_color='#000000')
 print(f'Vector-rendered master: 15360 x {height}')
print('Generated vector and optimized Android logo assets.')

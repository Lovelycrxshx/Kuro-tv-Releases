'use strict';
// A small local navigation checkpoint, used only when a notification creates a
// new Activity. A live Activity always keeps its existing DOM and player.
// Never persist a third-party stream URL or pretend a killed WebView is alive.
(function(){
 try{if('scrollRestoration' in history)history.scrollRestoration='manual'}catch(_){}
 const key='kuro-page-checkpoint-v1';
 const tabs=['home','search','library','simulcasts','profile'];
 const pages=[...tabs,'detail','episode'];
 let boot=null,restoring=false,scrollTarget=null,scrollTimer=null;
 try{const raw=localStorage.getItem(key);if(raw&&raw.length<=48000)boot=JSON.parse(raw)}catch(_){}
 const safeNumber=(n,max)=>Math.max(0,Math.min(max,Number.isFinite(Number(n))?Number(n):0));
 const short=(s,n)=>String(s==null?'':s).slice(0,n);
 function safeItem(item){
  try{
   if(!item||!unifiedCodes.includes(item.source)||typeof item.title!=='string'||!item.title.trim()||item.title.length>500)return null;
   let u=new URL(item.url),b=new URL(base(item.source));
   if(!validUrl(item.url)||u.protocol!=='https:'||u.hostname!==b.hostname||u.port||u.username||u.password)return null;
   if(adultFlag(item))return null;
   // Explicit metadata-only allowlist: no embed, stream, cookie, header, or episode URLs.
   const copy={source:item.source,title:short(item.title,500),url:u.href,img:short(item.img,2000),meta:short(item.meta,300),description:short(item.description,3000),anilistId:Number(item.anilistId)||0,malId:Number(item.malId)||0,verifyTitle:!!item.verifyTitle};
   if(Array.isArray(item.titles))copy.titles=item.titles.filter(x=>typeof x==='string').slice(0,12).map(x=>short(x,240));
   if(Array.isArray(item.genres))copy.genres=item.genres.filter(x=>typeof x==='string').slice(0,25).map(x=>short(x,80));
   if(item.counts&&typeof item.counts==='object'){copy.counts={};for(const k of ['sub','dub','total'])if(item.counts[k]!=null)copy.counts[k]=short(item.counts[k],8)}
   if(/^[A-Za-z0-9_-]{1,80}$/.test(String(item.miruroId||'')))copy.miruroId=String(item.miruroId);
   if(/^[a-z0-9][a-z0-9-]{0,180}$/.test(String(item.zslug||'')))copy.zslug=String(item.zslug);
   if(/^\d{1,10}$/.test(String(item.awId||'')))copy.awId=String(item.awId);
   if(/^[A-Za-z0-9_-]{1,80}$/.test(String(item.paradiseId||'')))copy.paradiseId=String(item.paradiseId);
   if(Number.isInteger(Number(item.sourceYear))&&Number(item.sourceYear)>=1900&&Number(item.sourceYear)<=2100)copy.sourceYear=Number(item.sourceYear);
   for(const k of ['isAdult','adult','nsfw','adultSource'])if(typeof item[k]==='boolean')copy[k]=item[k];
   return copy;
  }catch(_){return null}
 }
 function capture(){
  if(restoring||!pages.includes(view))return;
  let item=(view==='detail'||view==='episode')?safeItem(selected):null;
  if((view==='detail'||view==='episode')&&!item)return;
  const saved={v:1,view,source:unifiedCodes.includes(source)?source:'ms',scroll:Math.round(safeNumber(window.scrollY,100000)),
   origin:{view:tabs.includes(showOrigin?.view)?showOrigin.view:'home',y:Math.round(safeNumber(showOrigin?.y,100000))},
   browse:{query:short(browseQuery,200),typed:short(document.querySelector('#q')?.value||'',200),tab:short(browseTab,20),genre:short(browseGenreId,80),sort:short(browseSort,20),genreFilter:short(genreFilter,100)},
   listFilter:short(listFilter,30)};
  if(item)saved.item=item;
  if(view==='episode'){
   if(!episode||!validEpisodeNumber(episode.number))return;
   saved.episode={number:String(Number(episode.number)),name:short(episode.name,160)};
  }
  try{const json=JSON.stringify(saved);if(json.length<=48000)localStorage.setItem(key,json)}catch(_){}
 }
 function afterCall(fn){return function(...args){let value=fn.apply(this,args);capture();if(value&&typeof value.then==='function')value.then(capture,()=>{});return value}}
 // Capture actual page transitions and filters, without changing what they do.
 nav=afterCall(nav);openEpisode=afterCall(openEpisode);
 openShow=afterCall(openShow);
 library=afterCall(library);setBrowseSort=afterCall(setBrowseSort);
 const originalSearch=unifiedSearchPage;unifiedSearchPage=afterCall(originalSearch);
 if(searchPage===originalSearch)searchPage=unifiedSearchPage;
 window.kuroSavePage=capture;
 let inputTimer;document.addEventListener('input',e=>{if(e.target?.id==='q'||e.target?.id==='genre-filter'){clearTimeout(inputTimer);inputTimer=setTimeout(capture,150)}},true);
 window.addEventListener('scroll',()=>{clearTimeout(scrollTimer);scrollTimer=setTimeout(capture,180)},{passive:true});
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')capture()});
 window.addEventListener('pagehide',capture);
 function applyScroll(){if(scrollTarget&&view===scrollTarget.view)window.scrollTo(0,scrollTarget.y)}
 function restoreScroll(page,y){
  if(page==='home'){scrollTarget=null;window.scrollTo(0,0);return}
  scrollTarget={view:page,y:Math.round(safeNumber(y,100000))};
  requestAnimationFrame(applyScroll);setTimeout(applyScroll,300);setTimeout(applyScroll,1200);
 }
 for(const event of ['pointerdown','touchstart','wheel','keydown'])document.addEventListener(event,()=>{if(!newsOverlayMode)scrollTarget=null},{capture:true,passive:true});
 const closeNews=closeNewsOverlay;closeNewsOverlay=function(){closeNews();requestAnimationFrame(applyScroll)};
 function setDock(page){document.querySelectorAll('nav button').forEach(b=>{const active=b.dataset.nav===page;b.classList.toggle('active',active);if(active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')})}
 function genericRecovery(message){
  main.innerHTML=`<div class="topline"><button class="back" id="recovery-back">‹ Back</button></div><div class="overline">RESTORING YOUR PAGE</div><h1>Return to your page</h1><p class="notice">${escapeHTML(message)}</p>`;
  $('#recovery-back').onclick=()=>returnToShowOrigin();
 }
 function recoveredEpisode(item,ep){
  if(!selected||selected.url!==item.url||view!=='episode')return;
  main.innerHTML=`<div class="topline"><button class="back" id="recovery-back">‹ Episodes</button><span class="sub">One library</span></div><div class="overline">RETURN TO WATCH</div><h1>${escapeHTML(item.title)}</h1><p class="sub">Episode ${escapeHTML(ep.number)}</p><div class="notice">iOS closed the player while Kuro was in the background. Reload this episode to continue; its previous playback position may not be available.</div><div class="space"></div><button class="btn primary" id="recovery-resume">▶ Reload episode</button>`;
  $('#recovery-back').onclick=()=>openShow(item);
  $('#recovery-resume').onclick=async()=>{
   const button=$('#recovery-resume');button.disabled=true;button.textContent='Loading episodes…';
   await openShow(item);
   if(view!=='detail'||!selected||selected.url!==item.url||selected.source!==item.source)return;
   const matches=episodes.filter(x=>String(x.number)===String(ep.number));
   if(matches.length===1)openEpisode(matches[0]);
   else placeholder('Episode '+ep.number+' could not be verified. Choose from the available episodes.');
  };
 }
 function restoreItem(r,item){
  pageTransition();view=r.view;selected=item;source=item.source;
  episode=r.view==='episode'?{number:String(Number(r.episode.number)),name:short(r.episode.name,160),url:item.url}:null;
  episodes=[];servers=[];setDock(showOrigin.view);const marker=++window.renderSeq;
  genericRecovery('Restoring your page…');
  const alive=()=>window.renderSeq===marker&&selected&&selected.url===item.url&&view===r.view;
  const show=()=>{
   if(!alive())return;
   if(r.view==='episode'){recoveredEpisode(item,episode);restoreScroll('episode',r.scroll)}
   else{const pending=openShow(item);restoreScroll('detail',r.scroll);if(pending&&typeof pending.then==='function')pending.then(()=>requestAnimationFrame(applyScroll),()=>{})}
  };
  if(['zenkai','wixi','kitsune','paradise'].includes(item.source)){
   classifyAdded([item]).then(allowed=>{if(!alive())return;if(allowed.length===1)show();else genericRecovery('This page cannot be restored while 18+ is off or its classification is unknown.')}).catch(()=>{if(alive())genericRecovery('Classification is temporarily unavailable. Go back and try again later.')});
  }else show();
 }
 function restore(r){
  if(!r||r.v!==1||!pages.includes(r.view))return false;
  let item=null;if(r.view==='detail'||r.view==='episode'){
   item=safeItem(r.item);if(!item)return false;
   if(r.view==='episode'&&(!r.episode||!validEpisodeNumber(r.episode.number)))return false;
  }
  const b=r.browse||{};source=unifiedCodes.includes(r.source)?r.source:'ms';
  browseQuery=short(b.query,200);browseTab=['all','genres','music'].includes(b.tab)?b.tab:'all';
  browseGenreId=discoveryGenres.some(g=>g.id===b.genre)?b.genre:'';
  browseSort=['source','az','za'].includes(b.sort)?b.sort:'source';genreFilter=short(b.genreFilter,100);
  listFilter=['all','bookmarks','watching','planned','completed','paused','on_hold','dropped','history','imported'].includes(r.listFilter)?r.listFilter:'all';
  showOrigin={view:tabs.includes(r.origin?.view)?r.origin.view:'home',y:safeNumber(r.origin?.y,100000)};
  restoring=true;
  try{
   if(item)restoreItem(r,item);
   else{nav(r.view);if(r.view==='search'&&document.querySelector('#q')&&typeof b.typed==='string')document.querySelector('#q').value=short(b.typed,200);restoreScroll(r.view,r.scroll)}
  }finally{restoring=false}
  capture();return true;
 }
 // Called by the Android Activity only for a fresh notification launch.
 window.kuroRestoreForNews=()=>{try{restore(boot)}catch(_){}boot=null;showNews()};
 window.kuroRestoreStartup560=()=>{try{if(window.kuroSettings560?.snapshot?.().startup==='last')restore(boot)}catch(_){}boot=null};
})();
